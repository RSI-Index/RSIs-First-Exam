# molmo2 video pointing — autoresearch task

A Harbor-format autoresearch task built on the pinned public
[`allenai/molmo2`](https://github.com/allenai/molmo2) repository
(`f3cb1085fbb97c4a4d7fdcadd77cf871bf37a88a`), plus the end-to-end harness
smoke run that validates it.

**Status: not finalized.** The task package is complete and its harness is
proven to run end to end, but the pristine baseline reproduction
(design SOP step 4) has not been done — every baseline number in
`task/instruction.md` and `task/task.toml` is still `TBD`.

## The task

Starting from the released **Molmo2-4B pretrain-stage checkpoint** (image
captioning + NLP + image pointing only — no video pointing yet), fine-tune a
model that beats the pristine released video-pointing lane on the frozen
video pointing evaluation.

| | |
|---|---|
| Baseline lane | `launch_scripts/sft.py` defaults + the released `video_pointing` sub-mixture |
| Metric | mean of count accuracy (`correct` on `vixmo_points_count_clip_63s:val`) and pointing F1 (`f1` on `vixmo_points_point_eval:val`) |
| Reward | `video_point_score = (count_correct + point_f1) / 2`, higher is better |
| Budget | ≤ 8,000 optimizer updates, global batch ≤ 128, `seq_len` ≤ 16,384, 1 node × 8 H100 |
| Free variables | data mixture, temporal/visual preprocessing, supervision format, loss shaping, recipe, and the pointing-head architecture (including the in-repo MolmoPoint grounding-token mechanism) |
| Frozen | starting checkpoint, staged corpora, budget, topology, tokenizer, a 1.005× parameter budget, the eval-path code, and the evaluator |

The guiding scientific question is which mechanisms actually carry video
pointing quality: frame-sampling density and caps, time encoding, token
pooling, the point/count supervision mix and its count-stratified splits, the
pointing output format, or loss weighting.

## Layout

```
task/            the Harbor task package
  instruction.md   agent-facing task statement
  task.toml        task metadata, budgets, environment/verifier images
  policy.yaml      reward-integrity rules (RH-001..007) and allowed scope
  environment/     agent container + 1x8 LSF/Apptainer launch wrapper
  tests/           verifier: policy gate -> frozen eval -> reward
smoke/           2-GPU end-to-end harness validation (see smoke/README.md)
  run_train_smoke.sh, run_verify_smoke.sh, stage_submission.py, stage_data.py
  results/         reward, metrics, provenance, ledger, policy-gate report
  logs/            training and verifier logs
```

## Smoke-run result

The full chain — train → stage → policy gate → frozen eval → reward — ran on
2×H100 against the real repo with no mocks, returning **reward 0.020833** with
`policy_gate: 1`. That validates the harness only; it is not a baseline. The
scale-downs (20 updates instead of 8,000, 24 eval examples instead of the full
val splits, etc.) are tabulated in `smoke/README.md`.

## Known caveats before the step-4 reproduction

1. **Video staging is not anonymously downloadable.** Stage from the shared
   mirror (`MOLMO_DATA_DIR=/weka/oe-training-default/mm-olmo` on the AI2
   cluster). The GCS bucket referenced by the HuggingFace
   `youtube_id_to_urls_mapping.json` (`gs://molmo2-youtube-cc-videos`) is
   **requester-pays** and returns HTTP 400 anonymously; a fresh copy needs a
   billed GCS project. Annotation parquets are public; only the videos are billed.
2. **`cp_degree > 1` is untested.** The smoke run exercised only the
   `attention_type: sdpa` path, because `ring_flash_attn`/`flash_attn` are not
   buildable without a CUDA toolkit. Since the action space allows context
   parallelism, validate `cp_degree=2` inside the real container.

Both are also recorded in `task/task.toml` under `[metadata.run_contract]`.

## Notes on the pinned upstream snapshot

Verified defects in `allenai/molmo2@f3cb1085` that constrain task design:

- `pointing_eval_v2` is hardcoded to a developer path,
  `/data/chrisc/pixmo-points-eval-dbg` (`olmo/data/pixmo_datasets.py:495`).
- The `video_pointing` download group is a missing comma, concatenating two
  dataset names into one invalid string (`scripts/download_datasets.py:54-57`).
- `launch_scripts/pretrain.py` raises `NotImplementedError` for its own default
  `--model=molmo2`: the `else` at line 198 binds to the `molmo_point` `if` at
  line 142, not to the `molmo`/`molmo2` chain at lines 81/109.
- `launch_scripts/sft.py` cannot fine-tune MolmoPoint — `get_model` reads
  `model_cfg.vision_backbone` (line 251), but `MolmoPointConfig` has
  `vit`/`connector`.
- `PointingEval` and `PointCountEval` parse points out of generated text, so
  they score the MolmoPoint grounding-token architecture near zero. Only
  `PointBenchEval` and the ScreenSpot evaluators are architecture-neutral.
