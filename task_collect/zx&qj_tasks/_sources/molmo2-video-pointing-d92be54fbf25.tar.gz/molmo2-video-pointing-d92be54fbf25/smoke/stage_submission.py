"""Small-scale stand-in for `mvp_task_tool.py stage` + provenance/ledger writing.

Stages the selected training checkpoint as output/submission and writes the
provenance.json / experiments.jsonl / submission-selection.json the policy gate
requires.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

WORK = Path("/weka/oe-training-default/zixianm/autoresearch/molmo2_e2e")
OUT = WORK / "output"
ATTEMPT = sys.argv[1] if len(sys.argv) > 1 else "vpt-smoke-001"
CKPT = Path(sys.argv[2])

SUBMISSION = OUT / "submission"
if SUBMISSION.exists():
    shutil.rmtree(SUBMISSION)
SUBMISSION.mkdir(parents=True)

# The checkpoint dir has model_and_optim/; config.yaml lives there or one level up.
for name in ["config.yaml"]:
    src = CKPT / name
    if not src.exists():
        src = CKPT.parent / name
    shutil.copy2(src, SUBMISSION / name)
shutil.copytree(CKPT / "model_and_optim", SUBMISSION / "model_and_optim")
print("staged:", sorted(p.name for p in SUBMISSION.iterdir()))

diff = subprocess.run(
    ["git", "diff", "--binary"], cwd=WORK / "project", capture_output=True, text=True
).stdout
diff_sha = hashlib.sha256(diff.encode()).hexdigest()
commit = subprocess.run(
    ["git", "rev-parse", "HEAD"], cwd=WORK / "project", capture_output=True, text=True
).stdout.strip()

train_cmd = (
    "torchrun --standalone --nnodes=1 --nproc-per-node=2 launch_scripts/sft.py "
    f"{WORK}/checkpoints/Molmo2-4B-Pretrain vpointing_smoke --seq_len=8192 "
    "--device_batch_size=1 --max_duration=20 --global_train_batch_size=2 "
    "--model.mm_preprocessor.video.max_frames=8 --model.llm.max_sequence_length=8192"
)
eval_cmd = (
    "torchrun --standalone --nnodes=1 --nproc-per-node=2 launch_scripts/eval.py "
    "<submission> --task={vixmo_points_count_clip_63s,vixmo_points_point_eval} --split=val "
    "--device_batch_size=1 --precision=amp_bf16 --model.llm.max_sequence_length=64000"
)

provenance = {
    "base_model": "allenai Molmo2-4B-Pretrain (released pretrain-stage checkpoint, step32000)",
    "model_config": "Molmo2Config from submission/config.yaml (qwen3_4b_instruct LLM + siglip2 ViT, video max_frames=8)",
    "training_data": [
        "vixmo_points_minmax_0_60 (Molmo2VideoPoint, allenai/Molmo2-VideoPoint train split, staged locally)"
    ],
    "optimizer_updates": 20,
    "packed_tokens": 20 * 2 * 8192,
    "training_command": train_cmd,
    "upstream_commits": {"allenai/molmo2": commit},
    "downloads": [
        "https://storage.googleapis.com/oe-training-public/Molmo2-1225/Molmo2-4B-Pretrain.tar",
        "hf:allenai/Molmo2-VideoPoint (annotations, staged)",
        "hf:allenai/Molmo2-VideoPointEval (annotations, staged)",
        "hf:allenai/Molmo2-VideoCountEval (annotations, staged)",
    ],
    "evaluation_commands": [eval_cmd],
    "optimization_attempts": [ATTEMPT],
    "topology_mapping": "SCALED-DOWN SMOKE: 1 node x 2 H100 (task contract is 1 node x 8 H100)",
    "web_search": "disabled",
    "source_diff_sha256": diff_sha,
    "smoke_run": True,
}
(OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")

ledger = {
    "attempt_id": ATTEMPT,
    "hypothesis": "End-to-end harness smoke: the released sft.py lane fine-tunes the pretrain checkpoint on video-pointing data and the frozen evaluator scores the result.",
    "change": "Added a video-pointing-only `vpointing_smoke` mixture to launch_scripts/sft.py (vixmo_points_minmax_0_60).",
    "command": train_cmd,
    "source_diff_sha256": diff_sha,
    "run_kind": "screening",
    "gpu_count": 2,
    "optimizer_updates": 20,
    "packed_tokens": 20 * 2 * 8192,
    "status": "selected",
    "metrics": "see output/verifier-metrics.json",
}
with open(OUT / "experiments.jsonl", "w") as f:
    f.write(json.dumps(ledger) + "\n")

(OUT / "submission-selection.json").write_text(
    json.dumps({"attempt_id": ATTEMPT, "checkpoint": str(CKPT), "run_kind": "screening"}, indent=2) + "\n"
)
print("wrote provenance.json, experiments.jsonl, submission-selection.json")
