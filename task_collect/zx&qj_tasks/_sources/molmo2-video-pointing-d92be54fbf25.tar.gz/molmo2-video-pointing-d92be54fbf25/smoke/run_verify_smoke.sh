#!/usr/bin/env bash
# Small-scale stand-in for the task verifier (tests/test.sh):
# runs the shipped policy gate + evaluate.py + score.py against local paths,
# with 2 GPUs instead of 8 and the LLM policy judge disabled (static gate only).
set -uo pipefail

WORK=/weka/oe-training-default/zixianm/autoresearch/molmo2_e2e
TESTS="/weka/oe-training-default/zixianm/autoresearch/bundle(1)/samples/molmo2_video_pointing/tests"
ENV=/weka/oe-training-default/zixianm/.conda/envs/molmo2

export PATH=$ENV/bin:$PATH
export LD_LIBRARY_PATH=$ENV/lib:${LD_LIBRARY_PATH:-}
export MOLMO_DATA_DIR=/weka/oe-training-default/mm-olmo
export HF_HOME=$WORK/hf_home
export HF_DATASETS_OFFLINE=1
export OLMO_SHARED_FS=1
export OMP_NUM_THREADS=8
export WANDB_MODE=offline
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

export MVP_OUTPUT_ROOT=$WORK/output
export MVP_CLEAN_PROJECT=$WORK/clean_project
export MVP_CANDIDATE_PROJECT=$WORK/project
export MVP_VERIFIER_NPROC=2
export MOLMO2_START_CHECKPOINT=$WORK/checkpoints/Molmo2-4B-Pretrain
export POLICY_JUDGE_SKIP_LLM=1
# Cap generated examples: the 20-update smoke model never emits EOS, so every
# example runs to the 2048-token cap.
export MVP_SINGLE_GPU_VERIFIER_SMOKE=1
export MVP_SMOKE_MAX_EXAMPLES=${MVP_SMOKE_MAX_EXAMPLES:-24}

LOGS=$WORK/logs/verifier
mkdir -p "$LOGS"

zero() {
  python3 - "$1" "$LOGS" <<'PY'
import json, sys
reason, logs = sys.argv[1], sys.argv[2]
open(f"{logs}/reward.json", "w").write(json.dumps({"reward": 0.0, "policy_gate": 0.0}, indent=2) + "\n")
open(f"{logs}/failure.json", "w").write(json.dumps({"reason": reason}, indent=2) + "\n")
open(f"{logs}/reward.txt", "w").write("0.0\n")
PY
}

echo "== reward-integrity gate =="
if ! python3 "$TESTS/policy_check.py" \
    --policy "$TESTS/policy.yaml" --clean "$MVP_CLEAN_PROJECT" \
    --candidate "$MVP_CANDIDATE_PROJECT" --output-dir "$MVP_OUTPUT_ROOT" \
    --report "$LOGS/policy_check.json"; then
  zero reward_integrity_gate
  exit 0
fi

echo "== frozen evaluation =="
if ! python3 "$TESTS/evaluate.py"; then
  zero official_release_evaluation_failed
  exit 0
fi

cp "$MVP_OUTPUT_ROOT/verifier-metrics.json" "$LOGS/metrics.json"
echo "== score =="
python3 - "$LOGS" <<'PY'
import json, math, sys
from pathlib import Path
logs = Path(sys.argv[1])
metrics = json.loads((logs / "metrics.json").read_text())
score = float(metrics["video_point_score"])
reward = 0.0 if not math.isfinite(score) else min(max(score, 0.0), 1.0)
result = {"reward": round(reward, 6), "policy_gate": 1, "metric": "video_point_score", **metrics}
(logs / "reward.json").write_text(json.dumps(result, indent=2) + "\n")
(logs / "reward.txt").write_text(f"{reward:.6f}\n")
print(json.dumps(result, indent=2))
PY
