#!/usr/bin/env bash
# Small-scale stand-in for the task's training lane:
# 1x2 H100 instead of 1x8, 20 updates instead of 8000, seq_len 4096, 8 frames.
set -euo pipefail

WORK=/weka/oe-training-default/zixianm/autoresearch/molmo2_e2e
ENV=/weka/oe-training-default/zixianm/.conda/envs/molmo2

export PATH=$ENV/bin:$PATH
export LD_LIBRARY_PATH=$ENV/lib:${LD_LIBRARY_PATH:-}
export PYTHONPATH=$WORK/project
export MOLMO_DATA_DIR=/weka/oe-training-default/mm-olmo
export HF_HOME=$WORK/hf_home
export HF_DATASETS_OFFLINE=1
export OLMO_SHARED_FS=1
export OMP_NUM_THREADS=8
export WANDB_MODE=offline
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export NCCL_TIMEOUT_MINUTES=20

ATTEMPT=${1:-vpt-smoke-001}
SAVE=$WORK/output/attempts/$ATTEMPT/save
mkdir -p "$SAVE" "$WORK/output/logs"

cd "$WORK/project"
exec torchrun --standalone --nnodes=1 --nproc-per-node=2 \
  launch_scripts/sft.py \
  "$WORK/checkpoints/Molmo2-4B-Pretrain" \
  vpointing_smoke \
  --seq_len=8192 \
  --device_batch_size=1 \
  --num_workers=2 \
  --prefetch_factor=2 \
  --save_folder="$SAVE" \
  --save_overwrite=true \
  --max_duration=20 \
  --stop_at=20 \
  --global_train_batch_size=2 \
  --save_interval=20 \
  --console_log_interval=1 \
  --compile=null \
  --wandb=null \
  --model.mm_preprocessor.video.max_frames=8 \
  --model.llm.max_sequence_length=8192
