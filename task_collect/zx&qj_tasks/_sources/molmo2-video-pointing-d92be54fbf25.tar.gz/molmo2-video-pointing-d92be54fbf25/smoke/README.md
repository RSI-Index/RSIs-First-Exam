# molmo2 video pointing — 2-GPU end-to-end harness smoke

Purpose: prove the `samples/molmo2_video_pointing` task package actually runs —
train → stage → policy gate → frozen eval → reward — on this machine, at a
scale that fits 2 GPUs. This is **not** the task baseline; it is a harness test.

## Deviations from the task contract (all deliberate, all downward)

| Contract | Task | This smoke run |
|---|---|---|
| Topology | 1 node x 8 H100 | 1 node x 2 H100 |
| Optimizer updates | 8,000 | 20 |
| Global batch | 128 | 2 |
| `seq_len` | 16,384 | 8,192 |
| `video.max_frames` | up to 128 | 8 |
| Training mixture | released `video_pointing` (4 datasets) | `vpointing_smoke` = `vixmo_points_minmax_0_60` only |
| Eval examples | full val splits (533 count / 181 point) | capped at 24 per task |
| Policy judge | LLM judge + static gate | static gate only (`POLICY_JUDGE_SKIP_LLM=1`) |
| Container | Apptainer/`.sif` from `ghcr.io/allenai/molmo2` | conda env `molmo2` on the host |

## Layout

- `project/` — candidate workspace, pinned `allenai/molmo2@f3cb1085`, plus the
  agent-style edit that adds the `vpointing_smoke` mixture to `launch_scripts/sft.py`
- `clean_project/` — pristine checkout at the same commit (policy-gate reference)
- `checkpoints/Molmo2-4B-Pretrain/` — released pretrain-stage starting checkpoint
- `output/` — attempts, staged `submission/`, provenance, ledger, verifier metrics
- `logs/verifier/` — `reward.json`, `metrics.json`, `policy_check.json`
- `run_train_smoke.sh` / `run_verify_smoke.sh` / `stage_submission.py` — the three steps

## Data

Training and eval data come from the existing shared mirror at
`MOLMO_DATA_DIR=/weka/oe-training-default/mm-olmo`, which already holds the
2fps videos plus the `Molmo2-VideoPoint{,Eval}` and `Molmo2-VideoCountEval`
annotation copies. The public GCS bucket referenced by the HF
`youtube_id_to_urls_mapping.json` (`molmo2-youtube-cc-videos`) is
**requester-pays**, so anonymous download fails with HTTP 400 — staging for the
real task must use the shared mirror or a billed GCS project.

## Result (chain completed, exit 0)

Reward `0.020833` from `logs/verifier/reward.json`, `policy_gate: 1`.

| Metric | Value |
|---|---:|
| `count_correct` (24 ex) | 0.0417 |
| `count_close` | 0.0417 |
| `point_precision` / `recall` / `f1` (24 ex) | 0.0 / 0.0 / 0.0 |
| `video_point_score` | 0.0208 |
| parameters / budget | 4,461,913,040 / 4,484,222,605 |

The zero pointing F1 is model quality, not a pipeline fault. The 20-update
model emits correctly shaped markup — `<points coords="...">seals</points>` —
but the wrong numeric encoding. `UnifiedPointFormatter` requires
`(object_id) (x) (y)` triplets with x/y as 3-4 digit integers on a 0-1000
scale, grouped per timestamp; the model emitted one-decimal floats
(`"0.0 0.0 15.9 31.7 ..."`), so the extractor matched nothing. Many
generations are also degenerate ramps (0,1,2,3,...) that run to the
2048-token cap because the model never emits EOS.

## Open caveats for the step-4 reproduction

1. **Video staging is not anonymously downloadable.** Stage from
   `/weka/oe-training-default/mm-olmo` (`MOLMO_DATA_DIR`). The GCS bucket in
   the HF `youtube_id_to_urls_mapping.json` (`gs://molmo2-youtube-cc-videos`)
   is requester-pays and 400s anonymously; a fresh copy needs a billed GCS
   project (`gsutil -u <project>`). Annotation parquets are public; only the
   videos are billed.
2. **`cp_degree > 1` is untested.** Only the `attention_type: sdpa` path ran
   here; `ring_flash_attn`/`flash_attn` are unbuildable on this host (no CUDA
   toolkit, no `nvcc`). Since the task action space allows context
   parallelism, validate `cp_degree=2` in the real container (ships
   ring-flash-attn 0.1.8) as part of the reproduction.

Both are also recorded in `task.toml` under `[metadata.run_contract]`
(`data_staging_caveat`, `context_parallel_caveat`).
