"""Stage a small-scale subset of Molmo2 video pointing data for a 2-GPU smoke run.

- Filters the local eval dataset copies (which _load_hf_dataset prefers) to rows
  whose videos we stage, so the frozen eval code runs unmodified.
- Downloads videos from the public GCS bucket and converts them to the 2fps
  layout the repo expects.
- Builds the Molmo2-VideoPoint_preprocessed.pkl the training dataset requires,
  restricted to staged videos.
"""
import collections
import json
import os
import pickle
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import datasets
from huggingface_hub import hf_hub_download

WORK = Path("/weka/oe-training-default/zixianm/autoresearch/molmo2_e2e")
VD = WORK / "molmo_data" / "video_datasets"
VIDEO_OUT = VD / "youtube-cc" / "youtube-cc-exist-2fps"
RAW_DIR = WORK / "raw_videos"
N_POINT_EVAL = 40
N_COUNT_EVAL = 60
N_TRAIN_VIDEOS = 30
MAX_TRAIN_ROWS_PER_VIDEO = 6

VIDEO_OUT.mkdir(parents=True, exist_ok=True)
RAW_DIR.mkdir(parents=True, exist_ok=True)

mapping_path = hf_hub_download(
    "allenai/Molmo2-VideoPointEval", "youtube_id_to_urls_mapping.json", repo_type="dataset"
)
URLS = json.load(open(mapping_path))

needed_videos = {}  # video_id -> gcs url


def keep_shortest(ds, n, id_key="video_id"):
    order = sorted(
        range(len(ds)),
        key=lambda i: ds[i]["video_duration"] if ds[i]["video_duration"] else 1e9,
    )
    kept, seen_rows = [], 0
    for i in order:
        row = ds[i]
        vid = row[id_key]
        if row.get("video_source", "youtube") != "youtube":
            continue
        if vid not in URLS:
            continue
        kept.append(i)
        needed_videos[vid] = URLS[vid]["gcp_url"]
        seen_rows += 1
        if seen_rows >= n:
            break
    return ds.select(kept)


# ---- eval sets: filter local copies to staged subsets ----
for local_name, n in [("Molmo2-VideoPointEval", N_POINT_EVAL), ("Molmo2-VideoCountEval", N_COUNT_EVAL)]:
    full_dir = VD / f"{local_name}_full"
    cur_dir = VD / local_name
    if not full_dir.exists():
        os.rename(cur_dir, full_dir)
    ds = datasets.load_from_disk(str(full_dir))
    sub = keep_shortest(ds, n)
    sub.save_to_disk(str(cur_dir))
    print(local_name, "->", len(sub), "rows kept")

# ---- train: pick short videos from the 'object' config ----
train_ds = datasets.load_dataset("allenai/Molmo2-VideoPoint", "object", split="train")
by_vid = collections.defaultdict(list)
for i, row in enumerate(train_ds):
    if row["video_id"] in URLS:
        by_vid[row["video_id"]].append(i)
vid_order = sorted(
    by_vid,
    key=lambda v: train_ds[by_vid[v][0]]["video_duration"] or 1e9,
)
train_rows = []
for vid in vid_order[:N_TRAIN_VIDEOS]:
    needed_videos[vid] = URLS[vid]["gcp_url"]
    for i in by_vid[vid][:MAX_TRAIN_ROWS_PER_VIDEO]:
        train_rows.append(dict(train_ds[i]))
print("train rows:", len(train_rows), "train videos:", len(vid_order[:N_TRAIN_VIDEOS]))

# ---- download + convert to 2fps ----
def fetch(item):
    vid, url = item
    out = VIDEO_OUT / f"{vid}_2fps.mp4"
    if out.exists():
        return vid, "cached"
    raw = RAW_DIR / f"{vid}.mp4"
    try:
        if not raw.exists():
            subprocess.run(
                ["wget", "-q", "-O", str(raw), url], check=True, timeout=600
            )
        subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw),
             "-vf", "fps=2", "-an", str(out)],
            check=True, timeout=1200,
        )
        return vid, "ok"
    except Exception as e:  # noqa: BLE001
        if out.exists():
            out.unlink()
        return vid, f"FAIL {e}"


print("downloading", len(needed_videos), "videos")
results = collections.Counter()
with ThreadPoolExecutor(max_workers=16) as pool:
    for vid, status in pool.map(fetch, sorted(needed_videos.items())):
        results[status.split()[0]] += 1
        if not status.startswith(("ok", "cached")):
            print("  ", vid, status[:200])
print("download results:", dict(results))

# ---- build train preprocessed pickle (rows whose video staged) ----
rows_with_clips = []
for row in train_rows:
    vp = VIDEO_OUT / f"{row['video_id']}_2fps.mp4"
    if vp.exists():
        rows_with_clips.append((row, str(vp), row["clip_start"], row["clip_end"]))
pkl = VD / "Molmo2-VideoPoint_preprocessed.pkl"
with open(pkl, "wb") as f:
    pickle.dump(rows_with_clips, f)
print("pickle rows:", len(rows_with_clips), "->", pkl)

# ---- drop eval rows whose video failed to download ----
for local_name in ["Molmo2-VideoPointEval", "Molmo2-VideoCountEval"]:
    cur_dir = VD / local_name
    ds = datasets.load_from_disk(str(cur_dir))
    keep = [i for i in range(len(ds)) if (VIDEO_OUT / f"{ds[i]['video_id']}_2fps.mp4").exists()]
    if len(keep) != len(ds):
        tmp = VD / f"{local_name}_tmp"
        ds.select(keep).save_to_disk(str(tmp))
        subprocess.run(["rm", "-rf", str(cur_dir)], check=True)
        os.rename(tmp, cur_dir)
    print(local_name, "final rows:", len(keep))
print("STAGING DONE")
