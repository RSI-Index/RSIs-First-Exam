# Author-only steady-window calibration

This protocol is a development instrument for measuring Qwen3.6 agent-step
throughput under sustained backlog. It is not a Harbor public profile, hidden
profile, scoring input, release qualification profile, or claim of paper
reproduction.

## Current implementation status

The repository currently contains a fail-closed protocol scaffold:

- `author_profiles/qwen36-steady-window.json` freezes 96, 144, 168, and 192
  fixed-slot plans with 135 steps per rollout, a 600-second ramp, a
  3,600-second measurement window, and a 1,500-second drain bound.
- `scripts/run-steady-window-calibration.py plan` validates the complete author
  profile and prints its immutable digests and measurement contract without
  contacting a controller.
- `check` performs one read-only capability request.
- `run` sends a run request only after the controller returns every required
  capability and the exact measurement-semantics digest.

The current bench controller does **not** expose the frozen steady-window
capability or run endpoints. Consequently, `check` and `run` refuse before any
measurement mutation. This is intentional. Existing `/admin/run` executes a
finite workflow pool and cannot safely express rolling replacement, a fixed
window numerator, step-boundary shutdown, or persistent-slot fairness.

Do not relabel a bounded `/admin/run` report as steady-window evidence. Do not
add these profiles to `environment/bench-controller/profiles/public.json`,
`hidden.json`, `calibration.json`, the release qualification allowlist, or the
hidden scoring policy.

## Frozen semantics

Each profile has `N` persistent slots. Every rollout can take at most 135 model
steps. A slot receives a replacement only after its current rollout terminates
naturally and only before the fixed window ends. Each replacement needs a new
run ID, cache namespace, and clean sandbox.

The ramp is excluded from the primary throughput numerator. The primary
numerator contains only agent steps whose Bash tool execution completed with a
return code during the closed-open measurement interval. Its denominator is
exactly the configured 3,600 seconds, independent of ramp or drain duration.

At the window boundary, an already-started model stream and its Bash action
must finish normally. The controller closes admission before the next model
query; it must not cancel clients merely because the window ended. It starts no
replacement after the boundary. The bounded drain is outside the numerator.
Exceeding the drain bound invalidates the leg.

The one-to-one backend audit covers every measured-leg request from ramp start
through drain completion. Fairness is Jain fairness over per-slot
tool-completed steps in the fixed window, not raw progress of a rollout that
was created just before the boundary.

## Safe commands today

Validate and print the default 192-slot plan:

```bash
python3 scripts/run-steady-window-calibration.py plan
```

Print another concurrency shape:

```bash
python3 scripts/run-steady-window-calibration.py plan \
  --profile qwen36-paper-window-144-deep135
```

After a future author controller implements the protocol, perform only the
read-only handshake:

```bash
python3 scripts/run-steady-window-calibration.py check \
  --controller-base http://127.0.0.1:7000 \
  --admin-token-file /run/kvbench-admin/token
```

On the current controller this must fail with `CapabilityUnavailable` and the
message `no run request was sent`.

## Future controller work required before execution

The controller must add author-only endpoints at the exact paths frozen in the
profile file. It needs a separate persistent-slot rolling pool, a cooperative
deadline check before each new model query, deterministic rollout ordinals,
per-slot step-event accounting, steady-window metric slicing, and an audit that
remains open through drain. Public and hidden profile loaders must continue to
reject this protocol.

The author endpoint must return the result schema validated by the CLI,
including zero post-window query starts, zero window-boundary cancellations,
exact fixed-denominator rate arithmetic, exact slot Jain arithmetic, rollout
replacement accounting, full one-to-one audit, and candidate lifecycle release
counts.

After that support exists, use one explicit workload nonce for a Direct leg and
the same nonce for its Oracle leg. A separate author pair evaluator is still
needed: the existing bounded pair evaluator assumes equal request counts and a
release count equal to finite workflows, both of which are wrong for a fixed
window where a faster candidate should complete more steps and may start more
rollouts.

Steady-window evidence must be paired with the existing bounded semantic
quality evidence before any public/hidden shape or reference speedup is frozen.
