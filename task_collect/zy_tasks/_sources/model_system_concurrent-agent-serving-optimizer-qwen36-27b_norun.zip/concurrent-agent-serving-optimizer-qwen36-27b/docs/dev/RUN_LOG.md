# Qwen3.6 author run log

Machine-readable JSON remains authoritative. This file keeps the active Qwen
design decisions and successful/failed milestones needed to understand the
current task; retired-model history is intentionally outside this release
surface.

## 2026-07-16 — compact SWE-bench corpus

- Reduced the local SWE-bench Lite image set to 12 pinned issues: six public
  and six disjoint held-out issues, retaining one immutable local image per
  selected issue.
- Every rollout still gets a fresh sandbox and trajectory. Repeated issues are
  independent programs; they do not share writable repository state.
- The compact corpus is a systems-load fixture, not a broad SWE solve-rate
  claim. Its purpose is to create reproducible multi-agent KV pressure without
  downloading hundreds of task images.

## 2026-07-18 — external Qwen runtime and adapter

- Pinned `Qwen/Qwen3.6-27B` revision
  `6a9e13bd6fc8f0983b9b99948120bc37f49c13e9`, vLLM 0.24.0, BF16 weights,
  FP8 KV, TP2, and physical H100 NVL indices 6 and 7.
- Moved model ownership outside Harbor Compose into a networkless standalone
  container. Trusted model-api reaches one Unix socket; candidate code sees
  only the OpenAI-compatible loopback URL.
- Re-pinned the active runtime as
  `qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2`, with profile SHA-256
  `3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46`
  and 30 GiB KV allocation per GPU.
- Resolved Qwen's hybrid cache geometry from live telemetry: 1,253 raw GPU
  pages, one reserved null page, 1,252 decision pages, 1,568 attention tokens
  per page, plus three resident and up to three transient Mamba pages per live
  request. The reported 1,887,738 logical tokens are informational, not a
  token-linear admission budget.
- Froze adapter `qwen36-text-bash-v1`: chat-template thinking disabled,
  temperature 0, top-p 1, no function tools, and one Bash-fence action.

## 2026-07-18 — selected 192×24 pressure family

- The natural 24-workflow/48-step trajectory completed 1,032 requests and
  proved prompt/KV growth, but KV maximum was only about 14.4%.
- The completed Direct pressure leg used 192 fresh rollouts, concurrency 192,
  maximum 24 actions, and a 2,048-token completion cap. It produced 4,542
  valid actions at 84.953 steps/minute with request success 1.0, fairness 1.0,
  and minimum progress 24.
- Direct KV p95/max reached 0.9888/1.0; waiting p95/max reached 104/171 and
  vLLM recorded 44 preemptions. This qualified the bounded pressure family.
- The early state-aware Oracle was intentionally rejected: 0.998701× speedup,
  excessive tail wait, increased backend work, and emergency force-resume.
  That failure motivated page-accurate admission, bounded request age, and
  service-fair restore ordering rather than a workload change.

## 2026-07-19 — public fixed-window policy v4

- A first 600-second candidate reached 1.3252× throughput but failed fairness
  (0.8361) because advanced workflows repeatedly re-entered ahead of lower-step
  requests.
- Policy v4 added one-request-ordinal bounded service lag. The controlled rerun
  measured Direct at 150.1 and Oracle at 173.8 valid steps/minute, a 1.157895×
  improvement.
- Fairness improved 0.9641→0.9840, zero-progress workflows fell 3→1, Direct KV
  p95/max 0.9872/0.9984 fell to 0.7388/0.7692, and vLLM preemptions fell 4→0.
  Every fixed-window audit, cutoff, pressure, quality, and lifecycle gate
  passed.
- Exploratory finite hidden v4 A/B/B/A measured Direct geometric mean 81.164
  and Oracle 84.082 steps/minute (1.035962×), with Direct CV 0.76%. It exposed
  two verifier defects: normal 24-step-limit exits were treated as missing
  completions, and post-agent verify/cleanup time diluted the throughput
  denominator. The result remained non-release exploratory evidence.

## 2026-07-19 — timing, isolation, continuation, and formal evidence

- Finite throughput now starts at one global monotonic timestamp immediately
  before dispatch and ends at the last `agent.run` termination. Repository
  verification and cleanup remain hard gates outside that denominator.
- The author-only exploratory hidden A/B/B/A tool uses fresh B processes and
  was used to select the conservative reference. It is not the formal release
  protocol. Formal hidden is one Direct plus one Candidate, in a
  nonce-committed AB or BA order, with exactly one Candidate process epoch.
- Public candidate attempts form append-only pair lineage with immutable raw
  leg payloads. The multi-session wrapper freezes code by tree hash/tar,
  validates canonical pair parent/anchor binding, and passes only sanitized
  public handoff plus current code to a fresh Codex home.
- Formal release evidence requires one fixed-600 public Direct/Oracle
  qualification (which creates the reusable Direct anchor) and one two-leg
  hidden AB-or-BA whose sole Candidate epoch activates all six deep-tier
  witnesses. Private health observations never enter the public verifier
  report.

## 2026-07-20 — release evidence and first Luna infrastructure findings

- Final public qualification measured Direct 146.9 versus Oracle 165.4
  actions/minute (1.125936x); a Candidate-only release-topology Oracle rerun
  measured 169.4 (1.153165x) against the immutable anchor.
- Formal hidden ran exactly two legs and measured Direct 80.8705 versus Oracle
  100.6611 (1.244720x); reward was 0.988640 and all hard gates passed.
- The first Luna trial produced one valid Candidate pair at 1.01838x, then
  exposed a wrapper-root 0711->0700 permission regression and an OverlayFS
  lower-directory restore failure. Both are runner infrastructure defects, not
  scheduler scores; the verifier correctly stayed fail-closed.

## 2026-07-19 — policy v5 public development qualification

- Policy v5 preserves exact v4 behavior through request step 12. From step 13,
  deep requests may bypass only service-lag ordering and use total-token SJF;
  capacity safety and aged-request reservation still take precedence.
- Development fixed-600 A/B result:
  `calibration/qwen36-public-fixed600-v5-protected-dev-r4-20260719.json`,
  SHA-256 `a00d1bd60696aae6d7ad752f485df115fb81aa8e9c90a54ce2be28bbc52a5f69`.
- Direct measured 153.0 steps/minute; Oracle measured 176.0, a 1.150327×
  improvement. Fairness improved 0.9666→0.9829, zero-progress 2→1, KV p95
  0.9745→0.7348, and vLLM preemptions 3→0. Both legs kept request success 1.0.
- Oracle made 532 admission pauses and 230 least-service restores. Every deep
  witness and mixed-tier tick was zero, proving that the public result measures
  only the protected policy. All pair contracts and quality gates passed.
- This is development evidence, not the final release pair. A v5 exploratory
  hidden A/B/B/A is running to select the frozen reference; final public and
  hidden evidence must then be regenerated on one non-development controller
  image before Luna is allowed.
