# External Qwen3.6-27B runtime

The model server is author-owned infrastructure outside Harbor Compose. Harbor
owns only the trusted `model-api`, controller, candidate gateway, and sandbox
worker. This separation lets the task reuse one warm model while keeping the
raw socket, model files, Docker daemon, and GPUs outside the candidate trust
boundary.

## Frozen development identity

- model: `Qwen/Qwen3.6-27B`
- revision: `6a9e13bd6fc8f0983b9b99948120bc37f49c13e9`
- snapshot:
  `/home/yuetaili/.cache/huggingface/hub/models--Qwen--Qwen3.6-27B/snapshots/6a9e13bd6fc8f0983b9b99948120bc37f49c13e9`
- profile: `environment/vllm-runtime/model-profile-qwen3.6-27b.json`
- profile SHA-256:
  `3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46`
- profile ID: `qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2`
- image: `harbor-kv/vllm-qwen36-27b-h100:host-r1`
- vLLM: 0.24.0
- devices: physical H100 NVL indices 6 and 7, TP2
- weights: BF16; KV cache: FP8
- transport: Unix socket only; model container network mode `none`
- served name: `target-model`
- scheduler ceiling: 192 sequences
- explicit KV-cache allocation: 30 GiB per GPU
- resolved hybrid geometry: 1,253 raw GPU blocks minus one reserved null block,
  leaving 1,252 scheduler decision pages
- attention page size: 1,568 tokens; each live program also needs three resident
  Mamba pages and can need three additional transient Mamba pages at request peak
- reported logical KV telemetry: 1,887,738 tokens from
  `cache_config_info.kv_cache_size_tokens`

Admission and preemption decisions use the resolved 1,252-page geometry and the
separate Mamba costs. Do not use 1,887,738 as a token-linear scheduler budget,
and do not derive a replacement budget by multiplying raw block count by a user
block size. Hybrid attention/linear-attention alignment gives those values
different meanings.

## Lifecycle

Use one absolute runtime directory for every command:

```bash
export HARBOR_VLLM_RUNTIME_DIR="/tmp/harbor-kv-qwen36-27b-$(id -u)"

scripts/host-vllm-qwen36-27b.sh preflight
scripts/host-vllm-qwen36-27b.sh start
scripts/host-vllm-qwen36-27b.sh status
```

The launcher owns these fixed identities:

- tmux socket/session: `harbor-kv-qwen36-27b`
- container: `harbor-kv-qwen36-27b-host`
- selected host devices: `6,7`
- runtime UDS: `$HARBOR_VLLM_RUNTIME_DIR/vllm.sock`
- readiness record: `$HARBOR_VLLM_RUNTIME_DIR/attestation.json`
- persistent log: `$HARBOR_VLLM_RUNTIME_DIR/vllm.log`

The launcher validates the complete model file manifest, profile digest,
runtime image content ID, vLLM version, selected GPU UUIDs, idle-device state,
and exact container command before publishing readiness. `status` revalidates
the live process/container/UDS identity; it is the authoritative liveness
check.

Inspect and stop without involving Harbor Compose:

```bash
scripts/host-vllm-qwen36-27b.sh logs
scripts/host-vllm-qwen36-27b.sh stop
```

The stop path validates the attested ownership tuple before signaling or
removing anything.

## Harbor UDS bridge

Start the model first, export the same runtime directory, and then start the
task services:

```bash
scripts/calibration-stack.sh build
scripts/calibration-stack.sh start
scripts/calibration-stack.sh status
scripts/calibration-stack.sh verify-phase0-local
```

Only `model-api` receives a read-only mount of the runtime directory and
connects to `/run/kvbench-vllm/vllm.sock`. The candidate sees
`http://127.0.0.1:8100/v1`; it never receives the host UDS path or mount.

`scripts/calibration-stack.sh stop` does not stop the model. This is
intentional: the task stack and model runtime are separate ownership domains.

## Agent adapter contract

The trusted controller sends the same Qwen request shape for Direct and Oracle
legs. Chat-template thinking is disabled:

```json
{"chat_template_kwargs":{"enable_thinking":false}}
```

The mini-SWE adapter expects plain text containing one Bash code fence and does
not send function tools. This avoids a Qwen thinking-only completion consuming
the 2,048-token action budget without producing an executable step. The
gateway remains byte-transparent and may not change this request or response.

## Release boundary

The ready attestation proves live runtime identity; release qualification adds
the independent pressure, Oracle, and verifier evidence. The selected
192-workflow, 192-concurrency, 24-step, 2,048-token shape now has an immutable
public Direct anchor, a passing fixed-1800 Oracle calibration, and a passing
nonce-committed formal hidden run containing exactly one Direct and one Oracle
leg. Exploratory ABBA remains historical reference-selection evidence only.
The first Luna trial was launched against this qualified runtime and kept the
same boot identity throughout. Its runner-source repairs were regression-tested
and refrozen without a new model or workload calibration; strict currentness
still matches the same live attestation and exact images.

The bench controller derives an opaque canonical digest from the ready epoch,
wrapper PID/start ticks, container ID, and launch token. Only that digest is
added to leg model provenance: raw process/container values remain private.
Public Candidate preflight compares the digest with its baseline anchor, and
the hidden final session fixes the digest at session begin and rejects any
cross-leg host-vLLM restart.
