# Current Qwen task state

Last reconciled: 2026-07-20. Live process state can change; use
`scripts/host-vllm-qwen36-27b.sh status` and
`scripts/calibration-stack.sh status` as authoritative runtime checks.

## Current outcome

The task now exercises the intended systems problem. Real concurrent
mini-SWE-agent trajectories fill and oversubscribe Qwen's KV cache; the Direct
starter is protocol-correct but has no cross-program scheduler; and the
ThunderAgent-derived reference scheduler produces a repeatable public
steps/minute improvement without changing request payloads or model work.

The final r2 Oracle qualification passed every public and hidden gate:

- public author calibration: Direct 146.9 versus Oracle 165.4 actions/minute,
  or 1.125936×; Direct KV p95/preemptions were 0.9920/13 versus Oracle
  0.7420/0;
- release-topology public Candidate-only Oracle: 169.4 actions/minute, or
  1.153165× the immutable Direct anchor, with KV p95 0.7245 and zero
  preemptions;
- formal hidden: Direct 80.8705 versus Oracle 100.6611 actions/minute, or
  1.244720×, with fairness 1.0, request success 1.0, minimum progress 24,
  156 repository-test passes per leg, and verifier reward 0.988640.

The formal hidden protocol used exactly two live legs in its nonce-committed
Candidate/Direct order and exactly one Candidate gateway epoch. Four-leg ABBA
was used only during author-side reference selection.

The first three-session GPT-5.6 Luna Max trial began after strict release
currentness passed. Round 1 produced a valid Candidate result at 149.6
actions/minute, 1.01838× the cached Direct anchor. Rounds 2 and 3 did not reach
Codex because public helper installation accidentally changed a traverse root
from 0711 to 0700. Terminal champion restoration then failed because OverlayFS
does not support exchanging its lower-layer `/app/submission` directory. Both
runner defects now have offline and exact-image container fixes. The repaired
execution surface has passed pre-author currentness, strict currentness, and
canonical runner preflight.

## Runtime and topology

- Model: `Qwen/Qwen3.6-27B`, revision
  `6a9e13bd6fc8f0983b9b99948120bc37f49c13e9`.
- Profile: `qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2`, SHA-256
  `3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46`.
- Runtime: vLLM 0.24.0, standalone networkless host container, physical H100
  NVL devices 6 and 7, TP2, BF16 weights, FP8 KV, prefix caching, 192 sequence
  ceiling, and 30 GiB KV allocation per GPU.
- Transport: one Unix socket visible read-only only to trusted model-api. The
  candidate receives the verifier-selected OpenAI-compatible `BACKEND_URL`.
- Hybrid scheduler geometry: 1,253 raw pages minus one reserved null page,
  leaving 1,252 decision pages; 1,568 attention tokens per page; three resident
  and up to three transient Mamba pages per request.
- The reported 1,887,738 logical KV tokens are telemetry, not a token-linear
  admission budget.

Phase-0 verifies the exact model files, runtime image, vLLM command, UDS-only
transport, GPU UUIDs, profile and live process/container identity. It does not
by itself qualify scheduling performance.

## What the workflows do

Each workflow is an independent mini-SWE-agent loop in a fresh no-network
repository sandbox:

1. render the issue and current repository observation;
2. call Qwen through Direct or the evaluated gateway;
3. parse one Bash-fence action;
4. execute it in the sandbox;
5. append the tool observation and call the model again;
6. stop on submission or the bounded action limit.

There is no synthetic prompt padding or sleep. Surviving agents naturally
accumulate repository output and longer KV contexts. Repeated issue images
still yield independent writable repositories, program IDs, histories and
model trajectories.

The adapter is `qwen36-text-bash-v1`: temperature 0, top-p 1, thinking
disabled, no function tools, and at most 2,048 completion tokens. Thinking is
disabled because empirical probes consumed the action budget without yielding
an executable command; that would measure protocol failure rather than
scheduling.

## Public versus hidden

Public pressure starts 192 independent workflows at concurrency 192 and allows
at most 24 actions. Direct and Candidate calibration legs each have one exact
1800-second measurement interval. Actions count only when tool execution
finishes before the trusted cutoff. The one-time author calibration takes about
20–22 minutes and creates a private immutable Direct anchor. Every actual
Harbor public round runs only Candidate, normally 10–11 minutes, with a
2100-second outer failure ceiling.

Hidden uses a disjoint finite cohort and no fixed-window censoring. Its rate
interval starts globally immediately before cohort dispatch and ends at the
last `agent.run` termination. Repository verification and sandbox cleanup are
still mandatory quality/lifecycle gates but are outside that throughput
denominator. Formal hidden runs one Direct and one fresh Candidate; a
domain-separated private nonce commitment chooses AB or BA. The author-only
four-leg ABBA remains only the reference-selection experiment. Private profile
details, trajectories and Oracle health never enter candidate-visible output.

The public and hidden timing protocols intentionally differ. Public is an
affordable scheduler edit loop; hidden verifies full bounded progress,
semantic quality, cleanup, pressure and repeatability.

## Reference scheduler

The Oracle is a task-compatible extraction of upstream ThunderAgent commit
`7ddc8610270e56d3b109eed8796b3a4360fc67c9`. Its data plane remains one-request
to one-request and byte transparent. Its scheduling state is keyed only by the
opaque program header and optional lifecycle release hint.

Policy v5 has two observable tiers:

- steps 1–12 preserve the passing v4 bounded-service-lag policy exactly;
- requests from step 13 use total-token shortest-job-first and may bypass only
  service-lag ordering.

Capacity safety, request-phase hybrid page accounting, aged-request reservation
and no-pause-inflight rules precede both tiers. Public release evidence must
show zero deep activation. The sole fresh formal hidden Oracle epoch must show
positive deep offers, waiters, wait duration, service-lag bypass, resumes and
SJF ticks.

## Isolation and evidence status

Completed validation includes:

- full CPU/mutation suite;
- transparent bridge and UDS signed/audited model-api integrations;
- hidden process, filesystem, shared-memory, SysV IPC and output-root reset;
- root-signed main-network egress seal while preserving internal model/control
  traffic;
- fixed/finite timing identity, live-sample cutoff and sampler-error mutations;
- public report nested allowlists and private-health exclusion;
- append-only public pair lineage and retry immutability;
- one-to-three fresh serial Codex sessions, code snapshot/tar validation, and
  sanitized result handoff without transcript replay.

The sanitized joint release evidence is stored at
`calibration/qwen36-release/qwen36-final-oracle-full-verifier-r2.json`; the
immutable index is `calibration/qwen36-release/evidence-index.json`.

## Remaining release sequence

1. Launch a fresh three-session GPT-5.6 Luna Max trial. Confirm Round 2 reaches
   native Codex, all three public snapshots remain independent, the best
   snapshot restores with the same `/app/submission` inode, and Harbor's
   verifier runs only after the durable final marker exists.
