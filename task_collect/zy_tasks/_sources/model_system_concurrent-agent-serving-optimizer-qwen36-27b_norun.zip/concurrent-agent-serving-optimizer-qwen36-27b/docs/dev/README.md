# Development documentation

This directory is the author-side source of truth while the Qwen Harbor task
is under calibration. It is deliberately separate from `instruction.md`:
candidate agents receive the neutral gateway contract, not hidden profiles,
failed probes, Oracle policy, or release decisions.

## Active documents

- [`../../README.md`](../../README.md): operator overview and minimal reading
  path.
- [`CURRENT_STATE.md`](CURRENT_STATE.md): current Qwen evidence, blockers, and
  next experiment.
- [`HOST_QWEN36_RUNTIME.md`](HOST_QWEN36_RUNTIME.md): external Qwen3.6-27B TP2
  lifecycle, UDS contract, and author commands.
- [`RUN_LOG.md`](RUN_LOG.md): append-only command and outcome history.
- [`STEADY_WINDOW_CALIBRATION.md`](STEADY_WINDOW_CALIBRATION.md): author-only
  fixed-window rolling protocol, current fail-closed status, and future
  controller requirements.
- [`../../calibration/READINESS.md`](../../calibration/READINESS.md): Qwen
  qualification and release checklist.

Historical model experiments are not part of this task's active documentation
or release surface. They cannot set Qwen capacity, pressure thresholds,
public/hidden shapes, reference values, or release evidence.

## Current release rule

`release_ready`, `real_agent_test_allowed`, and every real-agent gate remain
false until one frozen Qwen runtime/corpus/controller fingerprint has:

1. passed external UDS/attestation Phase-0 and end-to-end API qualification;
2. located a natural multi-agent KV contention knee by varying concurrency and
   real agent depth;
3. passed sustained pressure and largest-request admission-safety gates;
4. demonstrated same-workload Oracle speedup above noise without quality,
   progress, audit, or backend-work regression;
5. repeated those results independently on public and hidden partitions;
6. passed protocol, cancellation, isolation, cleanup, and scoring mutations;
7. completed the required soaks and immutable release-manifest sequence.

A healthy model, a smoke run, projected KV demand, or one favorable throughput
number is not release readiness.
