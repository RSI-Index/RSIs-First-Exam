# Optimize Concurrent Coding-Agent Inference

Implement a transparent scheduling gateway that improves the rate at which
many concurrent, multi-turn coding agents produce executable actions.

## Deliverable

A working Direct/FIFO starter gateway is installed in:

```text
/app/submission
```

It is the protocol-correct no-scheduler starting point: requests are forwarded
immediately without a cross-workflow admission queue.

Modify that directory in place. Your final submission must keep an executable:

```text
/app/submission/launch.sh
```

The verifier launches it as:

```bash
BACKEND_URL=<verifier-selected OpenAI-compatible /v1 endpoint> \
PORT=9000 \
/app/submission/launch.sh
```

`launch.sh` must stay in the foreground and listen on `0.0.0.0:${PORT}`.
Always use the supplied `BACKEND_URL`; do not hard-code the normal backend
address. Keep runtime state in memory or under `/tmp`, not in the submitted
source tree.

The gateway must implement:

- `GET /health`
- `GET /v1/models`
- `POST /v1/chat/completions`

Both streaming and non-streaming chat completions are exercised.

Only files under `/app/submission` are part of the solution graded by the final
verifier.

## Problem and objective

The serving endpoint is shared by many independent agents working on different
tasks at the same time. Each agent repeatedly alternates between model
inference and work in its own tools or environment, then returns with a longer
conversation. Their requests therefore arrive asynchronously, carry different
amounts of accumulated context, and compete for a finite model KV cache.

Build an online admission and scheduling policy that maximizes the aggregate
rate at which these agents make useful progress. The primary objective is valid
executable agent steps per minute (`valid_steps_per_min`), not isolated request
throughput. An apparent throughput improvement is not valid if it comes from
dropped requests, stalled agents, excessive latency, extra backend work, or a
protocol violation.

Requests from one agent carry the same opaque `X-Agent-Run-ID`. You may use that
identity and online request state to control admission and queue order in front
of the fixed backend. Treat the identifier as opaque and do not assume anything
about the task behind it.

Only the gateway is in scope. Do not change the model server, model weights,
test runner, or GPU configuration.

## Transparency requirements

For every accepted `/v1/models` or `/v1/chat/completions` request, make exactly
one matching request to `BACKEND_URL` and faithfully return that response.

Do not modify or replace:

- messages, model names, sampling parameters, or token limits;
- response content, usage, finish reasons, or errors;
- streaming chunk content or ordering.

Do not synthesize, cache, replay, truncate, merge, or skip model responses.
Propagate client cancellation, timeout, and disconnect behavior correctly.
Forward benchmark tracing headers unchanged.

At the trusted end of a fixed measurement window, the controller may disconnect
requests that are still waiting or in flight. Those boundary-cancelled requests
are handled by the benchmark separately; this does not permit dropping or
short-circuiting ordinary requests.

The runner may send an optional lifecycle notification after a workflow's final
model call:

```text
POST /programs/release
Content-Type: application/json
X-Agent-Run-ID: <workflow ID>

{"program_id":"<workflow ID>"}
```

You may use it to discard scheduling state for that workflow. It is not a model
request and must not be forwarded to `BACKEND_URL`. Any 2xx response
acknowledges it; returning 404 or 405 is also allowed.

## Public development loop

Check that the trusted benchmark services are ready:

```bash
kvbench doctor
```

`kvbench` measures an already-running gateway; it does not start
`/app/submission/launch.sh`. Start exactly one copy, wait for health, run a
Candidate measurement, and stop it before editing or testing another version:

```bash
set -euo pipefail
BACKEND_URL="${BACKEND_URL:?BACKEND_URL is required}" PORT=9000 \
  /app/submission/launch.sh >/tmp/kvbench-gateway.log 2>&1 &
gateway_pid=$!
trap 'kill "$gateway_pid" 2>/dev/null || true; wait "$gateway_pid" 2>/dev/null || true' EXIT

for _ in $(seq 1 120); do
  curl -fsS http://127.0.0.1:9000/health >/dev/null && break
  kill -0 "$gateway_pid"
  sleep 0.25
done
curl -fsS http://127.0.0.1:9000/health >/dev/null
```

The environment supplies two public profile names. Use the debug profile for
fast API and queue checks:

```bash
kvbench run --mode baseline --profile "$KVBENCH_DEBUG_PROFILE"
kvbench run --mode candidate --profile "$KVBENCH_DEBUG_PROFILE"
kvbench compare --profile "$KVBENCH_DEBUG_PROFILE"
```

Its Baseline leg calls the trusted backend directly and bypasses your gateway;
its Candidate leg uses the currently running gateway.

Use the pressure profile before making performance conclusions:

```bash
kvbench run --mode candidate --profile "$KVBENCH_PUBLIC_PROFILE"
kvbench compare --profile "$KVBENCH_PUBLIC_PROFILE"
```

The pressure profile's trusted Direct result is already cached, so a normal
public iteration runs only a fresh Candidate measurement. You may print the
cached Direct summary without rerunning it:

```bash
kvbench run --mode baseline --profile "$KVBENCH_PUBLIC_PROFILE"
```

Every pressure-profile Candidate run snapshots the current `/app/submission`
before the measurement and saves the code, result, comparison, and speedup
under:

```text
/app/public_evals/eval_000001.COMPLETE/
/app/public_evals/eval_000002.COMPLETE/
...
/app/public_evals/latest.json
/app/public_evals/history.jsonl
```

Optimize iteratively. Inspect the saved public history, form a scheduling
hypothesis, edit the gateway, run appropriate checks, inspect the result, and
then keep, revise, or revert the change. Continue with new evidence-based
hypotheses instead of stopping after the first working implementation or the
first improvement.

Use the debug profile for fast protocol and queue debugging. Use the pressure
profile whenever you need reliable performance evidence; smoke results are not
enough to establish a scheduling improvement. Choose the testing cadence that
best supports your investigation. Use the reported throughput, progress,
KV-cache, waiting-request, latency, audit, and failure fields to guide the next
change. Restart the gateway after each edit so every measured result corresponds
to exactly one saved code version, and leave the best valid measured version in
`/app/submission` as the final solution.
