#!/usr/bin/env python3
"""CPU tests for the optional candidate program-lifecycle control hint."""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace
from typing import Any

from runner import workload


class Handler(BaseHTTPRequestHandler):
    status = 200
    delay = 0.0
    records: list[dict[str, Any]] = []

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        type(self).records.append(
            {
                "path": self.path,
                "run_id": self.headers.get("X-Agent-Run-ID"),
                "body": json.loads(body),
            }
        )
        if type(self).delay:
            time.sleep(type(self).delay)
        payload = b'{}'
        try:
            self.send_response(type(self).status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass


class Server(ThreadingHTTPServer):
    daemon_threads = True


def release_http_cases() -> dict[str, bool]:
    Handler.records = []
    Handler.status = 200
    Handler.delay = 0.0
    server = Server(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    endpoint = f"http://127.0.0.1:{server.server_port}/nested/v1"
    try:
        success = workload.release_gateway_program(
            endpoint, "program-1", enabled=True, timeout=1
        )
        Handler.status = 404
        unsupported = workload.release_gateway_program(
            endpoint, "program-2", enabled=True, timeout=1
        )
        before_disabled = len(Handler.records)
        disabled = workload.release_gateway_program(
            endpoint, "program-3", enabled=False, timeout=1
        )
        after_disabled = len(Handler.records)
        Handler.status = 200
        Handler.delay = 0.2
        timed_out = workload.release_gateway_program(
            endpoint, "program-4", enabled=True, timeout=0.02
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)

    first = Handler.records[0]
    return {
        "url_and_payload_are_derived_exactly": (
            first["path"] == "/nested/programs/release"
            and first["run_id"] == "program-1"
            and first["body"] == {"program_id": "program-1"}
        ),
        "two_xx_is_acknowledged": (
            success["attempted"] is True
            and success["supported"] is True
            and success["acknowledged"] is True
            and success["status"] == 200
        ),
        "404_is_optional_not_failure": (
            unsupported["attempted"] is True
            and unsupported["supported"] is False
            and unsupported["acknowledged"] is False
            and unsupported["error"] is None
        ),
        "disabled_hint_makes_no_request": (
            disabled["attempted"] is False
            and before_disabled == after_disabled
        ),
        "timeout_is_recorded_not_raised": (
            timed_out["attempted"] is True
            and timed_out["acknowledged"] is False
            and isinstance(timed_out["error"], str)
            and "timed out" in timed_out["error"].lower()
        ),
    }


def workflow_order_case() -> bool:
    events: list[str] = []

    class FakeModel:
        def __init__(self, **_kwargs: Any) -> None:
            self.n_calls = 0

    class FakeAgent:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            self.step_timings: list[dict[str, Any]] = []

        def run(self, _prompt: str) -> tuple[str, str]:
            events.append("agent")
            return "Submitted", "done"

    class FakeSandbox:
        def verify(self) -> tuple[bool, str]:
            events.append("verify")
            return True, "ok"

        def cleanup(self) -> None:
            events.append("cleanup")

    def fake_release(
        _endpoint: str,
        _program_id: str,
        *,
        enabled: bool,
        timeout: float = 5.0,
    ) -> dict[str, Any]:
        del timeout
        events.append("release")
        return {
            "attempted": enabled,
            "acknowledged": enabled,
            "supported": True,
            "status": 200,
            "error": None,
        }

    replacements = {
        "BenchmarkVllmModel": FakeModel,
        "DefaultAgent": FakeAgent,
        "release_gateway_program": fake_release,
        "task_prompt": lambda *_args: "prompt",
    }
    originals = {name: getattr(workload, name) for name in replacements}
    for name, value in replacements.items():
        setattr(workload, name, value)
    try:
        result = workload.run_workflow(
            spec=SimpleNamespace(task_id="task"),
            profile=SimpleNamespace(
                max_tokens=1,
                seed=1,
                request_timeout_sec=1,
                context_bytes=0,
                max_steps=1,
                workflow_timeout_sec=1,
            ),
            endpoint="http://candidate:9000/v1",
            leg_id="leg",
            profile_token="opaque",
            token="token",
            audit_epoch=1,
            ledger=SimpleNamespace(),
            ordinal=0,
            workload_nonce="nonce",
            sandbox=FakeSandbox(),
            model_adapter=SimpleNamespace(
                model_config=lambda _max_tokens: {},
                instruction="instruction",
                instance_template="instance",
                instruction_role="system",
                format_error_template="format",
            ),
            program_release_enabled=True,
        )
    finally:
        for name, value in originals.items():
            setattr(workload, name, value)
    return (
        events == ["agent", "release", "verify", "cleanup"]
        and result["program_lifecycle_release"]["acknowledged"] is True
        and "agent_execution_interval" not in result
    )


def finite_tracker_order_cases() -> dict[str, bool]:
    def run_case(*, agent_raises: bool) -> tuple[list[str], dict[str, Any], bool]:
        events: list[str] = []

        class FakeModel:
            def __init__(self, **_kwargs: Any) -> None:
                self.n_calls = 0

        class FakeAgent:
            def __init__(self, *_args: Any, **_kwargs: Any) -> None:
                self.step_timings: list[dict[str, Any]] = []

            def run(self, _prompt: str) -> tuple[str, str]:
                events.append("agent")
                if agent_raises:
                    raise RuntimeError("agent-boom")
                return "Submitted", "done"

        class FakeSandbox:
            def verify(self) -> tuple[bool, str]:
                events.append("verify")
                return True, "ok"

            def cleanup(self) -> None:
                events.append("cleanup")

        class RecordingTracker(workload.AgentExecutionTracker):
            def mark(
                self,
                ordinal: int,
                *,
                ended_unix: float,
                ended_monotonic: float,
            ) -> None:
                events.append("mark")
                super().mark(
                    ordinal,
                    ended_unix=ended_unix,
                    ended_monotonic=ended_monotonic,
                )

        def fake_release(
            _endpoint: str,
            _program_id: str,
            *,
            enabled: bool,
            timeout: float = 5.0,
        ) -> dict[str, Any]:
            del timeout
            events.append("release")
            return {
                "attempted": enabled,
                "acknowledged": enabled,
                "supported": True,
                "status": 200,
                "error": None,
            }

        replacements = {
            "BenchmarkVllmModel": FakeModel,
            "DefaultAgent": FakeAgent,
            "release_gateway_program": fake_release,
            "task_prompt": lambda *_args: "prompt",
        }
        originals = {name: getattr(workload, name) for name in replacements}
        tracker = RecordingTracker(1)
        for name, value in replacements.items():
            setattr(workload, name, value)
        try:
            result = workload.run_workflow(
                spec=SimpleNamespace(task_id="task"),
                profile=SimpleNamespace(
                    max_tokens=1,
                    seed=1,
                    request_timeout_sec=1,
                    context_bytes=0,
                    max_steps=1,
                    workflow_timeout_sec=1,
                ),
                endpoint="http://candidate:9000/v1",
                leg_id="leg",
                profile_token="opaque",
                token="token",
                audit_epoch=1,
                ledger=SimpleNamespace(),
                ordinal=0,
                workload_nonce="nonce",
                sandbox=FakeSandbox(),
                model_adapter=SimpleNamespace(
                    model_config=lambda _max_tokens: {},
                    instruction="instruction",
                    instance_template="instance",
                    instruction_role="system",
                    format_error_template="format",
                ),
                agent_execution_tracker=tracker,
                program_release_enabled=True,
            )
        finally:
            for name, value in originals.items():
                setattr(workload, name, value)
        return events, result, tracker.complete.is_set()

    normal_events, normal_result, normal_complete = run_case(agent_raises=False)
    raised_events, raised_result, raised_complete = run_case(agent_raises=True)
    return {
        "finite_agent_end_is_marked_before_release_verify_cleanup": (
            normal_events == ["agent", "mark", "release", "verify", "cleanup"]
            and normal_complete
            and normal_result["tests_passed"] is True
        ),
        "raised_agent_is_still_marked_and_quality_fails": (
            raised_events == ["agent", "mark", "release", "cleanup"]
            and raised_complete
            and raised_result["tests_passed"] is False
            and raised_result["error"] == "RuntimeError: agent-boom"
        ),
    }


def main() -> int:
    checks = {
        **release_http_cases(),
        "workflow_releases_before_sandbox_verification": workflow_order_case(),
        **finite_tracker_order_cases(),
    }
    report = {
        "schema_version": 1,
        "kind": "program-lifecycle-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
