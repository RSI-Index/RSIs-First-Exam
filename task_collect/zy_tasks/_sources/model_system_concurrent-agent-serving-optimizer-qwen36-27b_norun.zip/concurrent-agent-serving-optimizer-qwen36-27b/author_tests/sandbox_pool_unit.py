#!/usr/bin/env python3
"""Prove queued workflows cannot exceed the live-sandbox or create limits."""

from __future__ import annotations

import json
import inspect
import sys
import threading
import time
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))

from runner.corpus import make_specs  # noqa: E402
from runner.ledger import Ledger  # noqa: E402
from runner import workload as workload_module  # noqa: E402
from runner.workload import Profile, prepare_sandboxes, run_workflow_pool  # noqa: E402


class FakeSandbox:
    lock = threading.Lock()
    live = 0
    maximum_live = 0
    creating = 0
    maximum_creating = 0
    created = 0
    cleaned = 0
    fail_task_ids: set[str] = set()

    @classmethod
    def reset(cls, *, fail_task_ids: set[str] | None = None) -> None:
        with cls.lock:
            cls.live = 0
            cls.maximum_live = 0
            cls.creating = 0
            cls.maximum_creating = 0
            cls.created = 0
            cls.cleaned = 0
            cls.fail_task_ids = set(fail_task_ids or set())

    def __init__(self, spec: Any, **_: Any) -> None:
        self.spec = spec
        self._cleaned = False
        with self.lock:
            type(self).creating += 1
            type(self).maximum_creating = max(
                type(self).maximum_creating,
                type(self).creating,
            )
        # Make overlapping constructors observable without touching Docker.
        time.sleep(0.01)
        with self.lock:
            type(self).creating -= 1
            if spec.task_id in type(self).fail_task_ids:
                raise RuntimeError(f"injected sandbox creation failure: {spec.task_id}")
            type(self).created += 1
            type(self).live += 1
            type(self).maximum_live = max(type(self).maximum_live, type(self).live)

    def cleanup(self) -> None:
        with self.lock:
            if self._cleaned:
                return
            self._cleaned = True
            type(self).live -= 1
            type(self).cleaned += 1


def make_profile(name: str, workflows: int, concurrency: int) -> Profile:
    return Profile(
        name=name,
        enabled=True,
        workflows=workflows,
        concurrency=concurrency,
        max_steps=1,
        context_bytes=0,
        max_tokens=32,
        workflow_timeout_sec=30,
        request_timeout_sec=20,
        tool_delay_min_sec=0,
        tool_delay_max_sec=0,
        seed=11,
        warmup_requests=0,
        warmup_context_bytes=0,
        warmup_steps=1,
        sandbox_prepare_concurrency=2,
    )


def exercise(
    *,
    workflows: int,
    concurrency: int,
    creation_failure_index: int | None = None,
    runner_failure_index: int | None = None,
) -> tuple[list[dict[str, Any]] | None, dict[str, Any] | None, Exception | None, list[dict[str, Any]]]:
    namespace = f"pool-{workflows}-{concurrency}"
    specs = make_specs(namespace, workflows)
    failure_ids = (
        {specs[creation_failure_index].task_id}
        if creation_failure_index is not None
        else set()
    )
    FakeSandbox.reset(fail_task_ids=failure_ids)
    profile = make_profile(namespace, workflows, concurrency)
    seen: list[dict[str, Any]] = []
    seen_lock = threading.Lock()

    def fake_run_workflow(**kwargs: Any) -> dict[str, Any]:
        ordinal = int(kwargs["ordinal"])
        with seen_lock:
            seen.append(
                {
                    "ordinal": ordinal,
                    "task_id": kwargs["spec"].task_id,
                    "workload_nonce": kwargs["workload_nonce"],
                    "leg_id": kwargs["leg_id"],
                }
            )
        time.sleep(0.005 + (ordinal % 3) * 0.002)
        if ordinal == runner_failure_index:
            raise RuntimeError(f"injected workflow failure: {ordinal}")
        return {"task_id": kwargs["spec"].task_id, "ordinal": ordinal}

    original_sandbox = workload_module.TimedSandbox
    original_runner = workload_module.run_workflow
    workload_module.TimedSandbox = FakeSandbox
    workload_module.run_workflow = fake_run_workflow
    results: list[dict[str, Any]] | None = None
    preparation: dict[str, Any] | None = None
    failure: Exception | None = None
    try:
        initial = prepare_sandboxes(specs[:concurrency], profile)
        try:
            results, preparation = run_workflow_pool(
                specs=specs,
                profile=profile,
                initial_sandboxes=initial,
                endpoint="http://model.invalid/v1",
                leg_id="unit-leg",
                profile_token="unit-profile-token",
                token="unit-admin-token",
                audit_epoch=7,
                ledger=Ledger(),
                workload_nonce="unit-workload-nonce",
                model_adapter=object(),  # fake runner does not inspect the adapter
                cancel_event=None,
            )
        except Exception as exc:  # expected in the two cleanup mutation cases
            failure = exc
    finally:
        workload_module.TimedSandbox = original_sandbox
        workload_module.run_workflow = original_runner
    return results, preparation, failure, seen


def main() -> int:
    results, preparation, failure, seen = exercise(workflows=11, concurrency=4)
    success_state = {
        "maximum_live": FakeSandbox.maximum_live,
        "maximum_creating": FakeSandbox.maximum_creating,
        "live_after": FakeSandbox.live,
        "created": FakeSandbox.created,
        "cleaned": FakeSandbox.cleaned,
    }
    success_checks = {
        "run_succeeded": failure is None and results is not None and preparation is not None,
        "all_logical_workflows_ran": (
            results is not None
            and sorted(item["ordinal"] for item in results) == list(range(11))
        ),
        "workflow_identity_is_preserved": (
            sorted(item["ordinal"] for item in seen) == list(range(11))
            and all(item["workload_nonce"] == "unit-workload-nonce" for item in seen)
            and all(item["leg_id"] == "unit-leg" for item in seen)
        ),
        "live_sandboxes_never_exceed_workers": success_state["maximum_live"] <= 4,
        "queued_creation_is_bounded": (
            success_state["maximum_creating"] <= 2
            and preparation is not None
            and preparation["maximum_observed_create_concurrency"] <= 2
        ),
        "queued_count_is_exact": (
            preparation is not None
            and preparation["attempts"] == 7
            and preparation["prepared"] == 7
            and preparation["failures"] == 0
            and preparation["included_in_measured_interval"] is True
        ),
        "every_created_sandbox_was_cleaned": (
            success_state["created"] == 11
            and success_state["cleaned"] == 11
            and success_state["live_after"] == 0
        ),
    }

    one_wave_results, one_wave_prep, one_wave_failure, _ = exercise(
        workflows=4,
        concurrency=4,
    )
    one_wave_state = {
        "created": FakeSandbox.created,
        "cleaned": FakeSandbox.cleaned,
        "live_after": FakeSandbox.live,
    }
    one_wave_check = (
        one_wave_failure is None
        and one_wave_results is not None
        and len(one_wave_results) == 4
        and one_wave_prep is not None
        and one_wave_prep["attempts"] == 0
        and one_wave_prep["prepared"] == 0
        and one_wave_state == {"created": 4, "cleaned": 4, "live_after": 0}
    )

    _, _, create_failure, _ = exercise(
        workflows=9,
        concurrency=4,
        creation_failure_index=5,
    )
    creation_failure_check = (
        isinstance(create_failure, RuntimeError)
        and FakeSandbox.live == 0
        and FakeSandbox.created == FakeSandbox.cleaned
        and FakeSandbox.maximum_live <= 4
        and FakeSandbox.maximum_creating <= 2
    )

    _, _, runner_failure, _ = exercise(
        workflows=9,
        concurrency=4,
        runner_failure_index=5,
    )
    runner_failure_check = (
        isinstance(runner_failure, RuntimeError)
        and FakeSandbox.live == 0
        and FakeSandbox.created == FakeSandbox.cleaned
        and FakeSandbox.maximum_live <= 4
        and FakeSandbox.maximum_creating <= 2
    )

    checks = {
        **success_checks,
        "benchmark_prepares_only_the_initial_worker_wave": (
            "initial_sandbox_count = min(profile.workflows, profile.concurrency)"
            in inspect.getsource(workload_module.run_benchmark)
            and "prepare_sandboxes(specs[:initial_sandbox_count], profile)"
            in inspect.getsource(workload_module.run_benchmark)
        ),
        "executor_width_remains_profile_concurrency": (
            "ThreadPoolExecutor(max_workers=profile.concurrency)"
            in inspect.getsource(run_workflow_pool)
        ),
        "one_wave_has_no_queued_preparation": one_wave_check,
        "creation_failure_cleans_every_successful_creation": creation_failure_check,
        "runner_failure_cleans_every_created_sandbox": runner_failure_check,
    }
    report = {
        "schema_version": 1,
        "kind": "bounded-sandbox-pool-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "successful_pool_state": success_state,
        "one_wave_state": one_wave_state,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
