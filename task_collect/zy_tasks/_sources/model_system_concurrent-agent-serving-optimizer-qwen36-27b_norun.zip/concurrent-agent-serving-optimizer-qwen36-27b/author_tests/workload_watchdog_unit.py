#!/usr/bin/env python3
"""CPU-only checks for token telemetry and backend admission stall detection."""

from __future__ import annotations

import json
import math

from runner.workload import (
    AdmissionStallDetector,
    CandidateAdmissionStallDetector,
    model_response_outcomes,
    request_token_distribution,
)


def main() -> int:
    cases = []

    distribution = request_token_distribution(
        [
            {"prompt_tokens": 1},
            {"prompt_tokens": 2},
            {"prompt_tokens": 3},
            {"prompt_tokens": 4},
            {"prompt_tokens": None},
            {"prompt_tokens": True},
        ],
        "prompt_tokens",
    )
    cases.append(
        {
            "name": "token_distribution_is_aggregate_and_interpolated",
            "passed": distribution["sample_count"] == 4
            and distribution["total"] == 10
            and distribution["max"] == 4
            and math.isclose(distribution["p50"], 2.5)
            and math.isclose(distribution["p95"], 3.85)
            and math.isclose(distribution["p99"], 3.97),
            "observed": distribution,
        }
    )

    candidate_detector = CandidateAdmissionStallDetector(timeout_sec=60)
    client = {
        "active_requests": 72,
        "completed_requests": 0,
        "oldest_active_age_sec": 75.0,
    }
    idle_zero = {"active_backend_requests": 0, "audit_count": 0}
    busy_zero = {"active_backend_requests": 1, "audit_count": 0}
    idle_one = {"active_backend_requests": 0, "audit_count": 1}
    first = candidate_detector.observe(client, idle_zero, 100.0)
    early = candidate_detector.observe(client, idle_zero, 159.9)
    backend_reset = candidate_detector.observe(client, busy_zero, 160.0)
    restarted = candidate_detector.observe(client, idle_zero, 161.0)
    audit_reset = candidate_detector.observe(client, idle_one, 220.0)
    restarted_after_audit = candidate_detector.observe(
        client,
        idle_one,
        221.0,
    )
    fatal = candidate_detector.observe(client, idle_one, 281.0)
    cases.append(
        {
            "name": "candidate_zero_admission_requires_continuous_no_backend_progress",
            "passed": first is None
            and early is None
            and backend_reset is None
            and restarted is None
            and audit_reset is None
            and restarted_after_audit is None
            and fatal is not None
            and "client_active=72" in fatal
            and "backend_active=0" in fatal
            and "audited_completed=1" in fatal
            and "duration_sec=60.0" in fatal,
            "fatal": fatal,
        }
    )

    outcomes = model_response_outcomes(
        [
            {
                "finish_reason": "tool_calls",
                "tool_call_count": 1,
                "completion_tokens": 32,
                "content_chars": 0,
                "internal_reasoning_chars": 40,
            },
            {
                "finish_reason": "length",
                "tool_call_count": 0,
                "completion_tokens": 384,
                "content_chars": 0,
                "internal_reasoning_chars": 512,
            },
        ],
        384,
    )
    cases.append(
        {
            "name": "model_response_outcomes_expose_actionability_failures",
            "passed": outcomes["response_count"] == 2
            and outcomes["responses_with_tool_call"] == 1
            and outcomes["responses_without_tool_call"] == 1
            and outcomes["completion_budget_exhausted"] == 1
            and outcomes["no_tool_and_budget_exhausted"] == 1
            and outcomes["finish_reasons"] == {"tool_calls": 1, "length": 1},
            "observed": outcomes,
        }
    )

    detector = AdmissionStallDetector(timeout_sec=30)
    stalled = {"requests_running": 0.0, "requests_waiting": 72.0, "kv_cache_usage": 0.0}
    healthy = {"requests_running": 1.0, "requests_waiting": 71.0, "kv_cache_usage": 0.1}
    first = detector.observe(stalled, 100.0)
    early = detector.observe(stalled, 129.9)
    fatal = detector.observe(stalled, 130.0)
    reset = detector.observe(healthy, 131.0)
    restarted = detector.observe(stalled, 132.0)
    cases.append(
        {
            "name": "stall_requires_a_continuous_timeout_and_resets_on_progress",
            "passed": first is None
            and early is None
            and fatal is not None
            and "waiting=72" in fatal
            and reset is None
            and restarted is None,
            "fatal": fatal,
        }
    )

    report = {
        "schema_version": 1,
        "kind": "workload-watchdog-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
