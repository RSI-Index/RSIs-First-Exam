#!/usr/bin/env python3
"""CPU-only checks for the frozen Qwen3.6-27B profile and optional KV budget."""

from __future__ import annotations

import copy
import json
import sys
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
RUNTIME_ROOT = TASK_ROOT / "environment" / "vllm-runtime"
sys.path.insert(0, str(RUNTIME_ROOT))

from model_contract import ContractError, load_profile  # noqa: E402


def main() -> int:
    source = json.loads(
        (RUNTIME_ROOT / "model-profile-qwen3.6-27b.json").read_text()
    )
    cases = []
    with tempfile.TemporaryDirectory(prefix="kvbench-model-profile-") as raw:
        path = Path(raw) / "profile.json"

        def profile_case(name: str, profile: dict, expected: bool) -> None:
            path.write_text(json.dumps(profile))
            passed = True
            try:
                load_profile(path)
            except ContractError:
                passed = False
            cases.append({"name": name, "passed": passed is expected})

        def budget_case(name: str, value: object, expected: bool) -> None:
            profile = copy.deepcopy(source)
            profile["runtime"]["kv_cache_memory_bytes"] = value
            profile_case(name, profile, expected)

        profile_case("frozen_qwen36_27b_tp2_kv30g_profile_is_structurally_valid", source, True)
        cases.append(
            {
                "name": "frozen_profile_reserves_exactly_30gib_for_kv_cache",
                "passed": source["runtime"]["kv_cache_memory_bytes"] == 30 * 1024**3,
            }
        )
        cases.append(
            {
                "name": "profile_keeps_user_block_size_distinct_from_resolved_hybrid_page",
                "passed": source["runtime"]["block_size"] == 16
                and source["runtime"]["mamba_cache_mode"] == "align"
                and not any(
                    "speculative" in key.lower() for key in source["runtime"]
                ),
            }
        )
        cases.append(
            {
                "name": "profile_attests_the_hybrid_model_architecture",
                "passed": source["config_contract"]["num_hidden_layers"] == 64
                and source["config_contract"]["full_attention_interval"] == 4
                and source["config_contract"]["full_attention_layer_count"] == 16,
            }
        )
        cases.append(
            {
                "name": "resolved_cache_geometry_is_not_fabricated_as_a_launch_input",
                "passed": all(
                    key not in source["runtime"]
                    for key in (
                        "attention_page_tokens",
                        "num_gpu_blocks",
                        "reserved_null_blocks",
                        "capacity_pages",
                        "kv_cache_size_tokens",
                    )
                ),
            }
        )
        budget_case("natural_vllm_budget_remains_supported_for_author_calibration", None, True)
        budget_case(
            "structurally_valid_4gib_budget_is_parseable_but_requires_feasibility_gate",
            4 * 1024**3,
            True,
        )
        budget_case(
            "structurally_valid_16gib_budget_is_parseable_but_requires_feasibility_gate",
            16 * 1024**3,
            True,
        )
        budget_case("string_budget_is_rejected", str(16 * 1024**3), False)
        budget_case("sub_gib_budget_is_rejected", 512 * 1024**2, False)
        budget_case("oversized_budget_is_rejected", 81 * 1024**3, False)

        broken_tp = copy.deepcopy(source)
        broken_tp["runtime"]["tensor_parallel_size"] = 1
        profile_case(
            "tensor_parallel_gpu_count_mismatch_is_rejected", broken_tp, False
        )

        duplicated_indices = copy.deepcopy(source)
        duplicated_indices["gpu_contract"]["host_indices"] = [6, 6]
        profile_case(
            "duplicated_physical_gpu_indices_are_rejected", duplicated_indices, False
        )

        wrong_count = copy.deepcopy(source)
        wrong_count["gpu_contract"]["count"] = 0
        profile_case("nonpositive_gpu_count_is_rejected", wrong_count, False)

        unnamed_model = copy.deepcopy(source)
        unnamed_model["runtime"]["served_model_name"] = ""
        profile_case("empty_served_model_name_is_rejected", unnamed_model, False)

        parser_extension = copy.deepcopy(source)
        parser_extension["runtime"]["harmony"] = {"unexpected": True}
        profile_case(
            "legacy_harmony_runtime_extension_is_rejected", parser_extension, False
        )

    report = {
        "schema_version": 1,
        "kind": "model-profile-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
