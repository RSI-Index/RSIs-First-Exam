#!/usr/bin/env python3
"""CPU contracts for isolated direct-A / ThunderAgent-B evidence evaluation."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = TASK_ROOT / "scripts" / "run-reference-pair.py"
STACK_PATH = TASK_ROOT / "scripts" / "calibration-stack.sh"


def load_runner() -> Any:
    spec = importlib.util.spec_from_file_location("reference_pair_runner", RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load reference pair runner")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def leg(mode: str, rate: float) -> dict[str, Any]:
    started_unix = 1_000.0
    elapsed_sec = 1_000 * 60.0 / rate
    ended_unix = started_unix + elapsed_sec
    value: dict[str, Any] = {
        "schema_version": 1,
        "run_id": f"run-{mode}",
        "mode": mode,
        "profile": "pressure",
        "profile_config": {
            "workflows": 192,
            "warmup_requests": 4,
            "concurrency": 192,
            "max_steps": 24,
        },
        "corpus_namespace": "calibration-pressure",
        "corpus_fingerprint": "a" * 64,
        "model_adapter": {"mode": "qwen36-text-bash-v1"},
        "model_provenance": {
            "revision": "6a9e13bd6fc8f0983b9b99948120bc37f49c13e9"
        },
        "release_id": "release",
        "controller_config_sha256": "c" * 64,
        "request_count": 1000,
        "workload_nonce_sha256": "b" * 64,
        "infrastructure_failure": None,
        "candidate_failure": None,
        "backend_audit": {
            "passed": True,
            "p95_gateway_wait_sec": 0.0,
            "p99_gateway_wait_sec": 0.0,
            "max_gateway_wait_sec": 0.0,
        },
        "warmup_audit": {"passed": True},
        "request_success_rate": 1.0,
        "started_unix": started_unix,
        "ended_unix": ended_unix,
        "elapsed_sec": elapsed_sec,
        "wall_elapsed_sec": elapsed_sec + 1.0,
        "measurement_window": {
            "configured": False,
            "deadline_reached": False,
            "termination": "finite_workload",
        },
        "agent_execution_interval": {
            "schema_version": 1,
            "start_event": "measured_leg_started",
            "end_event": "last_agent_run_termination",
            "duration_clock": "monotonic",
            "started_unix": started_unix,
            "ended_unix": ended_unix,
            "elapsed_sec": elapsed_sec,
            "expected_agent_runs": 192,
            "observed_agent_runs": 192,
            "complete": True,
        },
        "vllm_metrics": {
            "live_series": {"sampler_error_count": 0},
            "live_samples": [
                {"created_unix": started_unix, "kv_cache_usage": 0.9},
                {"created_unix": ended_unix, "kv_cache_usage": 0.8},
            ],
        },
        "pressure_validation": {"valid": True},
        "valid_steps_per_min": rate,
        "valid_steps": 1000,
        "valid_step_ratio": 0.99,
        "jain_progress_fairness": 1.0,
        "minimum_workflow_progress": 24,
        "p99_step_latency_sec": 100.0 if mode == "baseline" else 110.0,
        "tests_passed_workflows": 100,
        "completed_workflows": 0,
        "backend_tokens_per_valid_step": 100.0,
    }
    if mode == "candidate":
        value["backend_tokens_per_valid_step"] = 95.0
        value["program_lifecycle"] = {
            "enabled": True,
            "warmup": {
                "program_release_attempted": 4,
                "program_release_acknowledged": 4,
                "program_release_failed": 0,
            },
            "measured_attempted": 192,
            "measured_acknowledged": 192,
            "measured_unsupported": 0,
            "measured_failed": 0,
        }
    return value


def main() -> int:
    module = load_runner()
    scoring_policy = module.load_scoring_policy()
    baseline = leg("baseline", 100.0)
    candidate = leg("candidate", 120.0)
    tree_sha256 = module.reference_gateway_tree_sha256()
    health = {
        "reference_gateway_tree_sha256_at_start": tree_sha256,
        "scheduler": {
            "algorithm": "thunderagent-program-aware-single-backend",
            "scheduler_policy_schema_version": 4,
            "queue_policy": (
                "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"
            ),
            "fair_service_lag_steps": 1,
            "fair_service_until_step": 12,
            "deep_request_first_step": 13,
            "protected_request_policy": "v4-exact-through-step-12",
            "deep_request_policy": (
                "total_tokens-sjf-with-service-lag-bypass-from-step-13"
            ),
            "service_lag_scope": (
                "protected-reentry-vs-feasible-blocked-request-ordinal"
            ),
            "service_lag_comparison": (
                "protected_reentry_ordinal>least_waiting_ordinal+lag"
            ),
            "normal_restore_order": (
                "aged-then-protected-request-ordinal-then-deep-total-tokens-"
                "then-idle-acting"
            ),
            "deep_restore_order": (
                "total_tokens-then-request-wait-age-then-program-id"
            ),
            "deep_reentry_bypasses_service_lag": True,
            "fair_wait_threshold_sec": 220.0,
            "aged_resume_quota_per_tick": 4,
            "request_age_scope": "blocked_gateway_request_only",
            "aged_priority_scope": (
                "single-oldest-reservation-then-aged-quota-then-tiered-sjf"
            ),
            "aged_reservation_precedes_service_lag_order": True,
            "aged_reservation_owner_limit": 1,
            "aged_reservation_capacity_basis": (
                "full_phase_aware_decision_units"
            ),
            "aged_reservation_victim_policy": (
                "active-idle-acting-shortest-context-first"
            ),
            "aged_reservation_blocks_younger_restore": True,
            "aged_reservation_blocks_conflicting_reentry": True,
            "aged_reservation_inflight_reasoning_policy": "never_pause",
            "capacity_tokens": 1_887_738,
            "scheduler_interval_sec": 5.0,
            "acting_decay_base": 2.0,
            "buffer_per_program": 100,
            "high_watermark": 1.0,
            "low_watermark": 1.0,
            "accounting_schema_version": 3,
            "accounting_mode": "qwen36-vllm024-hybrid-state-aware-pages",
            "decision_unit": "kv_pages",
            "decision_capacity": 1_252,
            "raw_gpu_blocks": 1_253,
            "reserved_null_blocks": 1,
            "capacity_pages": 1_252,
            "attention_page_tokens": 1_568,
            "mamba_group_count": 3,
            "mamba_peak_pages_per_group": 2,
            "mamba_resident_pages_per_group": 1,
            "fixed_mamba_pages_per_program": 3,
            "transient_mamba_pages_per_program": 3,
            "peak_mamba_pages_per_reasoning_program": 6,
            "mamba_initial_uncached_pages_per_program": 3,
            "mamba_reservation_scope": "request_lifetime_peak",
            "mamba_reservation_phase": "reasoning_or_request_pending",
            "mamba_reservation_uses_agent_step_count": False,
            "decision_pages_are_reservations": True,
            "acting_attention_decay_scope": "restore_only",
            "decode_headroom_tokens": 100,
            "reported_logical_capacity_tokens": 1_887_738,
            "reported_logical_capacity_is_informational": True,
            "programs": 0,
            "programs_peak": 192,
            "scheduler_task_alive": True,
            "last_scheduler_error": None,
            "active": 0,
            "reasoning": 0,
            "acting": 0,
            "paused": 0,
            "service_lag_blocked": 0,
            "pending_request_waiters": 0,
            "protected_pending_request_waiters": 0,
            "deep_pending_request_waiters": 0,
            "aged_request_waiters": 0,
            "oldest_pending_request_wait_sec": 0.0,
            "aged_reservation_active": 0,
            "aged_reservation_required_capacity": 0,
            "aged_reservation_gap_capacity": 0,
            "aged_reservation_age_sec": 0.0,
            "marked_for_pause": 0,
            "terminating": 0,
            "tracked_tokens_full": 0.0,
            "tracked_tokens_with_decay": 0.0,
            "tracked_pages_full": 0,
            "tracked_pages_with_decay": 0,
            "tracked_attention_pages_full": 0,
            "tracked_attention_pages_with_decay": 0,
            "tracked_fixed_mamba_pages": 0,
            "tracked_reserved_transient_mamba_pages": 0,
            "reasoning_peak_reserved_programs": 0,
            "capacity_overflow_pages": 0,
            "first_pause_elapsed_sec": 12.0,
            "first_pause_reason": "admission_capacity",
            "first_pause_tracked_full": 1_900_000.0,
            "first_pause_tracked_pages_full": 1_253,
            "first_pause_overflow_pages": 1,
            "first_pause_attention_pages_full": 101,
            "first_pause_fixed_mamba_pages": 576,
            "first_pause_reserved_transient_mamba_pages": 576,
            "first_pause_reasoning_peak_reserved_programs": 192,
            "first_pause_active": 192,
            "first_resume_elapsed_sec": 17.0,
            "active_peak": 192,
            "paused_peak": 64,
            "service_lag_blocked_peak": 8,
            "pending_request_waiters_peak": 64,
            "protected_pending_request_waiters_peak": 40,
            "deep_pending_request_waiters_peak": 24,
            "aged_request_waiters_peak": 8,
            "oldest_pending_request_wait_sec_peak": 300.0,
            "aged_reservation_active_peak": 1,
            "aged_reservation_required_capacity_peak": 20,
            "aged_reservation_gap_capacity_peak": 10,
            "aged_reservation_age_sec_peak": 300.0,
            "aged_rescue_post_commit_overflow_peak": 0,
            "marked_for_pause_peak": 8,
            "tracked_tokens_full_peak": 1_900_000.0,
            "tracked_tokens_with_decay_peak": 1_850_000.0,
            "tracked_pages_full_peak": 1_253,
            "tracked_pages_with_decay_peak": 1_253,
            "tracked_attention_pages_full_peak": 101,
            "tracked_attention_pages_with_decay_peak": 101,
            "tracked_fixed_mamba_pages_peak": 576,
            "tracked_reserved_transient_mamba_pages_peak": 576,
            "reasoning_peak_reserved_programs_peak": 192,
            "pause_wait_count": 64,
            "pause_wait_total_sec": 320.0,
            "pause_wait_max_sec": 300.0,
            "protected_pause_wait_count": 40,
            "protected_pause_wait_total_sec": 300.0,
            "protected_pause_wait_max_sec": 300.0,
            "deep_pause_wait_count": 24,
            "deep_pause_wait_total_sec": 20.0,
            "deep_pause_wait_max_sec": 10.0,
            "scheduler_ticks": 100,
            "counters": {
                "pause_admission": 2,
                "pause_admission_new": 1,
                "pause_admission_reentry": 1,
                "pause_admission_aged_reservation": 1,
                "pause_admission_service_lag": 1,
                "protected_request_offers": 2000,
                "deep_request_offers": 1000,
                "deep_service_lag_bypass_decisions": 1,
                "pause_acting": 3,
                "pause_acting_pressure": 1,
                "pause_acting_aged_reservation": 2,
                "mark_reasoning": 1,
                "resume_pending": 2,
                "resume_new": 0,
                "resume_acting": 1,
                "resume_aged_pending": 1,
                "resume_aged_new": 0,
                "resume_aged_reservation_pending": 1,
                "resume_aged_reservation_new": 0,
                "resume_least_service_request": 1,
                "resume_protected_request": 1,
                "resume_deep_request": 1,
                "least_service_priority_ticks": 2,
                "deep_sjf_priority_ticks": 2,
                "mixed_request_tier_ticks": 1,
                "aged_priority_ticks": 10,
                "aged_capacity_skip_count": 2,
                "aged_no_fit_ticks": 1,
                "aged_quota_exhausted_ticks": 1,
                "aged_reservation_started": 1,
                "aged_reservation_satisfied": 1,
                "aged_reservation_cancelled": 0,
                "aged_reservation_oversize": 0,
                "aged_reservation_oversize_owner": 0,
                "aged_reservation_partial_ticks": 1,
                "aged_reservation_no_safe_victim_ticks": 1,
                "aged_reservation_blocked_reentry": 1,
                "aged_reservation_victims_paused": 2,
                "aged_reservation_capacity_freed": 20,
                "aged_reservation_post_commit_capacity_violations": 0,
                "force_resume": 0,
                "blocked_capacity_timeout": 0,
                "release": 196,
                "release_deferred": 0,
                "scheduler_errors": 0,
            },
        },
    }
    valid = module.evaluate_pair(
        baseline,
        candidate,
        nonce_sha256="b" * 64,
        minimum_speedup=1.0,
        gateway_after=health,
        expected_profile="pressure",
        expected_corpus_namespace="calibration-pressure",
        expected_tree_sha256=tree_sha256,
    )

    mutations: dict[str, tuple[dict[str, Any], dict[str, Any], dict[str, Any]]] = {}
    changed = copy.deepcopy(candidate)
    changed["workload_nonce_sha256"] = "c" * 64
    mutations["nonce_mismatch"] = (copy.deepcopy(baseline), changed, copy.deepcopy(health))
    changed = copy.deepcopy(candidate)
    changed["backend_audit"]["passed"] = False
    mutations["audit_failure"] = (copy.deepcopy(baseline), changed, copy.deepcopy(health))
    changed = copy.deepcopy(candidate)
    changed["tests_passed_workflows"] = 99
    mutations["quality_regression"] = (copy.deepcopy(baseline), changed, copy.deepcopy(health))
    low_absolute_baseline = copy.deepcopy(baseline)
    low_absolute_candidate = copy.deepcopy(candidate)
    low_absolute_baseline["valid_step_ratio"] = 0.89
    low_absolute_candidate["valid_step_ratio"] = 0.89
    mutations["absolute_quality_floor"] = (
        low_absolute_baseline,
        low_absolute_candidate,
        copy.deepcopy(health),
    )
    shallow_baseline = copy.deepcopy(baseline)
    shallow_candidate = copy.deepcopy(candidate)
    shallow_baseline["minimum_workflow_progress"] = 23
    shallow_candidate["minimum_workflow_progress"] = 23
    mutations["finite_progress_below_max_steps"] = (
        shallow_baseline,
        shallow_candidate,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["program_lifecycle"]["measured_acknowledged"] = 191
    mutations["release_leak"] = (copy.deepcopy(baseline), changed, copy.deepcopy(health))
    changed = copy.deepcopy(candidate)
    changed.pop("agent_execution_interval")
    mutations["missing_agent_execution_interval"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["agent_execution_interval"]["end_event"] = "verify_complete"
    mutations["wrong_agent_execution_end_event"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["agent_execution_interval"]["observed_agent_runs"] = 191
    mutations["incomplete_agent_execution_interval"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["agent_execution_interval"]["ended_unix"] -= 1.0
    mutations["agent_execution_top_level_mismatch"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["valid_steps_per_min"] = 121.0
    mutations["agent_execution_rate_identity_mismatch"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["vllm_metrics"]["live_samples"].append(
        {
            "created_unix": changed["ended_unix"] + 0.001,
            "kv_cache_usage": 0.7,
        }
    )
    mutations["post_agent_end_live_sample"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["vllm_metrics"]["live_samples"] = []
    mutations["empty_finite_live_samples"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["agent_execution_interval"]["unexpected"] = True
    mutations["finite_interval_extra_field"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["wall_elapsed_sec"] = changed["elapsed_sec"] - 0.001
    mutations["finite_wall_elapsed_precedes_interval"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["measurement_window"]["termination"] = "deadline"
    mutations["finite_measurement_window_drift"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["vllm_metrics"]["live_series"]["sampler_error_count"] = 1
    mutations["finite_metrics_sampler_error"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["valid_steps_per_min"] = 100.0
    mutations["no_speedup"] = (copy.deepcopy(baseline), changed, copy.deepcopy(health))
    mutations["gateway_state_leak"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        {
            "reference_gateway_tree_sha256_at_start": tree_sha256,
            "scheduler": {
                **copy.deepcopy(health["scheduler"]),
                "programs": 1,
            },
        },
    )
    insufficient_peak_health = copy.deepcopy(health)
    insufficient_peak_health["scheduler"]["programs_peak"] = 191
    mutations["insufficient_programs_peak"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        insufficient_peak_health,
    )
    dead_scheduler_health = copy.deepcopy(health)
    dead_scheduler_health["scheduler"]["scheduler_task_alive"] = False
    mutations["dead_scheduler_task"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        dead_scheduler_health,
    )
    scheduler_error_health = copy.deepcopy(health)
    scheduler_error_health["scheduler"]["last_scheduler_error"] = "RuntimeError"
    scheduler_error_health["scheduler"]["counters"]["scheduler_errors"] = 1
    mutations["scheduler_tick_error"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        scheduler_error_health,
    )
    warmup_only_pause_health = copy.deepcopy(health)
    warmup_only_pause_health["scheduler"]["first_pause_active"] = 4
    warmup_only_pause_health["scheduler"]["first_pause_fixed_mamba_pages"] = 12
    warmup_only_pause_health["scheduler"][
        "first_pause_reserved_transient_mamba_pages"
    ] = 12
    warmup_only_pause_health["scheduler"][
        "first_pause_reasoning_peak_reserved_programs"
    ] = 4
    warmup_only_pause_health["scheduler"]["first_pause_attention_pages_full"] = (
        1_229
    )
    warmup_only_pause_health["scheduler"]["tracked_attention_pages_full_peak"] = (
        1_229
    )
    mutations["warmup_only_first_pause"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        warmup_only_pause_health,
    )
    missing_scheduler_telemetry_health = copy.deepcopy(health)
    missing_scheduler_telemetry_health["scheduler"].pop(
        "first_resume_elapsed_sec"
    )
    mutations["missing_scheduler_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_scheduler_telemetry_health,
    )
    old_token_linear_health = copy.deepcopy(health)
    old_token_linear_health["scheduler"]["buffer_per_program"] = 1_568
    old_token_linear_health["scheduler"]["accounting_mode"] = "token-linear"
    old_token_linear_health["scheduler"]["decision_unit"] = "tokens"
    mutations["old_token_linear_1568_contract"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        old_token_linear_health,
    )
    legacy_schema2_health = copy.deepcopy(health)
    legacy_schema2_health["scheduler"]["accounting_schema_version"] = 2
    legacy_schema2_health["scheduler"][
        "accounting_mode"
    ] = "qwen36-vllm024-hybrid-pages"
    mutations["legacy_schema2_contract"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        legacy_schema2_health,
    )
    legacy_scheduler_policy_health = copy.deepcopy(health)
    legacy_scheduler_policy_health["scheduler"][
        "scheduler_policy_schema_version"
    ] = 0
    mutations["legacy_scheduler_policy_contract"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        legacy_scheduler_policy_health,
    )
    wrong_service_lag_health = copy.deepcopy(health)
    wrong_service_lag_health["scheduler"]["fair_service_lag_steps"] = 2
    mutations["wrong_service_lag_contract"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wrong_service_lag_health,
    )
    wrong_tier_cutoff_health = copy.deepcopy(health)
    wrong_tier_cutoff_health["scheduler"]["fair_service_until_step"] = 11
    mutations["wrong_tier_cutoff_contract"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wrong_tier_cutoff_health,
    )
    missing_tier_telemetry_health = copy.deepcopy(health)
    missing_tier_telemetry_health["scheduler"].pop(
        "deep_pending_request_waiters_peak"
    )
    mutations["missing_tier_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_tier_telemetry_health,
    )
    wait_tier_partition_health = copy.deepcopy(health)
    wait_tier_partition_health["scheduler"]["deep_pause_wait_count"] = 23
    mutations["wait_tier_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wait_tier_partition_health,
    )
    resume_tier_partition_health = copy.deepcopy(health)
    resume_tier_partition_health["scheduler"]["counters"][
        "resume_deep_request"
    ] = 0
    mutations["resume_tier_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        resume_tier_partition_health,
    )
    hidden_without_deep_witness_health = copy.deepcopy(health)
    hidden_without_deep_witness_health["scheduler"].update(
        {
            "protected_pending_request_waiters_peak": 64,
            "deep_pending_request_waiters_peak": 0,
            "protected_pause_wait_count": 64,
            "protected_pause_wait_total_sec": 320.0,
            "protected_pause_wait_max_sec": 300.0,
            "deep_pause_wait_count": 0,
            "deep_pause_wait_total_sec": 0.0,
            "deep_pause_wait_max_sec": 0.0,
        }
    )
    hidden_without_deep_witness_health["scheduler"]["counters"].update(
        {
            "deep_request_offers": 0,
            "deep_service_lag_bypass_decisions": 0,
            "resume_protected_request": 2,
            "resume_deep_request": 0,
            "deep_sjf_priority_ticks": 0,
            "mixed_request_tier_ticks": 0,
        }
    )
    mutations["hidden_without_deep_witness"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        hidden_without_deep_witness_health,
    )
    public_baseline = copy.deepcopy(baseline)
    public_candidate = copy.deepcopy(candidate)
    for public_leg in (public_baseline, public_candidate):
        public_leg["profile_config"]["measurement_window_sec"] = 1800
        public_leg.pop("agent_execution_interval")
        public_leg["measurement_window"] = {
            "schema_version": 1,
            "configured": True,
            "duration_sec": 1800,
            "deadline_reached": True,
            "termination": "trusted_fixed_window",
            "control_passed": True,
            "passed": True,
            "measurement_elapsed_sec": 1800.0,
            "zero_progress_fraction": 0.05,
        }
    # Fixed-window p99 is right-censored and must not be interpreted as the
    # finite-cohort tail gate used by hidden/reference qualification.
    public_candidate["p99_step_latency_sec"] = 10_000.0
    valid_public_window = module.evaluate_pair(
        public_baseline,
        public_candidate,
        nonce_sha256="b" * 64,
        minimum_speedup=1.0,
        gateway_after=health,
        expected_profile="pressure",
        expected_corpus_namespace="calibration-pressure",
        expected_tree_sha256=tree_sha256,
    )
    wrong_age_threshold_health = copy.deepcopy(health)
    wrong_age_threshold_health["scheduler"]["fair_wait_threshold_sec"] = 300.0
    mutations["wrong_bounded_age_threshold"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wrong_age_threshold_health,
    )
    wrong_age_quota_health = copy.deepcopy(health)
    wrong_age_quota_health["scheduler"]["aged_resume_quota_per_tick"] = 8
    mutations["wrong_bounded_age_quota"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wrong_age_quota_health,
    )
    wrong_reservation_basis_health = copy.deepcopy(health)
    wrong_reservation_basis_health["scheduler"][
        "aged_reservation_capacity_basis"
    ] = "decayed_decision_units"
    mutations["wrong_reservation_capacity_basis"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wrong_reservation_basis_health,
    )
    wrong_inflight_policy_health = copy.deepcopy(health)
    wrong_inflight_policy_health["scheduler"][
        "aged_reservation_inflight_reasoning_policy"
    ] = "mark_as_free"
    mutations["wrong_reservation_inflight_policy"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wrong_inflight_policy_health,
    )
    missing_age_telemetry_health = copy.deepcopy(health)
    missing_age_telemetry_health["scheduler"].pop(
        "oldest_pending_request_wait_sec_peak"
    )
    mutations["missing_bounded_age_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_age_telemetry_health,
    )
    missing_service_lag_telemetry_health = copy.deepcopy(health)
    missing_service_lag_telemetry_health["scheduler"].pop(
        "service_lag_blocked_peak"
    )
    mutations["missing_service_lag_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_service_lag_telemetry_health,
    )
    dormant_service_lag_health = copy.deepcopy(health)
    dormant_service_lag_health["scheduler"]["service_lag_blocked_peak"] = 0
    dormant_service_lag_health["scheduler"]["counters"][
        "pause_admission_service_lag"
    ] = 0
    dormant_service_lag_health["scheduler"]["counters"][
        "least_service_priority_ticks"
    ] = 0
    dormant_service_lag_health["scheduler"]["counters"][
        "resume_least_service_request"
    ] = 0
    mutations["service_lag_not_triggered"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        dormant_service_lag_health,
    )
    missing_reservation_telemetry_health = copy.deepcopy(health)
    missing_reservation_telemetry_health["scheduler"].pop(
        "aged_reservation_gap_capacity_peak"
    )
    mutations["missing_reservation_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_reservation_telemetry_health,
    )
    stale_reservation_gauge_health = copy.deepcopy(health)
    stale_reservation_gauge_health["scheduler"]["aged_reservation_active"] = 1
    stale_reservation_gauge_health["scheduler"][
        "aged_reservation_required_capacity"
    ] = 20
    stale_reservation_gauge_health["scheduler"][
        "aged_reservation_gap_capacity"
    ] = 10
    stale_reservation_gauge_health["scheduler"][
        "aged_reservation_age_sec"
    ] = 300.0
    mutations["stale_reservation_after_release"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        stale_reservation_gauge_health,
    )
    reservation_partition_health = copy.deepcopy(health)
    reservation_partition_health["scheduler"]["counters"][
        "aged_reservation_started"
    ] = 2
    mutations["reservation_lifecycle_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        reservation_partition_health,
    )
    acting_partition_health = copy.deepcopy(health)
    acting_partition_health["scheduler"]["counters"][
        "pause_acting_pressure"
    ] = 2
    mutations["reservation_acting_pause_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        acting_partition_health,
    )
    reentry_partition_health = copy.deepcopy(health)
    reentry_partition_health["scheduler"]["counters"][
        "aged_reservation_blocked_reentry"
    ] = 0
    mutations["reservation_reentry_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        reentry_partition_health,
    )
    victim_partition_health = copy.deepcopy(health)
    victim_partition_health["scheduler"]["counters"][
        "aged_reservation_victims_paused"
    ] = 1
    mutations["reservation_victim_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        victim_partition_health,
    )
    rescue_overflow_health = copy.deepcopy(health)
    rescue_overflow_health["scheduler"][
        "aged_rescue_post_commit_overflow_peak"
    ] = 1
    rescue_overflow_health["scheduler"]["counters"][
        "aged_reservation_post_commit_capacity_violations"
    ] = 1
    mutations["reservation_post_commit_capacity_violation"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        rescue_overflow_health,
    )
    aged_counter_partition_health = copy.deepcopy(health)
    aged_counter_partition_health["scheduler"]["counters"][
        "resume_aged_pending"
    ] = 3
    mutations["aged_resume_counter_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        aged_counter_partition_health,
    )
    stale_age_gauge_health = copy.deepcopy(health)
    stale_age_gauge_health["scheduler"]["pending_request_waiters"] = 1
    stale_age_gauge_health["scheduler"]["oldest_pending_request_wait_sec"] = 1.0
    mutations["stale_bounded_age_gauge_after_release"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        stale_age_gauge_health,
    )
    current_above_peak_health = copy.deepcopy(health)
    current_above_peak_health["scheduler"]["paused"] = 65
    current_above_peak_health["scheduler"]["pending_request_waiters"] = 65
    current_above_peak_health["scheduler"]["aged_request_waiters"] = 9
    current_above_peak_health["scheduler"][
        "oldest_pending_request_wait_sec"
    ] = 300.0
    mutations["bounded_age_current_exceeds_peak"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        current_above_peak_health,
    )
    missing_priority_witness_health = copy.deepcopy(health)
    missing_priority_witness_health["scheduler"]["aged_request_waiters_peak"] = 0
    missing_priority_witness_health["scheduler"][
        "oldest_pending_request_wait_sec_peak"
    ] = 0.0
    missing_priority_witness_health["scheduler"]["counters"][
        "resume_aged_pending"
    ] = 0
    missing_priority_witness_health["scheduler"]["counters"][
        "aged_priority_ticks"
    ] = 1
    mutations["aged_priority_without_peak_witness"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_priority_witness_health,
    )
    quota_violation_health = copy.deepcopy(health)
    quota_violation_health["scheduler"]["counters"]["resume_pending"] = 41
    quota_violation_health["scheduler"]["counters"][
        "resume_aged_pending"
    ] = 41
    mutations["aged_resume_exceeds_tick_quota"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        quota_violation_health,
    )
    wait_without_peak_health = copy.deepcopy(health)
    wait_without_peak_health["scheduler"]["pending_request_waiters_peak"] = 0
    wait_without_peak_health["scheduler"]["aged_request_waiters_peak"] = 0
    wait_without_peak_health["scheduler"][
        "oldest_pending_request_wait_sec_peak"
    ] = 0.0
    for key in (
        "resume_aged_pending",
        "resume_aged_new",
        "aged_priority_ticks",
        "aged_capacity_skip_count",
        "aged_no_fit_ticks",
        "aged_quota_exhausted_ticks",
    ):
        wait_without_peak_health["scheduler"]["counters"][key] = 0
    mutations["pause_wait_without_pending_peak"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        wait_without_peak_health,
    )
    blocked_timeout_health = copy.deepcopy(health)
    blocked_timeout_health["scheduler"]["counters"][
        "blocked_capacity_timeout"
    ] = 1
    mutations["blocked_capacity_timeout"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        blocked_timeout_health,
    )
    legacy_peak_as_steady_health = copy.deepcopy(health)
    legacy_peak_as_steady_health["scheduler"]["accounting_schema_version"] = 1
    legacy_peak_as_steady_health["scheduler"].pop(
        "mamba_resident_pages_per_group"
    )
    legacy_peak_as_steady_health["scheduler"].pop(
        "transient_mamba_pages_per_program"
    )
    legacy_peak_as_steady_health["scheduler"][
        "fixed_mamba_pages_per_program"
    ] = 6
    mutations["legacy_v1_peak6_as_steady_contract"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        legacy_peak_as_steady_health,
    )
    transient_peak_as_steady_health = copy.deepcopy(health)
    transient_peak_as_steady_health["scheduler"][
        "first_pause_attention_pages_full"
    ] = 101
    transient_peak_as_steady_health["scheduler"][
        "first_pause_fixed_mamba_pages"
    ] = 1_152
    transient_peak_as_steady_health["scheduler"][
        "tracked_attention_pages_full_peak"
    ] = 101
    transient_peak_as_steady_health["scheduler"][
        "tracked_attention_pages_with_decay_peak"
    ] = 98
    transient_peak_as_steady_health["scheduler"][
        "tracked_fixed_mamba_pages_peak"
    ] = 1_152
    mutations["transient_peak6_misreported_as_steady_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        transient_peak_as_steady_health,
    )
    missing_page_telemetry_health = copy.deepcopy(health)
    missing_page_telemetry_health["scheduler"].pop(
        "first_pause_tracked_pages_full"
    )
    mutations["missing_page_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_page_telemetry_health,
    )
    missing_reserved_component_health = copy.deepcopy(health)
    missing_reserved_component_health["scheduler"].pop(
        "tracked_reserved_transient_mamba_pages_peak"
    )
    mutations["missing_reserved_transient_telemetry"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        missing_reserved_component_health,
    )
    invalid_page_components_health = copy.deepcopy(health)
    invalid_page_components_health["scheduler"][
        "first_pause_attention_pages_full"
    ] = 100
    mutations["invalid_page_component_sum"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        invalid_page_components_health,
    )
    invalid_page_overflow_health = copy.deepcopy(health)
    invalid_page_overflow_health["scheduler"]["first_pause_overflow_pages"] = 0
    mutations["invalid_page_overflow"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        invalid_page_overflow_health,
    )
    invalid_page_decay_health = copy.deepcopy(health)
    invalid_page_decay_health["scheduler"]["tracked_pages_with_decay_peak"] = (
        1_254
    )
    mutations["page_decay_exceeds_full"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        invalid_page_decay_health,
    )
    changed = copy.deepcopy(candidate)
    changed["backend_audit"].pop("p99_gateway_wait_sec")
    mutations["missing_gateway_wait_metric"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["backend_tokens_per_valid_step"] = 84.9
    mutations["backend_work_below_lower_bound"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["backend_tokens_per_valid_step"] = 102.1
    mutations["backend_work_above_upper_bound"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["request_count"] = 1051
    mutations["request_count_outside_tolerance"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["backend_audit"]["p99_gateway_wait_sec"] = (
        float(scoring_policy["max_p99_gateway_wait_sec"]) + 0.1
    )
    mutations["p99_gateway_wait_above_bound"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    changed["p99_step_latency_sec"] = (
        float(baseline["p99_step_latency_sec"])
        * float(scoring_policy["max_p99_step_latency_ratio"])
        + 0.1
    )
    mutations["finite_p99_step_latency_ratio_above_bound"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    changed = copy.deepcopy(candidate)
    for key in (
        "profile",
        "corpus_namespace",
        "corpus_fingerprint",
        "model_adapter",
        "model_provenance",
        "release_id",
        "controller_config_sha256",
        "request_count",
        "jain_progress_fairness",
        "minimum_workflow_progress",
        "tests_passed_workflows",
        "completed_workflows",
    ):
        changed.pop(key, None)
    mutations["missing_identity_and_quality_fields"] = (
        copy.deepcopy(baseline),
        changed,
        copy.deepcopy(health),
    )
    no_decisions_health = copy.deepcopy(health)
    for key in (
        "pause_admission",
        "pause_admission_new",
        "pause_admission_reentry",
        "pause_acting",
        "mark_reasoning",
        "resume_pending",
        "resume_new",
        "resume_acting",
    ):
        no_decisions_health["scheduler"]["counters"][key] = 0
    mutations["scheduler_not_triggered"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        no_decisions_health,
    )
    split_counter_mismatch_health = copy.deepcopy(health)
    split_counter_mismatch_health["scheduler"]["counters"][
        "pause_admission_reentry"
    ] = 0
    mutations["admission_counter_partition_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        split_counter_mismatch_health,
    )
    release_mismatch_health = copy.deepcopy(health)
    release_mismatch_health["scheduler"]["counters"]["release"] = 195
    mutations["gateway_release_counter_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        release_mismatch_health,
    )
    tree_mismatch_health = copy.deepcopy(health)
    tree_mismatch_health["reference_gateway_tree_sha256_at_start"] = "d" * 64
    mutations["gateway_tree_mismatch"] = (
        copy.deepcopy(baseline),
        copy.deepcopy(candidate),
        tree_mismatch_health,
    )
    mutation_evaluations = {
        name: module.evaluate_pair(
            base,
            cand,
            nonce_sha256="b" * 64,
            minimum_speedup=1.0,
            gateway_after=after,
            expected_profile="pressure",
            expected_corpus_namespace="calibration-pressure",
            expected_tree_sha256=tree_sha256,
        )
        for name, (base, cand, after) in mutations.items()
    }
    mutation_results = {
        name: evaluation["passed"]
        for name, evaluation in mutation_evaluations.items()
    }
    requested_gate_mutations = {
        "insufficient_programs_peak": (
            mutation_evaluations["insufficient_programs_peak"]["contracts"][
                "oracle_registered_full_agent_concurrency"
            ]
            is False
        ),
        "dead_scheduler_task": (
            mutation_evaluations["dead_scheduler_task"]["contracts"][
                "oracle_scheduler_task_alive"
            ]
            is False
        ),
        "scheduler_tick_error": (
            mutation_evaluations["scheduler_tick_error"]["contracts"][
                "oracle_scheduler_error_free"
            ]
            is False
        ),
        "warmup_only_first_pause": (
            mutation_evaluations["warmup_only_first_pause"]["contracts"][
                "oracle_first_pause_belongs_to_measured_workload"
            ]
            is False
            and mutation_evaluations["warmup_only_first_pause"]["contracts"][
                "oracle_scheduler_telemetry_complete_and_sane"
            ]
            is True
        ),
        "missing_scheduler_telemetry": (
            mutation_evaluations["missing_scheduler_telemetry"]["contracts"][
                "oracle_scheduler_telemetry_complete_and_sane"
            ]
            is False
        ),
        "missing_agent_execution_interval": (
            mutation_evaluations["missing_agent_execution_interval"][
                "contracts"
            ]["candidate_agent_execution_interval_contract"]
            is False
        ),
        "wrong_agent_execution_end_event": (
            mutation_evaluations["wrong_agent_execution_end_event"][
                "contracts"
            ]["candidate_agent_execution_interval_contract"]
            is False
        ),
        "incomplete_agent_execution_interval": (
            mutation_evaluations["incomplete_agent_execution_interval"][
                "contracts"
            ]["candidate_agent_execution_interval_contract"]
            is False
        ),
        "agent_execution_top_level_mismatch": (
            mutation_evaluations["agent_execution_top_level_mismatch"][
                "contracts"
            ]["candidate_agent_execution_interval_contract"]
            is False
        ),
        "agent_execution_rate_identity_mismatch": (
            mutation_evaluations["agent_execution_rate_identity_mismatch"][
                "contracts"
            ]["candidate_agent_execution_interval_contract"]
            is False
        ),
        "post_agent_end_live_sample": (
            mutation_evaluations["post_agent_end_live_sample"]["contracts"]
            ["candidate_agent_execution_interval_contract"]
            is False
        ),
        "empty_finite_live_samples": (
            mutation_evaluations["empty_finite_live_samples"]["contracts"]
            ["candidate_agent_execution_interval_contract"]
            is False
        ),
        "finite_interval_extra_field": (
            mutation_evaluations["finite_interval_extra_field"]["contracts"]
            ["candidate_agent_execution_interval_contract"]
            is False
        ),
        "finite_wall_elapsed_precedes_interval": (
            mutation_evaluations["finite_wall_elapsed_precedes_interval"]
            ["contracts"]["candidate_agent_execution_interval_contract"]
            is False
        ),
        "finite_measurement_window_drift": (
            mutation_evaluations["finite_measurement_window_drift"]["contracts"]
            ["candidate_agent_execution_interval_contract"]
            is False
        ),
        "finite_metrics_sampler_error": (
            mutation_evaluations["finite_metrics_sampler_error"]["contracts"]
            ["candidate_agent_execution_interval_contract"]
            is False
        ),
        "old_token_linear_1568_contract": (
            mutation_evaluations["old_token_linear_1568_contract"]["contracts"][
                "oracle_qwen_hybrid_page_accounting_contract"
            ]
            is False
            and mutation_evaluations["old_token_linear_1568_contract"][
                "contracts"
            ]["oracle_page_telemetry_complete_and_sane"]
            is True
        ),
        "legacy_schema2_contract": (
            mutation_evaluations["legacy_schema2_contract"]["contracts"][
                "oracle_qwen_hybrid_page_accounting_contract"
            ]
            is False
            and mutation_evaluations["legacy_schema2_contract"]["contracts"][
                "oracle_page_telemetry_complete_and_sane"
            ]
            is True
        ),
        "legacy_scheduler_policy_contract": (
            mutation_evaluations["legacy_scheduler_policy_contract"][
                "contracts"
            ]["oracle_bounded_request_age_policy_contract"]
            is False
            and mutation_evaluations["legacy_scheduler_policy_contract"][
                "contracts"
            ]["oracle_qwen_hybrid_page_accounting_contract"]
            is True
        ),
        "wrong_service_lag_contract": (
            mutation_evaluations["wrong_service_lag_contract"]["contracts"]
            ["oracle_bounded_request_age_policy_contract"]
            is False
        ),
        "wrong_tier_cutoff_contract": (
            mutation_evaluations["wrong_tier_cutoff_contract"]["contracts"]
            ["oracle_bounded_request_age_policy_contract"]
            is False
        ),
        "missing_tier_telemetry": (
            mutation_evaluations["missing_tier_telemetry"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "wait_tier_partition_mismatch": (
            mutation_evaluations["wait_tier_partition_mismatch"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "resume_tier_partition_mismatch": (
            mutation_evaluations["resume_tier_partition_mismatch"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "hidden_without_deep_witness": (
            mutation_evaluations["hidden_without_deep_witness"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is True
            and mutation_evaluations["hidden_without_deep_witness"][
                "contracts"
            ]["oracle_deep_tier_matches_measurement_shape"]
            is False
        ),
        "wrong_bounded_age_threshold": (
            mutation_evaluations["wrong_bounded_age_threshold"]["contracts"][
                "oracle_bounded_request_age_policy_contract"
            ]
            is False
        ),
        "wrong_bounded_age_quota": (
            mutation_evaluations["wrong_bounded_age_quota"]["contracts"][
                "oracle_bounded_request_age_policy_contract"
            ]
            is False
        ),
        "wrong_reservation_capacity_basis": (
            mutation_evaluations["wrong_reservation_capacity_basis"][
                "contracts"
            ]["oracle_bounded_request_age_policy_contract"]
            is False
        ),
        "wrong_reservation_inflight_policy": (
            mutation_evaluations["wrong_reservation_inflight_policy"][
                "contracts"
            ]["oracle_bounded_request_age_policy_contract"]
            is False
        ),
        "missing_bounded_age_telemetry": (
            mutation_evaluations["missing_bounded_age_telemetry"]["contracts"][
                "oracle_bounded_request_age_telemetry_complete_and_sane"
            ]
            is False
        ),
        "missing_service_lag_telemetry": (
            mutation_evaluations["missing_service_lag_telemetry"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "service_lag_not_triggered": (
            mutation_evaluations["service_lag_not_triggered"]["contracts"]
            ["oracle_service_lag_was_triggered"]
            is False
            and mutation_evaluations["service_lag_not_triggered"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is True
        ),
        "missing_reservation_telemetry": (
            mutation_evaluations["missing_reservation_telemetry"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "stale_reservation_after_release": (
            mutation_evaluations["stale_reservation_after_release"]["contracts"]
            ["gateway_working_set_released"]
            is False
            and mutation_evaluations["stale_reservation_after_release"][
                "contracts"
            ]["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "reservation_lifecycle_partition_mismatch": (
            mutation_evaluations["reservation_lifecycle_partition_mismatch"]
            ["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "reservation_acting_pause_partition_mismatch": (
            mutation_evaluations[
                "reservation_acting_pause_partition_mismatch"
            ]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "reservation_reentry_partition_mismatch": (
            mutation_evaluations["reservation_reentry_partition_mismatch"]
            ["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "reservation_victim_partition_mismatch": (
            mutation_evaluations["reservation_victim_partition_mismatch"]
            ["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "reservation_post_commit_capacity_violation": (
            mutation_evaluations[
                "reservation_post_commit_capacity_violation"
            ]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "aged_resume_counter_partition_mismatch": (
            mutation_evaluations["aged_resume_counter_partition_mismatch"][
                "contracts"
            ]["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "stale_bounded_age_gauge_after_release": (
            mutation_evaluations["stale_bounded_age_gauge_after_release"][
                "contracts"
            ]["gateway_working_set_released"]
            is False
            and mutation_evaluations["stale_bounded_age_gauge_after_release"][
                "contracts"
            ]["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "bounded_age_current_exceeds_peak": (
            mutation_evaluations["bounded_age_current_exceeds_peak"][
                "contracts"
            ]["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "aged_priority_without_peak_witness": (
            mutation_evaluations["aged_priority_without_peak_witness"][
                "contracts"
            ]["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "aged_resume_exceeds_tick_quota": (
            mutation_evaluations["aged_resume_exceeds_tick_quota"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "pause_wait_without_pending_peak": (
            mutation_evaluations["pause_wait_without_pending_peak"]["contracts"]
            ["oracle_bounded_request_age_telemetry_complete_and_sane"]
            is False
        ),
        "blocked_capacity_timeout": (
            mutation_evaluations["blocked_capacity_timeout"]["contracts"][
                "oracle_had_no_blocked_capacity_timeout"
            ]
            is False
        ),
        "legacy_v1_peak6_as_steady_contract": (
            mutation_evaluations["legacy_v1_peak6_as_steady_contract"][
                "contracts"
            ]["oracle_qwen_hybrid_page_accounting_contract"]
            is False
            and mutation_evaluations["legacy_v1_peak6_as_steady_contract"][
                "contracts"
            ]["oracle_page_telemetry_complete_and_sane"]
            is True
        ),
        "transient_peak6_misreported_as_steady_telemetry": (
            mutation_evaluations[
                "transient_peak6_misreported_as_steady_telemetry"
            ]["contracts"]["oracle_qwen_hybrid_page_accounting_contract"]
            is True
            and mutation_evaluations[
                "transient_peak6_misreported_as_steady_telemetry"
            ]["contracts"]["oracle_page_telemetry_complete_and_sane"]
            is False
        ),
        "missing_page_telemetry": (
            mutation_evaluations["missing_page_telemetry"]["contracts"][
                "oracle_page_telemetry_complete_and_sane"
            ]
            is False
        ),
        "missing_reserved_transient_telemetry": (
            mutation_evaluations["missing_reserved_transient_telemetry"][
                "contracts"
            ]["oracle_page_telemetry_complete_and_sane"]
            is False
        ),
        "invalid_page_component_sum": (
            mutation_evaluations["invalid_page_component_sum"]["contracts"][
                "oracle_page_telemetry_complete_and_sane"
            ]
            is False
        ),
        "invalid_page_overflow": (
            mutation_evaluations["invalid_page_overflow"]["contracts"][
                "oracle_page_telemetry_complete_and_sane"
            ]
            is False
        ),
        "page_decay_exceeds_full": (
            mutation_evaluations["page_decay_exceeds_full"]["contracts"][
                "oracle_page_telemetry_complete_and_sane"
            ]
            is False
        ),
        "missing_gateway_wait_metric": (
            mutation_evaluations["missing_gateway_wait_metric"]["contracts"][
                "candidate_gateway_wait_metrics_present"
            ]
            is False
        ),
        "absolute_quality_floor": (
            mutation_evaluations["absolute_quality_floor"]["quality"][
                "baseline_absolute_quality"
            ]
            is False
            and mutation_evaluations["absolute_quality_floor"]["quality"][
                "candidate_absolute_quality"
            ]
            is False
        ),
        "finite_progress_below_max_steps": (
            mutation_evaluations["finite_progress_below_max_steps"]["quality"]
            ["baseline_absolute_quality"]
            is False
            and mutation_evaluations["finite_progress_below_max_steps"][
                "quality"
            ]["candidate_absolute_quality"]
            is False
        ),
        "backend_work_below_lower_bound": (
            mutation_evaluations["backend_work_below_lower_bound"]["quality"][
                "backend_work_per_step_not_deflated"
            ]
            is False
        ),
        "backend_work_above_upper_bound": (
            mutation_evaluations["backend_work_above_upper_bound"]["quality"][
                "backend_work_per_step_not_inflated"
            ]
            is False
        ),
        "request_count_outside_tolerance": (
            mutation_evaluations["request_count_outside_tolerance"]["contracts"][
                "request_count_within_five_percent"
            ]
            is False
        ),
        "p99_gateway_wait_above_bound": (
            mutation_evaluations["p99_gateway_wait_above_bound"]["quality"][
                "candidate_p99_gateway_wait_bounded"
            ]
            is False
        ),
        "finite_p99_step_latency_ratio_above_bound": (
            mutation_evaluations["finite_p99_step_latency_ratio_above_bound"][
                "quality"
            ]["finite_position_paired_p99_step_latency_bounded"]
            is False
            and mutation_evaluations[
                "finite_p99_step_latency_ratio_above_bound"
            ]["tail_anti_gaming"]["evaluated"]
            is True
        ),
        "admission_counter_partition_mismatch": (
            mutation_evaluations["admission_counter_partition_mismatch"][
                "contracts"
            ]["oracle_admission_counter_partition_is_exact"]
            is False
        ),
    }

    stack = STACK_PATH.read_text()
    runner = RUNNER_PATH.read_text()
    digest = tree_sha256
    valid_nonce_is_accepted = (
        module.validate_workload_nonce("a" * 64) == "a" * 64
    )
    invalid_nonce_rejections = []
    for invalid_nonce in ("a" * 63, "A" * 64, "g" * 64, "a" * 65):
        try:
            module.validate_workload_nonce(invalid_nonce)
        except ValueError:
            invalid_nonce_rejections.append(True)
        else:
            invalid_nonce_rejections.append(False)
    public_interval_free_leg = copy.deepcopy(candidate)
    public_interval_free_leg.pop("agent_execution_interval")
    public_interval_free_leg["measurement_window"] = {"configured": True}
    public_interval_leak_leg = copy.deepcopy(public_interval_free_leg)
    public_interval_leak_leg["agent_execution_interval"] = copy.deepcopy(
        candidate["agent_execution_interval"]
    )

    private_nonce = "unit-private-public-anchor-nonce"
    private_nonce_sha256 = hashlib.sha256(private_nonce.encode()).hexdigest()
    public_anchor_baseline = copy.deepcopy(baseline)
    public_anchor_candidate = copy.deepcopy(candidate)
    for public_leg in (public_anchor_baseline, public_anchor_candidate):
        public_leg["profile"] = module.RELEASE_PUBLIC_PROFILE
        public_leg["corpus_namespace"] = (
            f"{module.RELEASE_PUBLIC_SUITE}-{module.RELEASE_PUBLIC_PROFILE}"
        )
        public_leg["release_id"] = module.RELEASE_ID
        public_leg["workload_nonce_sha256"] = private_nonce_sha256
    public_anchor_report = {
        "status": "complete",
        "passed": True,
        "suite": module.RELEASE_PUBLIC_SUITE,
        "profile": module.RELEASE_PUBLIC_PROFILE,
        "workload_nonce_sha256": private_nonce_sha256,
        "controller": {"image_id": "sha256:" + "d" * 64},
        "legs": {
            "baseline": public_anchor_baseline,
            "candidate": public_anchor_candidate,
        },
        "evaluation": {"passed": True},
    }
    public_anchor = module.build_public_direct_anchor(
        report=public_anchor_report,
        workload_nonce=private_nonce,
        source_report_sha256="e" * 64,
        scoring_policy=scoring_policy,
        scoring_policy_sha256="f" * 64,
    )
    with tempfile.TemporaryDirectory(prefix="kvbench-anchor-unit-") as temporary:
        anchor_path = Path(temporary) / "release" / "public-direct-anchor.json"
        resolved_anchor = module.public_anchor_output_path(
            anchor_path,
            suite=module.RELEASE_PUBLIC_SUITE,
            profile=module.RELEASE_PUBLIC_PROFILE,
            pair_output=Path(temporary) / "pair.json",
        )
        module.atomic_create_private_json(resolved_anchor, public_anchor)
        anchor_bytes_before_refusal = resolved_anchor.read_bytes()
        anchor_mode = stat.S_IMODE(resolved_anchor.stat().st_mode)
        anchor_payload = json.loads(anchor_bytes_before_refusal)
        overwrite_refused = False
        try:
            module.atomic_create_private_json(resolved_anchor, {"replacement": True})
        except RuntimeError:
            overwrite_refused = True
        outside_only_rejections = []
        for invalid_suite, invalid_profile, invalid_path in (
            ("hidden", module.RELEASE_PUBLIC_PROFILE, anchor_path),
            (module.RELEASE_PUBLIC_SUITE, "wrong-profile", anchor_path),
            (
                module.RELEASE_PUBLIC_SUITE,
                module.RELEASE_PUBLIC_PROFILE,
                resolved_anchor,
            ),
            (
                module.RELEASE_PUBLIC_SUITE,
                module.RELEASE_PUBLIC_PROFILE,
                TASK_ROOT / "private-anchor-must-not-live-here.json",
            ),
        ):
            try:
                module.public_anchor_output_path(
                    invalid_path,
                    suite=invalid_suite,
                    profile=invalid_profile,
                    pair_output=Path(temporary) / "pair.json",
                )
            except ValueError:
                outside_only_rejections.append(True)
            else:
                outside_only_rejections.append(False)
        private_anchor_checks = {
            "release_id_is_r2": (
                module.RELEASE_ID == "qwen36-27b-tp2-public30-v7-r1"
                and anchor_payload["release_id"] == module.RELEASE_ID
                and anchor_payload["policy_release_id"] == module.RELEASE_ID
            ),
            "schema_and_kind_are_frozen": (
                anchor_payload["schema_version"] == 1
                and anchor_payload["kind"]
                == "kvbench-release-public-direct-anchor"
            ),
            "raw_nonce_is_private_artifact_only": (
                anchor_payload["workload_nonce"] == private_nonce
                and "workload_nonce" not in public_anchor_report
                and anchor_payload["workload_nonce_sha256"]
                == private_nonce_sha256
            ),
            "full_baseline_and_run_id_are_bound": (
                anchor_payload["baseline"] == public_anchor_baseline
                and anchor_payload["baseline_run_id"]
                == public_anchor_baseline["run_id"]
            ),
            "source_policy_controller_corpus_and_model_are_bound": (
                anchor_payload["source_report_sha256"] == "e" * 64
                and anchor_payload["scoring_policy_sha256"] == "f" * 64
                and anchor_payload["controller_config_sha256"] == "c" * 64
                and anchor_payload["controller_image_id"] == "sha256:" + "d" * 64
                and anchor_payload["corpus_namespace"]
                == "public-public-pressure-192"
                and anchor_payload["corpus_fingerprint"] == "a" * 64
                and anchor_payload["model_provenance"]
                == public_anchor_baseline["model_provenance"]
                and anchor_payload["model_provenance_sha256"]
                == module.canonical_object_sha256(
                    public_anchor_baseline["model_provenance"]
                )
            ),
            "atomic_file_is_exactly_mode_0600": (
                resolved_anchor.is_file()
                and not resolved_anchor.is_symlink()
                and anchor_mode == 0o600
            ),
            "atomic_create_refuses_overwrite": (
                overwrite_refused
                and resolved_anchor.read_bytes() == anchor_bytes_before_refusal
            ),
            "anchor_destination_is_public_profile_and_outside_task_only": all(
                outside_only_rejections
            ),
        }

    checks = {
        "valid_pair_passes": valid["passed"] is True,
        "every_invalid_mutation_fails": not any(mutation_results.values()),
        "requested_mutations_hit_expected_gates": all(
            requested_gate_mutations.values()
        ),
        "direct_leg_stops_oracle": (
            '[str(STACK), "stop-oracle"]' in runner
            and "author gateway remained running during direct baseline leg" in runner
        ),
        "candidate_leg_fresh_recreates_oracle": (
            '[str(STACK), "restart-oracle"]' in runner
            and "fresh-recreated main container" in runner
            and "--force-recreate main" in stack
        ),
        "pair_uses_one_explicit_nonce": (
            runner.count('"workload_nonce": nonce') == 2
            and '"workload_nonce_sha256": nonce_sha256' in runner
        ),
        "custom_nonce_is_validated_before_controller_or_gpu_work": (
            valid_nonce_is_accepted
            and all(invalid_nonce_rejections)
            and runner.index("nonce = validate_workload_nonce(")
            < runner.index("controller = exactly_one_service(")
        ),
        "qualification_role_matches_release_anchor_design": (
            module.REFERENCE_QUALIFICATION_ROLE
            == "author public pair creates the reusable release Direct anchor; "
            "exploratory hidden ABBA is reference derivation only"
            and "repeated fresh ABBA with baseline-CV" not in runner
        ),
        "oracle_scheduler_contract_uses_live_qwen_capacity": (
            module.EXPECTED_ORACLE_SCHEDULER["capacity_tokens"] == 1_887_738
        ),
        "oracle_scheduler_keeps_thunderagent_paper_semantics": (
            module.EXPECTED_ORACLE_SCHEDULER["scheduler_interval_sec"] == 5.0
            and module.EXPECTED_ORACLE_SCHEDULER["acting_decay_base"] == 2.0
            and module.EXPECTED_ORACLE_SCHEDULER["buffer_per_program"] == 100
        ),
        "oracle_scheduler_binds_finite_cohort_fairness_adapters_separately": (
            module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "scheduler_policy_schema_version"
            ]
            == 4
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY["queue_policy"]
            == "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "fair_service_lag_steps"
            ]
            == 1
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "fair_service_until_step"
            ]
            == 12
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "deep_request_first_step"
            ]
            == 13
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "service_lag_scope"
            ]
            == "protected-reentry-vs-feasible-blocked-request-ordinal"
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "normal_restore_order"
            ]
            == "aged-then-protected-request-ordinal-then-deep-total-tokens-then-idle-acting"
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "deep_reentry_bypasses_service_lag"
            ]
            is True
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "fair_wait_threshold_sec"
            ]
            == 220.0
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "aged_resume_quota_per_tick"
            ]
            == 4
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "aged_reservation_owner_limit"
            ]
            == 1
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "aged_reservation_capacity_basis"
            ]
            == "full_phase_aware_decision_units"
            and module.EXPECTED_ORACLE_SCHEDULER_POLICY[
                "aged_reservation_inflight_reasoning_policy"
            ]
            == "never_pause"
            and "scheduler_policy_schema_version"
            not in module.EXPECTED_ORACLE_SCHEDULER
        ),
        "public30_requires_both_protected_and_deep_tiers": (
            module.deep_tier_activation_contract(
                health["scheduler"], windowed=True
            )
            is True
            and module.deep_tier_activation_contract(
                hidden_without_deep_witness_health["scheduler"],
                windowed=True,
            )
            is False
        ),
        "finite_limits_exceeded_zero_completion_is_healthy": (
            baseline["completed_workflows"] == 0
            and candidate["completed_workflows"] == 0
            and valid["quality"]["baseline_absolute_quality"] is True
            and valid["quality"]["candidate_absolute_quality"] is True
            and valid["quality"]["completed_workflows_preserved"] is True
        ),
        "finite_agent_execution_interval_is_bound_and_public_omits_it": (
            valid["contracts"]["baseline_agent_execution_interval_contract"]
            is True
            and valid["contracts"][
                "candidate_agent_execution_interval_contract"
            ]
            is True
            and module.agent_execution_interval_contract(
                public_interval_free_leg, windowed=True
            )
            is True
            and module.agent_execution_interval_contract(
                public_interval_leak_leg, windowed=True
            )
            is False
        ),
        "fixed_window_explicitly_skips_finite_p99_step_tail_gate": (
            valid_public_window["tail_anti_gaming"]["evaluated"] is False
            and valid_public_window["tail_anti_gaming"]["skip_reason"]
            == "fixed-window-censored"
            and valid_public_window["tail_anti_gaming"]["passed"] is True
            and valid_public_window["quality"][
                "finite_position_paired_p99_step_latency_bounded"
            ]
            is True
        ),
        "reference_pair_tail_bounds_come_from_scoring_policy": (
            scoring_policy["max_p99_gateway_wait_sec"] == 720.0
            and scoring_policy["max_p99_step_latency_ratio"] == 1.25
            and "<= 720.0" not in runner
        ),
        "oracle_scheduler_uses_qwen_hybrid_page_accounting": (
            module.EXPECTED_ORACLE_SCHEDULER["accounting_schema_version"] == 3
            and module.EXPECTED_ORACLE_SCHEDULER["accounting_mode"]
            == "qwen36-vllm024-hybrid-state-aware-pages"
            and module.EXPECTED_ORACLE_SCHEDULER["decision_unit"] == "kv_pages"
            and module.EXPECTED_ORACLE_SCHEDULER["raw_gpu_blocks"] == 1_253
            and module.EXPECTED_ORACLE_SCHEDULER["reserved_null_blocks"] == 1
            and module.EXPECTED_ORACLE_SCHEDULER["capacity_pages"] == 1_252
            and module.EXPECTED_ORACLE_SCHEDULER["decision_capacity"] == 1_252
            and module.EXPECTED_ORACLE_SCHEDULER["attention_page_tokens"] == 1_568
            and module.EXPECTED_ORACLE_SCHEDULER["mamba_group_count"] == 3
            and module.EXPECTED_ORACLE_SCHEDULER["mamba_peak_pages_per_group"]
            == 2
            and module.EXPECTED_ORACLE_SCHEDULER[
                "mamba_resident_pages_per_group"
            ]
            == 1
            and module.EXPECTED_ORACLE_SCHEDULER[
                "fixed_mamba_pages_per_program"
            ]
            == 3
            and module.EXPECTED_ORACLE_SCHEDULER[
                "transient_mamba_pages_per_program"
            ]
            == 3
            and module.EXPECTED_ORACLE_SCHEDULER[
                "peak_mamba_pages_per_reasoning_program"
            ]
            == 6
            and module.EXPECTED_ORACLE_SCHEDULER[
                "mamba_initial_uncached_pages_per_program"
            ]
            == 3
            and module.EXPECTED_ORACLE_SCHEDULER["mamba_reservation_scope"]
            == "request_lifetime_peak"
            and module.EXPECTED_ORACLE_SCHEDULER["mamba_reservation_phase"]
            == "reasoning_or_request_pending"
            and module.EXPECTED_ORACLE_SCHEDULER[
                "mamba_reservation_uses_agent_step_count"
            ]
            is False
            and module.EXPECTED_ORACLE_SCHEDULER[
                "decision_pages_are_reservations"
            ]
            is True
            and module.EXPECTED_ORACLE_SCHEDULER[
                "acting_attention_decay_scope"
            ]
            == "restore_only"
            and module.EXPECTED_ORACLE_SCHEDULER["decode_headroom_tokens"] == 100
            and module.EXPECTED_ORACLE_SCHEDULER[
                "reported_logical_capacity_tokens"
            ]
            == 1_887_738
            and module.EXPECTED_ORACLE_SCHEDULER[
                "reported_logical_capacity_is_informational"
            ]
            is True
        ),
        "oracle_tree_digest_is_valid": (
            isinstance(digest, str)
            and len(digest) == 64
            and all(character in "0123456789abcdef" for character in digest)
        ),
        "private_public_direct_anchor_contract": all(private_anchor_checks.values()),
    }
    report = {
        "schema_version": 1,
        "kind": "reference-pair-runner-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "mutation_pass_values": mutation_results,
        "requested_gate_mutations": requested_gate_mutations,
        "valid_effect": valid["effect"],
        "reference_gateway_tree_sha256": digest,
        "private_public_direct_anchor_checks": private_anchor_checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
