#!/usr/bin/env python3
"""Keep the active Harbor path bound to Qwen3.6-27B TP2."""

from __future__ import annotations

import json
import re
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]


def text(relative: str) -> str:
    return (TASK_ROOT / relative).read_text()


def main() -> int:
    run_local = text("scripts/run-local-h100.sh")
    calibration_stack = text("scripts/calibration-stack.sh")
    host_launcher = text("scripts/host-vllm-qwen36-27b.sh")
    task_image_sources = "\n".join(
        text(path)
        for path in (
            "environment/docker-compose.yaml",
            "scripts/compose-main-base.yaml",
            "scripts/test-container-integrations.sh",
            "scripts/test-hidden-isolation-container.sh",
            "scripts/test-main-egress-seal-container.sh",
        )
    )
    calibration_runner = text("scripts/run-real-swe-calibration.py")
    reference_gateway = text("solution/reference_gateway/gateway.py")
    reference_scheduler = text("solution/reference_gateway/scheduler.py")
    phase0_verifier = text("tests/verify_phase0.py")
    model_profile = json.loads(
        text("environment/vllm-runtime/model-profile-qwen3.6-27b.json")
    )
    release_freezer = text("scripts/freeze-release-manifest.py")
    controller = text("environment/bench-controller/server.py")
    calibration_profiles = json.loads(
        text("environment/bench-controller/profiles/calibration.json")
    )["profiles"]
    public_profiles = json.loads(
        text("environment/bench-controller/profiles/public.json")
    )["profiles"]
    hidden_profiles = json.loads(
        text("environment/bench-controller/profiles/hidden.json")
    )["profiles"]
    scoring_policy = json.loads(
        text("environment/bench-controller/profiles/scoring-policy.json")
    )
    release_readiness = json.loads(text("calibration/release-readiness.json"))
    active_sources = "\n".join(
        text(path)
        for path in (
            "task.toml",
            "environment/docker-compose.yaml",
            "environment/bench-controller/runner/model.py",
            "scripts/run-local-h100.sh",
            "scripts/calibration-stack.sh",
            "scripts/run-real-swe-calibration.py",
            "solution/reference_gateway/gateway.py",
        )
    ).lower()
    retired = (
        "scripts/gpt-oss-20b-stack.sh",
        "scripts/compose-gpt-oss-20b.yaml",
        "environment/vllm-runtime/Dockerfile",
        "environment/vllm-runtime/Dockerfile.gpt-oss-20b",
        "environment/vllm-runtime/model-profile.json",
        "environment/vllm-runtime/model-profile-gpt-oss-20b.json",
        "environment/vllm-runtime/start-vllm.sh",
        "environment/vllm-runtime/start-vllm-gpt-oss-20b.sh",
        "environment/vllm-runtime/kvbench_harmony_patch.py",
        "tests/gpt_oss_attestation_unit.py",
        "tests/harmony_patch_unit.py",
    )
    pressure_profiles = {
        name: profile
        for name, profile in calibration_profiles.items()
        if name.startswith("qwen36-pressure-192-")
    }
    checks = {
        "final_task_images_use_public30_r1_while_host_image_stays_host_r1": (
            all(
                reference in task_image_sources
                for reference in (
                    "harbor-kv/main:qwen36-27b-tp2-public30-r2",
                    "harbor-kv/model-api:qwen36-27b-tp2-public30-r2",
                    "harbor-kv/bench-controller:qwen36-27b-tp2-public30-r2",
                    "harbor-kv/sandbox-worker:qwen36-27b-tp2-public30-r2",
                )
            )
            and re.search(
                r"qwen36-27b-tp2-public10-r(?:0|1|2)(?:\W|$)",
                task_image_sources,
            )
            is None
            and model_profile["runtime"]["runtime_image_ref"]
            == "harbor-kv/vllm-qwen36-27b-h100:host-r1"
            and 'IMAGE_REF="harbor-kv/vllm-qwen36-27b-h100:host-r1"'
            in host_launcher
        ),
        "active_sources_have_no_legacy_model_contract": all(
            marker not in active_sources
            for marker in (
                "deepseek",
                "dsv4",
                "gpt-oss",
                "gpt_oss",
                "harmony",
                "host-vllm-glm46",
                "model-profile-glm-4.6-fp8",
            )
        ),
        "qwen_model_contract_has_no_legacy_quantization_alias": (
            'quantization.get("format")' in text("environment/vllm-runtime/model_contract.py")
            and 'quantization.get("fmt"' not in text("environment/vllm-runtime/model_contract.py")
            and "deepseek" not in text("environment/vllm-runtime/model_contract.py").lower()
            and "gpt-oss" not in text("environment/vllm-runtime/model_contract.py").lower()
        ),
        "retired_sidecar_assets_are_absent": all(
            not (TASK_ROOT / relative).exists() for relative in retired
        ),
        "harbor_wrapper_only_gates_external_runtime": (
            '"$SCRIPT_DIR/host-vllm-qwen36-27b.sh" status' in run_local
            and "preflight-host.py" not in run_local
            and "kernel_cache" not in run_local
            and "gpu0-7.lock" not in run_local
        ),
        "calibration_stack_does_not_own_model_lifecycle": (
            '"$SCRIPT_DIR/host-vllm-qwen36-27b.sh" status' in calibration_stack
            and "preflight-host.py" not in calibration_stack
            and "MODEL_PROFILE" not in calibration_stack
            and "COMPOSE_OVERLAY" not in calibration_stack
            and "KV_VLLM_CACHE" not in calibration_stack
        ),
        "external_uds_is_required_by_both_wrappers": (
            "HARBOR_VLLM_RUNTIME_DIR" in run_local
            and "HARBOR_VLLM_RUNTIME_DIR" in calibration_stack
        ),
        "host_launcher_exposes_only_the_attested_tp2_devices": (
            "--gpus '\"device=6,7\"'" in host_launcher
            and "--gpu-indices 6,7" in host_launcher
            and "--gpus all" not in host_launcher
        ),
        "qwen_profile_and_project_are_calibration_defaults": (
            "model-profile-qwen3.6-27b.json" in calibration_runner
            and 'default="kvbench-qwen36-public30"' in calibration_runner
        ),
        "reference_gateway_matches_qwen_capacity_and_sequence_ceiling": (
            'os.environ.get("THUNDER_KV_CAPACITY_TOKENS", "1887738")'
            in reference_gateway
            and 'os.environ.get("MAX_INFLIGHT", "192")' in reference_gateway
            and "two long prefills" not in reference_gateway.lower()
            and "50-workflow rotation" not in reference_gateway.lower()
        ),
        "qwen_oracle_uses_exact_vllm024_hybrid_page_geometry": (
            'os.environ.get("THUNDER_KV_RAW_GPU_BLOCKS", "1253")'
            in reference_gateway
            and 'os.environ.get("THUNDER_KV_RESERVED_NULL_BLOCKS", "1")'
            in reference_gateway
            and 'os.environ.get("THUNDER_ATTENTION_PAGE_TOKENS", "1568")'
            in reference_gateway
            and 'os.environ.get("THUNDER_MAMBA_GROUP_COUNT", "3")'
            in reference_gateway
            and 'os.environ.get("THUNDER_MAMBA_RESIDENT_PAGES_PER_GROUP", "1")'
            in reference_gateway
            and 'os.environ.get("THUNDER_MAMBA_PEAK_PAGES_PER_GROUP", "2")'
            in reference_gateway
            and "return self.raw_gpu_blocks - self.reserved_null_blocks"
            in reference_scheduler
            and "return self.mamba_group_count * self.mamba_resident_pages_per_group"
            in reference_scheduler
            and "self.mamba_peak_pages_per_group"
            in reference_scheduler
            and "- self.mamba_resident_pages_per_group"
            in reference_scheduler
        ),
        "qwen_oracle_decides_in_1252_usable_hybrid_pages": (
            "hybrid_page_accounting = HybridPageAccounting(" in reference_gateway
            and "hybrid_page_accounting=hybrid_page_accounting"
            in reference_gateway
            and '"decision_unit": "kv_pages"' in reference_scheduler
            and "return self.hybrid_page_accounting.capacity_pages"
            in reference_scheduler
            and "decode_headroom_tokens=self.buffer_per_program"
            in reference_scheduler
        ),
        "generic_thunderagent_decode_headroom_remains_100_tokens": (
            'os.environ.get("THUNDER_BUFFER_PER_PROGRAM", "100")'
            in reference_gateway
            and 'os.environ.get("THUNDER_BUFFER_PER_PROGRAM", "1568")'
            not in reference_gateway
            and "buffer_per_program: int = 100" in reference_scheduler
        ),
        "oracle_v5_has_public_compatible_12_13_tier_cutover": (
            'os.environ.get("THUNDER_FAIR_SERVICE_UNTIL_STEP", "12")'
            in reference_gateway
            and "fair_service_until_step=FAIR_SERVICE_UNTIL_STEP"
            in reference_gateway
            and '"scheduler_policy_schema_version": 4'
            in reference_scheduler
            and "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"
            in reference_scheduler
            and '"deep_request_first_step"' in reference_scheduler
            and '"deep_service_lag_bypass_decisions": 0'
            in reference_scheduler
        ),
        "logical_capacity_is_retained_as_informational_telemetry": (
            'os.environ.get("THUNDER_KV_CAPACITY_TOKENS", "1887738")'
            in reference_gateway
            and '"reported_logical_capacity_is_informational": True'
            in reference_scheduler
            and '"reported_logical_capacity_tokens": 1887738'
            in phase0_verifier
        ),
        "phase0_attests_resolved_geometry_without_conflating_cli_block_size": (
            model_profile["runtime"]["block_size"] == 16
            and '"attention_page_tokens": 1568' in phase0_verifier
            and '"raw_gpu_blocks": 1253' in phase0_verifier
            and '"reserved_null_blocks": 1' in phase0_verifier
            and '"capacity_pages": 1252' in phase0_verifier
            and '"accounting_schema_version": 2' in phase0_verifier
            and '"mamba_group_count": 3' in phase0_verifier
            and '"mamba_resident_pages_per_group": 1' in phase0_verifier
            and '"mamba_peak_pages_per_group": 2' in phase0_verifier
            and '"fixed_mamba_pages_per_program": 3' in phase0_verifier
            and '"transient_mamba_pages_per_program": 3' in phase0_verifier
            and "validate_hybrid_cache_metrics(metrics_snapshot)"
            in phase0_verifier
        ),
        "release_manifest_distinguishes_workload_and_oracle_provenance": (
            '"mini_swe_vendor_source_commit": "a989f24c2d53096e243aae39775637b8ddd0e380"'
            in release_freezer
            and '"oracle_scheduler_source_commit": "7ddc8610270e56d3b109eed8796b3a4360fc67c9"'
            in release_freezer
            and "vendored_from_thunderagent_commit" not in release_freezer
        ),
        "calibration_has_192_agent_pressure_stages": (
            set(pressure_profiles)
            >= {
                "qwen36-pressure-192-deep32",
                "qwen36-pressure-192-deep48",
                "qwen36-pressure-192-deep64",
                "qwen36-pressure-192-deep96",
            }
            and all(
                profile["workflows"] == profile["concurrency"] == 192
                and profile["max_tokens"] == 2048
                and profile["pressure_required"] is True
                for profile in pressure_profiles.values()
            )
        ),
        "public_and_hidden_use_the_selected_bounded_pressure_shape": (
            set(public_profiles)
            == {"smoke-api", "public-12", "public-pressure-192"}
            and set(hidden_profiles) == {"hidden-pressure-192"}
            and all(
                profile["workflows"] == profile["concurrency"] == 192
                and profile["max_steps"] == 24
                and profile["max_tokens"] == 2048
                and profile["workflow_timeout_sec"] == 4500
                and profile["request_timeout_sec"] == 2700
                and profile["pressure_kv_threshold"] == 0.8
                and profile["pressure_kv_p95_min"] == 0.9
                and profile["pressure_time_fraction_min"] == 0.25
                and profile["pressure_min_samples"] == 60
                for profile in (
                    public_profiles["public-pressure-192"],
                    hidden_profiles["hidden-pressure-192"],
                )
            )
            and public_profiles["public-pressure-192"]["seed"] == 314159
            and public_profiles["public-pressure-192"]["corpus_partition"]
            == "public"
            and hidden_profiles["hidden-pressure-192"]["seed"] == 730073
            and hidden_profiles["hidden-pressure-192"]["corpus_partition"]
            == "hidden"
        ),
        "controller_opts_every_profile_set_into_the_192_ceiling": (
            '"public": load_profiles(PUBLIC_PROFILES, concurrency_limit=192)'
            in controller
            and '"calibration": load_profiles(CALIBRATION_PROFILES, concurrency_limit=192)'
            in controller
            and '"hidden": load_profiles(HIDDEN_PROFILES, concurrency_limit=192)'
            in controller
        ),
        "qwen_release_phase_identity_and_readiness_are_coherent": (
            isinstance(scoring_policy.get("release_id"), str)
            and scoring_policy["release_id"] == release_readiness.get("release_id")
            and isinstance(scoring_policy.get("release_ready"), bool)
            and len(scoring_policy.get("hidden_profiles") or []) == 1
            and (
                (
                    scoring_policy["release_ready"] is False
                    and release_readiness.get("real_agent_test_allowed") is False
                    and bool(scoring_policy.get("not_ready_reasons"))
                    and bool(release_readiness.get("blocking_gates"))
                )
                or (
                    scoring_policy["release_ready"] is True
                    and not scoring_policy["release_id"].startswith("development")
                    and scoring_policy["hidden_profiles"][0]["reference_speedup"]
                    > 1.0
                )
            )
            and (
                release_readiness.get("real_agent_test_allowed") is not True
                or (
                    scoring_policy["release_ready"] is True
                    and release_readiness.get("infrastructure_ready") is True
                    and release_readiness.get("benchmark_ready") is True
                    and release_readiness.get("oracle_ready") is True
                )
            )
            and scoring_policy["hidden_profiles"][0]["name"]
            == "hidden-pressure-192"
            and scoring_policy["hidden_profiles"][0]["weight"] == 1.0
            and isinstance(
                scoring_policy["hidden_profiles"][0]["reference_speedup"],
                (int, float),
            )
            and not isinstance(
                scoring_policy["hidden_profiles"][0]["reference_speedup"],
                bool,
            )
            and scoring_policy["hidden_profiles"][0]["reference_speedup"]
            >= 1.0
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "qwen36-active-path-migration-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
