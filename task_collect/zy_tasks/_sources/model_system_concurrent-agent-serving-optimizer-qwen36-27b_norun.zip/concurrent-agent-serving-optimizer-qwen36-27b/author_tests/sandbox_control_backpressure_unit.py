#!/usr/bin/env python3
"""CPU-only contracts for burst-safe sandbox control and failure cleanup."""

from __future__ import annotations

import errno
import importlib.util
import json
import os
import sys
import threading
import types
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
SOAK_PATH = TASK_ROOT / "scripts" / "soak-swebench-sandboxes.py"
SOAK_SHELL_PATH = TASK_ROOT / "scripts" / "soak-swebench-sandboxes.sh"
WORKER_PATH = TASK_ROOT / "environment" / "sandbox-worker" / "worker.py"


def load_soak_module() -> Any:
    # The host CPU test environment intentionally does not install docker-py.
    # The client connection helper under test is standard-library-only, so a
    # placeholder module keeps this unit independent of a Docker daemon.
    fake_docker = types.ModuleType("docker")
    fake_docker.DockerClient = object
    fake_docker.from_env = lambda **_kwargs: None
    previous = sys.modules.get("docker")
    sys.modules["docker"] = fake_docker
    try:
        spec = importlib.util.spec_from_file_location(
            "sandbox_soak_backpressure_target", SOAK_PATH
        )
        if spec is None or spec.loader is None:
            raise RuntimeError("could not load soak module")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        if previous is None:
            sys.modules.pop("docker", None)
        else:
            sys.modules["docker"] = previous


def load_worker_module() -> Any:
    class APIError(Exception):
        pass

    class ImageNotFound(APIError):
        pass

    class NotFound(APIError):
        pass

    class PlaceholderClient:
        def __init__(self, kwargs: dict[str, Any]) -> None:
            self.kwargs = dict(kwargs)
            self.closed = False

        def close(self) -> None:
            self.closed = True

    fake_docker = types.ModuleType("docker")
    fake_errors = types.ModuleType("docker.errors")
    fake_models = types.ModuleType("docker.models")
    fake_containers = types.ModuleType("docker.models.containers")
    fake_types = types.ModuleType("docker.types")
    fake_errors.APIError = APIError
    fake_errors.ImageNotFound = ImageNotFound
    fake_errors.NotFound = NotFound
    fake_containers.Container = object
    fake_types.Ulimit = lambda **_kwargs: object()
    fake_docker.from_env = lambda **kwargs: PlaceholderClient(kwargs)
    names = {
        "docker": fake_docker,
        "docker.errors": fake_errors,
        "docker.models": fake_models,
        "docker.models.containers": fake_containers,
        "docker.types": fake_types,
    }
    previous = {name: sys.modules.get(name) for name in names}
    previous_owner = os.environ.get("SANDBOX_OWNER")
    os.environ["SANDBOX_OWNER"] = "soak-unit"
    sys.modules.update(names)
    try:
        spec = importlib.util.spec_from_file_location(
            "sandbox_worker_cleanup_target", WORKER_PATH
        )
        if spec is None or spec.loader is None:
            raise RuntimeError("could not load sandbox worker module")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        if previous_owner is None:
            os.environ.pop("SANDBOX_OWNER", None)
        else:
            os.environ["SANDBOX_OWNER"] = previous_owner
        for name, value in previous.items():
            if value is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value


class RemovalTarget:
    def __init__(self, outcomes: list[BaseException | None]) -> None:
        self.outcomes = list(outcomes)
        self.remove_calls = 0

    def remove(self, *, force: bool) -> None:
        if force is not True:
            raise AssertionError("cleanup must force-remove an ephemeral sandbox")
        self.remove_calls += 1
        outcome = self.outcomes.pop(0)
        if outcome is not None:
            raise outcome


class RemovalCollection:
    def __init__(self, targets: dict[str, RemovalTarget | BaseException]) -> None:
        self.targets = targets
        self.get_order: list[str] = []

    def get(self, container_id: str) -> RemovalTarget:
        self.get_order.append(container_id)
        target = self.targets[container_id]
        if isinstance(target, BaseException):
            raise target
        return target


class FakeDockerClient:
    def __init__(self, containers: RemovalCollection) -> None:
        self.containers = containers


class FakeSocket:
    def __init__(self, connect_error: BaseException | None) -> None:
        self.connect_error = connect_error
        self.closed = False
        self.timeout: int | None = None
        self.responses = [b'{"ok":true}', b""]

    def settimeout(self, timeout: int) -> None:
        self.timeout = timeout

    def connect(self, _path: str) -> None:
        if self.connect_error is not None:
            raise self.connect_error

    def sendall(self, _payload: bytes) -> None:
        return None

    def shutdown(self, _direction: int) -> None:
        return None

    def recv(self, _size: int) -> bytes:
        return self.responses.pop(0)

    def close(self) -> None:
        self.closed = True


class SocketFactory:
    def __init__(self, errors: list[BaseException | None]) -> None:
        self.errors = list(errors)
        self.sockets: list[FakeSocket] = []

    def __call__(self, _family: int, _kind: int) -> FakeSocket:
        error = self.errors.pop(0)
        client = FakeSocket(error)
        self.sockets.append(client)
        return client


def run_rpc_case(
    module: Any,
    errors: list[BaseException | None],
    *,
    attempts: int = 20,
) -> tuple[dict[str, Any] | None, BaseException | None, SocketFactory, list[float]]:
    factory = SocketFactory(errors)
    sleeps: list[float] = []
    original_socket = module.socket.socket
    original_sleep = module.time.sleep
    original_attempts = module.RPC_CONNECT_MAX_ATTEMPTS
    module.socket.socket = factory
    module.time.sleep = sleeps.append
    module.RPC_CONNECT_MAX_ATTEMPTS = attempts
    result = None
    error = None
    try:
        result = module.rpc({"action": "unit"}, timeout=75)
    except BaseException as exc:  # Deliberately inspect exact propagated error.
        error = exc
    finally:
        module.socket.socket = original_socket
        module.time.sleep = original_sleep
        module.RPC_CONNECT_MAX_ATTEMPTS = original_attempts
    return result, error, factory, sleeps


def main() -> int:
    module = load_soak_module()
    worker = load_worker_module()

    client_proxy = worker.docker_client
    client_barrier = threading.Barrier(2)
    client_results: list[tuple[object, object]] = []
    client_results_lock = threading.Lock()

    def access_thread_local_client() -> None:
        client_barrier.wait(timeout=5)
        first = client_proxy._client()
        second = client_proxy._client()
        with client_results_lock:
            client_results.append((first, second))

    client_threads = [
        threading.Thread(target=access_thread_local_client) for _ in range(2)
    ]
    for thread in client_threads:
        thread.start()
    for thread in client_threads:
        thread.join(timeout=5)
    thread_clients = [pair[0] for pair in client_results]
    thread_local_client_ownership = (
        len(client_results) == 2
        and all(first is second for first, second in client_results)
        and thread_clients[0] is not thread_clients[1]
        and all(
            client.kwargs == {"timeout": 180, "max_pool_size": 8}
            for client in thread_clients
        )
    )
    client_proxy.close_all()
    thread_local_clients_closed = (
        all(client.closed for client in thread_clients)
        and client_proxy._clients == []
    )

    transient = BlockingIOError(errno.EAGAIN, "listen backlog full")
    result, error, retried, sleeps = run_rpc_case(
        module, [transient, transient, None]
    )

    nontransient = BlockingIOError(errno.EINPROGRESS, "not a retryable backlog error")
    _, nontransient_error, rejected, rejected_sleeps = run_rpc_case(
        module, [nontransient]
    )

    exhausted_errors = [
        BlockingIOError(errno.EAGAIN, "listen backlog full") for _ in range(3)
    ]
    _, exhausted_error, exhausted, exhausted_sleeps = run_rpc_case(
        module, exhausted_errors, attempts=3
    )

    worker_source = WORKER_PATH.read_text()
    shell_source = SOAK_SHELL_PATH.read_text()
    soak_source = SOAK_PATH.read_text()
    stop_index = shell_source.find('docker stop --time 180 "$worker_name"')
    remove_index = shell_source.find('docker rm -f "$worker_name"')
    cleanup_check_index = soak_source.find('cleanup.get("removed") is not True')
    active_discard_index = soak_source.find("active_ids.discard(sandbox_id)")

    sandbox_id = "a" * 32
    persistent = RemovalTarget(
        [worker.APIError("busy") for _ in range(worker.CLEANUP_ATTEMPTS)]
    )
    worker.docker_client = FakeDockerClient(
        RemovalCollection({"persistent": persistent})
    )
    worker.runtimes.clear()
    worker.owned_containers.clear()
    worker.runtimes[sandbox_id] = "persistent"
    worker.owned_containers[sandbox_id] = "persistent"
    original_worker_sleep = worker.time.sleep
    worker.time.sleep = lambda _seconds: None
    cleanup_error = None
    try:
        worker.cleanup_runtime({"sandbox_id": sandbox_id})
    except BaseException as exc:
        cleanup_error = exc
    finally:
        worker.time.sleep = original_worker_sleep
    cleanup_failure_retained = (
        isinstance(cleanup_error, worker.APIError)
        and worker.runtimes.get(sandbox_id) == "persistent"
        and worker.owned_containers.get(sandbox_id) == "persistent"
        and persistent.remove_calls == worker.CLEANUP_ATTEMPTS
    )

    removable = RemovalTarget([None])
    worker.docker_client = FakeDockerClient(RemovalCollection({"persistent": removable}))
    cleanup_result = worker.cleanup_runtime({"sandbox_id": sandbox_id})
    cleanup_success_forgot = (
        cleanup_result.get("removed") is True
        and sandbox_id not in worker.runtimes
        and sandbox_id not in worker.owned_containers
    )

    failed_id = "b" * 32
    removed_id = "c" * 32
    missing_id = "d" * 32
    failed_target = RemovalTarget(
        [worker.APIError("busy") for _ in range(worker.CLEANUP_ATTEMPTS)]
    )
    removed_target = RemovalTarget([None])
    removal_collection = RemovalCollection(
        {
            "failed": failed_target,
            "removed": removed_target,
            "missing": worker.NotFound("already gone"),
        }
    )
    worker.docker_client = FakeDockerClient(removal_collection)
    worker.runtimes.clear()
    worker.owned_containers.clear()
    worker.runtimes.update(
        {failed_id: "failed", removed_id: "removed", missing_id: "missing"}
    )
    worker.owned_containers.update(worker.runtimes)
    worker.time.sleep = lambda _seconds: None
    shutdown_error = None
    try:
        worker.cleanup_all_runtimes()
    except BaseException as exc:
        shutdown_error = exc
    finally:
        worker.time.sleep = original_worker_sleep
    shutdown_continues_and_retains_only_failure = (
        isinstance(shutdown_error, RuntimeError)
        and worker.runtimes == {failed_id: "failed"}
        and worker.owned_containers == {failed_id: "failed"}
        and "removed" in removal_collection.get_order
        and "missing" in removal_collection.get_order
    )

    create_index = worker_source.find("docker_client.containers.create(")
    ownership_index = worker_source.find(
        "owned_containers[sandbox_id] = container.id", create_index
    )
    start_index = worker_source.find("container.start()", create_index)
    handler_drain_index = worker_source.find("while active_handlers:")
    final_cleanup_index = worker_source.find(
        "await asyncio.to_thread(cleanup_all_runtimes)"
    )

    checks = {
        "eagain_is_retried_then_rpc_succeeds": (
            result == {"ok": True}
            and error is None
            and len(retried.sockets) == 3
            and len(sleeps) == 2
            and all(client.closed for client in retried.sockets)
            and all(client.timeout == 75 for client in retried.sockets)
        ),
        "nontransient_connect_error_fails_without_retry": (
            nontransient_error is nontransient
            and len(rejected.sockets) == 1
            and rejected.sockets[0].closed
            and rejected_sleeps == []
        ),
        "retry_budget_exhaustion_fails_closed": (
            isinstance(exhausted_error, BlockingIOError)
            and len(exhausted.sockets) == 3
            and len(exhausted_sleeps) == 2
            and all(client.closed for client in exhausted.sockets)
        ),
        "worker_backlog_covers_full_192_wave": (
            "CONTROL_SOCKET_BACKLOG = 512" in worker_source
            and "backlog=CONTROL_SOCKET_BACKLOG" in worker_source
        ),
        "worker_docker_sessions_are_thread_local_and_closed": (
            thread_local_client_ownership and thread_local_clients_closed
        ),
        "soak_docker_inspection_serializes_the_shared_client": (
            "docker_probe_lock = threading.Lock()" in soak_source
            and soak_source.count("with docker_probe_lock:") == 3
        ),
        "wrapper_stops_worker_gracefully_before_force_removal": (
            stop_index >= 0 and remove_index > stop_index
        ),
        "runtime_is_untracked_only_after_confirmed_cleanup": (
            cleanup_check_index >= 0
            and active_discard_index > cleanup_check_index
            and "cleanup returned an invalid response" in soak_source
        ),
        "cleanup_api_error_retries_and_retains_ownership": cleanup_failure_retained,
        "successful_cleanup_forgets_exact_generation": cleanup_success_forgot,
        "shutdown_cleanup_continues_and_retains_only_failures": (
            shutdown_continues_and_retains_only_failure
        ),
        "creation_is_owned_before_start_and_baseline": (
            create_index >= 0
            and ownership_index > create_index
            and start_index > ownership_index
        ),
        "accepted_handlers_drain_before_final_cleanup": (
            handler_drain_index >= 0 and final_cleanup_index > handler_drain_index
        ),
        "wrapper_fallback_is_scoped_to_unique_owner": (
            'run_owner="soak-$$"' in shell_source
            and '--env "SANDBOX_OWNER=$run_owner"' in shell_source
            and "swe-sandbox.owner=$run_owner" in shell_source
            and "docker rm -f \"${validated_ids[@]}\"" in shell_source
            and "docker ps -aq --no-trunc" in shell_source
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "sandbox-control-backpressure-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
