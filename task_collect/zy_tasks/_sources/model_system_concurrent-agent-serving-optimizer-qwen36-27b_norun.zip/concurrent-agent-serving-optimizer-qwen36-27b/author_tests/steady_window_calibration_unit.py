#!/usr/bin/env python3
"""CPU-only contracts for the author steady-window fail-closed scaffold."""

from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = TASK_ROOT / "scripts" / "run-steady-window-calibration.py"
PROFILE_PATH = TASK_ROOT / "author_profiles" / "qwen36-steady-window.json"
SPEC = importlib.util.spec_from_file_location("steady_window_calibration", SCRIPT)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("could not import steady-window calibration script")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def rejects(action: Any, expected: str, exception: type[Exception] = ValueError) -> bool:
    try:
        action()
    except exception as exc:
        return expected in str(exc)
    return False


def capability(profile_set: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "protocol": MODULE.PROTOCOL_ID,
        "author_only": True,
        "supported": True,
        "semantics_sha256": profile_set["semantics_sha256"],
        "result_schema_version": 1,
        "features": {name: True for name in MODULE.REQUIRED_CAPABILITIES},
        "supported_slots": list(MODULE.ALLOWED_SLOTS),
        "max_rollout_steps": 135,
    }


def leg_result(
    profile_set: dict[str, Any],
    profile_name: str,
    mode: str,
    nonce: str,
) -> dict[str, Any]:
    profile = profile_set["profiles"][profile_name]
    semantics_sha256 = profile_set["semantics_sha256"]
    slots = profile["slots"]
    slot_steps = [1] * slots
    valid_steps = sum(slot_steps)
    started = slots
    return {
        "schema_version": 1,
        "kind": MODULE.RESULT_KIND,
        "author_only": True,
        "release_evidence_eligible": False,
        "protocol": MODULE.PROTOCOL_ID,
        "semantics_sha256": semantics_sha256,
        "profile_name": profile_name,
        "profile_sha256": MODULE.profile_sha256(
            profile_name, profile, semantics_sha256
        ),
        "profile_config": profile,
        "mode": mode,
        "workload_nonce_sha256": MODULE.hashlib.sha256(nonce.encode()).hexdigest(),
        "measurement": {
            "ramp_sec": profile["ramp_sec"],
            "window_sec": profile["window_sec"],
            "drain_timeout_sec": profile["drain_timeout_sec"],
            "numerator_event": MODULE.EXPECTED_SEMANTICS["numerator_event"],
            "numerator_interval": MODULE.EXPECTED_SEMANTICS["numerator_interval"],
            "replacement_policy": MODULE.EXPECTED_SEMANTICS["replacement_policy"],
            "window_end_policy": MODULE.EXPECTED_SEMANTICS["window_end_policy"],
            "audit_scope": MODULE.EXPECTED_SEMANTICS["audit_scope"],
            "post_window_model_query_starts": 0,
            "window_boundary_client_cancellations": 0,
            "drain_completed": True,
            "ramp_started_unix": 1_000.0,
            "window_started_unix": 1_000.0 + profile["ramp_sec"],
            "window_ended_unix": (
                1_000.0 + profile["ramp_sec"] + profile["window_sec"]
            ),
            "drain_ended_unix": (
                1_001.0 + profile["ramp_sec"] + profile["window_sec"]
            ),
        },
        "steady": {
            "valid_steps": valid_steps,
            "valid_steps_per_min": valid_steps * 60.0 / profile["window_sec"],
            "slot_valid_steps": slot_steps,
            "slot_jain_fairness": MODULE.jain(slot_steps),
            "minimum_slot_steps": 1,
        },
        "rollouts": {
            "started": started,
            "natural_terminal": 0,
            "replacements_started": 0,
            "window_censored": slots,
            "rollout_cap_exhausted": False,
        },
        "backend_audit": {
            "scope": MODULE.EXPECTED_SEMANTICS["audit_scope"],
            "passed": True,
            "client_requests": valid_steps,
            "audited_backend_requests": valid_steps,
        },
        "program_lifecycle": {
            "measured_release_attempted": started if mode == "candidate" else 0,
            "measured_release_acknowledged": started if mode == "candidate" else 0,
            "measured_release_failed": 0,
        },
    }


def main() -> int:
    raw_profile_set = json.loads(PROFILE_PATH.read_text())
    profile_set = MODULE.validate_profile_set(copy.deepcopy(raw_profile_set))
    expected_names = {
        f"qwen36-paper-window-{slots}-deep135" for slots in MODULE.ALLOWED_SLOTS
    }
    default_name = MODULE.DEFAULT_PROFILE
    default_profile = profile_set["profiles"][default_name]
    nonce = "steady-window-unit-nonce-0001"

    release_mutation = copy.deepcopy(raw_profile_set)
    release_mutation["release_qualification_profiles"] = [default_name]
    semantics_mutation = copy.deepcopy(raw_profile_set)
    semantics_mutation["semantics"]["numerator_event"] = "query-started"
    depth_mutation = copy.deepcopy(raw_profile_set)
    depth_mutation["profiles"][default_name]["max_rollout_steps"] = 24
    name_mutation = copy.deepcopy(raw_profile_set)
    moved = name_mutation["profiles"].pop(default_name)
    name_mutation["profiles"]["qwen36-paper-window-191-deep135"] = moved

    good_capability = capability(profile_set)
    unsupported_capability = copy.deepcopy(good_capability)
    unsupported_capability["supported"] = False
    semantic_capability = copy.deepcopy(good_capability)
    semantic_capability["semantics_sha256"] = "0" * 64
    incomplete_capability = copy.deepcopy(good_capability)
    incomplete_capability["features"][MODULE.REQUIRED_CAPABILITIES[0]] = False

    unsupported_calls: list[tuple[str, str]] = []

    def unsupported_requester(
        method: str,
        path: str,
        payload: dict[str, Any] | None,
        timeout: int,
    ) -> dict[str, Any]:
        del payload, timeout
        unsupported_calls.append((method, path))
        if method != "GET":
            raise AssertionError("unsupported controller received a mutating request")
        return unsupported_capability

    refused_without_post = rejects(
        lambda: MODULE.execute_author_leg(
            profile_set=profile_set,
            profile_name=default_name,
            mode="candidate",
            workload_nonce=nonce,
            requester=unsupported_requester,
        ),
        "no run request was sent",
        MODULE.CapabilityUnavailable,
    )

    supported_calls: list[tuple[str, str]] = []
    expected_result = leg_result(profile_set, default_name, "candidate", nonce)

    def supported_requester(
        method: str,
        path: str,
        payload: dict[str, Any] | None,
        timeout: int,
    ) -> dict[str, Any]:
        del timeout
        supported_calls.append((method, path))
        if method == "GET":
            if payload is not None:
                raise AssertionError("capability GET unexpectedly had a body")
            return good_capability
        if method != "POST" or not isinstance(payload, dict):
            raise AssertionError("invalid author run request")
        if payload.get("workload_nonce") != nonce:
            raise AssertionError("author run request changed workload nonce")
        return {"result": expected_result}

    executed = MODULE.execute_author_leg(
        profile_set=profile_set,
        profile_name=default_name,
        mode="candidate",
        workload_nonce=nonce,
        requester=supported_requester,
    )

    rate_mutation = copy.deepcopy(expected_result)
    rate_mutation["steady"]["valid_steps_per_min"] += 1.0
    boundary_mutation = copy.deepcopy(expected_result)
    boundary_mutation["measurement"]["post_window_model_query_starts"] = 1
    cancellation_mutation = copy.deepcopy(expected_result)
    cancellation_mutation["measurement"]["window_boundary_client_cancellations"] = 1
    slot_mutation = copy.deepcopy(expected_result)
    slot_mutation["steady"]["slot_valid_steps"][0] = 0
    audit_mutation = copy.deepcopy(expected_result)
    audit_mutation["backend_audit"]["audited_backend_requests"] -= 1
    release_mutation_result = copy.deepcopy(expected_result)
    release_mutation_result["program_lifecycle"]["measured_release_acknowledged"] -= 1

    def result_rejects(payload: dict[str, Any], expected: str) -> bool:
        return rejects(
            lambda: MODULE.validate_leg_result(
                payload,
                profile_name=default_name,
                profile=default_profile,
                semantics_sha256=profile_set["semantics_sha256"],
                mode="candidate",
                workload_nonce=nonce,
            ),
            expected,
            MODULE.ContractError,
        )

    with tempfile.TemporaryDirectory(prefix="steady-window-author-profile-") as raw:
        staged = Path(raw) / "profiles.json"
        staged.write_text(json.dumps(raw_profile_set))
        disk_loader_matches = MODULE.load_profile_set(staged)["profiles"] == profile_set["profiles"]

    plans = {
        name: MODULE.plan(profile_set, name) for name in profile_set["profiles"]
    }
    checks = {
        "author_matrix_is_exact": set(profile_set["profiles"]) == expected_names,
        "slot_matrix_is_exact": {
            config["slots"] for config in profile_set["profiles"].values()
        }
        == set(MODULE.ALLOWED_SLOTS),
        "all_profiles_are_author_only_non_release": all(
            config["release_evidence_eligible"] is False
            and config["pressure_required"] is False
            for config in profile_set["profiles"].values()
        )
        and profile_set["release_qualification_profiles"] == [],
        "paper_depth_and_completion_cap_are_frozen": all(
            config["max_rollout_steps"] == 135 and config["max_tokens"] == 2048
            for config in profile_set["profiles"].values()
        ),
        "fixed_10_to_70_minute_window_is_frozen": all(
            config["ramp_sec"] == 600 and config["window_sec"] == 3600
            for config in profile_set["profiles"].values()
        ),
        "same_public_workload_sequence_is_frozen": len(
            {config["workload_sequence_id"] for config in profile_set["profiles"].values()}
        )
        == 1,
        "profile_digests_are_distinct": len(
            {item["profile_sha256"] for item in plans.values()}
        )
        == len(plans),
        "plans_use_fixed_window_denominator": all(
            item["primary_metric"]["denominator_sec"]
            == item["profile_config"]["window_sec"]
            for item in plans.values()
        ),
        "disk_loader_matches": disk_loader_matches,
        "release_allowlist_mutation_rejected": rejects(
            lambda: MODULE.validate_profile_set(release_mutation),
            "cannot enter release qualification",
            MODULE.ContractError,
        ),
        "numerator_semantics_mutation_rejected": rejects(
            lambda: MODULE.validate_profile_set(semantics_mutation),
            "measurement semantics changed",
            MODULE.ContractError,
        ),
        "short_depth_mutation_rejected": rejects(
            lambda: MODULE.validate_profile_set(depth_mutation),
            "max_rollout_steps=135",
            MODULE.ContractError,
        ),
        "profile_name_slot_mismatch_rejected": rejects(
            lambda: MODULE.validate_profile_set(name_mutation),
            "does not match slot count",
            MODULE.ContractError,
        ),
        "unsupported_capability_refuses_before_post": (
            refused_without_post
            and unsupported_calls
            == [("GET", MODULE.EXPECTED_CONTROLLER_PROTOCOL["capabilities_path"])]
        ),
        "semantic_capability_mismatch_rejected": rejects(
            lambda: MODULE.validate_capability(
                semantic_capability,
                profile=default_profile,
                semantics_sha256=profile_set["semantics_sha256"],
            ),
            "semantics_sha256",
            MODULE.CapabilityUnavailable,
        ),
        "incomplete_capability_rejected": rejects(
            lambda: MODULE.validate_capability(
                incomplete_capability,
                profile=default_profile,
                semantics_sha256=profile_set["semantics_sha256"],
            ),
            "feature:",
            MODULE.CapabilityUnavailable,
        ),
        "supported_path_gets_then_posts_exact_endpoint": (
            executed == expected_result
            and supported_calls
            == [
                ("GET", MODULE.EXPECTED_CONTROLLER_PROTOCOL["capabilities_path"]),
                ("POST", MODULE.EXPECTED_CONTROLLER_PROTOCOL["run_path"]),
            ]
        ),
        "fixed_denominator_rate_mutation_rejected": result_rejects(
            rate_mutation, "fixed denominator"
        ),
        "post_window_query_mutation_rejected": result_rejects(
            boundary_mutation, "boundary contract failed"
        ),
        "window_cancel_mutation_rejected": result_rejects(
            cancellation_mutation, "boundary contract failed"
        ),
        "slot_accounting_mutation_rejected": result_rejects(
            slot_mutation, "slot step accounting"
        ),
        "one_to_one_audit_mutation_rejected": result_rejects(
            audit_mutation, "full-lifecycle audit failed"
        ),
        "lifecycle_release_mutation_rejected": result_rejects(
            release_mutation_result, "lifecycle release failed"
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "kvbench-author-steady-window-calibration-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "profiles": sorted(profile_set["profiles"]),
        "semantics_sha256": profile_set["semantics_sha256"],
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
