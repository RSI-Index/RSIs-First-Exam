#!/usr/bin/env python3
"""CPU-only contracts for finite agent-execution timing and live metrics."""

from __future__ import annotations

import json
import math
import threading
import time
from types import SimpleNamespace
from typing import Any, Callable

import runner.workload as workload
from runner.workload import (
    AgentExecutionTracker,
    Profile,
    attach_agent_execution_interval,
    finite_metric_points_through,
)


def rejected(factory: Callable[[], Any], expected: type[BaseException]) -> bool:
    try:
        factory()
    except expected:
        return True
    return False


def concurrent_interval_case() -> dict[str, Any]:
    tracker = AgentExecutionTracker(3)
    # Ordinal order, Unix order, and termination order are deliberately
    # different. The monotonic clock alone defines the final agent end.
    marks = (
        (2, 101.5, 40.0),
        (0, 250.0, 25.0),
        (1, 180.0, 31.0),
    )
    threads = [
        threading.Thread(
            target=tracker.mark,
            args=(ordinal,),
            kwargs={
                "ended_unix": ended_unix,
                "ended_monotonic": ended_monotonic,
            },
        )
        for ordinal, ended_unix, ended_monotonic in marks
    ]
    for thread in reversed(threads):
        thread.start()
    for thread in threads:
        thread.join(timeout=2)
    snapshot = tracker.snapshot(started_unix=100.0, started_monotonic=10.0)
    expected_keys = {
        "schema_version",
        "start_event",
        "end_event",
        "duration_clock",
        "started_unix",
        "ended_unix",
        "elapsed_sec",
        "expected_agent_runs",
        "observed_agent_runs",
        "complete",
    }
    valid_steps = 36
    rate = valid_steps * 60 / snapshot["elapsed_sec"]
    cleanup_ended_unix = 900.0
    attached = attach_agent_execution_interval(
        {"schema_version": 1, "elapsed_sec": snapshot["elapsed_sec"]},
        snapshot,
    )
    return {
        "name": "monotonic_last_agent_end_excludes_verify_and_cleanup",
        "passed": all(not thread.is_alive() for thread in threads)
        and tracker.complete.is_set()
        and set(snapshot) == expected_keys
        and snapshot["end_event"] == "last_agent_run_termination"
        and snapshot["duration_clock"] == "monotonic"
        and snapshot["ended_unix"] == 101.5
        and snapshot["elapsed_sec"] == 30.0
        and snapshot["expected_agent_runs"] == 3
        and snapshot["observed_agent_runs"] == 3
        and snapshot["complete"] is True
        and attached["agent_execution_interval"] == snapshot
        and math.isclose(rate, 72.0)
        and snapshot["ended_unix"] != cleanup_ended_unix,
        "snapshot": snapshot,
        "rate": rate,
    }


def live_sample_cutoff_case() -> dict[str, Any]:
    points: list[dict[str, float | None]] = [
        {"created_unix": 9.0, "kv_cache_usage": 0.4},
        {"created_unix": 10.0, "kv_cache_usage": 0.8},
        {"created_unix": 10.0001, "kv_cache_usage": 0.9},
        {"created_unix": None, "kv_cache_usage": 1.0},
        {"created_unix": math.nan, "kv_cache_usage": 1.0},
        {"created_unix": True, "kv_cache_usage": 1.0},
    ]
    selected = finite_metric_points_through(points, 10.0)
    return {
        "name": "finite_live_samples_stop_at_inclusive_agent_end",
        "passed": [point["created_unix"] for point in selected] == [9.0, 10.0]
        and rejected(
            lambda: finite_metric_points_through(points, math.inf), ValueError
        ),
        "selected": selected,
    }


def fail_closed_cases() -> dict[str, Any]:
    incomplete = AgentExecutionTracker(2)
    incomplete.mark(0, ended_unix=101.0, ended_monotonic=11.0)

    duplicate = AgentExecutionTracker(2)
    duplicate.mark(0, ended_unix=101.0, ended_monotonic=11.0)
    duplicate_rejected = rejected(
        lambda: duplicate.mark(0, ended_unix=102.0, ended_monotonic=12.0),
        RuntimeError,
    )
    duplicate.mark(1, ended_unix=103.0, ended_monotonic=13.0)

    before_start = AgentExecutionTracker(1)
    before_start.mark(0, ended_unix=99.0, ended_monotonic=9.0)

    invalid_marks = []
    for ordinal, ended_unix, ended_monotonic in (
        (True, 101.0, 11.0),
        (0, math.nan, 11.0),
        (0, 101.0, math.inf),
    ):
        tracker = AgentExecutionTracker(1)
        invalid_marks.append(
            rejected(
                lambda tracker=tracker, ordinal=ordinal, ended_unix=ended_unix,
                ended_monotonic=ended_monotonic: tracker.mark(
                    ordinal,  # type: ignore[arg-type]
                    ended_unix=ended_unix,
                    ended_monotonic=ended_monotonic,
                ),
                RuntimeError,
            )
        )

    checks = {
        "invalid_expected_counts": all(
            rejected(lambda value=value: AgentExecutionTracker(value), ValueError)
            for value in (0, -1, True)
        ),
        "incomplete_snapshot": rejected(
            lambda: incomplete.snapshot(
                started_unix=100.0, started_monotonic=10.0
            ),
            RuntimeError,
        ),
        "duplicate_mark": duplicate_rejected
        and rejected(
            lambda: duplicate.snapshot(
                started_unix=100.0, started_monotonic=10.0
            ),
            RuntimeError,
        ),
        "end_before_start": rejected(
            lambda: before_start.snapshot(
                started_unix=100.0, started_monotonic=10.0
            ),
            RuntimeError,
        ),
        "invalid_mark_values": all(invalid_marks),
    }
    return {
        "name": "tracker_mutations_fail_closed",
        "passed": all(checks.values()),
        "checks": checks,
    }


def integrated_finite_benchmark_case() -> dict[str, Any]:
    """Exercise run_benchmark without a model, Docker, or network service."""

    class FakeAdapter:
        instruction = "unit"
        instance_template = "unit"
        instruction_role = "system"
        format_error_template = "unit"

        @staticmethod
        def effective_max_tokens(value: int) -> int:
            return value

        @staticmethod
        def summary() -> dict[str, Any]:
            return {"contract": "finite-agent-unit"}

    class FakeSandbox:
        def cleanup(self) -> None:
            return

    audit = {
        "passed": True,
        "mismatches": [],
        "client_requests": 0,
        "audited_backend_requests": 0,
        "missing_backend_requests": 0,
        "extra_backend_requests": 0,
        "p95_gateway_wait_sec": None,
        "p99_gateway_wait_sec": None,
        "max_gateway_wait_sec": None,
    }
    warmup_protocol = {
        "program_release_attempted": 0,
        "program_release_acknowledged": 0,
        "program_release_failed": 0,
    }

    def fake_pool(**kwargs: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        tracker = kwargs["agent_execution_tracker"]
        assert isinstance(tracker, AgentExecutionTracker)
        time.sleep(0.02)
        agent_ended_unix = time.time()
        tracker.mark(
            0,
            ended_unix=agent_ended_unix,
            ended_monotonic=time.monotonic(),
        )
        # Simulate semantic verification and cleanup after the last agent end.
        time.sleep(0.08)
        workflow_ended = time.time()
        return (
            [
                {
                    "task_id": "finite-agent-unit",
                    "run_id": "run-unit",
                    "status": "LimitsExceeded",
                    "completed": False,
                    "tests_passed": True,
                    "valid_steps": 2,
                    "total_executed_steps": 2,
                    "step_outcomes": {"executed": 2},
                    "format_error_details": {},
                    "model_calls": 2,
                    "started_unix": agent_ended_unix - 0.01,
                    "ended_unix": workflow_ended,
                    "duration_sec": 0.09,
                    "query_latencies_sec": [],
                    "tool_latencies_sec": [],
                    "step_latencies_sec": [],
                    "error": None,
                    "program_lifecycle_release": {"attempted": False},
                    "measurement": {
                        "semantic_evaluated": True,
                        "measurement_truncated": False,
                    },
                    "terminal_message": "",
                    "test_output": "ok",
                }
            ],
            {
                "attempts": 0,
                "prepared": 0,
                "failures": 0,
                "included_in_measured_interval": True,
            },
        )

    def fake_admin_json(
        _method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
        *,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        del timeout, payload
        if path == "/admin/metrics/snapshot":
            return {}
        raise AssertionError(path)

    replacements: dict[str, Any] = {
        "load_model_adapter_contract": lambda: FakeAdapter(),
        "reset_measurement_state": lambda *_args: 1,
        "run_warmup": lambda **_kwargs: (workload.Ledger(), warmup_protocol),
        "wait_for_quiescence": lambda *_args, **_kwargs: None,
        "wait_for_audit_count": lambda *_args, **_kwargs: {
            "audit_epoch": 1,
            "count": 0,
            "records": [],
        },
        "verify_audit": lambda *_args, **_kwargs: dict(audit),
        "make_specs": lambda *_args, **_kwargs: [
            SimpleNamespace(task_id="finite-agent-unit")
        ],
        "prepare_sandboxes": lambda *_args, **_kwargs: [FakeSandbox()],
        "cleanup_sandboxes": lambda *_args, **_kwargs: None,
        "run_workflow_pool": fake_pool,
        "admin_json": fake_admin_json,
        "metric_point": lambda _snapshot: {
            "created_unix": time.time(),
            "requests_running": 1.0,
            "requests_waiting": 0.0,
            "kv_cache_usage": 0.1,
            "kv_token_capacity": 1000.0,
        },
        "corpus_fingerprint": lambda *_args, **_kwargs: "f" * 64,
    }
    originals = {name: getattr(workload, name) for name in replacements}
    profile = Profile(
        name="finite-agent-unit",
        enabled=True,
        workflows=1,
        concurrency=1,
        max_steps=2,
        context_bytes=0,
        max_tokens=16,
        workflow_timeout_sec=10,
        request_timeout_sec=5,
        tool_delay_min_sec=0.0,
        tool_delay_max_sec=0.0,
        seed=1,
        warmup_requests=0,
        metrics_sample_interval_sec=0.1,
        metrics_request_timeout_sec=5,
        backend_stall_timeout_sec=10,
        candidate_admission_stall_timeout_sec=10,
    )
    for name, value in replacements.items():
        setattr(workload, name, value)
    try:
        result = workload.run_benchmark(
            profile=profile,
            endpoint="http://direct/v1",
            mode="baseline",
            model_api_base="http://model-api",
            admin_token="unit-token",
            workload_nonce="unit-nonce",
        )
    finally:
        for name, value in originals.items():
            setattr(workload, name, value)

    interval = result["agent_execution_interval"]
    expected_rate = result["valid_steps"] * 60 / interval["elapsed_sec"]
    samples = result["vllm_metrics"]["live_samples"]
    checks = {
        "finite_schema_attached": interval["complete"] is True
        and interval["expected_agent_runs"] == 1
        and interval["observed_agent_runs"] == 1,
        "top_level_interval_is_exact": result["ended_unix"]
        == interval["ended_unix"]
        and result["elapsed_sec"] == interval["elapsed_sec"],
        "rate_uses_agent_interval": math.isclose(
            result["valid_steps_per_min"], expected_rate
        ),
        "semantic_tail_is_wall_only": result["wall_elapsed_sec"]
        > result["elapsed_sec"] + 0.05
        and result["measurement_window"]["teardown_sec"] > 0.05,
        "live_samples_are_cut_at_agent_end": all(
            float(point["created_unix"]) <= interval["ended_unix"]
            for point in samples
        ),
    }
    return {
        "name": "run_benchmark_uses_agent_end_and_keeps_teardown_in_wall",
        "passed": all(checks.values()),
        "checks": checks,
        "interval": interval,
        "elapsed_sec": result["elapsed_sec"],
        "wall_elapsed_sec": result["wall_elapsed_sec"],
        "valid_steps_per_min": result["valid_steps_per_min"],
    }


def main() -> int:
    cases = [
        concurrent_interval_case(),
        live_sample_cutoff_case(),
        fail_closed_cases(),
        integrated_finite_benchmark_case(),
    ]
    report = {
        "schema_version": 1,
        "kind": "finite-agent-execution-interval-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
