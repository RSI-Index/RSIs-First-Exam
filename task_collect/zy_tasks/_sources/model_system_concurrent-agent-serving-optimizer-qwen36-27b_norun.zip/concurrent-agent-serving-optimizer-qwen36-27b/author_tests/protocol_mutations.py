#!/usr/bin/env python3
"""Author-side bad-gateway mutations exercised by the real protocol suite."""

from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import select
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from protocol_cases import NONSTREAM_BODY, ProtocolError, run_protocol_cases


HOP_BY_HOP = {
    "connection",
    "content-length",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
}
TRACE_HEADERS = {
    "x-agent-run-id",
    "x-kvbench-request-id",
    "x-kvbench-auth",
    "x-kvbench-audit-epoch",
    "x-kvbench-body-sha256",
    "x-kvbench-profile",
    "x-kvbench-leg",
    "x-kvbench-cache-namespace",
}


class MutationGatewayServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 128
    mode: str


class MutationGatewayHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "KVBenchMutation/1"

    @property
    def mutation_server(self) -> MutationGatewayServer:
        return self.server  # type: ignore[return-value]

    def log_message(self, _format: str, *_args: object) -> None:
        return

    @staticmethod
    def _connection_tokens(headers: list[tuple[str, str]]) -> set[str]:
        return {
            token.strip().lower()
            for name, value in headers
            if name.lower() == "connection"
            for token in value.split(",")
            if token.strip()
        }

    def _client_headers(self) -> list[tuple[str, str]]:
        source = list(self.headers.items())
        excluded = HOP_BY_HOP | self._connection_tokens(source) | {"host"}
        result: list[tuple[str, str]] = []
        for name, value in source:
            lowered = name.lower()
            if lowered in excluded:
                continue
            if self.mutation_server.mode == "strip_opaque_headers" and lowered in TRACE_HEADERS:
                continue
            result.append((name, value))
        return result

    @staticmethod
    def _open_upstream(
        method: str,
        path: str,
        body: bytes | None,
        headers: list[tuple[str, str]],
    ) -> http.client.HTTPConnection:
        connection = http.client.HTTPConnection("127.0.0.1", 18080, timeout=30)
        connection.putrequest(method, path)
        for name, value in headers:
            connection.putheader(name, value)
        if body is not None and not any(
            name.lower() == "content-length" for name, _ in headers
        ):
            connection.putheader("Content-Length", str(len(body)))
        connection.endheaders(body)
        return connection

    def _client_disconnected(self) -> bool:
        try:
            readable, _, _ = select.select([self.connection], [], [], 0)
            if not readable:
                return False
            return self.connection.recv(1, socket.MSG_PEEK) == b""
        except (BlockingIOError, InterruptedError):
            return False
        except OSError:
            return True

    def _await_upstream_response(
        self,
        connection: http.client.HTTPConnection,
    ) -> http.client.HTTPResponse:
        """Wait for headers while propagating a pre-header client disconnect."""

        completed = threading.Event()
        response: list[http.client.HTTPResponse] = []
        errors: list[BaseException] = []

        def receive() -> None:
            try:
                response.append(connection.getresponse())
            except BaseException as exc:  # The main handler re-raises this result.
                errors.append(exc)
            finally:
                completed.set()

        receiver = threading.Thread(target=receive, daemon=True)
        receiver.start()
        while not completed.wait(0.01):
            if not self._client_disconnected():
                continue
            if connection.sock is not None:
                try:
                    connection.sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
            connection.close()
            completed.wait(1)
            raise ConnectionResetError(
                "client disconnected before upstream response headers"
            )
        receiver.join(timeout=1)
        if errors:
            raise errors[0]
        if not response:
            raise RuntimeError("upstream response thread returned no result")
        return response[0]

    @staticmethod
    def _abort_upstream_response(response: http.client.HTTPResponse) -> None:
        """Close the detached socket even when HTTPConnection saw Connection: close."""

        buffered = response.fp
        raw = getattr(buffered, "raw", None) if buffered is not None else None
        upstream_socket = getattr(raw, "_sock", None)
        if upstream_socket is not None:
            try:
                upstream_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        response.close()

    def _upstream(
        self,
        method: str,
        path: str,
        body: bytes | None,
        headers: list[tuple[str, str]],
    ) -> tuple[http.client.HTTPConnection, http.client.HTTPResponse]:
        connection = self._open_upstream(method, path, body, headers)
        return connection, self._await_upstream_response(connection)

    @classmethod
    def _response_headers(
        cls,
        headers: list[tuple[str, str]],
    ) -> list[tuple[str, str]]:
        excluded = HOP_BY_HOP | cls._connection_tokens(headers) | {"server", "date"}
        return [
            (name, value)
            for name, value in headers
            if name.lower() not in excluded
        ]

    def _write_fixed(self, status: int, body: bytes, headers: list[tuple[str, str]]) -> None:
        self.send_response(status)
        for name, value in self._response_headers(headers):
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def _proxy(self, method: str, body: bytes | None = None) -> None:
        headers = self._client_headers()
        connection: http.client.HTTPConnection | None = None
        response: http.client.HTTPResponse | None = None
        try:
            connection, response = self._upstream(method, self.path, body, headers)
            response_headers = list(response.getheaders())
            is_stream = response.getheader("Content-Type", "").lower().startswith("text/event-stream")
            if not is_stream:
                payload = response.read()
                if self.mutation_server.mode == "truncate_body" and payload:
                    payload = payload[:-1]
                self._write_fixed(response.status, payload, response_headers)
                return

            self.send_response(response.status)
            for name, value in self._response_headers(response_headers):
                self.send_header(name, value)
            self.send_header("Transfer-Encoding", "chunked")
            self.end_headers()
            while True:
                if self._client_disconnected():
                    self._abort_upstream_response(response)
                    return
                chunk = response.read(16_384)
                if not chunk:
                    break
                self.wfile.write(f"{len(chunk):X}\r\n".encode())
                self.wfile.write(chunk)
                self.wfile.write(b"\r\n")
                self.wfile.flush()
                if self._client_disconnected():
                    self._abort_upstream_response(response)
                    return
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, socket.error):
            if response is not None:
                self._abort_upstream_response(response)
            return
        finally:
            if response is not None:
                response.close()
            if connection is not None:
                connection.close()

    def do_GET(self) -> None:  # noqa: N802
        self._proxy("GET")

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        if self.path == "/programs/release":
            self._write_fixed(
                404,
                b'{"error":"optional_control_unsupported"}',
                [("Content-Type", "application/json")],
            )
            return
        mode = self.mutation_server.mode
        if mode == "drop_request":
            self._write_fixed(503, b'{"error":"mutated_drop"}', [("Content-Type", "application/json")])
            return
        if mode == "fake_response":
            self._write_fixed(200, NONSTREAM_BODY, [("Content-Type", "application/json")])
            return
        if mode == "duplicate_backend_call" and b"case-nonstream" in body:
            duplicate_connection, duplicate_response = self._upstream(
                "POST", self.path, body, self._client_headers()
            )
            try:
                duplicate_response.read()
            finally:
                duplicate_connection.close()
        self._proxy("POST", body)


def run_mutation(mode: str) -> dict[str, Any]:
    server = MutationGatewayServer(("127.0.0.1", 9000), MutationGatewayHandler)
    server.mode = mode
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        try:
            # Cancellation has its own mandatory positive test in the full
            # verifier.  Omitting that one probe here lets audit mutations run
            # through to the precise duplicate/header ledger assertions.
            run_protocol_cases(include_disconnect=False)
        except ProtocolError as exc:
            return {"name": mode, "passed": True, "rejected_by": str(exc)}
        except Exception as exc:  # A mutation may break the transport before a semantic assertion.
            return {
                "name": mode,
                "passed": True,
                "rejected_by": f"{type(exc).__name__}: {exc}",
            }
        return {"name": mode, "passed": False, "rejected_by": None}
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
        # Failed mutations can leave a daemon request handler unwinding just
        # after the listening socket closes.  Give it a bounded drain window
        # before the next case reuses ports 9000/18080.
        time.sleep(0.25)


def run_positive_control() -> dict[str, Any]:
    server = MutationGatewayServer(("127.0.0.1", 9000), MutationGatewayHandler)
    server.mode = "transparent_control"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        result = run_protocol_cases(include_disconnect=True)
        return {
            "name": "transparent_control",
            "passed": bool(result.get("passed")),
            "checks": result.get("checks", []),
        }
    except Exception as exc:
        return {
            "name": "transparent_control",
            "passed": False,
            "rejected_by": f"{type(exc).__name__}: {exc}",
        }
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
        time.sleep(0.25)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    cases = [run_positive_control()] + [
        run_mutation(mode)
        for mode in (
            "fake_response",
            "drop_request",
            "truncate_body",
            "duplicate_backend_call",
            "strip_opaque_headers",
        )
    ]
    source = Path(__file__).resolve().parents[1] / "tests" / "protocol_cases.py"
    report = {
        "schema_version": 1,
        "kind": "protocol-cheat-mutations",
        "protocol_suite_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered, end="")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
