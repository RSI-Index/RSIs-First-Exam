#!/usr/bin/env python3
"""Fail-closed checks for the paper-aligned Qwen3.6 text adapter."""

from __future__ import annotations

import json
import os
import hashlib
import sys
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))

from runner.workload import (  # noqa: E402
    THUNDERAGENT_SWEBENCH_FORMAT_ERROR_TEMPLATE,
    THUNDERAGENT_SWEBENCH_INSTANCE_TEMPLATE,
    THUNDERAGENT_SWEBENCH_PROMPT_CONTRACT,
    THUNDERAGENT_SWEBENCH_SYSTEM_TEMPLATE,
    load_model_adapter_contract,
    task_prompt,
    workflow_cache_namespace,
)
from runner.corpus import TaskSpec  # noqa: E402


UPSTREAM_TEMPLATE_SHA256 = {
    "system": "75434201e849f434256fd3ad6cc5c936b4ac41dec988c3546e8532fc6fa73098",
    "instance": "dbafa361c3aa0c54e7d476773a8ae97bf585b728f1cd591a5da97f65b390a778",
    "format_error": "3a4c765859508b9f499353bb713f6c37b3bee170102e0872e9f206b37e82c7ae",
}


def main() -> int:
    previous = os.environ.pop("KV_MODEL_ADAPTER_MODE", None)
    try:
        default = load_model_adapter_contract()
        os.environ["KV_MODEL_ADAPTER_MODE"] = "qwen36-text-bash-v1"
        explicit = load_model_adapter_contract()
        os.environ["KV_MODEL_ADAPTER_MODE"] = ""
        empty = load_model_adapter_contract()

        rejected_modes: dict[str, bool] = {}
        for mode in (
            "glm46-text-bash-v1",
            "text-bash-v1",
            "gpt-oss-function-v1",
            "gpt-oss-function-v2",
            "gpt-oss-function-v3",
            "unknown-adapter",
        ):
            os.environ["KV_MODEL_ADAPTER_MODE"] = mode
            try:
                load_model_adapter_contract()
            except ValueError:
                rejected_modes[mode] = True
            else:
                rejected_modes[mode] = False
    finally:
        if previous is None:
            os.environ.pop("KV_MODEL_ADAPTER_MODE", None)
        else:
            os.environ["KV_MODEL_ADAPTER_MODE"] = previous

    model_config = default.model_config(512)
    summary = default.summary()
    source = (CONTROLLER_ROOT / "runner" / "workload.py").read_text().lower()
    namespace = workflow_cache_namespace("nonce", "leg", "task-r01")
    raw_problem_statement = (
        "First line from the dataset.\n\n"
        "Preserve whitespace and literal {{template_like_text}} exactly.\n"
    )
    swe_spec = TaskSpec(
        task_id="org__repo-1",
        issue=raw_problem_statement,
        module_name="org/repo",
        files={},
        workload_family="swebench-lite",
    )
    raw_task = task_prompt(swe_spec, 0, "opaque-nonce")
    rendered_instance = default.render_instance(raw_task)
    rendered_format_error = default.render_format_error([])
    rejects_synthetic_swe_padding = False
    try:
        task_prompt(swe_spec, 1, "opaque-nonce")
    except ValueError:
        rejects_synthetic_swe_padding = True

    template_hashes = {
        "system": hashlib.sha256(
            THUNDERAGENT_SWEBENCH_SYSTEM_TEMPLATE.encode()
        ).hexdigest(),
        "instance": hashlib.sha256(
            THUNDERAGENT_SWEBENCH_INSTANCE_TEMPLATE.encode()
        ).hexdigest(),
        "format_error": hashlib.sha256(
            THUNDERAGENT_SWEBENCH_FORMAT_ERROR_TEMPLATE.encode()
        ).hexdigest(),
    }
    checks = {
        "qwen36_mode_is_the_default": (
            default.mode == explicit.mode == empty.mode == "qwen36-text-bash-v1"
        ),
        "paper_text_protocol_uses_system_role": default.instruction_role == "system",
        "upstream_swebench_templates_are_byte_frozen": (
            template_hashes == UPSTREAM_TEMPLATE_SHA256
            and len(THUNDERAGENT_SWEBENCH_SYSTEM_TEMPLATE.encode()) == 543
            and len(THUNDERAGENT_SWEBENCH_INSTANCE_TEMPLATE.encode()) == 4764
            and len(THUNDERAGENT_SWEBENCH_FORMAT_ERROR_TEMPLATE.encode()) == 477
        ),
        "upstream_prompt_contract_marker_is_frozen": (
            THUNDERAGENT_SWEBENCH_PROMPT_CONTRACT
            == "thunderagent-a989f24-mini-swe-agent-swebench-yaml-v1"
            and summary["prompt_contract"] == THUNDERAGENT_SWEBENCH_PROMPT_CONTRACT
        ),
        "instruction_requires_thought_and_one_bash_fence": (
            "THOUGHT" in default.instruction
            and "exactly ONE bash code block" in default.instruction
            and "```bash" in default.instruction
        ),
        "format_correction_reinforces_text_bash": (
            "EXACTLY ONE action" in default.format_error_template
            and "```bash" in default.format_error_template
            and "function" not in default.format_error_template
        ),
        "instance_wraps_raw_problem_statement_without_rewriting": (
            raw_task == raw_problem_statement
            and rendered_instance
            == THUNDERAGENT_SWEBENCH_INSTANCE_TEMPLATE.replace(
                "{{task}}", raw_problem_statement
            ).rstrip("\n")
            and rendered_instance.startswith(
                "<pr_description>\nConsider the following PR description:\n"
            )
            and rendered_instance.endswith("</instructions>")
            and "Repository issue:" not in rendered_instance
            and "Pinned repository notes" not in rendered_instance
            and "Network access is disabled" not in rendered_instance
            and rejects_synthetic_swe_padding
        ),
        "first_turn_prompt_size_tracks_only_raw_task_bytes": (
            len(rendered_instance.encode())
            == 4764 - len("{{task}}".encode()) + len(raw_problem_statement.encode()) - 1
            and len(default.instruction.encode()) + len(rendered_instance.encode())
            == 543 + 4764 - 8 + len(raw_problem_statement.encode()) - 1
            and len(rendered_instance.encode()) > 4_800
        ),
        "format_error_template_renders_upstream_action_count": (
            "found 0 actions" in rendered_format_error
            and "{{actions|length}}" not in rendered_format_error
            and rendered_format_error.endswith("after that).")
        ),
        "paper_sampling_parameters": (
            default.temperature == 0.0
            and default.top_p == 1.0
            and model_config.temperature == 0.0
            and model_config.top_p == 1.0
        ),
        "profile_caps_are_honored_exactly": (
            default.model_config(96).max_tokens == 96
            and default.model_config(512).max_tokens == 512
            and default.model_config(2048).max_tokens == 2048
        ),
        "request_has_no_function_tool_or_reasoning_override": (
            not hasattr(model_config, "enable_execute_bash_tool")
            and not hasattr(model_config, "reasoning_effort")
            and not hasattr(model_config, "tool_choice")
            and model_config.enable_thinking is False
        ),
        "summary_freezes_protocol_and_token_policy": (
            summary["response_protocol"] == "single-bash-fence"
            and summary["max_tokens_policy"] == "profile_cap"
            and summary["function_tools"] is False
            and summary["reasoning_override"]
            == "qwen-chat-template-thinking-disabled"
            and summary["chat_template_kwargs"] == {"enable_thinking": False}
            and summary["instruction_sha256"] == UPSTREAM_TEMPLATE_SHA256["system"]
            and summary["instance_template_sha256"]
            == UPSTREAM_TEMPLATE_SHA256["instance"]
            and summary["format_error_sha256"]
            == UPSTREAM_TEMPLATE_SHA256["format_error"]
            and summary["task_input"] == "raw-problem-statement"
            and summary["offline_constraint"]
            == "sandbox-enforced-not-prompt-modified"
        ),
        "legacy_modes_fail_closed": all(rejected_modes.values()),
        "workflow_cache_namespace_is_stable_isolated_and_opaque": (
            namespace == workflow_cache_namespace("nonce", "leg", "task-r01")
            and namespace != workflow_cache_namespace("nonce", "leg", "task-r02")
            and namespace != workflow_cache_namespace("nonce", "other-leg", "task-r01")
            and len(namespace) == 64
            and all(character in "0123456789abcdef" for character in namespace)
            and "task" not in namespace
        ),
        "active_adapter_source_has_no_legacy_model_repairs": (
            "glm46-text-bash-v1" not in source
            and "gpt_oss" not in source
            and "gpt-oss" not in source
            and "harmony" not in source
            and "reasoning_effort" not in source
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "qwen36-model-adapter-contract-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "adapter": summary,
        "template_sha256": template_hashes,
        "representative_first_turn_chars": {
            "system": len(default.instruction),
            "user": len(rendered_instance),
            "combined": len(default.instruction) + len(rendered_instance),
            "raw_problem_statement": len(raw_problem_statement),
        },
        "rejected_legacy_modes": rejected_modes,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
