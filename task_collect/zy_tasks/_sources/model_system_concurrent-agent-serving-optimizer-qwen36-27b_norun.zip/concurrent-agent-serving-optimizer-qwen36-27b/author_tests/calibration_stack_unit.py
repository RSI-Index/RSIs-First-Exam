#!/usr/bin/env python3
"""CPU-only regression checks for calibration-stack host path handling."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
STACK_SCRIPT = TASK_ROOT / "scripts" / "calibration-stack.sh"
COMPOSE_FILE = TASK_ROOT / "environment" / "docker-compose.yaml"
CALIBRATION_COMPOSE_FILE = TASK_ROOT / "scripts" / "compose-calibration.yaml"
LOCAL_VERIFIER_COMPOSE_FILE = TASK_ROOT / "scripts" / "compose-local-verifier.yaml"


def write_executable(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(0o755)


def main() -> int:
    cases: list[dict[str, object]] = []
    stack_source = STACK_SCRIPT.read_text()
    compose_source = COMPOSE_FILE.read_text()
    calibration_compose_source = CALIBRATION_COMPOSE_FILE.read_text()
    local_verifier_compose_source = LOCAL_VERIFIER_COMPOSE_FILE.read_text()
    cases.append(
        {
            "name": "routine_stop_preserves_named_evidence_volumes",
            "passed": '"${compose[@]}" down --timeout 300 --remove-orphans'
            in stack_source
            and 'down --volumes' not in stack_source,
        }
    )
    cases.append(
        {
            "name": "sandbox_worker_gets_bounded_full_cohort_shutdown_grace",
            "passed": "sandbox-worker:" in compose_source
            and "stop_grace_period: 5m" in compose_source,
        }
    )
    cases.append(
        {
            "name": "compose_project_name_is_fixed",
            "passed": 'PROJECT_NAME="kvbench-qwen36-public30"' in stack_source
            and 'PROJECT_NAME="${KV_CALIBRATION_PROJECT' not in stack_source
            and "KV_CALIBRATION_PROJECT overrides are forbidden" in stack_source,
        }
    )
    cases.append(
        {
            "name": "release_requires_anchor_but_author_overlays_disable_it",
            "passed": 'RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED: "1"'
            in compose_source
            and 'RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED: "0"'
            in calibration_compose_source
            and 'RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED: "0"'
            in local_verifier_compose_source
            and "compose-calibration.yaml" in stack_source
            and "compose-local-verifier.yaml" in stack_source,
        }
    )
    prepare_source = stack_source[
        stack_source.index("prepare_local_verifier() {") : stack_source.index(
            '\ncase "$ACTION" in'
        )
    ]
    author_stage_markers = (
        'docker exec --user 0:0 "$main_container" sh -ceu',
        "rm -rf /app/submission",
        "cp -R /opt/reference-gateway /app/submission",
        "chown -R candidate:candidate /app/submission",
    )
    cases.append(
        {
            "name": "author_harness_root_replaces_submission_then_restores_candidate_owner",
            "passed": all(marker in prepare_source for marker in author_stage_markers)
            and [prepare_source.index(marker) for marker in author_stage_markers]
            == sorted(prepare_source.index(marker) for marker in author_stage_markers)
            and 'docker exec --user candidate "$main_container" sh -ceu'
            not in prepare_source,
        }
    )
    with tempfile.TemporaryDirectory(prefix="kvbench-calibration-stack-") as raw:
        root = Path(raw)
        fake_bin = root / "bin"
        fake_bin.mkdir()
        invocation_dir = root / "caller"
        invocation_dir.mkdir()
        runtime_dir = root / "qwen36-runtime"
        runtime_dir.mkdir()
        state_root = root / "state"
        corpus_root = state_root / "swebench-lite"
        corpus_root.mkdir(parents=True)
        (corpus_root / "manifest.json").write_text("{}\n")
        docker_capture = root / "docker-calls.tsv"
        status_reader_capture = root / "status-reader.py"

        write_executable(
            fake_bin / "docker",
            """#!/usr/bin/env bash
set -eu
printf '%s\\t%s\\n' "${KV_LOCAL_VERIFIER_LOGS-}" "$*" >> "${KV_TEST_DOCKER_CAPTURE:?}"
if [[ "${1:-}" == "info" && "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" != "1" ]]; then
  exit 1
fi
if [[ "$*" == *" ps --quiet main" ]]; then
  printf '%s\n' "fake-main"
fi
if [[ "$*" == *"exec --interactive --user 0:0 fake-main python3 -" ]]; then
  cat > "${KV_TEST_STATUS_READER_CAPTURE:?}"
  exit "${KV_TEST_STATUS_READER_RC:-0}"
fi
exit 0
""",
        )
        write_executable(
            fake_bin / "sg",
            """#!/usr/bin/env bash
set -eu
[[ "${1:-}" == "docker" && "${2:-}" == "-c" ]]
exec /bin/bash -c "${3:?missing command}"
""",
        )
        relative_output = Path("evidence") / "detached-run"
        expected_output = (invocation_dir / relative_output).resolve()
        expected_output.mkdir(parents=True)
        environment = os.environ.copy()
        environment["PATH"] = f"{fake_bin}:{environment['PATH']}"
        environment["HARBOR_KVBENCH_STATE_ROOT"] = str(state_root)
        environment["KV_TEST_DOCKER_CAPTURE"] = str(docker_capture)
        environment["KV_TEST_STATUS_READER_CAPTURE"] = str(status_reader_capture)
        environment.pop("KV_LOCAL_VERIFIER_LOGS", None)
        environment.pop("KV_TASK_DOCKER_GROUP_REEXEC", None)

        completed = subprocess.run(
            [
                str(STACK_SCRIPT),
                "verify-local-status",
                "--runtime-dir",
                str(runtime_dir),
                "--output-dir",
                str(relative_output),
            ],
            cwd=invocation_dir,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=30,
        )
        compose_paths = []
        if docker_capture.exists():
            for line in docker_capture.read_text().splitlines():
                output_path, _, command = line.partition("\t")
                if "compose-local-verifier.yaml" in command and " ps --quiet main" in command:
                    compose_paths.append(output_path)
        cases.append(
            {
                "name": "relative_output_dir_survives_docker_group_reexec",
                "passed": completed.returncode == 0
                and compose_paths == [str(expected_output)],
                "expected_output_dir": str(expected_output),
                "observed_compose_output_dirs": compose_paths,
                "command_output": completed.stdout[-2000:],
            }
        )

        reader_source = (
            status_reader_capture.read_text() if status_reader_capture.exists() else ""
        )
        cases.append(
            {
                "name": "status_reader_is_container_root_fixed_allowlist_only",
                "passed": all(
                    marker in reader_source
                    for marker in (
                        '("exit-code.txt", 16)',
                        '("report.json", 1024 * 1024)',
                        '("reward.json", 64 * 1024)',
                        '("reward.txt", 64)',
                        '("test-stdout.txt", 8 * 1024 * 1024)',
                        "os.O_NOFOLLOW",
                        "os.O_NONBLOCK",
                        "stat.S_ISREG",
                    )
                )
                and "private-report" not in reader_source
                and "listdir" not in reader_source
                and "iterdir" not in reader_source
                and ".glob(" not in reader_source,
            }
        )

        status_root = root / "status-evidence"
        status_root.mkdir()
        (status_root / "exit-code.txt").write_text("7\n")
        (status_root / "report.json").write_text("{}\n")
        (status_root / "reward.json").write_text('{"reward": 0}\n')
        (status_root / "reward.txt").write_text("0\n")
        (status_root / "test-stdout.txt").write_text("public status\n")
        private_marker = "HELDOUT-PRIVATE-STATUS-MARKER"
        (status_root / "private-report.json").write_text(private_marker + "\n")
        executable_reader = reader_source.replace(
            'VERIFIER_ROOT = "/logs/verifier"',
            f"VERIFIER_ROOT = {str(status_root)!r}",
        )
        safe_read = subprocess.run(
            [sys.executable, "-c", executable_reader],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=5,
        )
        cases.append(
            {
                "name": "status_reader_propagates_verifier_rc_without_private_enumeration",
                "passed": safe_read.returncode == 7
                and "verifier finished with exit code 7" in safe_read.stdout
                and "private-report" not in safe_read.stdout
                and private_marker not in safe_read.stdout,
                "command_output": safe_read.stdout[-2000:],
            }
        )

        exit_path = status_root / "exit-code.txt"
        exit_path.unlink()
        exit_path.symlink_to(status_root / "private-report.json")
        symlink_read = subprocess.run(
            [sys.executable, "-c", executable_reader],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=5,
        )
        cases.append(
            {
                "name": "status_reader_rejects_allowlisted_symlink",
                "passed": symlink_read.returncode == 4
                and private_marker not in symlink_read.stdout,
                "command_output": symlink_read.stdout[-2000:],
            }
        )

        exit_path.unlink()
        exit_path.write_text("0\n")
        stdout_path = status_root / "test-stdout.txt"
        stdout_path.unlink()
        os.mkfifo(stdout_path)
        fifo_read = subprocess.run(
            [sys.executable, "-c", executable_reader],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=5,
        )
        stdout_path.unlink()
        cases.append(
            {
                "name": "status_reader_rejects_fifo_without_blocking",
                "passed": fifo_read.returncode == 4,
                "command_output": fifo_read.stdout[-2000:],
            }
        )

        (status_root / "report.json").write_bytes(b"x" * (1024 * 1024 + 1))
        oversized_read = subprocess.run(
            [sys.executable, "-c", executable_reader],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=5,
        )
        cases.append(
            {
                "name": "status_reader_rejects_oversized_allowlisted_file",
                "passed": oversized_read.returncode == 4,
                "command_output": oversized_read.stdout[-2000:],
            }
        )

        (status_root / "report.json").write_text("{}\n")
        exit_path.write_text("256\n")
        invalid_exit_read = subprocess.run(
            [sys.executable, "-c", executable_reader],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=5,
        )
        cases.append(
            {
                "name": "status_reader_rejects_exit_code_outside_byte_range",
                "passed": invalid_exit_read.returncode == 4,
                "command_output": invalid_exit_read.stdout[-2000:],
            }
        )

        propagated_environment = environment.copy()
        propagated_environment["KV_TEST_STATUS_READER_RC"] = "37"
        propagated = subprocess.run(
            [
                str(STACK_SCRIPT),
                "verify-local-status",
                "--runtime-dir",
                str(runtime_dir),
                "--output-dir",
                str(relative_output),
            ],
            cwd=invocation_dir,
            env=propagated_environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=30,
        )
        cases.append(
            {
                "name": "status_action_propagates_container_reader_exit_code",
                "passed": propagated.returncode == 37,
                "command_output": propagated.stdout[-2000:],
            }
        )

        calls_before_override = (
            docker_capture.read_text().splitlines() if docker_capture.exists() else []
        )
        overridden_environment = environment.copy()
        overridden_environment["KV_CALIBRATION_PROJECT"] = "launch-unrelated"
        rejected = subprocess.run(
            [str(STACK_SCRIPT), "status", "--runtime-dir", str(runtime_dir)],
            cwd=invocation_dir,
            env=overridden_environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=30,
        )
        calls_after_override = (
            docker_capture.read_text().splitlines() if docker_capture.exists() else []
        )
        cases.append(
            {
                "name": "compose_project_override_is_rejected_before_docker",
                "passed": rejected.returncode == 2
                and "overrides are forbidden" in rejected.stdout
                and calls_after_override == calls_before_override,
                "command_output": rejected.stdout[-2000:],
            }
        )

    report = {
        "schema_version": 1,
        "kind": "calibration-stack-unit",
        "passed": all(bool(case["passed"]) for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
