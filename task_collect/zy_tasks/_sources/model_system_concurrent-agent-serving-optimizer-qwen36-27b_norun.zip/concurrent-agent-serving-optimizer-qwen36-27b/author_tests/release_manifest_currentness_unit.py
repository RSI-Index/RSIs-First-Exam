#!/usr/bin/env python3
"""CPU-only mutation checks for the real-agent release-currentness gate."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


SOURCE_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = SOURCE_ROOT / "scripts" / "verify-release-manifest.py"
SPEC = importlib.util.spec_from_file_location("verify_release_manifest", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
FREEZER = MODULE.FREEZER
SOURCE_REPOSITORY_ROOT = FREEZER.repository_root_for_task(SOURCE_ROOT)
RELEASE_ID = "qwen36-currentness-unit-release"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


@dataclass
class Fixture:
    root: Path
    manifest_path: Path
    readiness_path: Path
    policy_path: Path
    attestation_path: Path
    corpus_path: Path
    image_ids: dict[str, str]
    live_external: dict
    harbor_runtime: dict
    manifest: dict
    readiness: dict
    policy: dict

    def verify(
        self,
        *,
        image_resolver: Callable[[str], str] | None = None,
        harbor_identity_resolver: Callable[[Path], dict] | None = None,
        model_path: Path | None = None,
        pre_author_gate: bool = False,
    ) -> dict:
        resolver = image_resolver or (lambda reference: self.image_ids[reference])
        expected_live = copy.deepcopy(self.live_external)
        return MODULE.verify_release_manifest(
            manifest_path=self.manifest_path,
            readiness_path=self.readiness_path,
            policy_path=self.policy_path,
            attestation_path=self.attestation_path,
            model_path=(
                model_path
                if model_path is not None
                else Path(f"/models/{FREEZER.QWEN_REVISION}")
            ),
            corpus_manifest_path=self.corpus_path,
            task_root=self.root,
            image_id_resolver=resolver,
            external_attestation_validator=lambda *_args: copy.deepcopy(expected_live),
            harbor_bin_path=Path("/unit/harbor"),
            harbor_identity_resolver=(
                harbor_identity_resolver
                or (lambda _path: copy.deepcopy(self.harbor_runtime))
            ),
            pre_author_gate=pre_author_gate,
        )


def build_fixture(parent: Path) -> Fixture:
    repository_root = parent / "repository"
    root = repository_root / "harbor_tasks" / SOURCE_ROOT.name
    root.mkdir(parents=True)
    for name in ("environment", "tests", "scripts", "solution"):
        shutil.copytree(
            SOURCE_ROOT / name,
            root / name,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
    for name in ("task.toml", "instruction.md"):
        shutil.copy2(SOURCE_ROOT / name, root / name)
    for relative_name in FREEZER.REAL_AGENT_EXECUTION_SURFACE_ALLOWLIST:
        source = SOURCE_REPOSITORY_ROOT / relative_name
        destination = repository_root / relative_name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    policy_path = (
        root
        / "environment"
        / "bench-controller"
        / "profiles"
        / "scoring-policy.json"
    )
    policy = json.loads(policy_path.read_text())
    policy.update(
        {
            "release_id": RELEASE_ID,
            "release_ready": True,
            "not_ready_reasons": [],
        }
    )
    write_json(policy_path, policy)

    readiness_path = root / "calibration" / "release-readiness.json"
    readiness = {
        "schema_version": 2,
        "release_id": RELEASE_ID,
        "infrastructure_ready": True,
        "benchmark_ready": True,
        "oracle_ready": True,
        "real_agent_test_allowed": True,
        "blocking_gates": [],
    }
    write_json(readiness_path, readiness)

    corpus_path = parent / "corpus" / "manifest.json"
    write_json(
        corpus_path,
        {
            "schema_version": 1,
            "dataset": "princeton-nlp/SWE-bench_Lite",
            "dataset_revision": "unit-pinned",
            "instances": [{"instance_id": "unit"}],
        },
    )
    attestation_path = parent / "runtime" / "attestation.json"
    write_json(
        attestation_path,
        {
            "schema_version": 1,
            "state": "ready",
            "model": {
                "model_path": f"/models/{FREEZER.QWEN_REVISION}",
            },
        },
    )

    evidence_dir = root / "calibration" / "qwen36-release"
    public_direct_anchor_sha256 = "9" * 64
    evidence_payloads = {
        "oracle.json": {
            "schema_version": 2,
            "kind": "sanitized-full-verifier-evidence",
            "public_direct_anchor": {
                "schema_version": 1,
                "kind": "kvbench-release-public-direct-anchor",
                "sha256": public_direct_anchor_sha256,
            },
        },
    }
    for name, payload in evidence_payloads.items():
        write_json(evidence_dir / name, payload)
    index_path = evidence_dir / "evidence-index.json"
    write_json(
        index_path,
        {
            "schema_version": 1,
            "release_id": RELEASE_ID,
            "model_profile_sha256": FREEZER.QWEN_PROFILE_SHA256,
            "files": list(evidence_payloads),
        },
    )

    profile_path = (
        root / "environment" / "vllm-runtime" / "model-profile-qwen3.6-27b.json"
    )
    profile = json.loads(profile_path.read_text())
    image_ids = {
        reference: "sha256:" + f"{ordinal:x}" * 64
        for ordinal, reference in enumerate(FREEZER.DEFAULT_IMAGES.values(), start=1)
    }
    live_external = {
        "schema_version": 1,
        "state": "ready",
        "profile_id": FREEZER.QWEN_PROFILE_ID,
        "profile_sha256": FREEZER.QWEN_PROFILE_SHA256,
        "model_revision": FREEZER.QWEN_REVISION,
        "model_config_sha256": profile["required_files"]["config.json"],
        "model_weight_index_sha256": profile["required_files"]
        ["model.safetensors.index.json"],
        "runtime_image_id": profile["runtime"]["runtime_image_id"],
        "vllm_package_version": profile["runtime"]["vllm_package_version"],
        "tensor_parallel_size": 2,
        "kv_cache_dtype": "fp8",
        "tool_call_parser": None,
        "reasoning_parser": "qwen3",
        "model_mount_read_only": True,
        "runtime_boot_identity_sha256": "f" * 64,
    }
    critical_files, critical_tree = FREEZER.tree_manifest(
        FREEZER.critical_files(root), root
    )
    execution_surface = FREEZER.real_agent_execution_surface(repository_root)
    controller_config_files = {
        path.name: digest(path)
        for path in sorted(
            (root / "environment" / "bench-controller" / "profiles").glob("*.json")
        )
    }
    task_images = {
        name: {"reference": reference, "image_id": image_ids[reference]}
        for name, reference in FREEZER.DEFAULT_IMAGES.items()
    }
    evidence = {
        f"qwen36-release/{name}": digest(evidence_dir / name)
        for name in evidence_payloads
    }
    manifest_path = root / "calibration" / "release-manifest.json"
    harbor_runtime = {
        "schema_version": 1,
        "layout": "uv-tool-venv-v1",
        "harbor_version": "0.18.0",
        "distribution_version": "0.18.0",
        "entrypoint_path": "/unit/harbor/bin/harbor",
        "entrypoint_sha256": "a" * 64,
        "venv_root": "/unit/harbor",
        "pyvenv_cfg_sha256": "d" * 64,
        "uv_receipt_sha256": "e" * 64,
        "interpreter_path": "/unit/harbor/bin/python",
        "interpreter_realpath": "/unit/python3.14",
        "interpreter_implementation": "CPython",
        "interpreter_version": "3.14.0",
        "interpreter_sha256": "b" * 64,
        "stdlib_path": "/unit/python3.14/lib/python3.14",
        "stdlib_file_count": 886,
        "stdlib_tree_sha256": "1" * 64,
        "stdlib_tree_policy": "all-regular-except-site-packages-and-__pycache__-v1",
        "stdlib_zip": {
            "present": False,
            "path": "/unit/python3.14/lib/python314.zip",
        },
        "package_root": "/unit/harbor/site-packages/harbor",
        "dist_info_name": "harbor-0.18.0.dist-info",
        "module_relative_path": "harbor/__init__.py",
        "module_sha256": "f" * 64,
        "site_packages_path": "/unit/harbor/site-packages",
        "site_packages_file_count": 7575,
        "site_packages_tree_sha256": "c" * 64,
        "tree_policy": "all-regular-files-except-__pycache__-v1",
        "pth_policy": "exact-_virtualenv.pth-import-local-module-v1",
        "isolated_import_required": True,
    }
    manifest = {
        "schema_version": 3,
        "release_id": RELEASE_ID,
        "generated_at_utc": "2026-07-19T00:00:00Z",
        "harbor_version": harbor_runtime["harbor_version"],
        "harbor_runtime": FREEZER.publishable_harbor_runtime_identity(
            harbor_runtime
        ),
        "model": {
            "model_id": FREEZER.QWEN_REPOSITORY,
            "revision": FREEZER.QWEN_REVISION,
            "config_sha256": profile["required_files"]["config.json"],
            "weight_index_sha256": profile["required_files"]
            ["model.safetensors.index.json"],
        },
        "runtime": {
            "lifecycle": "external-host-vllm",
            "transport": "unix-domain-socket",
            "model_profile_path": (
                "environment/vllm-runtime/model-profile-qwen3.6-27b.json"
            ),
            "model_profile_id": FREEZER.QWEN_PROFILE_ID,
            "model_profile_sha256": FREEZER.QWEN_PROFILE_SHA256,
            "external_vllm": copy.deepcopy(live_external),
            "task_images": task_images,
        },
        "benchmark": {
            "controller_config_files": controller_config_files,
            "scoring_policy_sha256": digest(policy_path),
            "scoring_policy_contract_sha256": FREEZER.policy_contract_sha256(
                policy
            ),
            "release_evidence_policy": copy.deepcopy(
                FREEZER.RELEASE_EVIDENCE_POLICY
            ),
            "reference_gateway_tree_sha256": (
                FREEZER.reference_gateway_tree_sha256(
                    root / "solution" / "reference_gateway"
                )
            ),
            "reference_submission_sha256": FREEZER.reference_submission_sha256(
                root / "solution" / "reference_gateway", root / "solution" / "solve.sh"
            ),
            "corpus": {"manifest_sha256": digest(corpus_path)},
        },
        "critical_tree_sha256": critical_tree,
        "critical_files": critical_files,
        "real_agent_execution_surface": execution_surface,
        "calibration_evidence_index_sha256": digest(index_path),
        "calibration_evidence_sha256": evidence,
        "public_direct_anchor_sha256": public_direct_anchor_sha256,
    }
    write_json(manifest_path, manifest)
    return Fixture(
        root=root,
        manifest_path=manifest_path,
        readiness_path=readiness_path,
        policy_path=policy_path,
        attestation_path=attestation_path,
        corpus_path=corpus_path,
        image_ids=image_ids,
        live_external=live_external,
        harbor_runtime=harbor_runtime,
        manifest=manifest,
        readiness=readiness,
        policy=policy,
    )


def expect_rejected(label: str, callback: Callable[[], object]) -> None:
    try:
        callback()
    except (MODULE.ManifestVerificationError, OSError, SystemExit, ValueError):
        return
    raise AssertionError(f"stale release manifest mutation was accepted: {label}")


def mutate_manifest(fixture: Fixture, label: str, mutation: Callable[[dict], None]) -> None:
    changed = copy.deepcopy(fixture.manifest)
    mutation(changed)
    write_json(fixture.manifest_path, changed)
    try:
        expect_rejected(label, fixture.verify)
        write_json(
            fixture.readiness_path,
            {**fixture.readiness, "real_agent_test_allowed": False},
        )
        try:
            expect_rejected(
                f"pre-author mode: {label}",
                lambda: fixture.verify(pre_author_gate=True),
            )
        finally:
            write_json(fixture.readiness_path, fixture.readiness)
    finally:
        write_json(fixture.manifest_path, fixture.manifest)


with tempfile.TemporaryDirectory(prefix="release-currentness-unit-") as temporary:
    fixture = build_fixture(Path(temporary))
    valid = fixture.verify()
    assert valid["release_id"] == RELEASE_ID
    assert valid["task_image_count"] == 4
    assert valid["evidence_file_count"] == 1
    assert valid["real_agent_execution_file_count"] == len(
        FREEZER.REAL_AGENT_EXECUTION_SURFACE_ALLOWLIST
    )
    assert valid["real_agent_execution_tree_sha256"] == fixture.manifest[
        "real_agent_execution_surface"
    ]["tree_sha256"]
    assert (
        valid["release_evidence_policy_id"]
        == "single-oracle-public1800-anchor-hidden-committed-pair-v6-tier-qualified-v3"
    )
    assert valid["public_direct_anchor_sha256"] == "9" * 64
    manifest_rendered = fixture.manifest_path.read_text()
    for forbidden in (
        "model_path",
        "snapshot_path",
        "attestation_path",
        "socket_path",
        "wrapper_pid",
        "wrapper_start_ticks",
        "container_id",
        "launch_token_sha256",
        "gpu_uuids",
        "/unit/harbor",
        "/models/",
    ):
        assert forbidden not in manifest_rendered
    assert set(fixture.manifest["runtime"]["external_vllm"]) == (
        FREEZER.PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS
    )
    assert set(fixture.manifest["harbor_runtime"]) == (
        FREEZER.PUBLISHABLE_HARBOR_RUNTIME_KEYS
    )
    expect_rejected(
        "pre-author mode after author flip",
        lambda: fixture.verify(pre_author_gate=True),
    )
    expect_rejected(
        "caller private model path mismatch",
        lambda: fixture.verify(
            model_path=Path(f"/different/{FREEZER.QWEN_REVISION}")
        ),
    )

    mutate_manifest(fixture, "old schema", lambda value: value.update(schema_version=2))
    mutate_manifest(
        fixture, "three-way release ID", lambda value: value.update(release_id="old")
    )
    mutate_manifest(
        fixture,
        "Harbor package identity",
        lambda value: value["harbor_runtime"].update(
            site_packages_tree_sha256="0" * 64
        ),
    )
    mutate_manifest(
        fixture,
        "Harbor version alias",
        lambda value: value.update(harbor_version="0.18.0-forged"),
    )
    expect_rejected(
        "live Harbor package drift",
        lambda: fixture.verify(
            harbor_identity_resolver=lambda _path: {
                **fixture.harbor_runtime,
                "site_packages_tree_sha256": "9" * 64,
            }
        ),
    )
    mutate_manifest(
        fixture,
        "critical file map",
        lambda value: value["critical_files"].pop("instruction.md"),
    )
    mutate_manifest(
        fixture,
        "critical tree digest",
        lambda value: value.update(critical_tree_sha256="0" * 64),
    )
    mutate_manifest(
        fixture,
        "missing real-agent execution surface",
        lambda value: value.pop("real_agent_execution_surface"),
    )
    mutate_manifest(
        fixture,
        "real-agent execution allowlist entry missing",
        lambda value: value["real_agent_execution_surface"]["allowlist"].pop(),
    )
    mutate_manifest(
        fixture,
        "real-agent execution allowlist drift",
        lambda value: value["real_agent_execution_surface"]["allowlist"].append(
            "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/untrusted.sh"
        ),
    )
    mutate_manifest(
        fixture,
        "real-agent execution file digest",
        lambda value: value["real_agent_execution_surface"][
            "files_sha256"
        ].update(
            {
                "local_ext/concurrent_agent_serving_codex_continuation.py": "0"
                * 64
            }
        ),
    )
    mutate_manifest(
        fixture,
        "real-agent execution tree digest",
        lambda value: value["real_agent_execution_surface"].update(
            tree_sha256="0" * 64
        ),
    )
    mutate_manifest(
        fixture,
        "scoring policy digest",
        lambda value: value["benchmark"].update(scoring_policy_sha256="0" * 64),
    )
    mutate_manifest(
        fixture,
        "policy contract digest",
        lambda value: value["benchmark"].update(
            scoring_policy_contract_sha256="0" * 64
        ),
    )
    mutate_manifest(
        fixture,
        "release evidence policy",
        lambda value: value["benchmark"]["release_evidence_policy"].update(
            minimum_oracle_reports=0
        ),
    )
    mutate_manifest(
        fixture,
        "Qwen profile identity",
        lambda value: value["runtime"].update(model_profile_id="wrong"),
    )
    mutate_manifest(
        fixture,
        "Qwen revision",
        lambda value: value["model"].update(revision="unpinned"),
    )
    mutate_manifest(
        fixture,
        "live vLLM attestation",
        lambda value: value["runtime"]["external_vllm"].update(
            vllm_package_version="stale"
        ),
    )
    mutate_manifest(
        fixture,
        "private model path injection",
        lambda value: value["model"].update(
            model_path=f"/models/{FREEZER.QWEN_REVISION}"
        ),
    )
    mutate_manifest(
        fixture,
        "raw runtime PID injection",
        lambda value: value["runtime"]["external_vllm"].update(wrapper_pid=1234),
    )
    mutate_manifest(
        fixture,
        "raw runtime socket/GPU injection",
        lambda value: value["runtime"]["external_vllm"].update(
            socket_path="/tmp/unit/vllm.sock",
            gpu_uuids=["GPU-private"],
        ),
    )
    mutate_manifest(
        fixture,
        "exact four task image set",
        lambda value: value["runtime"]["task_images"].pop("main"),
    )
    expect_rejected(
        "live task image ID",
        lambda: fixture.verify(image_resolver=lambda _reference: "sha256:" + "f" * 64),
    )
    mutate_manifest(
        fixture,
        "Oracle gateway tree",
        lambda value: value["benchmark"].update(
            reference_gateway_tree_sha256="0" * 64
        ),
    )
    mutate_manifest(
        fixture,
        "Oracle submission",
        lambda value: value["benchmark"].update(
            reference_submission_sha256="0" * 64
        ),
    )
    mutate_manifest(
        fixture,
        "evidence index digest",
        lambda value: value.update(calibration_evidence_index_sha256="0" * 64),
    )
    mutate_manifest(
        fixture,
        "evidence exact set",
        lambda value: value["calibration_evidence_sha256"].pop(
            "qwen36-release/oracle.json"
        ),
    )
    mutate_manifest(
        fixture,
        "public Direct anchor digest",
        lambda value: value.update(public_direct_anchor_sha256="0" * 64),
    )

    original_readiness = fixture.readiness_path.read_bytes()
    write_json(fixture.readiness_path, {**fixture.readiness, "real_agent_test_allowed": False})
    try:
        expect_rejected("readiness flag", fixture.verify)
        assert fixture.verify(pre_author_gate=True)["release_id"] == RELEASE_ID
        changed = copy.deepcopy(fixture.manifest)
        changed["benchmark"]["reference_submission_sha256"] = "0" * 64
        write_json(fixture.manifest_path, changed)
        try:
            expect_rejected(
                "pre-author mode still checks every manifest identity",
                lambda: fixture.verify(pre_author_gate=True),
            )
        finally:
            write_json(fixture.manifest_path, fixture.manifest)
    finally:
        fixture.readiness_path.write_bytes(original_readiness)

    original_policy = fixture.policy_path.read_bytes()
    write_json(fixture.policy_path, {**fixture.policy, "release_ready": False})
    try:
        expect_rejected("policy release flag", fixture.verify)
    finally:
        fixture.policy_path.write_bytes(original_policy)

    original_corpus = fixture.corpus_path.read_bytes()
    fixture.corpus_path.write_bytes(original_corpus + b" \n")
    try:
        expect_rejected("corpus SHA", fixture.verify)
    finally:
        fixture.corpus_path.write_bytes(original_corpus)

    repository_root = FREEZER.repository_root_for_task(fixture.root)
    execution_path = (
        repository_root
        / "local_ext/concurrent_agent_serving_codex_continuation.py"
    )
    original_execution = execution_path.read_bytes()
    execution_path.write_bytes(original_execution + b"\n# mutation\n")
    try:
        expect_rejected("live real-agent execution file mutation", fixture.verify)
    finally:
        execution_path.write_bytes(original_execution)

    missing_execution_path = repository_root / "harbor_ext/agent_shell_safety.py"
    held_execution_path = missing_execution_path.with_suffix(".py.unit-held")
    missing_execution_path.rename(held_execution_path)
    try:
        expect_rejected("live real-agent execution file missing", fixture.verify)
    finally:
        held_execution_path.rename(missing_execution_path)

    # The allowlist is intentionally closed: unrelated files beside a runner
    # are not silently trusted and therefore do not perturb release currentness.
    untrusted_extra = (
        repository_root
        / "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/untrusted.sh"
    )
    untrusted_extra.write_text("#!/usr/bin/env bash\nexit 1\n")
    try:
        assert fixture.verify()["release_id"] == RELEASE_ID
    finally:
        untrusted_extra.unlink()

    evidence_path = fixture.root / "calibration" / "qwen36-release" / "oracle.json"
    original_evidence = evidence_path.read_bytes()
    evidence_path.write_bytes(original_evidence + b" \n")
    try:
        expect_rejected("evidence SHA", fixture.verify)
    finally:
        evidence_path.write_bytes(original_evidence)

    extra_evidence = fixture.root / "calibration" / "qwen36-release" / "unindexed.json"
    write_json(extra_evidence, {"schema_version": 1})
    try:
        expect_rejected("unindexed evidence JSON", fixture.verify)
    finally:
        extra_evidence.unlink()

    real_manifest = fixture.manifest_path.with_suffix(".real.json")
    fixture.manifest_path.rename(real_manifest)
    fixture.manifest_path.symlink_to(real_manifest.name)
    try:
        expect_rejected("symlink manifest", fixture.verify)
    finally:
        fixture.manifest_path.unlink()
        real_manifest.rename(fixture.manifest_path)

run_local = (SOURCE_ROOT / "scripts" / "run-local-h100.sh").read_text()
real_agent_rejection = run_local.index(
    "run-local-h100.sh is author-only and permits only oracle/nop agents"
)
docker_reexec = run_local.index("if ! docker info")
host_status = run_local.index('"$SCRIPT_DIR/host-vllm-qwen36-27b.sh" status')
corpus_preflight = run_local.index('"$SCRIPT_DIR/validate-staged-corpus.py"')
harbor_run = run_local.index('command=("$HARBOR_BIN" run --path')
assert real_agent_rejection < docker_reexec < host_status < corpus_preflight < harbor_run
assert 'if ((real_agent_requested)); then' in run_local[:real_agent_rejection]
assert 'verify-release-manifest.py' not in run_local
assert 'use the frozen canonical GPT-5.6 Luna runner' in run_local
assert '-u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH' in run_local
assert '-u PYTHONHOME -u PYTHONPATH' in run_local

print(
    "release manifest currentness unit: passed "
    "(default/pre-author valid paths + task/runtime/evidence execution-surface "
    "mutations; all allowlisted drifts rejected in both modes and unrelated "
    "runner files remain outside trust)"
)
