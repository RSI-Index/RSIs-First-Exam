#!/usr/bin/env python3
"""Static isolation checks for the external-vLLM UDS topology."""

from __future__ import annotations

import json
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
COMPOSE = (TASK_ROOT / "environment" / "docker-compose.yaml").read_text()
MODEL_API_SERVER = (TASK_ROOT / "environment" / "model-api" / "server.py").read_text()
MAIN_ENTRYPOINT = (TASK_ROOT / "environment" / "container-entrypoint.sh").read_text()
MAIN_DOCKERFILE = (TASK_ROOT / "environment" / "Dockerfile").read_text()
LOOPBACK_BRIDGE = (TASK_ROOT / "environment" / "loopback_bridge.py").read_text()
CONTROLLER_MODEL = (
    TASK_ROOT / "environment" / "bench-controller" / "runner" / "model.py"
).read_text()
CONTROLLER_WORKLOAD = (
    TASK_ROOT / "environment" / "bench-controller" / "runner" / "workload.py"
).read_text()
LIVE_SAMPLER_SOURCE = CONTROLLER_WORKLOAD.split(
    "class LiveMetricsSampler", 1
)[1].split("def wait_for_quiescence", 1)[0]


def service_section(name: str, next_name: str | None) -> str:
    lines = COMPOSE.splitlines()
    start_line = f"  {name}:"
    try:
        start = lines.index(start_line) + 1
    except ValueError:
        return ""
    if next_name is None:
        end = next(
            (index for index in range(start, len(lines)) if lines[index] and not lines[index].startswith(" ")),
            len(lines),
        )
    else:
        end = lines.index(f"  {next_name}:", start)
    return "\n".join(lines[start:end])


def main() -> int:
    main_service = service_section("main", "model-api")
    model_api = service_section("model-api", "bench-controller")
    controller = service_section("bench-controller", "sandbox-worker")
    worker = service_section("sandbox-worker", None).split("\nnetworks:\n", 1)[0]

    checks = {
        "no_compose_vllm_service": "\n  vllm:\n" not in COMPOSE,
        "no_compose_gpu_reservation": "capabilities: [gpu]" not in COMPOSE,
        "no_tcp_upstream_configuration": "UPSTREAM:" not in model_api,
        "uds_path_is_fixed_inside_proxy": (
            "UPSTREAM_UNIX_SOCKET: /run/kvbench-vllm/vllm.sock" in model_api
        ),
        "attestation_shares_trusted_runtime_mount": (
            "ATTESTATION_FILE: /run/kvbench-vllm/attestation.json" in model_api
        ),
        "runtime_dir_is_author_supplied": (
            "${HARBOR_VLLM_RUNTIME_DIR:?start the host Qwen3.6-27B TP2 vLLM first}"
            in model_api
        ),
        "runtime_mount_is_read_only": (
            "target: /run/kvbench-vllm" in model_api
            and "read_only: true" in model_api
            and "create_host_path: false" in model_api
        ),
        "candidate_has_no_runtime_mount": "/run/kvbench-vllm" not in main_service,
        "controller_has_no_runtime_mount": "/run/kvbench-vllm" not in controller,
        "sandbox_has_no_runtime_mount": "/run/kvbench-vllm" not in worker,
        "no_model_backend_network": "model-backend" not in COMPOSE,
        "candidate_contract_remains_loopback": (
            "MODEL_API_BASE: http://127.0.0.1:8100/v1" in main_service
        ),
        "front_network_has_no_external_route": (
            "  front:\n    internal: true" in COMPOSE
        ),
        "root_admin_token_mount_remains_read_only_in_main": (
            "verifier-control:/run/kvbench-admin:ro" in main_service
            and "ADMIN_TOKEN_FILE: /run/kvbench-admin/token" in main_service
        ),
        "candidate_receives_only_credential_path_not_secret": (
            "BRIDGE_CREDENTIAL_FILE: /run/kvbench-bridge/transport.credential"
            in main_service
            and "TRANSPORT_AUTH_HEADER" not in main_service
        ),
        "bridge_secret_is_root_group_narrow": (
            'install -d -o root -g bridge -m 0750' in MAIN_ENTRYPOINT
            and "--owner-uid 0" in MAIN_ENTRYPOINT
            and 'os.fchmod(descriptor, 0o440)' in LOOPBACK_BRIDGE
            and 'os.fchown(descriptor, owner_uid, owner_gid)' in LOOPBACK_BRIDGE
        ),
        "uid900_bridge_replaces_raw_socat_relay": (
            'python3 /opt/kvbench/loopback_bridge.py serve' in MAIN_ENTRYPOINT
            and '--reuid "$bridge_uid"' in MAIN_ENTRYPOINT
            and "socat" not in MAIN_ENTRYPOINT
            and "socat" not in MAIN_DOCKERFILE
        ),
        "bridge_streams_without_response_buffer_or_retry": (
            'async for chunk in upstream.content.iter_any()' in LOOPBACK_BRIDGE
            and 'await downstream.write(chunk)' in LOOPBACK_BRIDGE
            and "response.read()" not in LOOPBACK_BRIDGE
            and "for attempt" not in LOOPBACK_BRIDGE
            and "tenacity" not in LOOPBACK_BRIDGE
        ),
        "bridge_matches_frozen_192_data_plane": (
            "connector=TCPConnector(\n            limit=192,\n"
            "            limit_per_host=0,\n            force_close=True," in LOOPBACK_BRIDGE
            and 'app["data_client"]' in LOOPBACK_BRIDGE
        ),
        "bridge_control_plane_is_not_starved": (
            'app["control_client"]' in LOOPBACK_BRIDGE
            and "connector=TCPConnector(\n            limit=8,\n"
            "            limit_per_host=0,\n            force_close=True," in LOOPBACK_BRIDGE
        ),
        "controller_uses_trusted_proxy": (
            "BASELINE_URL: http://model-api:8100/v1" in controller
            and "TRUSTED_MODEL_API_DATA_URL: http://model-api:8100/v1" in controller
            and "MODEL_API_URL: http://model-api:8100" in controller
        ),
        "controller_credential_is_direct_leg_only": (
            'return endpoint.rstrip("/") == trusted.rstrip("/")' in CONTROLLER_MODEL
            and "transport_headers_for_endpoint(self.endpoint, self.admin_token)"
            in CONTROLLER_MODEL
            and 'return {}' in CONTROLLER_MODEL
        ),
        "model_api_authenticates_before_data_handlers": (
            "middlewares=[require_data_plane_transport]" in MODEL_API_SERVER
            and 'request.path.startswith("/v1/")' in MODEL_API_SERVER
            and "if not transport_allowed(request):" in MODEL_API_SERVER
            and "benchmark_auth_valid(" in MODEL_API_SERVER
            and "if not valid:" in MODEL_API_SERVER
            and "raise rejection" in MODEL_API_SERVER
        ),
        "transport_secret_never_reaches_vllm": (
            '"x-kvbench-transport-auth"' in MODEL_API_SERVER
            and "PRIVATE_FORWARD_HEADERS" in MODEL_API_SERVER
        ),
        "signed_digest_is_verified_before_candidate_body_buffering": (
            'request.headers.get("X-KVBench-Body-SHA256", "")'
            in MODEL_API_SERVER
            and MODEL_API_SERVER.index("if not valid:")
            < MODEL_API_SERVER.index(
                'actual_body_digest = hashlib.sha256(await request.read()).hexdigest()'
            )
            and "client_max_size=16 * 1024**2" in MODEL_API_SERVER
        ),
        "measurement_reset_is_an_exclusive_epoch_boundary": (
            'async def admin_measurement_reset' in MODEL_API_SERVER
            and 'data_plane_gate"].exclusive()' in MODEL_API_SERVER
            and 'app["seen_request_ids"].clear()' in MODEL_API_SERVER
            and 'app.router.add_post("/admin/measurement/reset"'
            in MODEL_API_SERVER
        ),
        "measurement_cutoff_seals_epoch_and_cancels_atomic_admissions": (
            'async def admin_measurement_cutoff' in MODEL_API_SERVER
            and 'app["audit_epoch_sealed"] = True' in MODEL_API_SERVER
            and 'tasks = list(app["admitted_tasks"])' in MODEL_API_SERVER
            and 'request.app["admitted_tasks"].add(admitted_task)' in MODEL_API_SERVER
            and 'request.app["admitted_tasks"].discard(admitted_task)' in MODEL_API_SERVER
            and 'app.router.add_post("/admin/measurement/cutoff"' in MODEL_API_SERVER
        ),
        "uds_data_plane_matches_frozen_192_sequence_ceiling": (
            "path=str(UPSTREAM_SOCKET),\n            limit=192,\n"
            "            limit_per_host=0,\n            force_close=True," in MODEL_API_SERVER
        ),
        "uds_data_plane_does_not_reuse_stale_stream_transports": (
            "force_close=True" in MODEL_API_SERVER
            and "without adding retries" in MODEL_API_SERVER
        ),
        "uds_control_plane_is_not_starved_by_long_streams": (
            'UnixConnector(path=str(UPSTREAM_SOCKET), limit=8, limit_per_host=0)'
            in MODEL_API_SERVER
            and 'app["control_client"]' in MODEL_API_SERVER
            and 'app["data_client"]' in MODEL_API_SERVER
        ),
        "metrics_snapshot_carries_lightweight_watchdog_state": (
            '"active_backend_requests": active_backend_requests'
            in MODEL_API_SERVER
            and '"audit_epoch": audit_epoch' in MODEL_API_SERVER
            and '"audit_count": audit_count' in MODEL_API_SERVER
            and '"admitted_request_count": admitted_request_count'
            in MODEL_API_SERVER
            and 'app["audit_count"] += 1' in MODEL_API_SERVER
            and 'app["audit_count"] = 0' in MODEL_API_SERVER
        ),
        "full_audit_is_not_polled_by_live_sampler": (
            '"/admin/audit/snapshot"' not in LIVE_SAMPLER_SOURCE
            and '"/admin/quiescent"' not in LIVE_SAMPLER_SOURCE
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "model-api-topology-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
