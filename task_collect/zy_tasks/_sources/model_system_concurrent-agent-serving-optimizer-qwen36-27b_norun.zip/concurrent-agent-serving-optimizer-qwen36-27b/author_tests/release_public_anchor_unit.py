#!/usr/bin/env python3
"""CPU-only fail-closed tests for the release public Direct anchor."""

from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import os
import stat
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any, Callable


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))
sys.path.insert(0, str(CONTROLLER_ROOT))


class FakeResponse:
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        self.payload = payload
        self.status = status


def json_response(payload: dict[str, Any], *, status: int = 200) -> FakeResponse:
    return FakeResponse(payload, status)


# aiohttp is intentionally absent from the author CPU-test image.  The selected
# controller paths need only json_response and are otherwise driven directly.
aiohttp = ModuleType("aiohttp")
aiohttp.ClientSession = object
aiohttp.ClientTimeout = object
aiohttp.web = SimpleNamespace(
    json_response=json_response,
    middleware=lambda function: function,
)
sys.modules.setdefault("aiohttp", aiohttp)

import server as server_module  # noqa: E402


PROFILE = server_module.RELEASE_PUBLIC_PROFILE
RELEASE_ID = server_module.RELEASE_PUBLIC_ID
NAMESPACE = "public-public-pressure-192"
NONCE = "0123456789abcdef" * 4
NONCE_SHA256 = hashlib.sha256(NONCE.encode()).hexdigest()
CONFIG_SHA256 = "3" * 64
CORPUS_SHA256 = "4" * 64


class FakeRequest:
    def __init__(self, app: dict[str, Any], payload: dict[str, Any]) -> None:
        self.app = app
        self._payload = payload

    async def json(self) -> dict[str, Any]:
        return self._payload


def provenance(*, boot: str = "a" * 64) -> dict[str, Any]:
    return {
        "profile_id": server_module.QWEN_PROFILE_ID,
        "profile_sha256": server_module.QWEN_PROFILE_SHA256,
        "model_revision": server_module.QWEN_REVISION,
        "runtime_image_id": "sha256:" + "b" * 64,
        "tensor_parallel_size": 2,
        "kv_cache_dtype": "fp8",
        "runtime_boot_identity_sha256": boot,
    }


def valid_leg(
    profile: server_module.Profile,
    model_adapter: dict[str, Any],
    *,
    mode: str = "baseline",
    run_id: str = "baseline-anchor-unit",
) -> dict[str, Any]:
    valid_steps = 3_000
    post_cutoff_steps = 1
    total_executed_steps = valid_steps + post_cutoff_steps
    elapsed = 1800.0
    effective_model_adapter = copy.deepcopy(model_adapter)
    effective_model_adapter["effective_max_tokens"] = profile.max_tokens
    return {
        "schema_version": 1,
        "run_id": run_id,
        "mode": mode,
        "profile": PROFILE,
        "profile_config": asdict(profile),
        "model_adapter": effective_model_adapter,
        "model_provenance": provenance(),
        "corpus_namespace": NAMESPACE,
        "corpus_fingerprint": CORPUS_SHA256,
        "workload_nonce_sha256": NONCE_SHA256,
        "controller_config_sha256": CONFIG_SHA256,
        "release_id": RELEASE_ID,
        "started_unix": 1_000.0,
        "ended_unix": 2_800.0,
        "wall_ended_unix": 2_806.0,
        "elapsed_sec": elapsed,
        "wall_elapsed_sec": 1806.0,
        "valid_steps": valid_steps,
        "total_executed_steps": total_executed_steps,
        "valid_steps_per_min": valid_steps * 60.0 / elapsed,
        "completed_workflows": 0,
        "completed_workflows_per_min": 0.0,
        "tests_passed_workflows": 0,
        "tests_passed_workflows_per_min": 0.0,
        "minimum_workflow_progress": 1,
        "zero_progress_workflows": 0,
        "request_count": 1_100,
        "measured_request_count": 1_000,
        "request_success_rate": 1.0,
        "valid_step_ratio": 0.99,
        "jain_progress_fairness": 0.99,
        "backend_tokens_per_valid_step": 4_500.0,
        "aggregate_model_query_sec": 50_000.0,
        "aggregate_tool_sec": 100.0,
        "model_query_time_fraction": 0.99,
        "prompt_tokens": 4_000_000,
        "completion_tokens": 500_000,
        "p95_tool_latency_sec": 0.1,
        "infrastructure_failure": None,
        "candidate_failure": None,
        "backend_audit": {
            "passed": True,
            "window_censored": True,
            "client_requests": 1_100,
            "audited_backend_requests": 1_100,
            "strict_client_requests": 1_000,
            "cutoff_client_requests": 100,
            "cutoff_backend_admitted": 100,
            "cutoff_backend_unadmitted": 0,
            "extra_backend_requests": 0,
            "missing_backend_requests": 0,
            "mismatches": [],
            "p95_gateway_wait_sec": 0.1,
            "p99_gateway_wait_sec": 0.2,
            "max_gateway_wait_sec": 0.3,
        },
        "warmup_audit": {
            "passed": True,
            "client_requests": 12,
            "audited_backend_requests": 12,
            "extra_backend_requests": 0,
            "missing_backend_requests": 0,
            "mismatches": [],
            "p95_gateway_wait_sec": 0.01,
            "p99_gateway_wait_sec": 0.02,
            "max_gateway_wait_sec": 0.03,
        },
        "pressure_validation": {
            "qualification_schema_version": 1,
            "required": True,
            "valid": True,
            "status": "pressurized",
            "minimum_samples": 60,
            "minimum_kv_p95": 0.9,
            "minimum_time_fraction": 0.25,
            "reasons": [],
        },
        "measurement_window": {
            "schema_version": 1,
            "configured": True,
            "duration_sec": 1800,
            "started_unix": 1_000.0,
            "cutoff_unix": 2_800.0,
            "triggered_unix": 2_800.0,
            "sealed_unix": 2_800.1,
            "deadline_reached": True,
            "termination": "trusted_fixed_window",
            "control_passed": True,
            "backend_cancelled_requests": 100,
            "measurement_elapsed_sec": elapsed,
            "wall_elapsed_sec": 1806.0,
            "teardown_sec": 6.0,
            "total_executed_steps": total_executed_steps,
            "post_cutoff_steps": post_cutoff_steps,
            "semantic_evaluated_workflows": 0,
            "truncated_workflows": profile.workflows,
            "zero_progress_workflows": 0,
            "zero_progress_fraction": 0.0,
            "audit_passed": True,
            "backend_quiescent_after_cutoff": True,
            "errors": [],
            "passed": True,
        },
        "vllm_metrics": {
            "live_samples": [],
            "counter_deltas": [],
            "gauge_end": [],
            "live_series": {},
            "derived": {},
        },
    }


def build_anchor(
    profile: server_module.Profile,
    model_adapter: dict[str, Any],
    policy_sha256: str,
) -> dict[str, Any]:
    baseline = valid_leg(profile, model_adapter)
    current_provenance = provenance()
    return {
        "schema_version": 1,
        "kind": server_module.RELEASE_PUBLIC_DIRECT_ANCHOR_KIND,
        "created_at_utc": "2026-07-19T00:00:00Z",
        "release_id": RELEASE_ID,
        "policy_release_id": RELEASE_ID,
        "suite": "public",
        "profile": PROFILE,
        "workload_nonce": NONCE,
        "workload_nonce_sha256": NONCE_SHA256,
        "baseline_run_id": baseline["run_id"],
        "baseline": baseline,
        "source_report_sha256": "5" * 64,
        "scoring_policy_sha256": policy_sha256,
        "controller_config_sha256": CONFIG_SHA256,
        "controller_image_id": "sha256:" + "6" * 64,
        "corpus_namespace": NAMESPACE,
        "corpus_fingerprint": CORPUS_SHA256,
        "model_provenance": current_provenance,
        "model_provenance_sha256": server_module.model_provenance_sha256(
            current_provenance
        ),
    }


def write_anchor(path: Path, payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    path.write_bytes(encoded)
    path.chmod(0o600)
    return hashlib.sha256(encoded).hexdigest()


def make_app(
    profiles: dict[str, server_module.Profile],
    policy: dict[str, Any],
    model_adapter: dict[str, Any],
    path: Path | None,
    digest: str = "",
    *,
    required: bool | None = None,
) -> dict[str, Any]:
    return {
        "profile_sets": {"public": profiles},
        "policy": copy.deepcopy(policy),
        "model_adapter": copy.deepcopy(model_adapter),
        "config_sha256": CONFIG_SHA256,
        "lease": asyncio.Lock(),
        "final_session": None,
        "history": [],
        "public_pair": {},
        "release_public_anchor_file": "" if path is None else str(path),
        "release_public_anchor_expected_sha256": digest,
        "release_public_anchor_material_json": None,
        "release_public_anchor_pair_id": None,
        "release_public_anchor_required": bool(path) if required is None else required,
    }


async def main_async() -> dict[str, Any]:
    cases: list[dict[str, Any]] = []
    profiles = server_module.load_profiles(
        TASK_ROOT / "environment" / "bench-controller" / "profiles" / "public.json",
        concurrency_limit=192,
    )
    profile = profiles[PROFILE]
    policy = json.loads(
        (
            TASK_ROOT
            / "environment"
            / "bench-controller"
            / "profiles"
            / "scoring-policy.json"
        ).read_text()
    )
    policy.update(release_ready=True, release_id=RELEASE_ID)
    model_adapter = {"mode": "qwen-unit"}

    originals = {
        "SCORING_POLICY": server_module.SCORING_POLICY,
        "CORPUS_MANIFEST": server_module.CORPUS_MANIFEST,
        "FEEDBACK_ROOT": server_module.FEEDBACK_ROOT,
        "TRUSTED_RESULTS_ROOT": server_module.TRUSTED_RESULTS_ROOT,
        "corpus_fingerprint": server_module.corpus_fingerprint,
        "model_provenance": server_module.model_provenance,
        "execute_leg": server_module.execute_leg,
        "ClientSession": server_module.ClientSession,
        "ClientTimeout": server_module.ClientTimeout,
    }
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        policy_path = root / "scoring-policy.json"
        policy_path.write_text(json.dumps(policy, sort_keys=True) + "\n")
        policy_sha256 = hashlib.sha256(policy_path.read_bytes()).hexdigest()
        manifest_path = root / "manifest.json"
        manifest_path.write_text("{}\n")
        anchor_payload = build_anchor(profile, model_adapter, policy_sha256)
        anchor_path = root / "public-direct-anchor.json"
        anchor_digest = write_anchor(anchor_path, anchor_payload)
        server_module.SCORING_POLICY = policy_path
        server_module.CORPUS_MANIFEST = manifest_path
        server_module.FEEDBACK_ROOT = root / "feedback"
        server_module.TRUSTED_RESULTS_ROOT = root / "trusted"
        fingerprint_box = {"value": CORPUS_SHA256}
        provenance_box = {"value": provenance()}
        server_module.corpus_fingerprint = (
            lambda *args, **kwargs: fingerprint_box["value"]
        )

        async def current_provenance(_app: dict[str, Any]) -> dict[str, Any]:
            return copy.deepcopy(provenance_box["value"])

        server_module.model_provenance = current_provenance

        app = make_app(profiles, policy, model_adapter, anchor_path, anchor_digest)
        await server_module.load_release_public_direct_anchor(app)
        material_before = app["release_public_anchor_material_json"]
        anchor_pair_id = app["release_public_anchor_pair_id"]
        persisted_anchor = json.loads(
            (
                server_module.FEEDBACK_ROOT
                / "pairs"
                / anchor_pair_id
                / "pair.json"
            ).read_text()
        )
        cases.append(
            {
                "name": "valid_anchor_loads_and_materializes_private_immutable_baseline",
                "passed": anchor_pair_id
                == f"{PROFILE}-anchor-{anchor_digest[:16]}"
                and app["public_pair"][PROFILE]["status"] == "baseline_complete"
                and app["public_pair"][PROFILE]["workload_nonce"] == NONCE
                and "workload_nonce" not in persisted_anchor
                and NONCE not in json.dumps(persisted_anchor),
            }
        )
        cases.append(
            {
                "name": "fixed_window_anchor_accepts_zero_semantic_tests_and_completions",
                "passed": app["public_pair"][PROFILE]["baseline"][
                    "tests_passed_workflows"
                ]
                == 0
                and app["public_pair"][PROFILE]["baseline"][
                    "completed_workflows"
                ]
                == 0,
            }
        )
        cases.append(
            {
                "name": "fixed_window_anchor_accepts_and_binds_post_cutoff_steps",
                "passed": app["public_pair"][PROFILE]["baseline"][
                    "total_executed_steps"
                ]
                == 3_001
                and app["public_pair"][PROFILE]["baseline"][
                    "measurement_window"
                ]["post_cutoff_steps"]
                == 1,
            }
        )

        async def must_not_execute(*args: Any, **kwargs: Any) -> dict[str, Any]:
            raise AssertionError("cached baseline executed a GPU leg")

        server_module.execute_leg = must_not_execute
        baseline_response = await server_module.public_run(
            FakeRequest(app, {"mode": "baseline", "profile": PROFILE})
        )
        baseline_rendered = json.dumps(baseline_response.payload, sort_keys=True)
        cases.append(
            {
                "name": "release_baseline_is_cached_and_never_executes_a_leg",
                "passed": baseline_response.status == 200
                and baseline_response.payload["pair_id"] == anchor_pair_id
                and baseline_response.payload["parent_pair_id"] is None
                and NONCE not in baseline_rendered
                and "workload_nonce" not in baseline_response.payload,
            }
        )

        candidate_calls: list[dict[str, Any]] = []

        async def candidate_leg(
            _app: dict[str, Any],
            **kwargs: Any,
        ) -> dict[str, Any]:
            candidate_calls.append(copy.deepcopy(kwargs))
            result = valid_leg(
                profile,
                model_adapter,
                mode="candidate",
                run_id=f"candidate-anchor-unit-{len(candidate_calls)}",
            )
            return result

        server_module.execute_leg = candidate_leg
        candidate_pairs: list[dict[str, Any]] = []
        candidate_responses: list[FakeResponse] = []
        for _index in range(2):
            response = await server_module.public_run(
                FakeRequest(app, {"mode": "candidate", "profile": PROFILE})
            )
            candidate_responses.append(response)
            candidate_pairs.append(copy.deepcopy(app["public_pair"][PROFILE]))
        cases.append(
            {
                "name": "candidate_retries_fork_the_same_anchor_without_chaining",
                "passed": all(response.status == 200 for response in candidate_responses)
                and candidate_pairs[0]["pair_id"] != candidate_pairs[1]["pair_id"]
                and all(
                    pair["parent_pair_id"] == anchor_pair_id
                    and pair["baseline_anchor_pair_id"] == anchor_pair_id
                    and pair["workload_nonce"] == NONCE
                    for pair in candidate_pairs
                )
                and candidate_pairs[0]["baseline"]
                == candidate_pairs[1]["baseline"]
                and all(
                    call["corpus_namespace"] == NAMESPACE
                    and call["workload_nonce"] == NONCE
                    and call["expected_model_provenance"] == provenance()
                    for call in candidate_calls
                )
                and app["release_public_anchor_material_json"] == material_before
                and NONCE
                not in json.dumps(
                    [response.payload for response in candidate_responses],
                    sort_keys=True,
                ),
                "statuses": [response.status for response in candidate_responses],
                "parent_ids": [pair["parent_pair_id"] for pair in candidate_pairs],
                "anchor_ids": [
                    pair["baseline_anchor_pair_id"] for pair in candidate_pairs
                ],
                "call_namespaces": [
                    call.get("corpus_namespace") for call in candidate_calls
                ],
            }
        )

        async def rejected_load(
            name: str,
            mutate: Callable[[dict[str, Any], dict[str, Any]], None],
        ) -> None:
            candidate_anchor = copy.deepcopy(anchor_payload)
            candidate_app = make_app(
                profiles, policy, model_adapter, root / f"{name}.json"
            )
            mutate(candidate_anchor, candidate_app)
            observed = write_anchor(
                Path(candidate_app["release_public_anchor_file"]), candidate_anchor
            )
            if not candidate_app["release_public_anchor_expected_sha256"]:
                candidate_app["release_public_anchor_expected_sha256"] = observed
            rejected = False
            detail = ""
            try:
                await server_module.load_release_public_direct_anchor(candidate_app)
            except Exception as exc:
                rejected = True
                detail = f"{type(exc).__name__}: {exc}"
            cases.append({"name": name, "passed": rejected, "detail": detail})

        await rejected_load(
            "stale_model_boot_is_rejected",
            lambda _anchor, _app: provenance_box.update(
                value=provenance(boot="c" * 64)
            ),
        )
        provenance_box["value"] = provenance()
        await rejected_load(
            "stale_controller_config_is_rejected",
            lambda _anchor, candidate_app: candidate_app.update(
                config_sha256="7" * 64
            ),
        )
        fingerprint_box["value"] = "8" * 64
        await rejected_load(
            "recomputed_corpus_fingerprint_mismatch_is_rejected",
            lambda _anchor, _app: None,
        )
        fingerprint_box["value"] = CORPUS_SHA256
        await rejected_load(
            "baseline_candidate_mode_is_rejected",
            lambda candidate_anchor, _app: candidate_anchor["baseline"].update(
                mode="candidate"
            ),
        )
        await rejected_load(
            "stale_release_id_is_rejected",
            lambda candidate_anchor, _app: candidate_anchor.update(
                release_id="stale-release"
            ),
        )
        await rejected_load(
            "non_builder_nonce_shape_is_rejected",
            lambda candidate_anchor, _app: candidate_anchor.update(
                workload_nonce="a" * 32
            ),
        )
        await rejected_load(
            "anchor_created_before_baseline_end_is_rejected",
            lambda candidate_anchor, _app: candidate_anchor.update(
                created_at_utc="1970-01-01T00:00:00Z"
            ),
        )
        await rejected_load(
            "baseline_timestamp_order_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"].update(
                ended_unix=999.0
            ),
        )
        await rejected_load(
            "effective_model_adapter_binding_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"][
                "model_adapter"
            ].pop("effective_max_tokens"),
        )
        await rejected_load(
            "baseline_tests_passed_count_shape_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"].update(
                tests_passed_workflows=-1
            ),
        )
        await rejected_load(
            "baseline_completed_workflows_count_shape_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"].update(
                completed_workflows=-1
            ),
        )
        await rejected_load(
            "baseline_total_executed_steps_is_bound_to_window",
            lambda candidate_anchor, _app: candidate_anchor["baseline"].update(
                total_executed_steps=1_002
            ),
        )
        await rejected_load(
            "baseline_post_cutoff_steps_identity_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"][
                "measurement_window"
            ].update(post_cutoff_steps=0),
        )
        await rejected_load(
            "baseline_post_cutoff_steps_type_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"][
                "measurement_window"
            ].update(post_cutoff_steps=True),
        )
        await rejected_load(
            "baseline_post_cutoff_steps_cannot_exceed_one_per_workflow",
            lambda candidate_anchor, _app: (
                candidate_anchor["baseline"].update(total_executed_steps=1_193),
                candidate_anchor["baseline"]["measurement_window"].update(
                    total_executed_steps=1_193,
                    post_cutoff_steps=193,
                ),
            ),
        )
        await rejected_load(
            "baseline_total_executed_steps_cannot_precede_valid_steps",
            lambda candidate_anchor, _app: (
                candidate_anchor["baseline"].update(total_executed_steps=999),
                candidate_anchor["baseline"]["measurement_window"].update(
                    total_executed_steps=999,
                    post_cutoff_steps=-1,
                ),
            ),
        )
        await rejected_load(
            "baseline_gateway_wait_hard_bound_is_enforced",
            lambda candidate_anchor, _app: candidate_anchor["baseline"][
                "backend_audit"
            ].update(p99_gateway_wait_sec=721.0),
        )

        stale_policy_path = root / "stale-policy.json"
        stale_policy_path.write_text("{\"changed\":true}\n")
        server_module.SCORING_POLICY = stale_policy_path
        await rejected_load("stale_scoring_policy_digest_is_rejected", lambda _a, _b: None)
        server_module.SCORING_POLICY = policy_path

        required_missing_file = make_app(
            profiles,
            policy,
            model_adapter,
            None,
            "",
            required=True,
        )
        required_missing_file_rejected = False
        try:
            await server_module.load_release_public_direct_anchor(
                required_missing_file
            )
        except RuntimeError:
            required_missing_file_rejected = True
        cases.append(
            {
                "name": "required_release_mode_rejects_missing_anchor_at_startup",
                "passed": required_missing_file_rejected,
            }
        )

        required_digest_without_file = make_app(
            profiles,
            policy,
            model_adapter,
            None,
            "a" * 64,
            required=True,
        )
        required_digest_without_file_rejected = False
        try:
            await server_module.load_release_public_direct_anchor(
                required_digest_without_file
            )
        except RuntimeError:
            required_digest_without_file_rejected = True
        cases.append(
            {
                "name": "required_release_mode_rejects_digest_without_anchor",
                "passed": required_digest_without_file_rejected,
            }
        )

        explicit_author_mode = make_app(
            profiles,
            policy,
            model_adapter,
            None,
            "",
            required=False,
        )
        await server_module.load_release_public_direct_anchor(explicit_author_mode)
        cases.append(
            {
                "name": "explicit_author_mode_retains_live_pair_path_after_freeze",
                "passed": explicit_author_mode[
                    "release_public_anchor_material_json"
                ]
                is None
                and explicit_author_mode["public_pair"] == {},
            }
        )

        bad_sha_app = make_app(
            profiles, policy, model_adapter, anchor_path, "9" * 64
        )
        bad_sha_rejected = False
        try:
            await server_module.load_release_public_direct_anchor(bad_sha_app)
        except Exception:
            bad_sha_rejected = True
        cases.append(
            {
                "name": "configured_artifact_sha_mismatch_is_rejected",
                "passed": bad_sha_rejected,
            }
        )
        missing_sha_app = make_app(
            profiles, policy, model_adapter, anchor_path, ""
        )
        missing_sha_rejected = False
        try:
            await server_module.load_release_public_direct_anchor(missing_sha_app)
        except Exception:
            missing_sha_rejected = True
        cases.append(
            {
                "name": "configured_anchor_requires_an_explicit_sha",
                "passed": missing_sha_rejected,
            }
        )

        symlink_path = root / "anchor-symlink.json"
        symlink_path.symlink_to(anchor_path)
        symlink_rejected = False
        try:
            server_module.read_release_public_direct_anchor(
                str(symlink_path), anchor_digest
            )
        except Exception:
            symlink_rejected = True
        cases.append(
            {
                "name": "symlink_anchor_is_rejected",
                "passed": symlink_rejected,
            }
        )

        nonrelease_policy = copy.deepcopy(policy)
        nonrelease_policy["release_ready"] = False
        nonrelease = make_app(
            profiles,
            nonrelease_policy,
            model_adapter,
            anchor_path,
            anchor_digest,
            required=False,
        )
        await server_module.load_release_public_direct_anchor(nonrelease)
        cases.append(
            {
                "name": "nonrelease_calibration_ignores_anchor_and_keeps_live_pair_path",
                "passed": nonrelease["release_public_anchor_material_json"] is None
                and nonrelease["public_pair"] == {},
            }
        )

        legacy_calls: list[dict[str, Any]] = []

        async def legacy_probe(*args: Any, **kwargs: Any) -> dict[str, Any]:
            legacy_calls.append(kwargs)
            raise RuntimeError("legacy-path-probe")

        server_module.execute_leg = legacy_probe
        smoke_response = await server_module.public_run(
            FakeRequest(app, {"mode": "baseline", "profile": "smoke-api"})
        )
        cases.append(
            {
                "name": "release_anchor_does_not_change_smoke_or_public12_path",
                "passed": smoke_response.status == 500
                and len(legacy_calls) == 1
                and legacy_calls[0]["corpus_namespace"] == "public",
            }
        )

        flag_name = server_module.RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED_ENV
        saved_flag = os.environ.get(flag_name)
        try:
            os.environ[flag_name] = "1"
            one_is_required = (
                server_module.release_public_direct_anchor_required_from_env()
                is True
            )
            os.environ[flag_name] = "0"
            zero_is_author = (
                server_module.release_public_direct_anchor_required_from_env()
                is False
            )
            os.environ[flag_name] = "true"
            invalid_flag_rejected = False
            try:
                server_module.release_public_direct_anchor_required_from_env()
            except ValueError:
                invalid_flag_rejected = True
        finally:
            if saved_flag is None:
                os.environ.pop(flag_name, None)
            else:
                os.environ[flag_name] = saved_flag
        cases.append(
            {
                "name": "release_anchor_mode_switch_is_strict_binary",
                "passed": one_is_required
                and zero_is_author
                and invalid_flag_rejected,
            }
        )

        class ClosingClient:
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                self.closed = False

            async def close(self) -> None:
                self.closed = True

        startup_app = make_app(profiles, policy, model_adapter, anchor_path, anchor_digest)
        startup_failure = server_module.load_release_public_direct_anchor

        async def fail_startup(_app: dict[str, Any]) -> None:
            raise ValueError("invalid anchor")

        server_module.ClientSession = ClosingClient
        server_module.ClientTimeout = lambda **_kwargs: object()
        server_module.load_release_public_direct_anchor = fail_startup
        startup_rejected = False
        try:
            await server_module.on_startup(startup_app)
        except ValueError:
            startup_rejected = True
        cases.append(
            {
                "name": "startup_closes_model_client_when_anchor_validation_fails",
                "passed": startup_rejected and startup_app["client"].closed,
            }
        )
        server_module.load_release_public_direct_anchor = startup_failure

    for key, value in originals.items():
        setattr(server_module, key, value)
    return {
        "schema_version": 1,
        "kind": "release-public-anchor-unit",
        "passed": all(bool(case["passed"]) for case in cases),
        "cases": cases,
    }


def main() -> int:
    report = asyncio.run(main_async())
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
