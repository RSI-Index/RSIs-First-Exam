#!/usr/bin/env python3
"""Mutation coverage for the frozen external Qwen3.6-27B attestation."""

from __future__ import annotations

import copy
import json
import os
import sys
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TASK_ROOT / "tests"))

from verify_phase0 import (  # noqa: E402
    ATTESTATION_OVERRIDE_NAMES,
    EXPECTED_CONTAINER_NAME,
    EXPECTED_CONTAINER_SOCKET,
    EXPECTED_GPU_UUIDS,
    EXPECTED_HYBRID_CACHE_ACCOUNTING,
    EXPECTED_PROFILE,
    EXPECTED_PROFILE_SHA256,
    EXPECTED_REQUIRED_FILE_HASHES,
    EXPECTED_REVISION,
    EXPECTED_RUNTIME,
    EXPECTED_RUNTIME_IMAGE_ID,
    EXPECTED_RUNTIME_IMAGE_REF,
    EXPECTED_TMUX_SESSION,
    EXPECTED_VLLM_PACKAGE,
    VerificationError,
    validate_attestation,
    validate_hybrid_cache_metrics,
)


def accepted(attestation: dict) -> bool:
    try:
        validate_attestation(attestation)
    except VerificationError:
        return False
    return True


def metrics_accepted(snapshot: dict) -> bool:
    try:
        validate_hybrid_cache_metrics(snapshot)
    except VerificationError:
        return False
    return True


def frozen_metrics() -> dict:
    return {
        "schema_version": 1,
        "created_unix": 103.0,
        "raw_sha256": "c" * 64,
        "samples": [
            {
                "name": "vllm:cache_config_info",
                "labels": (
                    '_block_size_resolved="True",block_size="1568",engine="0",'
                    'kv_cache_size_tokens="1887738",mamba_block_size="16",'
                    'mamba_cache_mode="align",num_gpu_blocks="1253"'
                ),
                "value": 1.0,
            },
            {
                "name": "vllm:kv_cache_usage_perc",
                "labels": 'engine="0"',
                "value": 0.0,
            },
        ],
        "active_backend_requests": 0,
        "audit_epoch": 0,
        "audit_count": 0,
        "admitted_request_count": 0,
    }


def frozen_attestation() -> dict:
    gpu_base = {
        "name": "NVIDIA H100 NVL",
        "memory_mib": 95830,
        "compute_capability": "9.0",
    }
    return {
        "schema_version": 1,
        "state": "ready",
        "preflight_status": "ok",
        "preflight_created_unix": 100.0,
        "created_unix": 101.0,
        "ready_unix": 102.0,
        "profile_id": EXPECTED_PROFILE,
        "profile_sha256": EXPECTED_PROFILE_SHA256,
        "model_mount_read_only": True,
        "model": {
            "model_path": "/model/snapshots/" + EXPECTED_REVISION,
            "profile_id": EXPECTED_PROFILE,
            "revision": EXPECTED_REVISION,
            "file_hashes": dict(EXPECTED_REQUIRED_FILE_HASHES),
            "shard_count": 15,
            "tensor_count": 1199,
            "index_total_size": 55562855904,
            "stat_total_size": 55563006400,
            "hf_symlink_manifest_sha256": "91241d609ad30b9ed110284ea48e2ea740a2cba9ecb248a107fbd6295a62f4bb",
            "first_shard_name": "model-00001-of-00015.safetensors",
        },
        "gpus": [
            {**gpu_base, "index": index, "uuid": uuid}
            for index, uuid in zip((6, 7), EXPECTED_GPU_UUIDS, strict=True)
        ],
        "runtime": dict(EXPECTED_RUNTIME),
        "observed_vllm_package_version": EXPECTED_VLLM_PACKAGE,
        "transport": {
            "kind": "unix",
            "socket_path": "/tmp/kvbench-host-runtime/vllm.sock",
            "container_socket_path": EXPECTED_CONTAINER_SOCKET,
        },
        "process": {
            "tmux_session": EXPECTED_TMUX_SESSION,
            "wrapper_pid": 12345,
            "wrapper_start_ticks": 987654,
        },
        "container": {
            "name": EXPECTED_CONTAINER_NAME,
            "id": "a" * 64,
            "image_ref": EXPECTED_RUNTIME_IMAGE_REF,
            "image_id": EXPECTED_RUNTIME_IMAGE_ID,
            "launch_token_sha256": "b" * 64,
            "environment": {"VLLM_SERVER_DEV_MODE": "1"},
        },
        "vllm_command": [
            "/usr/local/bin/vllm",
            "serve",
            "/opt/model-repo/snapshots/" + EXPECTED_REVISION,
            "--served-model-name",
            "target-model",
            "--uds",
            EXPECTED_CONTAINER_SOCKET,
            "--tensor-parallel-size",
            "2",
            "--model-impl",
            "vllm",
            "--runner",
            "generate",
            "--language-model-only",
            "--mm-processor-cache-gb",
            "0",
            "--dtype",
            "bfloat16",
            "--kv-cache-dtype",
            "fp8",
            "--enable-prefix-caching",
            "--mamba-cache-mode",
            "align",
            "--mamba-ssm-cache-dtype",
            "float32",
            "--gdn-prefill-backend",
            "triton",
            "--block-size",
            "16",
            "--max-model-len",
            "262144",
            "--max-num-seqs",
            "192",
            "--max-num-batched-tokens",
            "8192",
            "--kv-cache-memory-bytes",
            "32212254720",
            "--gpu-memory-utilization",
            "0.9",
            "--enable-chunked-prefill",
            "--load-format",
            "safetensors",
            "--safetensors-load-strategy",
            "lazy",
            "--reasoning-parser",
            "qwen3",
            "--generation-config",
            "vllm",
            "--no-enable-log-requests",
            "--disable-uvicorn-access-log",
            "--no-fail-on-environ-validation",
        ],
    }


def main() -> int:
    base = frozen_attestation()
    metrics = frozen_metrics()
    accounting = validate_hybrid_cache_metrics(metrics)
    cases = [
        {
            "name": "frozen_external_qwen36_attestation_passes",
            "passed": accepted(base),
        },
        {
            "name": "resolved_qwen36_hybrid_cache_metrics_pass",
            "passed": metrics_accepted(metrics),
        },
        {
            "name": "resolved_hybrid_accounting_contract_is_exact",
            "passed": accounting == EXPECTED_HYBRID_CACHE_ACCOUNTING
            and accounting["attention_page_tokens"] == 1568
            and accounting["raw_gpu_blocks"] == 1253
            and accounting["reserved_null_blocks"] == 1
            and accounting["capacity_pages"] == 1252
            and accounting["accounting_schema_version"] == 2
            and accounting["mamba_group_count"] == 3
            and accounting["mamba_resident_pages_per_group"] == 1
            and accounting["mamba_peak_pages_per_group"] == 2
            and accounting["fixed_mamba_pages_per_program"] == 3
            and accounting["transient_mamba_pages_per_program"] == 3
            and accounting["reported_logical_capacity_tokens"] == 1887738
            and accounting["reported_logical_capacity_is_informational"] is True,
        },
    ]
    mutations = (
        ("starting_state_is_rejected", lambda value: value.__setitem__("state", "starting")),
        ("exited_state_is_rejected", lambda value: value.__setitem__("state", "exited")),
        ("profile_hash_mutation_is_rejected", lambda value: value.__setitem__("profile_sha256", "0" * 64)),
        ("revision_mutation_is_rejected", lambda value: value["model"].__setitem__("revision", "0" * 40)),
        ("writable_model_is_rejected", lambda value: value.__setitem__("model_mount_read_only", False)),
        ("kv_dtype_mutation_is_rejected", lambda value: value["runtime"].__setitem__("kv_cache_dtype", "auto")),
        (
            "user_block_size_must_not_be_replaced_by_resolved_page_size",
            lambda value: value["runtime"].__setitem__("block_size", 1568),
        ),
        ("runtime_image_mutation_is_rejected", lambda value: value["container"].__setitem__("image_id", "sha256:" + "0" * 64)),
        ("gpu_uuid_mutation_is_rejected", lambda value: value["gpus"][0].__setitem__("uuid", "GPU-unexpected")),
        ("tcp_transport_is_rejected", lambda value: value["transport"].__setitem__("kind", "tcp")),
        ("tmux_identity_mutation_is_rejected", lambda value: value["process"].__setitem__("tmux_session", "other")),
        ("container_identity_mutation_is_rejected", lambda value: value["container"].__setitem__("name", "other")),
        ("invalid_launch_token_is_rejected", lambda value: value["container"].__setitem__("launch_token_sha256", "not-a-hash")),
        ("cache_reset_router_disabled_is_rejected", lambda value: value["container"]["environment"].__setitem__("VLLM_SERVER_DEV_MODE", "0")),
        ("unexpected_command_flag_is_rejected", lambda value: value["vllm_command"].extend(["--port", "8000"])),
    )
    for name, mutate in mutations:
        changed = copy.deepcopy(base)
        mutate(changed)
        cases.append({"name": name, "passed": not accepted(changed)})

    metric_mutations = (
        (
            "unresolved_hybrid_block_size_is_rejected",
            lambda value: value["samples"][0].__setitem__(
                "labels", value["samples"][0]["labels"].replace(
                    '_block_size_resolved="True"', '_block_size_resolved="False"'
                )
            ),
        ),
        (
            "attention_page_size_mutation_is_rejected",
            lambda value: value["samples"][0].__setitem__(
                "labels", value["samples"][0]["labels"].replace(
                    'block_size="1568"', 'block_size="16"'
                )
            ),
        ),
        (
            "raw_gpu_block_count_mutation_is_rejected",
            lambda value: value["samples"][0].__setitem__(
                "labels", value["samples"][0]["labels"].replace(
                    'num_gpu_blocks="1253"', 'num_gpu_blocks="1252"'
                )
            ),
        ),
        (
            "reported_logical_capacity_mutation_is_rejected",
            lambda value: value["samples"][0].__setitem__(
                "labels", value["samples"][0]["labels"].replace(
                    'kv_cache_size_tokens="1887738"',
                    'kv_cache_size_tokens="1963136"',
                )
            ),
        ),
        (
            "duplicate_cache_config_sample_is_rejected",
            lambda value: value["samples"].append(
                copy.deepcopy(value["samples"][0])
            ),
        ),
        (
            "unasserted_cache_config_gauge_is_rejected",
            lambda value: value["samples"][0].__setitem__("value", 0.0),
        ),
    )
    for name, mutate in metric_mutations:
        changed = copy.deepcopy(metrics)
        mutate(changed)
        cases.append({"name": name, "passed": not metrics_accepted(changed)})

    previous = {name: os.environ.get(name) for name in ATTESTATION_OVERRIDE_NAMES}
    try:
        for name in ATTESTATION_OVERRIDE_NAMES:
            os.environ.pop(name, None)
        os.environ["KV_EXPECTED_MODEL_PROFILE_ID"] = EXPECTED_PROFILE
        cases.append(
            {
                "name": "partial_environment_contract_is_rejected",
                "passed": not accepted(copy.deepcopy(base)),
            }
        )
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value

    report = {
        "schema_version": 1,
        "kind": "external-qwen36-attestation-unit",
        "profile_sha256": EXPECTED_PROFILE_SHA256,
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
