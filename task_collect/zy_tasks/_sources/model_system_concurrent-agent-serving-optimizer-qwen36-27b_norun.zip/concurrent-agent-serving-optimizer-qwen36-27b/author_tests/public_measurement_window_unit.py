#!/usr/bin/env python3
"""CPU-only contract tests for the trusted public measurement window."""

from __future__ import annotations

import ast
import copy
import json
import math
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
PROFILE_ROOT = CONTROLLER_ROOT / "profiles"
SERVER_PATH = CONTROLLER_ROOT / "server.py"
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))
sys.path.insert(0, str(CONTROLLER_ROOT))

import runner.workload as workload_module  # noqa: E402
from runner.corpus import TaskSpec  # noqa: E402
from runner.ledger import (  # noqa: E402
    MEASUREMENT_WINDOW_REASON,
    Ledger,
    LedgerClosed,
)
from runner.workload import (  # noqa: E402
    MeasurementWindowController,
    Profile,
    attach_agent_execution_interval,
    verify_window_audit,
    window_ended_workflow_result,
)


def load_server_functions() -> tuple[Callable[..., Any], Callable[..., Any]]:
    """Load pure server helpers without importing its optional aiohttp runtime."""

    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    wanted = {"validate_policy", "public_summary"}
    selected = [
        node
        for node in parsed.body
        if isinstance(node, ast.FunctionDef) and node.name in wanted
    ]
    if {node.name for node in selected} != wanted:
        raise RuntimeError("server policy/public-summary helpers were not found")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "Profile": Any,
        "math": math,
        "swebench_partition_ready": lambda _partition, _minimum: True,
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102
    return namespace["validate_policy"], namespace["public_summary"]


def make_profile(**overrides: Any) -> Profile:
    config: dict[str, Any] = {
        "name": "public-window-unit",
        "enabled": True,
        "workflows": 4,
        "concurrency": 4,
        "max_steps": 2,
        "context_bytes": 0,
        "max_tokens": 128,
        "workflow_timeout_sec": 4500,
        "request_timeout_sec": 600,
        "tool_delay_min_sec": 0.0,
        "tool_delay_max_sec": 0.0,
        "seed": 42,
        "workload_family": "swebench-lite",
        "corpus_partition": "public",
        "corpus_unique_instances_min": 1,
        "measurement_window_sec": 1800,
    }
    config.update(overrides)
    return Profile(**config)


def rejected(factory: Callable[[], Any], expected: type[BaseException]) -> bool:
    try:
        factory()
    except expected:
        return True
    return False


def client_record(request_id: str) -> dict[str, Any]:
    return {
        "request_id": request_id,
        "audit_epoch": 7,
        "run_id": "run-1",
        "profile": "public-pressure-192",
        "leg_id": "candidate",
        "cache_namespace": "namespace-1",
        "canonical_body_digest": "body-digest",
        "response_digest": "response-digest",
        "status": 200,
        "prompt_tokens": 100,
        "completion_tokens": 20,
        "total_tokens": 120,
        "sse_done": True,
        "started_unix": 100.0,
    }


def audit_record(request_id: str) -> dict[str, Any]:
    return {
        **client_record(request_id),
        "started_unix": 100.25,
        "benchmark_auth_valid": True,
        "client_disconnected": False,
        "error": None,
    }


def cutoff_audit_record(request_id: str) -> dict[str, Any]:
    client = client_record(request_id)
    return {
        key: client[key]
        for key in (
            "request_id",
            "audit_epoch",
            "run_id",
            "profile",
            "leg_id",
            "cache_namespace",
            "canonical_body_digest",
        )
    } | {"started_unix": 100.25, "benchmark_auth_valid": True}


def hidden_profile(policy: dict[str, Any], *, window: int | None) -> dict[str, Any]:
    return {
        entry["name"]: SimpleNamespace(
            enabled=True,
            workload_family="swebench-lite",
            pressure_required=True,
            corpus_partition="hidden",
            corpus_unique_instances_min=1,
            measurement_window_sec=window,
        )
        for entry in policy["hidden_profiles"]
    }


def main() -> int:
    cases: list[dict[str, Any]] = []

    begin_first = Ledger()
    begin_first.begin({"request_id": "before-cutoff"})
    frozen = begin_first.close_for_measurement(
        MEASUREMENT_WINDOW_REASON,
        1234.5,
        now_monotonic=time.monotonic(),
    )
    state = begin_first.measurement_state()
    cases.append(
        {
            "name": "begin_before_close_is_atomically_frozen",
            "passed": frozen["request_ids"] == ["before-cutoff"]
            and state
            == {
                "closed": True,
                "reason": MEASUREMENT_WINDOW_REASON,
                "cutoff_unix": 1234.5,
                "request_ids": ["before-cutoff"],
            },
            "observed": state,
        }
    )

    close_first = Ledger()
    close_first.close_for_measurement(MEASUREMENT_WINDOW_REASON, 2345.5)
    close_exception: LedgerClosed | None = None
    try:
        close_first.begin({"request_id": "after-cutoff"})
    except LedgerClosed as exc:
        close_exception = exc
    cases.append(
        {
            "name": "close_before_begin_rejects_admission",
            "passed": close_exception is not None
            and close_exception.reason == MEASUREMENT_WINDOW_REASON
            and close_exception.cutoff_unix == 2345.5
            and close_first.measurement_state()["request_ids"] == [],
        }
    )

    race_failures: list[str] = []
    race_orders: set[bool] = set()
    for index in range(48):
        ledger = Ledger()
        request_id = f"race-{index}"
        ledger.begin({"request_id": request_id})
        barrier = threading.Barrier(3)
        callback_reasons: list[str] = []
        registration_results: list[bool] = []

        def register() -> None:
            try:
                barrier.wait()
                registration_results.append(
                    ledger.register_canceller(request_id, callback_reasons.append)
                )
            except Exception as exc:  # pragma: no cover - reported below
                race_failures.append(f"register:{type(exc).__name__}:{exc}")

        def close() -> None:
            try:
                barrier.wait()
                ledger.close_for_measurement(MEASUREMENT_WINDOW_REASON, 3000.0 + index)
            except Exception as exc:  # pragma: no cover - reported below
                race_failures.append(f"close:{type(exc).__name__}:{exc}")

        register_thread = threading.Thread(target=register)
        close_thread = threading.Thread(target=close)
        register_thread.start()
        close_thread.start()
        barrier.wait()
        register_thread.join(timeout=2.0)
        close_thread.join(timeout=2.0)
        if register_thread.is_alive() or close_thread.is_alive():
            race_failures.append("thread_timeout")
        if registration_results:
            race_orders.add(registration_results[0])
        if callback_reasons != [MEASUREMENT_WINDOW_REASON]:
            race_failures.append(f"callback_count_or_reason:{callback_reasons!r}")
    cases.append(
        {
            "name": "canceller_registration_close_race_cancels_exactly_once",
            "passed": not race_failures and bool(race_orders),
            "observed_registration_results": sorted(race_orders),
            "failures": race_failures[:5],
        }
    )

    cutoff_client = client_record("cutoff")
    cutoff_zero = verify_window_audit([cutoff_client], [], ["cutoff"])
    cutoff_one = verify_window_audit(
        [cutoff_client], [cutoff_audit_record("cutoff")], ["cutoff"]
    )
    cases.append(
        {
            "name": "trusted_cutoff_allows_zero_or_one_matching_backend_audit",
            "passed": cutoff_zero["passed"]
            and cutoff_zero["cutoff_backend_unadmitted"] == 1
            and cutoff_zero["missing_backend_requests"] == 1
            and cutoff_one["passed"]
            and cutoff_one["cutoff_backend_admitted"] == 1
            and cutoff_one["missing_backend_requests"] == 0,
            "observed": {"zero": cutoff_zero, "one": cutoff_one},
        }
    )

    ordinary = client_record("ordinary")
    missing = verify_window_audit([ordinary], [], [])
    duplicate = verify_window_audit(
        [ordinary], [audit_record("ordinary"), audit_record("ordinary")], []
    )
    unknown_extra = verify_window_audit(
        [ordinary], [audit_record("ordinary"), audit_record("unknown")], []
    )
    wrong_identity_audit = audit_record("ordinary")
    wrong_identity_audit["run_id"] = "forged-run"
    wrong_identity = verify_window_audit([ordinary], [wrong_identity_audit], [])
    wrong_auth_audit = audit_record("ordinary")
    wrong_auth_audit["benchmark_auth_valid"] = False
    wrong_auth = verify_window_audit([ordinary], [wrong_auth_audit], [])
    cutoff_wrong_identity_audit = cutoff_audit_record("cutoff")
    cutoff_wrong_identity_audit["cache_namespace"] = "forged-namespace"
    cutoff_wrong_identity = verify_window_audit(
        [cutoff_client], [cutoff_wrong_identity_audit], ["cutoff"]
    )
    cutoff_wrong_auth_audit = cutoff_audit_record("cutoff")
    cutoff_wrong_auth_audit["benchmark_auth_valid"] = False
    cutoff_wrong_auth = verify_window_audit(
        [cutoff_client], [cutoff_wrong_auth_audit], ["cutoff"]
    )
    cases.append(
        {
            "name": "audit_fails_closed_for_missing_duplicate_extra_identity_or_auth",
            "passed": not any(
                report["passed"]
                for report in (
                    missing,
                    duplicate,
                    unknown_extra,
                    wrong_identity,
                    wrong_auth,
                    cutoff_wrong_identity,
                    cutoff_wrong_auth,
                )
            )
            and unknown_extra["extra_backend_requests"] == 1
            and any(
                mismatch.get("reason") == "run_id"
                for mismatch in wrong_identity["mismatches"]
            )
            and any(
                mismatch.get("reason") == "benchmark_auth_invalid"
                for mismatch in wrong_auth["mismatches"]
            )
            and any(
                mismatch.get("reason") == "cutoff_cache_namespace"
                for mismatch in cutoff_wrong_identity["mismatches"]
            )
            and any(
                mismatch.get("reason") == "cutoff_benchmark_auth_invalid"
                for mismatch in cutoff_wrong_auth["mismatches"]
            ),
            "observed": {
                "missing": missing["mismatches"],
                "duplicate": duplicate["mismatches"],
                "unknown_extra": unknown_extra["mismatches"],
                "identity": wrong_identity["mismatches"],
                "auth": wrong_auth["mismatches"],
                "cutoff_identity": cutoff_wrong_identity["mismatches"],
                "cutoff_auth": cutoff_wrong_auth["mismatches"],
            },
        }
    )

    valid_profile = make_profile()
    invalid_profile_factories: list[Callable[[], Any]] = [
        lambda: make_profile(workflows=4, concurrency=2),
        lambda: make_profile(
            name="hidden-like-window",
            workflows=192,
            concurrency=96,
            corpus_partition="hidden",
        ),
        lambda: make_profile(measurement_window_sec=59),
        lambda: make_profile(measurement_window_sec=4501),
        lambda: make_profile(measurement_window_sec=True),
    ]
    cases.append(
        {
            "name": "profile_allows_public_single_wave_and_rejects_bad_window_shapes",
            "passed": valid_profile.measurement_window_sec == 1800
            and valid_profile.workflows == valid_profile.concurrency
            and all(
                rejected(factory, ValueError)
                for factory in invalid_profile_factories
            ),
        }
    )

    original_admin_json = workload_module.admin_json
    admin_calls: list[tuple[str, str]] = []

    def fake_admin_json(
        method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
        *,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        del timeout
        admin_calls.append((method, path))
        if path == "/admin/measurement/cutoff":
            assert payload == {"audit_epoch": 7}
            return {
                "sealed": True,
                "audit_epoch": 7,
                "sealed_unix": time.time(),
                "cancelled_requests": 1,
                "metrics": {"created_unix": time.time(), "samples": []},
            }
        raise AssertionError(f"unexpected admin path: {path}")

    try:
        workload_module.admin_json = fake_admin_json
        controller_ledger = Ledger()
        controller_cancelled: list[str] = []
        controller_ledger.begin({"request_id": "controller-active"})
        controller_ledger.register_canceller(
            "controller-active", controller_cancelled.append
        )
        controller = MeasurementWindowController(
            0.02, controller_ledger, "http://model-api", "token", 7  # type: ignore[arg-type]
        )
        controller.start(started_unix=time.time(), started_monotonic=time.monotonic())
        deadline_signalled = controller.closed.wait(timeout=1.0)
        controller.stop()
        snapshot = controller.private_snapshot()

        stop_race_calls_before = len(admin_calls)
        stop_race_ledger = Ledger()
        stop_race = MeasurementWindowController(
            0.10, stop_race_ledger, "http://model-api", "token", 7  # type: ignore[arg-type]
        )
        stop_race.start(started_unix=time.time(), started_monotonic=time.monotonic())
        stop_race.stop()
        time.sleep(0.13)
        stop_race_snapshot = stop_race.private_snapshot()
        stop_race_calls_after = len(admin_calls)
    finally:
        workload_module.admin_json = original_admin_json
    cases.append(
        {
            "name": "window_controller_expires_without_sampler_failure_and_stops_cleanly",
            "passed": deadline_signalled
            and snapshot["deadline_reached"] is True
            and snapshot["termination"] == "trusted_fixed_window"
            and snapshot["control_passed"] is True
            and snapshot["backend_cancelled_requests"] == 1
            and snapshot["_trusted_cutoff_request_ids"] == ["controller-active"]
            and controller_cancelled == [MEASUREMENT_WINDOW_REASON]
            and admin_calls[:1] == [("POST", "/admin/measurement/cutoff")]
            and stop_race_snapshot["deadline_reached"] is False
            and stop_race_snapshot["termination"] == "workload_exhausted_early"
            and stop_race_snapshot["errors"] == []
            and stop_race_ledger.measurement_state()["closed"] is False
            and stop_race_calls_after == stop_race_calls_before,
            "observed": {
                "expired": snapshot,
                "stopped_before_deadline": stop_race_snapshot,
                "admin_calls": admin_calls,
            },
        }
    )

    spec = TaskSpec(
        task_id="window-before-start",
        issue="unit",
        module_name="unit",
        files={"unit.py": ""},
    )
    window_result = window_ended_workflow_result(spec)
    cases.append(
        {
            "name": "cutoff_before_workflow_start_is_expected_censoring_not_error",
            "passed": window_result["status"] == "MeasurementWindowEnded"
            and window_result["error"] is None
            and window_result["valid_steps"] == 0
            and window_result["measurement"]
            == {
                "schema_version": 1,
                "configured": True,
                "terminal_reason": "trusted_fixed_window",
                "measurement_truncated": True,
                "semantic_evaluated": False,
                "valid_steps_before_cutoff": 0,
                "post_cutoff_steps": 0,
                "boundary_query_cancellations": 0,
            },
            "observed": window_result,
        }
    )

    fixed_window_payload = {
        "schema_version": 1,
        "elapsed_sec": 1800.0,
        "measurement_window": {
            "configured": True,
            "duration_sec": 1800,
            "deadline_reached": True,
            "termination": "trusted_fixed_window",
        },
    }
    canonical_before = json.dumps(
        fixed_window_payload,
        separators=(",", ":"),
        sort_keys=True,
    )
    unchanged = attach_agent_execution_interval(
        copy.deepcopy(fixed_window_payload), None
    )
    canonical_after = json.dumps(
        unchanged,
        separators=(",", ":"),
        sort_keys=True,
    )
    cases.append(
        {
            "name": "fixed_window_schema_is_byte_identical_without_finite_interval",
            "passed": canonical_after == canonical_before
            and "agent_execution_interval" not in unchanged
            and unchanged["elapsed_sec"] == 1800.0,
            "canonical": canonical_after,
        }
    )

    public_raw = json.loads((PROFILE_ROOT / "public.json").read_text())
    hidden_raw = json.loads((PROFILE_ROOT / "hidden.json").read_text())
    public_windows = {
        name: config.get("measurement_window_sec")
        for name, config in public_raw["profiles"].items()
    }
    hidden_windows = {
        name: config.get("measurement_window_sec")
        for name, config in hidden_raw["profiles"].items()
    }
    cases.append(
        {
            "name": "only_public_pressure_has_exact_1800_second_window",
            "passed": public_windows.get("public-pressure-192") == 1800
            and sum(value is not None for value in public_windows.values()) == 1
            and hidden_windows
            and all(value is None for value in hidden_windows.values()),
            "observed": {"public": public_windows, "hidden": hidden_windows},
        }
    )

    validate_policy, public_summary = load_server_functions()
    policy = json.loads((PROFILE_ROOT / "scoring-policy.json").read_text())
    policy_without_window_accepted = True
    try:
        validate_policy(policy, hidden_profile(policy, window=None))
    except Exception:
        policy_without_window_accepted = False
    policy_with_window_rejected = rejected(
        lambda: validate_policy(policy, hidden_profile(policy, window=600)), ValueError
    )
    cases.append(
        {
            "name": "server_policy_rejects_any_windowed_hidden_profile",
            "passed": policy_without_window_accepted and policy_with_window_rejected,
        }
    )

    private_result = {
        "future_top_level": {"secret_marker": "top-level-private"},
        "workflows": [{"task_id": "secret"}],
        "model_protocol_diagnostics": {"secret": True},
        "model_provenance": {"secret": True},
        "profile_config": {
            "workload_family": "swebench-lite",
            "future_nested": {"secret_marker": "profile-private"},
        },
        "model_adapter": {
            "mode": "unit",
            "chat_template_kwargs": {
                "enable_thinking": False,
                "future_nested": "adapter-private",
            },
            "future_nested": {"secret_marker": "adapter-private"},
        },
        "backend_audit": {
            "passed": True,
            "client_requests": 1,
            "mismatches": [{"secret": True}],
            "future_nested": {"secret_marker": "audit-private"},
        },
        "warmup_audit": {
            "passed": True,
            "future_nested": {"secret_marker": "warmup-private"},
        },
        "vllm_metrics": {
            "live_samples": [{"secret": True}],
            "counter_deltas": [
                {
                    "name": "vllm:request_success_total",
                    "value": 1,
                    "labels": "private-label",
                    "future_nested": {"secret_marker": "counter-private"},
                },
                {"name": "irrelevant_counter", "value": 2},
            ],
            "gauge_end": [
                {
                    "name": "vllm:kv_cache_usage_perc",
                    "value": 0.9,
                    "labels": "private-label",
                    "future_nested": {"secret_marker": "gauge-private"},
                },
                {"name": "irrelevant_gauge", "value": 2},
            ],
            "derived": {
                "prefix_cache_hit_ratio": 0.5,
                "future_nested": {"secret_marker": "derived-private"},
            },
            "live_series": {
                "kv_cache_usage_p95": 0.9,
                "future_nested": {"secret_marker": "series-private"},
            },
            "future_nested": {"secret_marker": "metrics-private"},
        },
        "measurement_window": {
            "configured": True,
            "duration_sec": 1800,
            "_trusted_cutoff_request_ids": ["private-request-id"],
            "future_nested": {"secret_marker": "window-private"},
        },
    }
    public = public_summary(copy.deepcopy(private_result))
    rendered_public = json.dumps(public, sort_keys=True)
    cases.append(
        {
            "name": "public_summary_is_recursive_fail_closed_allowlist",
            "passed": "_trusted_cutoff_request_ids" not in public["measurement_window"]
            and public["measurement_window"]
            == {"configured": True, "duration_sec": 1800}
            and set(public)
            == {
                "profile_config",
                "model_adapter",
                "backend_audit",
                "warmup_audit",
                "vllm_metrics",
                "measurement_window",
                "model_provenance_sha256",
                "infrastructure_failure",
                "candidate_failure",
            }
            and public["infrastructure_failure"] is None
            and public["candidate_failure"] is None
            and public["profile_config"] == {"workload_family": "swebench-lite"}
            and public["model_adapter"]
            == {
                "mode": "unit",
                "chat_template_kwargs": {"enable_thinking": False},
            }
            and public["backend_audit"]
            == {"passed": True, "client_requests": 1}
            and public["warmup_audit"] == {"passed": True}
            and public["vllm_metrics"]
            == {
                "counter_deltas": [
                    {"name": "vllm:request_success_total", "value": 1}
                ],
                "gauge_end": [
                    {"name": "vllm:kv_cache_usage_perc", "value": 0.9}
                ],
                "derived": {"prefix_cache_hit_ratio": 0.5},
                "live_series": {"kv_cache_usage_p95": 0.9},
            }
            and "future_nested" not in rendered_public
            and "secret_marker" not in rendered_public
            and "private-label" not in rendered_public
            and "private-request-id" not in rendered_public
            and "workflows" not in public
            and "model_protocol_diagnostics" not in public
            and "model_provenance" not in public,
            "observed": public,
        }
    )

    report = {
        "schema_version": 1,
        "kind": "public-measurement-window-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
