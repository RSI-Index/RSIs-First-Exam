#!/usr/bin/env python3
"""Strict text-bash parsing checks for the vendored mini-SWE loop."""

from __future__ import annotations

import json
import sys
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))

from minisweagent.agents.default import (  # noqa: E402
    DIRECT_SUBMIT_COMMAND,
    DIRECT_SUBMIT_MARKER,
    DefaultAgent,
    FormatError,
    Submitted,
    extract_bash_action,
)


class StubModel:
    def __init__(self) -> None:
        self.n_calls = 0
        self.cost = 0.0

    def get_template_vars(self) -> dict[str, object]:
        return {"n_model_calls": self.n_calls, "model_cost": self.cost}


class StubEnvironment:
    def __init__(self) -> None:
        self.commands: list[str] = []

    def get_template_vars(self) -> dict[str, object]:
        return {}

    def execute(self, command: str) -> dict[str, object]:
        self.commands.append(command)
        if command == DIRECT_SUBMIT_COMMAND:
            return {"output": f"{DIRECT_SUBMIT_MARKER}\n", "returncode": 0}
        return {"output": "command output", "returncode": 0}


def expect_format_error(agent: DefaultAgent, response: dict[str, object]) -> bool:
    try:
        agent.parse_action(response)
    except FormatError:
        return True
    return False


def main() -> int:
    environment = StubEnvironment()
    agent = DefaultAgent(StubModel(), environment, instruction_role="system")
    valid = {
        "content": "THOUGHT: Inspect first.\n\n```bash\nprintf 'ok\\n'\n```"
    }
    parsed = agent.parse_action(valid)
    agent.messages = [{"role": "assistant", **valid}]
    agent.get_observation(valid)

    unexpected_tool = {
        "content": "",
        "tool_calls": [
            {
                "id": "call_unit",
                "type": "function",
                "function": {
                    "name": "execute_bash",
                    "arguments": '{"cmd":"pwd"}',
                },
            }
        ],
    }
    malformed = [
        {"content": "pwd"},
        {"content": "```sh\npwd\n```"},
        {"content": "```bash\n\n```"},
        {"content": "```bash\npwd\n```\n```bash\nls\n```"},
        {"content": None},
        unexpected_tool,
        {"content": DIRECT_SUBMIT_MARKER},
    ]

    submit_response = {
        "content": f"THOUGHT: The verified fix is ready.\n\n```bash\n{DIRECT_SUBMIT_COMMAND}\n```"
    }
    submit_action = agent.parse_action(submit_response)
    submit_raised = False
    try:
        agent.get_observation(submit_response)
    except Submitted:
        submit_raised = True

    invalid_role_rejected = False
    try:
        DefaultAgent(StubModel(), StubEnvironment(), instruction_role="assistant")
    except ValueError:
        invalid_role_rejected = True
    developer_role_rejected = False
    try:
        DefaultAgent(StubModel(), StubEnvironment(), instruction_role="developer")
    except ValueError:
        developer_role_rejected = True

    checks = {
        "thought_plus_one_bash_fence_is_accepted": (
            parsed["action"] == "printf 'ok\\n'"
            and extract_bash_action(valid) == "printf 'ok\\n'"
        ),
        "action_is_executed_without_mutation": environment.commands[0] == "printf 'ok\\n'",
        "observation_returns_as_user_text": agent.messages[-1]["role"] == "user",
        "invalid_text_shapes_are_rejected": all(
            expect_format_error(agent, response) for response in malformed
        ),
        "function_tools_are_outside_the_protocol": expect_format_error(
            agent, unexpected_tool
        ),
        "submission_requires_the_same_fenced_command_protocol": (
            submit_action["action"] == DIRECT_SUBMIT_COMMAND
            and environment.commands[-1] == DIRECT_SUBMIT_COMMAND
            and submit_raised
        ),
        "invalid_instruction_role_rejected": invalid_role_rejected,
        "legacy_developer_role_rejected": developer_role_rejected,
    }
    report = {
        "schema_version": 1,
        "kind": "qwen36-mini-swe-text-bash-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
