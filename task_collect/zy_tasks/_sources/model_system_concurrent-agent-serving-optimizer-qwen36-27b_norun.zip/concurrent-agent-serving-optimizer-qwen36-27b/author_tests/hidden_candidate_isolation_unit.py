#!/usr/bin/env python3
"""CPU-only checks for the formal pair's sole candidate process epoch."""

from __future__ import annotations

import ast
import hashlib
import hmac
import importlib.util
import json
import os
import re
import shutil
import stat
import tempfile
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = TASK_ROOT / "environment" / "bench-controller" / "server.py"
VERIFIER_PATH = TASK_ROOT / "tests" / "verify.py"
PHASE0_PATH = TASK_ROOT / "tests" / "verify_phase0.py"
TEST_SH_PATH = TASK_ROOT / "tests" / "test.sh"
ENTRYPOINT_PATH = TASK_ROOT / "environment" / "container-entrypoint.sh"


def load_validator():
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    selected = []
    for node in parsed.body:
        if (
            isinstance(node, ast.Assign)
            and any(
                isinstance(target, ast.Name) and target.id == "LIFECYCLE_ATTESTATION_CONTEXT"
                for target in node.targets
            )
        ):
            selected.append(node)
        if isinstance(node, ast.FunctionDef) and node.name in {
            "_hex_text",
            "validate_lifecycle_attestation",
        }:
            selected.append(node)
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "hashlib": hashlib,
        "hmac": hmac,
        "json": json,
        "re": re,
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102 - trusted source
    return namespace["validate_lifecycle_attestation"], namespace["LIFECYCLE_ATTESTATION_CONTEXT"]


def session(mode: str = "candidate") -> dict[str, Any]:
    return {
        "session_id": "a" * 64,
        "frozen_submission_sha256": "b" * 64,
        "pending_challenge": "c" * 64,
        "seen_epoch_nonces": set(),
        "seen_candidate_process_identities": set(),
        "mode": mode,
    }


def signed_attestation(
    state: dict[str, Any],
    context: bytes,
    token: str,
    *,
    mode: str,
    ordinal: int,
    epoch_nonce: str,
    gateway_pid: int | None = None,
    gateway_start_ticks: int | None = None,
) -> dict[str, Any]:
    candidate_pids = [gateway_pid, gateway_pid + 1] if gateway_pid is not None else []
    payload: dict[str, Any] = {
        "schema_version": 1,
        "session_id": state["session_id"],
        "leg_ordinal": ordinal,
        "mode": mode,
        "challenge": state["pending_challenge"],
        "epoch_nonce": epoch_nonce,
        "frozen_submission_sha256": state["frozen_submission_sha256"],
        "gateway_pid": gateway_pid,
        "gateway_start_ticks": gateway_start_ticks,
        "candidate_pids": candidate_pids,
        "gateway_healthy_after_launch": mode == "candidate",
        "terminated_candidate_pids": [7001],
        "prelaunch_candidate_pids": [],
        "port_closed_before_launch": True,
        "runtime_state_scrubbed": True,
        "candidate_owned_runtime_entries": [],
        "candidate_owned_ipc_objects": [],
    }
    canonical = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    payload["signature"] = hmac.new(token.encode(), context + canonical, hashlib.sha256).hexdigest()
    return payload


def rejected(callable_) -> bool:
    try:
        callable_()
    except (KeyError, RuntimeError, TypeError, ValueError):
        return True
    return False


def canonical_runtime_copy_case() -> bool:
    spec = importlib.util.spec_from_file_location("kvbench_verify_phase0_unit", PHASE0_PATH)
    if spec is None or spec.loader is None:
        return False
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory(prefix="kvbench-canonical-runtime-") as raw:
        root = Path(raw)
        evidence_parent = root / "root-only-evidence"
        evidence = evidence_parent / "submission"
        evidence.mkdir(parents=True)
        launch = evidence / "launch.sh"
        launch.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        launch.chmod(0o755)
        (evidence / "payload.txt").write_text("bound\n", encoding="utf-8")
        evidence_parent.chmod(0o700)
        runtime_root = root / "runtime"
        module.TRUSTED_UID = os.getuid()
        module.TRUSTED_GID = os.getgid()
        module.CANDIDATE_RUNTIME_ROOT = runtime_root
        module.CANDIDATE_RUNTIME_SUBMISSION = runtime_root / "submission"
        module.CANDIDATE_RUNTIME_DIGEST = runtime_root / ".submission.sha256"
        module._freeze_candidate_tree(evidence)
        expected = module.submission_tree_sha256(evidence)
        try:
            installed = module.stage_candidate_execution(evidence)
            copied = (
                installed == runtime_root / "submission"
                and module.submission_tree_sha256(installed) == expected
                and stat.S_IMODE(evidence_parent.stat().st_mode) == 0o700
                and stat.S_IMODE(runtime_root.stat().st_mode) == 0o711
                and stat.S_IMODE(installed.stat().st_mode) == 0o555
                and stat.S_IMODE((installed / "launch.sh").stat().st_mode) == 0o555
            )
            module.clear_candidate_execution_root()
            cleaned = list(runtime_root.iterdir()) == []
            module.stage_candidate_execution(evidence)
            payload = runtime_root / "submission/payload.txt"
            payload.chmod(0o644)
            payload.write_text("tampered\n", encoding="utf-8")
            mutation_rejected = rejected(module.clear_candidate_execution_root)
            return copied and cleaned and mutation_rejected
        finally:
            if runtime_root.exists():
                for item in [runtime_root, *runtime_root.rglob("*")]:
                    try:
                        item.chmod(0o700 if item.is_dir() else 0o600)
                    except FileNotFoundError:
                        pass
                shutil.rmtree(runtime_root)


def main() -> int:
    validate, context = load_validator()
    token = "unit-test-root-admin-token"
    cases: list[dict[str, Any]] = []

    candidate_state = session()
    candidate = signed_attestation(
        candidate_state,
        context,
        token,
        mode="candidate",
        ordinal=2,
        epoch_nonce="d" * 32,
        gateway_pid=8123,
        gateway_start_ticks=998877,
    )
    summary = validate(
        candidate_state,
        candidate,
        expected_mode="candidate",
        expected_leg_ordinal=2,
        admin_token=token,
    )
    cases.append(
        {
            "name": "fresh_candidate_epoch_is_accepted_at_pair_ordinal_2",
            "passed": summary["mode"] == "candidate"
            and summary["frozen_submission_sha256"] == "b" * 64
            and len(candidate_state["seen_candidate_process_identities"]) == 1,
        }
    )

    candidate_first_state = session()
    candidate_first = signed_attestation(
        candidate_first_state,
        context,
        token,
        mode="candidate",
        ordinal=1,
        epoch_nonce="6" * 32,
        gateway_pid=8124,
        gateway_start_ticks=998878,
    )
    candidate_first_summary = validate(
        candidate_first_state,
        candidate_first,
        expected_mode="candidate",
        expected_leg_ordinal=1,
        admin_token=token,
    )
    cases.append(
        {
            "name": "fresh_candidate_epoch_is_accepted_at_pair_ordinal_1",
            "passed": candidate_first_summary["mode"] == "candidate"
            and candidate_first_summary["leg_ordinal"] == 1
            and len(candidate_first_state["seen_candidate_process_identities"]) == 1,
        }
    )

    baseline_state = session("baseline")
    baseline = signed_attestation(
        baseline_state,
        context,
        token,
        mode="baseline",
        ordinal=1,
        epoch_nonce="e" * 32,
    )
    baseline_summary = validate(
        baseline_state,
        baseline,
        expected_mode="baseline",
        expected_leg_ordinal=1,
        admin_token=token,
    )
    cases.append(
        {
            "name": "baseline_requires_candidate_quiescence",
            "passed": baseline_summary["mode"] == "baseline"
            and not baseline_state["seen_candidate_process_identities"],
        }
    )

    wrong_signature_state = session()
    wrong_signature = signed_attestation(
        wrong_signature_state,
        context,
        token,
        mode="candidate",
        ordinal=2,
        epoch_nonce="1" * 32,
        gateway_pid=8200,
        gateway_start_ticks=100,
    )
    wrong_signature["signature"] = "0" * 64
    cases.append(
        {
            "name": "candidate_cannot_forge_root_hmac",
            "passed": rejected(
                lambda: validate(
                    wrong_signature_state,
                    wrong_signature,
                    expected_mode="candidate",
                    expected_leg_ordinal=2,
                    admin_token=token,
                )
            ),
        }
    )

    stale_challenge_state = session()
    stale = signed_attestation(
        stale_challenge_state,
        context,
        token,
        mode="candidate",
        ordinal=2,
        epoch_nonce="4" * 32,
        gateway_pid=8400,
        gateway_start_ticks=300,
    )
    stale_challenge_state["pending_challenge"] = "9" * 64
    cases.append(
        {
            "name": "old_controller_challenge_cannot_be_replayed",
            "passed": rejected(
                lambda: validate(
                    stale_challenge_state,
                    stale,
                    expected_mode="candidate",
                    expected_leg_ordinal=2,
                    admin_token=token,
                )
            ),
        }
    )

    gateway_baseline_state = session("baseline")
    gateway_baseline = signed_attestation(
        gateway_baseline_state,
        context,
        token,
        mode="baseline",
        ordinal=1,
        epoch_nonce="5" * 32,
        gateway_pid=8500,
        gateway_start_ticks=400,
    )
    cases.append(
        {
            "name": "baseline_with_live_gateway_is_rejected",
            "passed": rejected(
                lambda: validate(
                    gateway_baseline_state,
                    gateway_baseline,
                    expected_mode="baseline",
                    expected_leg_ordinal=1,
                    admin_token=token,
                )
            ),
        }
    )

    server_source = SERVER_PATH.read_text()
    verifier_source = VERIFIER_PATH.read_text()
    phase0_source = PHASE0_PATH.read_text()
    test_sh_source = TEST_SH_PATH.read_text()
    entrypoint_source = ENTRYPOINT_PATH.read_text()
    static_checks = {
        "legacy_stateful_final_is_fail_closed": (
            '"error": "candidate_lifecycle_reset_required"' in server_source
            and 'app.router.add_post("/admin/final/session/begin"' in server_source
            and 'app.router.add_post("/admin/final/session/leg"' in server_source
        ),
        "verifier_resets_before_every_leg": (
            "reset_candidate_runtime(process)" in verifier_source
            and '["pkill", "-KILL", "-u", "candidate"]' in verifier_source
            and "wait_candidate_port_closed()" in verifier_source
        ),
        "candidate_scratch_roots_include_var_tmp": (
            'Path("/var/tmp")' in verifier_source
            and 'Path("/dev/mqueue")' in verifier_source
            and 'Path("/run/lock")' in verifier_source
        ),
        "candidate_sysv_ipc_is_removed": (
            'Path("/proc/sysvipc/shm")' in verifier_source
            and '"ipcrm",\n                    remove_flag,\n                    identifier' in verifier_source
            and '"candidate_owned_ipc_objects": []' in verifier_source
        ),
        "candidate_cannot_use_gateway_logs_as_cross_epoch_state": (
            "os.chmod(log_root, 0o700)" in phase0_source
            and "os.fchmod(descriptor, 0o600)" in phase0_source
            and "log_name=None" in verifier_source
            and "stdout: int | Any = subprocess.DEVNULL" in phase0_source
            and "stderr: int = subprocess.DEVNULL" in phase0_source
            and "gateway-final-leg-" not in verifier_source
            and "-m 0700 /logs/verifier" in test_sh_source
        ),
        "phase0_and_hidden_launch_only_from_canonical_candidate_path": (
            'CANDIDATE_RUNTIME_ROOT = Path("/run/kvbench-candidate")'
            in phase0_source
            and "runtime_submission = stage_candidate_execution(submission)"
            in phase0_source
            and 'str(runtime_submission / "launch.sh")' in phase0_source
            and "cwd=runtime_submission" in phase0_source
            and "clear_candidate_execution_root()" in verifier_source
            and 'snapshot_root.mkdir(mode=0o700' in phase0_source
        ),
        "shared_harbor_output_roots_are_opaque_for_every_final_leg": (
            "class CandidateSharedOutputRootSeal" in verifier_source
            and 'Path("/logs/agent")' in verifier_source
            and 'Path("/logs/artifacts")' in verifier_source
            and "os.chmod(root, 0o500)" in verifier_source
            and "reset_report.update(shared_output_seal.attest())" in verifier_source
            and '"candidate_shared_output_roots_sealed": True' in verifier_source
            and "shared_output_seal.restore()" in verifier_source
        ),
        "verifier_stdout_mount_is_sealed_before_agent_entrypoint": (
            "verifier_log_root=/logs/verifier" in entrypoint_source
            and 'chmod 0700 "$verifier_log_root"' in entrypoint_source
            and entrypoint_source.index('chmod 0700 "$verifier_log_root"')
            < entrypoint_source.index('exec "$@"')
            and "verifier-root.meta" in entrypoint_source
            and "trap restore_verifier_log_root EXIT" in test_sh_source
        ),
        "verifier_uses_session_not_stateful_final": (
            '"/admin/final/session/begin"' in verifier_source
            and '"/admin/final/session/leg"' in verifier_source
            and 'controller_base, "/admin/final/run"' not in verifier_source
        ),
        "formal_verifier_accepts_either_pair_order_but_exactly_one_candidate": (
            'sorted(completed_modes) != [\n                    "baseline",\n                    "candidate",\n                ]'
            in verifier_source
            and "mode in completed_modes" in verifier_source
            and "leg_ordinal > 2" in verifier_source
            and "formal pair did not capture exactly one candidate observation"
            in verifier_source
        ),
        "release_controller_has_no_legacy_four_leg_abba_route": (
            'app.router.add_post("/admin/abba/run"' not in server_source
            and "async def admin_abba_run" not in server_source
        ),
        "candidate_is_reaped_immediately_after_its_single_observation": (
            "observe_candidate_post_leg_health(" in verifier_source
            and verifier_source.index("observe_candidate_post_leg_health(")
            < verifier_source.index(
                "reset_candidate_runtime(process)",
                verifier_source.index("observe_candidate_post_leg_health("),
            )
            and "process = None" in verifier_source[
                verifier_source.index("observe_candidate_post_leg_health(") :
            ]
        ),
        "hidden_session_begins_only_after_signed_main_egress_seal": (
            'Path("/run/kvbench-sandbox/control.sock")' in verifier_source
            and '"/admin/final/network-seal/challenge"' in verifier_source
            and '"action": "seal_main_egress"' in verifier_source
            and '"network_egress_attestation": network_egress_attestation'
            in verifier_source
            and "MAX_SANDBOX_CONTROL_RESPONSE_BYTES" in verifier_source
            and verifier_source.index(
                "network_egress_attestation = seal_main_network_egress"
            )
            < verifier_source.index(
                'controller_base,\n        "/admin/final/session/begin"'
            )
        ),
        "controller_blocks_public_runs_during_final_session": (
            'request.app.get("final_session") is not None' in server_source
        ),
        "controller_independently_refuses_open_baseline_port": (
            'mode == "baseline" and await candidate_port_open()' in server_source
            and 'baseline leg refused while candidate port 9000 is open' in server_source
        ),
    }
    cases.extend(
        {"name": name, "passed": passed} for name, passed in static_checks.items()
    )
    cases.append(
        {
            "name": "canonical_runtime_fd_copy_is_digest_bound_and_fail_closed",
            "passed": canonical_runtime_copy_case(),
        }
    )

    report = {
        "schema_version": 1,
        "kind": "hidden-candidate-isolation-unit",
        "passed": all(bool(case["passed"]) for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
