#!/usr/bin/env python3
"""Author-side mutations for the concealed two-leg hidden reward function.

The test extracts the shipped scoring implementation instead of importing the
aiohttp controller.  Synthetic legs isolate trust and quality gates; they are
not benchmark calibration data.
"""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import math
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable


TASK_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = TASK_ROOT / "environment" / "bench-controller" / "server.py"
ORDER_CONTEXT = b"kvbench-final-leg-order-v1\n"


def geometric_mean(values: Any) -> float:
    numbers = [float(value) for value in values]
    if not numbers or any(value <= 0 for value in numbers):
        return 0.0
    return math.exp(sum(math.log(value) for value in numbers) / len(numbers))


def load_scoring_functions() -> tuple[
    Callable[[dict[str, Any], dict[str, list[dict[str, Any]]]], dict[str, Any]],
    Callable[[str], tuple[str, str]],
    Callable[[dict[str, Any], dict[str, Any]], None],
]:
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    names = {
        "_hex_text",
        "formal_leg_order",
        "validate_policy",
        "finite_agent_execution_interval_errors",
        "normalized_performance",
        "score_final",
    }
    selected = [
        node
        for node in parsed.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name in names
    ]
    if [node.name for node in selected] != [
        "_hex_text",
        "formal_leg_order",
        "validate_policy",
        "finite_agent_execution_interval_errors",
        "normalized_performance",
        "score_final",
    ]:
        raise RuntimeError("could not extract the controller scoring functions")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "Profile": Any,
        "hashlib": hashlib,
        "math": math,
        "re": re,
        "geometric_mean": geometric_mean,
        "FINAL_LEG_ORDER_CONTEXT": ORDER_CONTEXT,
        "FINAL_FORMAL_LEG_COUNT": 2,
        "swebench_partition_ready": lambda _partition, _minimum: True,
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102
    return (
        namespace["score_final"],
        namespace["formal_leg_order"],
        namespace["validate_policy"],
    )


def policy() -> dict[str, Any]:
    return {
        "noise_floor": 1.0,
        # Retained as calibration metadata. Formal single-pair scoring must not
        # read this value or emit a statistically meaningless one-sample CV.
        "max_baseline_cv": 0.0,
        "min_request_success_rate": 0.98,
        "request_success_tolerance": 0.02,
        "min_valid_step_ratio": 0.90,
        "valid_step_ratio_tolerance": 0.06,
        "min_tests_passed_workflows": 1,
        "tests_passed_workflows_tolerance": 1,
        "min_completed_workflows": 0,
        "completed_workflows_tolerance": 1,
        "minimum_workflow_progress": 1,
        "max_p99_gateway_wait_sec": 480.0,
        "max_p99_step_latency_ratio": 1.25,
        "min_baseline_valid_steps_per_min": 7.45,
        "tail_target_sec": 100.0,
        "backend_work_ratio_min": 0.85,
        "backend_work_ratio_max": 1.15,
        "hidden_profiles": [
            {"name": "mutation-profile", "weight": 1.0, "reference_speedup": 1.6}
        ],
    }


def commitment_for_order(order: tuple[str, str]) -> str:
    for index in range(10_000):
        commitment = hashlib.sha256(f"author-order-{index}".encode()).hexdigest()
        digest = hashlib.sha256(ORDER_CONTEXT + commitment.encode("ascii")).digest()
        derived = (
            ("candidate", "baseline")
            if digest[0] & 1
            else ("baseline", "candidate")
        )
        if derived == order:
            return commitment
    raise RuntimeError(f"could not synthesize commitment for {order}")


def leg(mode: str, rate: float, commitment: str) -> dict[str, Any]:
    elapsed = 300.0
    valid_steps = int(rate * elapsed / 60.0)
    return {
        "mode": mode,
        "workload_nonce_sha256": commitment,
        "started_unix": 100.0,
        "ended_unix": 400.0,
        "elapsed_sec": elapsed,
        "wall_elapsed_sec": 310.0,
        "valid_steps": valid_steps,
        "valid_steps_per_min": rate,
        "backend_audit": {"passed": True, "p99_gateway_wait_sec": 50.0},
        "warmup_audit": {"passed": True},
        "request_success_rate": 1.0,
        "valid_step_ratio": 1.0,
        "tests_passed_workflows": 8,
        "completed_workflows": 6,
        "minimum_workflow_progress": 2,
        "p99_step_latency_sec": 100.0 if mode == "baseline" else 110.0,
        "backend_tokens_per_valid_step": 100.0,
        "profile_config": {"pressure_required": True, "workflows": 1},
        "measurement_window": {
            "configured": False,
            "deadline_reached": False,
            "termination": "finite_workload",
        },
        "agent_execution_interval": {
            "schema_version": 1,
            "start_event": "measured_leg_started",
            "end_event": "last_agent_run_termination",
            "duration_clock": "monotonic",
            "started_unix": 100.0,
            "ended_unix": 400.0,
            "elapsed_sec": elapsed,
            "expected_agent_runs": 1,
            "observed_agent_runs": 1,
            "complete": True,
        },
        "vllm_metrics": {
            "live_samples": [{"created_unix": 400.0}],
            "live_series": {"sampler_error_count": 0},
        },
        "pressure_validation": {"valid": True, "reasons": []},
    }


def legs(
    candidate_rate: float = 16.0,
    *,
    order: tuple[str, str] = ("baseline", "candidate"),
) -> dict[str, list[dict[str, Any]]]:
    commitment = commitment_for_order(order)
    rates = {"baseline": 10.0, "candidate": candidate_rate}
    result = [leg(mode, rates[mode], commitment) for mode in order]
    snapshot = hashlib.sha256(b"frozen-submission").hexdigest()
    for index, item in enumerate(result):
        epoch = {
            "schema_version": 1,
            "leg_ordinal": index + 1,
            "mode": item["mode"],
            "frozen_submission_sha256": snapshot,
            "challenge_sha256": hashlib.sha256(f"challenge-{index}".encode()).hexdigest(),
            "epoch_nonce_sha256": hashlib.sha256(f"epoch-{index}".encode()).hexdigest(),
            "attestation_sha256": hashlib.sha256(f"attestation-{index}".encode()).hexdigest(),
        }
        if item["mode"] == "candidate":
            epoch["gateway_process_identity_sha256"] = hashlib.sha256(
                f"gateway-process-{index}".encode()
            ).hexdigest()
            item["candidate_reset_epoch"] = epoch
        else:
            item["candidate_quiescence_epoch"] = epoch
    return {"mutation-profile": result}


def selected_leg(
    profile_legs: dict[str, list[dict[str, Any]]], mode: str
) -> dict[str, Any]:
    return next(item for item in profile_legs["mutation-profile"] if item["mode"] == mode)


def selected_index(profile_legs: dict[str, list[dict[str, Any]]], mode: str) -> int:
    return next(
        index
        for index, item in enumerate(profile_legs["mutation-profile"])
        if item["mode"] == mode
    )


def mutated(
    profile_legs: dict[str, list[dict[str, Any]]],
    mode: str,
    mutation: Callable[[dict[str, Any]], None],
) -> dict[str, list[dict[str, Any]]]:
    changed = copy.deepcopy(profile_legs)
    mutation(selected_leg(changed, mode))
    return changed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    score_final, formal_leg_order, validate_policy = load_scoring_functions()
    fixture = policy()
    cases: list[dict[str, Any]] = []

    def append_case(name: str, passed: bool, result: dict[str, Any] | None = None) -> None:
        cases.append(
            {
                "name": name,
                "passed": bool(passed),
                "status": result.get("status") if result else None,
                "reward": result.get("reward") if result else None,
                "infra_failures": result.get("infra_failures", []) if result else [],
                "candidate_failures": result.get("candidate_failures", []) if result else [],
            }
        )

    def record(
        name: str,
        profile_legs: dict[str, list[dict[str, Any]]],
        check: Callable[[dict[str, Any]], bool],
    ) -> None:
        result = score_final(copy.deepcopy(fixture), profile_legs)
        append_case(name, bool(check(result)), result)

    def record_rejected(name: str, profile_legs: dict[str, list[dict[str, Any]]]) -> None:
        try:
            score_final(copy.deepcopy(fixture), profile_legs)
        except (KeyError, TypeError, ValueError):
            append_case(name, True)
        else:
            append_case(name, False)

    hidden_profiles = {
        "mutation-profile": SimpleNamespace(
            enabled=True,
            measurement_window_sec=None,
            workload_family="swebench-lite",
            pressure_required=True,
            corpus_partition="hidden",
            corpus_unique_instances_min=1,
        )
    }
    for invalid, label in (
        (None, "missing"),
        (True, "boolean"),
        (0.0, "zero"),
        (-1.0, "negative"),
        (math.inf, "infinite"),
        (math.nan, "nan"),
        ("7.45", "string"),
    ):
        broken_policy = copy.deepcopy(fixture)
        if invalid is None:
            broken_policy.pop("min_baseline_valid_steps_per_min")
        else:
            broken_policy["min_baseline_valid_steps_per_min"] = invalid
        try:
            validate_policy(broken_policy, hidden_profiles)
        except (KeyError, TypeError, ValueError):
            append_case(f"{label}_baseline_throughput_floor_is_rejected", True)
        else:
            append_case(f"{label}_baseline_throughput_floor_is_rejected", False)

    for label, order in (
        ("ab", ("baseline", "candidate")),
        ("ba", ("candidate", "baseline")),
    ):
        sample = legs(order=order)
        commitment = sample["mutation-profile"][0]["workload_nonce_sha256"]
        record(
            f"committed_{label}_order_full_score",
            sample,
            lambda result, expected=order, committed=commitment: (
                result["hard_gates_passed"]
                and abs(result["reward"] - 1.0) < 1e-12
                and formal_leg_order(committed) == expected
                and result["profiles"]["mutation-profile"]["leg_order_commitment"][
                    "order"
                ]
                == list(expected)
                and "baseline_cv" not in result["profiles"]["mutation-profile"]
            ),
        )

    one_leg = legs()
    one_leg["mutation-profile"].pop()
    record_rejected("one_leg_formal_result_is_rejected", one_leg)
    duplicate_baseline = legs()
    selected_leg(duplicate_baseline, "candidate")["mode"] = "baseline"
    record_rejected("duplicate_baseline_mode_is_rejected", duplicate_baseline)
    duplicate_candidate = legs()
    selected_leg(duplicate_candidate, "baseline")["mode"] = "candidate"
    record_rejected("duplicate_candidate_mode_is_rejected", duplicate_candidate)
    reversed_order = legs()
    reversed_order["mutation-profile"].reverse()
    record_rejected("order_reversed_against_commitment_is_rejected", reversed_order)
    inconsistent_commitment = legs()
    inconsistent_commitment["mutation-profile"][1]["workload_nonce_sha256"] = "0" * 64
    record_rejected("inconsistent_nonce_commitment_is_rejected", inconsistent_commitment)

    missing_reset = legs()
    selected_leg(missing_reset, "candidate").pop("candidate_reset_epoch")
    record(
        "missing_single_candidate_epoch_invalidates_infrastructure",
        missing_reset,
        lambda result: result["status"] == "infra_invalid"
        and any("formal_lifecycle_evidence_invalid" in item for item in result["infra_failures"]),
    )
    duplicate_epoch = legs()
    selected_leg(duplicate_epoch, "baseline")["candidate_reset_epoch"] = copy.deepcopy(
        selected_leg(duplicate_epoch, "candidate")["candidate_reset_epoch"]
    )
    record(
        "more_than_one_candidate_epoch_invalidates_infrastructure",
        duplicate_epoch,
        lambda result: result["status"] == "infra_invalid"
        and any("formal_lifecycle_evidence_invalid" in item for item in result["infra_failures"]),
    )
    missing_quiescence = legs(order=("candidate", "baseline"))
    selected_leg(missing_quiescence, "baseline").pop("candidate_quiescence_epoch")
    record(
        "missing_baseline_quiescence_epoch_invalidates_infrastructure",
        missing_quiescence,
        lambda result: result["status"] == "infra_invalid",
    )

    missing_interval = legs()
    selected_leg(missing_interval, "candidate").pop("agent_execution_interval")
    record(
        "missing_finite_agent_interval_invalidates_infrastructure",
        missing_interval,
        lambda result: result["status"] == "infra_invalid"
        and any("agent_execution_interval:missing" in item for item in result["infra_failures"]),
    )
    rate_tamper = legs()
    selected_leg(rate_tamper, "candidate")["valid_steps_per_min"] += 0.01
    record(
        "finite_rate_identity_tamper_invalidates_infrastructure",
        rate_tamper,
        lambda result: result["status"] == "infra_invalid"
        and any("rate_identity" in item for item in result["infra_failures"]),
    )
    post_end_sample = legs(order=("candidate", "baseline"))
    selected_leg(post_end_sample, "baseline")["vllm_metrics"]["live_samples"].append(
        {"created_unix": 400.01}
    )
    record(
        "post_agent_end_metric_sample_invalidates_infrastructure",
        post_end_sample,
        lambda result: result["status"] == "infra_invalid"
        and any("post_end_live_sample" in item for item in result["infra_failures"]),
    )

    record(
        "naive_passthrough_correctness_base",
        legs(candidate_rate=9.8),
        lambda result: result["hard_gates_passed"] and abs(result["reward"] - 0.20) < 1e-12,
    )
    record(
        "partial_policy_is_distinguished",
        legs(candidate_rate=12.0, order=("candidate", "baseline")),
        lambda result: result["hard_gates_passed"] and 0.20 < result["reward"] < 1.0,
    )
    record(
        "scoring_output_contains_no_fairness_metric",
        legs(),
        lambda result: "fairness" not in json.dumps(result).lower()
        and "jain" not in json.dumps(result).lower()
        and isinstance(result.get("tail_score"), float),
    )
    record(
        "candidate_backend_audit_failure_is_candidate_failure",
        mutated(legs(), "candidate", lambda item: item["backend_audit"].update(passed=False)),
        lambda result: result["status"] == "candidate_failed" and result["reward"] == 0.0,
    )
    record(
        "baseline_backend_audit_failure_is_infrastructure_invalid",
        mutated(legs(), "baseline", lambda item: item["backend_audit"].update(passed=False)),
        lambda result: result["status"] == "infra_invalid" and result["reward"] == 0.0,
    )
    record(
        "unpressurized_baseline_invalidates_infrastructure",
        mutated(
            legs(order=("candidate", "baseline")),
            "baseline",
            lambda item: item.update(
                pressure_validation={"valid": False, "reasons": ["kv_p95_below_floor"]}
            ),
        ),
        lambda result: result["status"] == "infra_invalid"
        and any("profile_not_pressurized" in item for item in result["infra_failures"]),
    )
    for name, mutation in (
        ("dropped_requests_rejected", lambda item: item.update(request_success_rate=0.70)),
        ("invalid_agent_steps_rejected", lambda item: item.update(valid_step_ratio=0.50)),
        ("semantic_test_regression_rejected", lambda item: item.update(tests_passed_workflows=5)),
        ("completion_regression_rejected", lambda item: item.update(completed_workflows=4)),
        (
            "starvation_rejected",
            lambda item: item.update(minimum_workflow_progress=0),
        ),
        (
            "over_throttle_rejected",
            lambda item: item["backend_audit"].update(p99_gateway_wait_sec=481.0),
        ),
        (
            "backend_work_shortcut_rejected",
            lambda item: item.update(backend_tokens_per_valid_step=50.0),
        ),
    ):
        record(
            name,
            mutated(legs(), "candidate", mutation),
            lambda result: result["status"] == "candidate_failed" and result["reward"] == 0.0,
        )

    record(
        "single_tail_ratio_is_reported_for_ba_order",
        legs(order=("candidate", "baseline")),
        lambda result: result["profiles"]["mutation-profile"]["tail_anti_gaming"]
        == {
            "schema_version": 2,
            "metric": "p99_step_latency_sec",
            "pairing": "candidate_over_baseline:single_committed_pair",
            "baseline_p99_step_latency_sec": 100.0,
            "candidate_p99_step_latency_sec": 110.0,
            "ratio": 1.1,
            "maximum_allowed_ratio": 1.25,
            "passed": True,
        },
    )
    tail_regression = mutated(
        legs(order=("candidate", "baseline")),
        "candidate",
        lambda item: item.update(p99_step_latency_sec=126.0),
    )
    record(
        "single_tail_ratio_above_limit_is_rejected",
        tail_regression,
        lambda result: result["status"] == "candidate_failed"
        and result["profiles"]["mutation-profile"]["tail_anti_gaming"]["ratio"] == 1.26
        and any("p99_step_latency_ratio" in item for item in result["candidate_failures"]),
    )
    missing_candidate_tail = legs()
    selected_leg(missing_candidate_tail, "candidate").pop("p99_step_latency_sec")
    record(
        "missing_candidate_tail_fails_candidate",
        missing_candidate_tail,
        lambda result: result["status"] == "candidate_failed"
        and result["profiles"]["mutation-profile"]["tail_anti_gaming"]["ratio"] is None,
    )
    missing_baseline_tail = legs(order=("candidate", "baseline"))
    selected_leg(missing_baseline_tail, "baseline").pop("p99_step_latency_sec")
    record(
        "missing_baseline_tail_invalidates_infrastructure",
        missing_baseline_tail,
        lambda result: result["status"] == "infra_invalid"
        and result["profiles"]["mutation-profile"]["tail_anti_gaming"]["ratio"] is None,
    )

    baseline_quality = legs()
    selected_leg(baseline_quality, "baseline").update(
        request_success_rate=0.70,
        valid_step_ratio=0.50,
        tests_passed_workflows=0,
        completed_workflows=-1,
        minimum_workflow_progress=0,
    )
    record(
        "baseline_quality_collapse_invalidates_infrastructure",
        baseline_quality,
        lambda result: result["status"] == "infra_invalid" and result["reward"] == 0.0,
    )
    slow_baseline = legs()
    selected_leg(slow_baseline, "baseline").update(
        valid_steps=35,
        valid_steps_per_min=7.0,
    )
    record(
        "baseline_throughput_floor_replaces_live_cv_gate",
        slow_baseline,
        lambda result: result["status"] == "infra_invalid"
        and any(
            "baseline_valid_steps_per_min=7.0000<7.4500" in item
            for item in result["infra_failures"]
        ),
    )

    report = {
        "schema_version": 1,
        "kind": "synthetic-two-leg-scoring-mutations",
        "controller_sha256": hashlib.sha256(SERVER_PATH.read_bytes()).hexdigest(),
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered, end="")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
