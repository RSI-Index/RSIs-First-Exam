#!/usr/bin/env python3
"""CPU-only contracts for the formal hidden baseline/candidate pair clock."""

from __future__ import annotations

import importlib.util
import json
import sys
import tomllib
from contextlib import ExitStack
from pathlib import Path
from unittest import mock


TASK_ROOT = Path(__file__).resolve().parents[1]
TEST_ROOT = TASK_ROOT / "tests"
sys.path.insert(0, str(TEST_ROOT))
SPEC = importlib.util.spec_from_file_location(
    "hidden_suite_deadline_verify",
    TEST_ROOT / "verify.py",
)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class FakeClock:
    def __init__(self, now: float = 1_000.0) -> None:
        self.now = now

    def monotonic(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


class SharedOutputSeal:
    def attest(self) -> dict[str, bool]:
        return {"candidate_shared_output_roots_sealed": True}


def leg(mode: str, ordinal: int) -> dict[str, object]:
    return {
        "mode": mode,
        "leg_ordinal": ordinal,
        "challenge": f"{ordinal:064x}",
    }


def verifier_patches(
    stack: ExitStack,
    *,
    clock: FakeClock,
    controller_post,
    observe_candidate_post_leg_health,
    reset_candidate_runtime=None,
    launch_gateway=None,
) -> None:
    stack.enter_context(
        mock.patch.object(MODULE.time, "monotonic", side_effect=clock.monotonic)
    )
    stack.enter_context(
        mock.patch.object(MODULE, "frozen_submission_sha256", return_value="f" * 64)
    )
    stack.enter_context(
        mock.patch.object(
            MODULE,
            "reset_candidate_runtime",
            side_effect=(reset_candidate_runtime or (lambda _process: {})),
        )
    )
    stack.enter_context(
        mock.patch.object(MODULE, "seal_main_network_egress", return_value={"sealed": True})
    )
    stack.enter_context(mock.patch.object(MODULE, "controller_post", side_effect=controller_post))
    stack.enter_context(
        mock.patch.object(
            MODULE,
            "launch_gateway",
            side_effect=(launch_gateway or (lambda *_args, **_kwargs: object())),
        )
    )
    stack.enter_context(mock.patch.object(MODULE, "wait_gateway", return_value=None))
    stack.enter_context(mock.patch.object(MODULE, "lifecycle_attestation", return_value={}))
    stack.enter_context(
        mock.patch.object(
            MODULE,
            "observe_candidate_post_leg_health",
            side_effect=observe_candidate_post_leg_health,
        )
    )


def successful_order_case(order: tuple[str, str]) -> dict[str, object]:
    clock = FakeClock()
    plans = [leg(mode, ordinal) for ordinal, mode in enumerate(order, start=1)]
    next_index = 1
    begin_timeouts: list[float] = []
    leg_timeouts: list[float] = []
    health_timeouts: list[float] = []
    observed_ordinals: list[int] = []
    gateway = object()
    launches: list[object] = []
    resets: list[object | None] = []

    def controller_post(
        _base: str,
        path: str,
        _token: str,
        timeout: float,
        payload: dict[str, object] | None = None,
    ) -> dict[str, object]:
        nonlocal next_index
        assert timeout > 0
        if path.endswith("/begin"):
            begin_timeouts.append(timeout)
            clock.advance(2.0)
            return {"session_id": "s" * 64, "next_leg": plans[0]}
        if path.endswith("/abort"):
            raise AssertionError("successful pair was unexpectedly aborted")
        assert path.endswith("/leg") and payload is not None
        leg_timeouts.append(timeout)
        clock.advance(15.0)
        if next_index == len(plans):
            return {"done": True, "report": {"status": "unit-complete"}}
        response = {"done": False, "next_leg": plans[next_index]}
        next_index += 1
        return response

    def observe(ordinal: int, *, timeout_sec: float) -> dict[str, object]:
        observed_ordinals.append(ordinal)
        health_timeouts.append(timeout_sec)
        clock.advance(1.0)
        return {"capture_status": "ok", "leg_ordinal": ordinal}

    def reset(process: object | None) -> dict[str, object]:
        resets.append(process)
        return {}

    def launch(*_args: object, **_kwargs: object) -> object:
        launches.append(gateway)
        return gateway

    observations: dict[str, object] = {}
    with ExitStack() as stack:
        verifier_patches(
            stack,
            clock=clock,
            controller_post=controller_post,
            observe_candidate_post_leg_health=observe,
            reset_candidate_runtime=reset,
            launch_gateway=launch,
        )
        result = MODULE.run_isolated_final_session(
            controller_base="http://controller",
            token="token",
            frozen_submission=Path("/frozen"),
            backend="http://backend/v1",
            suite_timeout_sec=100.0,
            verifier_deadline_monotonic=10_000.0,
            shared_output_seal=SharedOutputSeal(),
            candidate_post_leg_observations=observations,
        )

    candidate_ordinal = order.index("candidate") + 1
    return {
        "name": f"{''.join('A' if mode == 'baseline' else 'B' for mode in order)}_uses_one_decreasing_pair_clock",
        "passed": result == {"status": "unit-complete"}
        and begin_timeouts == [30.0]
        and len(leg_timeouts) == 2
        and leg_timeouts[0] > leg_timeouts[1] > 0
        and max(leg_timeouts) < 100.0
        and len(launches) == 1
        and resets.count(gateway) == 1
        and observed_ordinals == [candidate_ordinal]
        and len(health_timeouts) == 1
        and 0 < health_timeouts[0] <= MODULE.CANDIDATE_HEALTH_TIMEOUT_SEC
        and sorted(observations) == [str(candidate_ordinal)],
        "order": list(order),
        "begin_timeouts": begin_timeouts,
        "leg_timeouts": leg_timeouts,
        "health_timeouts": health_timeouts,
        "reset_count": len(resets),
    }


def timeout_case(stage: str) -> dict[str, object]:
    """Exercise expiry before or during each controller leg."""

    clock = FakeClock()
    plans = [leg("baseline", 1), leg("candidate", 2)]
    leg_calls: list[int] = []
    resets = 0
    aborted = False
    gateway = object()

    def reset(_process: object | None) -> dict[str, object]:
        nonlocal resets
        resets += 1
        # Reset call 1 is the one-time pre-suite quiescence. Calls 2 and 3 are
        # the mandatory pre-leg resets for the baseline-first plan.
        if stage == "before_leg_1" and resets == 2:
            clock.advance(10.0)
        if stage == "before_leg_2" and resets == 3:
            clock.advance(9.0)
        return {}

    def controller_post(
        _base: str,
        path: str,
        _token: str,
        timeout: float,
        payload: dict[str, object] | None = None,
    ) -> dict[str, object]:
        nonlocal aborted
        if path.endswith("/begin"):
            return {"session_id": "s" * 64, "next_leg": plans[0]}
        if path.endswith("/abort"):
            aborted = True
            return {"aborted": True}
        assert path.endswith("/leg") and payload is not None
        ordinal = len(leg_calls) + 1
        leg_calls.append(ordinal)
        if stage == f"during_leg_{ordinal}":
            clock.advance(timeout + 0.25)
        else:
            clock.advance(1.0)
        if ordinal == 1:
            return {"done": False, "next_leg": plans[1]}
        return {"done": True, "report": {"status": "too-late"}}

    def observe(ordinal: int, *, timeout_sec: float) -> dict[str, object]:
        return {"capture_status": "ok", "leg_ordinal": ordinal}

    error = ""
    with ExitStack() as stack:
        verifier_patches(
            stack,
            clock=clock,
            controller_post=controller_post,
            observe_candidate_post_leg_health=observe,
            reset_candidate_runtime=reset,
            launch_gateway=lambda *_args, **_kwargs: gateway,
        )
        try:
            MODULE.run_isolated_final_session(
                controller_base="http://controller",
                token="token",
                frozen_submission=Path("/frozen"),
                backend="http://backend/v1",
                suite_timeout_sec=10.0,
                verifier_deadline_monotonic=10_000.0,
                shared_output_seal=SharedOutputSeal(),
                candidate_post_leg_observations={},
            )
        except MODULE.VerificationError as exc:
            error = str(exc)

    expected_calls = {
        "before_leg_1": [],
        "during_leg_1": [1],
        "before_leg_2": [1],
        "during_leg_2": [1, 2],
    }[stage]
    return {
        "name": f"pair_timeout_{stage}_fails_closed",
        "passed": "monotonic deadline exhausted" in error
        and leg_calls == expected_calls
        and aborted,
        "leg_calls": leg_calls,
        "error": error,
        "abort_seen": aborted,
    }


def typed_early_failure_case(mode: str) -> dict[str, object]:
    """A trusted zero-score terminal failure keeps its typed attribution."""

    clock = FakeClock()
    status = "candidate_failed" if mode == "candidate" else "infra_invalid"
    report = {
        "schema_version": 2,
        "status": status,
        "hard_gates_passed": False,
        "reward": 0.0,
        "infra_failures": ["trusted-controller:unit"] if status == "infra_invalid" else [],
        "candidate_failures": ["candidate:unit"] if status == "candidate_failed" else [],
    }
    aborted = False
    gateway = object()
    resets: list[object | None] = []
    launches = 0

    def controller_post(
        _base: str,
        path: str,
        _token: str,
        timeout: float,
        payload: dict[str, object] | None = None,
    ) -> dict[str, object]:
        nonlocal aborted
        if path.endswith("/begin"):
            return {"session_id": "s" * 64, "next_leg": leg(mode, 1)}
        if path.endswith("/abort"):
            aborted = True
            return {"aborted": True}
        assert path.endswith("/leg") and payload is not None
        return {"done": True, "report": report}

    def reset(process: object | None) -> dict[str, object]:
        resets.append(process)
        return {}

    def launch(*_args: object, **_kwargs: object) -> object:
        nonlocal launches
        launches += 1
        return gateway

    with ExitStack() as stack:
        verifier_patches(
            stack,
            clock=clock,
            controller_post=controller_post,
            observe_candidate_post_leg_health=lambda *_args, **_kwargs: (_ for _ in ()).throw(
                AssertionError("early typed failure required a health observation")
            ),
            reset_candidate_runtime=reset,
            launch_gateway=launch,
        )
        result = MODULE.run_isolated_final_session(
            controller_base="http://controller",
            token="token",
            frozen_submission=Path("/frozen"),
            backend="http://backend/v1",
            suite_timeout_sec=100.0,
            verifier_deadline_monotonic=10_000.0,
            shared_output_seal=SharedOutputSeal(),
            candidate_post_leg_observations={},
        )

    trusted = MODULE.validate_trusted_final_report(result)
    expected_launches = 1 if mode == "candidate" else 0
    return {
        "name": f"early_{status}_retains_typed_zero_reward_report",
        "passed": result == report
        and trusted["reward"] == 0.0
        and not aborted
        and launches == expected_launches
        and (gateway in resets) == (mode == "candidate"),
        "mode": mode,
        "reset_count": len(resets),
    }


def malformed_pair_case(kind: str) -> dict[str, object]:
    clock = FakeClock()
    calls = 0
    aborted = False

    def controller_post(
        _base: str,
        path: str,
        _token: str,
        timeout: float,
        payload: dict[str, object] | None = None,
    ) -> dict[str, object]:
        nonlocal calls, aborted
        if path.endswith("/begin"):
            return {"session_id": "s" * 64, "next_leg": leg("baseline", 1)}
        if path.endswith("/abort"):
            aborted = True
            return {"aborted": True}
        assert path.endswith("/leg") and payload is not None
        calls += 1
        if kind == "early_done":
            return {"done": True, "report": {"status": "invalid"}}
        if kind == "nonzero_failure":
            return {
                "done": True,
                "report": {
                    "schema_version": 2,
                    "status": "candidate_failed",
                    "hard_gates_passed": False,
                    "reward": 0.25,
                    "infra_failures": [],
                    "candidate_failures": ["candidate:unit"],
                },
            }
        if calls == 1:
            second_mode = "baseline" if kind == "duplicate_mode" else "candidate"
            return {"done": False, "next_leg": leg(second_mode, 2)}
        assert kind == "third_leg"
        return {"done": False, "next_leg": leg("baseline", 3)}

    with ExitStack() as stack:
        verifier_patches(
            stack,
            clock=clock,
            controller_post=controller_post,
            observe_candidate_post_leg_health=lambda ordinal, **_kwargs: {
                "capture_status": "ok",
                "leg_ordinal": ordinal,
            },
        )
        error = ""
        try:
            MODULE.run_isolated_final_session(
                controller_base="http://controller",
                token="token",
                frozen_submission=Path("/frozen"),
                backend="http://backend/v1",
                suite_timeout_sec=100.0,
                verifier_deadline_monotonic=10_000.0,
                shared_output_seal=SharedOutputSeal(),
                candidate_post_leg_observations={},
            )
        except MODULE.VerificationError as exc:
            error = str(exc)

    return {
        "name": f"formal_pair_rejects_{kind}",
        "passed": bool(error) and aborted,
        "error": error,
    }


def post_suite_reserve_case() -> dict[str, object]:
    clock = FakeClock()
    plans = [leg("baseline", 1), leg("candidate", 2)]
    leg_timeouts: list[float] = []

    def controller_post(
        _base: str,
        path: str,
        _token: str,
        timeout: float,
        payload: dict[str, object] | None = None,
    ) -> dict[str, object]:
        if path.endswith("/begin"):
            clock.advance(2.0)
            return {"session_id": "s" * 64, "next_leg": plans[0]}
        if path.endswith("/abort"):
            raise AssertionError("successful capped pair was unexpectedly aborted")
        assert path.endswith("/leg") and payload is not None
        leg_timeouts.append(timeout)
        clock.advance(1.0)
        if len(leg_timeouts) == 1:
            return {"done": False, "next_leg": plans[1]}
        return {"done": True, "report": {"status": "unit-capped"}}

    # At t=1000, a nominal 100-second suite would end at t=1100. The complete
    # verifier must end by t=1650 and reserves 600 seconds after the pair, so
    # the suite is capped at t=1050 instead.
    with ExitStack() as stack:
        verifier_patches(
            stack,
            clock=clock,
            controller_post=controller_post,
            observe_candidate_post_leg_health=lambda ordinal, **_kwargs: {
                "capture_status": "ok",
                "leg_ordinal": ordinal,
            },
        )
        result = MODULE.run_isolated_final_session(
            controller_base="http://controller",
            token="token",
            frozen_submission=Path("/frozen"),
            backend="http://backend/v1",
            suite_timeout_sec=100.0,
            verifier_deadline_monotonic=1_650.0,
            shared_output_seal=SharedOutputSeal(),
            candidate_post_leg_observations={},
        )

    return {
        "name": "overall_deadline_shortens_pair_to_keep_post_suite_reserve",
        "passed": result == {"status": "unit-capped"}
        and len(leg_timeouts) == 2
        and 0 < leg_timeouts[1] < leg_timeouts[0] <= 48.0,
        "leg_timeouts": leg_timeouts,
    }


def budget_contract_case() -> dict[str, object]:
    task = tomllib.loads((TASK_ROOT / "task.toml").read_text())
    verifier_budget = float(task["verifier"]["timeout_sec"])
    agent_budget = float(task["agent"]["timeout_sec"])
    helper_rejected = False
    clock = FakeClock(now=50.0)
    with mock.patch.object(MODULE.time, "monotonic", side_effect=clock.monotonic):
        remaining = MODULE.hidden_suite_remaining_timeout(51.5, stage="unit")
        clock.advance(1.5)
        try:
            MODULE.hidden_suite_remaining_timeout(51.5, stage="unit-expired")
        except MODULE.VerificationError:
            helper_rejected = True

    margin = MODULE.VERIFIER_FREEZE_PROTOCOL_CLEANUP_ARTIFACT_MARGIN_SEC
    pre_margin = MODULE.VERIFIER_PRE_PAIR_FREEZE_PROTOCOL_SEAL_MARGIN_SEC
    post_margin = MODULE.VERIFIER_POST_PAIR_CLEANUP_ARTIFACT_MARGIN_SEC
    return {
        "name": "pair_budget_leaves_explicit_pre_and_post_margin",
        "passed": verifier_budget == MODULE.HARBOR_VERIFIER_WALL_BUDGET_SEC
        and verifier_budget == 12_600.0
        and agent_budget == 1_309_000.0
        and MODULE.HIDDEN_PAIR_SUITE_TIMEOUT_SEC == 9_000.0
        and margin == 3_600.0
        and pre_margin == 3_000.0
        and post_margin == 600.0
        and pre_margin + post_margin == margin
        and remaining == 1.5
        and helper_rejected,
        "agent_budget_sec": agent_budget,
        "verifier_budget_sec": verifier_budget,
        "suite_budget_sec": MODULE.HIDDEN_PAIR_SUITE_TIMEOUT_SEC,
        "reserved_margin_sec": margin,
        "pre_suite_margin_sec": pre_margin,
        "post_suite_margin_sec": post_margin,
    }


def main() -> int:
    cases = [
        successful_order_case(("baseline", "candidate")),
        successful_order_case(("candidate", "baseline")),
        *(timeout_case(stage) for stage in (
            "before_leg_1",
            "during_leg_1",
            "before_leg_2",
            "during_leg_2",
        )),
        typed_early_failure_case("baseline"),
        typed_early_failure_case("candidate"),
        malformed_pair_case("early_done"),
        malformed_pair_case("nonzero_failure"),
        malformed_pair_case("duplicate_mode"),
        malformed_pair_case("third_leg"),
        post_suite_reserve_case(),
        budget_contract_case(),
    ]
    report = {
        "schema_version": 1,
        "kind": "hidden-suite-deadline-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
