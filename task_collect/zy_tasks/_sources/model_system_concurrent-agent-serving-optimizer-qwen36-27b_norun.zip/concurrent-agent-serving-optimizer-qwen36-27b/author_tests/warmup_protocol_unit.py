#!/usr/bin/env python3
"""Bounded warm-up correction checks for the Qwen3.6 text-bash protocol."""

from __future__ import annotations

import json
import inspect
import sys
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))

from runner.workload import (  # noqa: E402
    WARMUP_CORPUS_SEED,
    WARMUP_MODEL_SEED_BASE,
    append_warmup_response,
    load_model_adapter_contract,
    run_benchmark,
    run_warmup,
)


def text_response(command: str = "pwd") -> dict[str, object]:
    return {
        "content": f"THOUGHT: Inspect the repository first.\n\n```bash\n{command}\n```"
    }


def main() -> int:
    adapter = load_model_adapter_contract()

    valid_messages: list[dict[str, object]] = []
    valid = append_warmup_response(
        valid_messages,
        text_response(),
        "Observation: ok",
        adapter,
    )

    invalid_cases = {
        "missing_fence": {"content": "pwd"},
        "empty_fence": {"content": "THOUGHT: inspect\n```bash\n\n```"},
        "multiple_fences": {
            "content": "THOUGHT: inspect\n```bash\npwd\n```\n```bash\nls\n```"
        },
        "unexpected_function_tool": {
            "content": "",
            "tool_calls": [
                {
                    "id": "call_warmup",
                    "type": "function",
                    "function": {
                        "name": "execute_bash",
                        "arguments": '{"cmd":"pwd"}',
                    },
                }
            ],
        },
    }
    invalid_results: dict[str, bool] = {}
    invalid_histories: dict[str, list[dict[str, object]]] = {}
    for name, response in invalid_cases.items():
        messages: list[dict[str, object]] = []
        invalid_results[name] = append_warmup_response(
            messages,
            response,
            "Observation: unreachable",
            adapter,
        )
        invalid_histories[name] = messages

    checks = {
        "valid_text_bash_step_accepted": valid is True,
        "valid_observation_uses_user_role": (
            valid_messages[-1]
            == {"role": "user", "content": "Observation: ok"}
        ),
        "invalid_shapes_get_bounded_correction": (
            all(result is False for result in invalid_results.values())
            and all(
                messages[-1]
                == {"role": "user", "content": adapter.render_format_error([])}
                for messages in invalid_histories.values()
            )
        ),
        "all_responses_remain_in_history": all(
            messages[0]["role"] == "assistant"
            for messages in invalid_histories.values()
        ),
        "function_tool_is_not_silently_accepted": (
            invalid_results["unexpected_function_tool"] is False
        ),
        "measured_leg_resets_cache_after_warmup": (
            inspect.getsource(run_benchmark).index("run_warmup(")
            < inspect.getsource(run_benchmark).index(
                "\n        audit_epoch = reset_measurement_state(model_api_base, admin_token)"
            )
        ),
        "warmup_and_measured_requests_bind_distinct_audit_epochs": (
            "warmup_audit_epoch = reset_measurement_state"
            in inspect.getsource(run_benchmark)
            and "audit_epoch=warmup_audit_epoch" in inspect.getsource(run_benchmark)
            and "audit_epoch=audit_epoch" in inspect.getsource(run_benchmark)
        ),
        "warmup_randomization_is_profile_independent": (
            WARMUP_CORPUS_SEED == 410_148
            and WARMUP_MODEL_SEED_BASE == 1_310_148
            and "seed=WARMUP_CORPUS_SEED" in inspect.getsource(run_warmup)
            and "seed=WARMUP_MODEL_SEED_BASE + index" in inspect.getsource(run_warmup)
        ),
        "hidden_warmup_uses_disjoint_public_corpus": (
            '"public" if profile.workload_family == "swebench-lite"'
            in inspect.getsource(run_warmup)
            and "corpus_partition=warmup_partition" in inspect.getsource(run_warmup)
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "qwen36-warmup-protocol-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
