#!/usr/bin/env python3
"""Exercise every trusted model-api operation over an aiohttp UnixConnector."""

from __future__ import annotations

import asyncio
import importlib
import hashlib
import hmac
import json
import os
import sys
import tempfile
from pathlib import Path

from aiohttp import ClientSession, web


CONTAINER_MODEL_API_ROOT = Path("/opt/model-api")
MODEL_API_ROOT = (
    CONTAINER_MODEL_API_ROOT
    if CONTAINER_MODEL_API_ROOT.is_dir()
    else Path(__file__).resolve().parents[1] / "environment" / "model-api"
)
sys.path.insert(0, str(MODEL_API_ROOT))

from transport import (  # noqa: E402
    UpstreamConfigurationError,
    configured_socket_path,
    require_live_socket,
)


def rejected(value: str | None) -> bool:
    try:
        configured_socket_path(value)
    except UpstreamConfigurationError:
        return True
    return False


async def exercise_proxy(root: Path) -> dict[str, bool]:
    socket_path = root / "vllm.sock"
    token_path = root / "token"
    audit_path = root / "requests.jsonl"
    attestation_path = root / "attestation.json"
    token_path.write_text("test-admin-token\n")
    attestation_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "state": "ready",
                "profile_id": "qwen3.6-27b-unit",
                "model": {"model_id": "Qwen/Qwen3.6-27B"},
                "transport": {
                    "kind": "unix",
                    "container_socket_path": str(socket_path),
                },
            }
        )
    )

    os.environ["UPSTREAM_UNIX_SOCKET"] = str(socket_path)
    os.environ["ADMIN_TOKEN_FILE"] = str(token_path)
    os.environ["AUDIT_FILE"] = str(audit_path)
    os.environ["ATTESTATION_FILE"] = str(attestation_path)

    observed: dict[str, object] = {
        "models_count": 0,
        "chat_count": 0,
        "chat_bodies": [],
        "reset_count": 0,
        "kv_usage": 0.75,
    }
    held_chat_entered = asyncio.Event()
    release_held_chat = asyncio.Event()

    async def upstream_health(_: web.Request) -> web.Response:
        return web.Response(text="ok")

    async def upstream_models(request: web.Request) -> web.Response:
        observed["models_count"] = int(observed["models_count"]) + 1
        observed["models_headers"] = {name.lower(): value for name, value in request.headers.items()}
        return web.json_response({"object": "list", "data": [{"id": "target-model"}]})

    async def upstream_chat(request: web.Request) -> web.Response:
        observed["chat_count"] = int(observed["chat_count"]) + 1
        observed["chat_headers"] = {name.lower(): value for name, value in request.headers.items()}
        chat_body = await request.json()
        observed["chat_body"] = chat_body
        observed["chat_bodies"].append(chat_body)  # type: ignore[union-attr]
        if chat_body.get("hold") is True:
            held_chat_entered.set()
            await release_held_chat.wait()
        return web.json_response(
            {
                "choices": [{"message": {"role": "assistant", "content": "ok"}}],
                "usage": {"prompt_tokens": 7, "completion_tokens": 1, "total_tokens": 8},
            }
        )

    async def upstream_reset(_: web.Request) -> web.Response:
        observed["reset_count"] = int(observed["reset_count"]) + 1
        observed["kv_usage"] = 0.0
        return web.json_response({"reset": True})

    async def upstream_metrics(_: web.Request) -> web.Response:
        return web.Response(
            text=(
                "# TYPE vllm:kv_cache_usage_perc gauge\n"
                f'vllm:kv_cache_usage_perc{{engine="0"}} {observed["kv_usage"]}\n'
                'vllm:num_requests_running{engine="0"} 0\n'
                'vllm:num_requests_waiting{engine="0"} 0\n'
                "untrusted_metric 99\n"
            )
        )

    upstream = web.Application()
    upstream.router.add_get("/health", upstream_health)
    upstream.router.add_get("/v1/models", upstream_models)
    upstream.router.add_post("/v1/chat/completions", upstream_chat)
    upstream.router.add_post("/reset_prefix_cache", upstream_reset)
    upstream.router.add_get("/metrics", upstream_metrics)
    upstream_runner = web.AppRunner(upstream)
    await upstream_runner.setup()
    upstream_site = web.UnixSite(upstream_runner, str(socket_path))
    await upstream_site.start()

    require_live_socket(socket_path)
    symlink_path = root / "symlink.sock"
    symlink_path.symlink_to(socket_path)
    symlink_rejected = False
    try:
        require_live_socket(symlink_path)
    except UpstreamConfigurationError:
        symlink_rejected = True

    server = importlib.import_module("server")
    proxy_runner = web.AppRunner(server.make_app())
    await proxy_runner.setup()
    proxy_site = web.TCPSite(proxy_runner, "127.0.0.1", 0)
    await proxy_site.start()
    port = proxy_site._server.sockets[0].getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    admin_headers = {"Authorization": "Bearer test-admin-token"}
    private_headers = {
        "X-KVBench-Request-ID": "request-1",
        "X-KVBench-Auth": "not-a-valid-signature",
        "X-KVBench-Audit-Epoch": "0",
        "X-KVBench-Body-SHA256": hashlib.sha256(b"").hexdigest(),
        "X-Agent-Run-ID": "run-1",
        "X-KVBench-Profile": "unit",
        "X-KVBench-Leg": "leg-1",
        "X-KVBench-Cache-Namespace": "workflow-1",
    }
    invalid_benchmark_headers = private_headers | {
        server.TRANSPORT_AUTH_HEADER: server.derive_transport_credential(
            b"test-admin-token"
        )
    }
    transport_only_headers = {
        server.TRANSPORT_AUTH_HEADER: server.derive_transport_credential(
            b"test-admin-token"
        )
    }

    def signed_headers(request_id: str, body: bytes, audit_epoch: int = 0) -> dict[str, str]:
        body_digest = hashlib.sha256(body).hexdigest()
        fields = {
            "audit_epoch": audit_epoch,
            "method": "GET" if not body else "POST",
            "path": "/v1/models" if not body else "/v1/chat/completions",
            "request_id": request_id,
            "run_id": "run-signed",
            "profile": "unit-signed",
            "leg_id": "leg-signed",
            "cache_namespace": "workflow-signed",
            "body_digest": body_digest,
        }
        signature = hmac.new(
            b"test-admin-token",
            server.benchmark_auth_message(**fields),
            hashlib.sha256,
        ).hexdigest()
        return {
            "Content-Type": "application/json",
            "X-KVBench-Request-ID": request_id,
            "X-KVBench-Auth": signature,
            "X-KVBench-Audit-Epoch": str(audit_epoch),
            "X-KVBench-Body-SHA256": body_digest,
            "X-Agent-Run-ID": "run-signed",
            "X-KVBench-Profile": "unit-signed",
            "X-KVBench-Leg": "leg-signed",
            "X-KVBench-Cache-Namespace": "workflow-signed",
            server.TRANSPORT_AUTH_HEADER: server.derive_transport_credential(
                b"test-admin-token"
            ),
        }

    checks: dict[str, bool] = {"symlink_socket_rejected": symlink_rejected}
    try:
        async with ClientSession() as client:
            async with client.get(f"{base}/health") as response:
                health = await response.json()
                checks["health_over_uds"] = response.status == 200 and health == {
                    "status": "ok",
                    "upstream": True,
                    "attested": True,
                }

            async with client.get(
                f"{base}/admin/quiescent", headers=admin_headers
            ) as response:
                quiescent = await response.json()
                checks["quiescence_includes_upstream_scheduler"] = (
                    response.status == 200
                    and quiescent["quiescent"] is True
                    and quiescent["upstream_requests_running"] == 0.0
                    and quiescent["upstream_requests_waiting"] == 0.0
                )

            async with client.get(f"{base}/v1/models", headers=private_headers) as response:
                await response.read()
                checks["unauthenticated_get_rejected_before_upstream"] = (
                    response.status == 404 and observed["models_count"] == 0
                )

            async with client.post(
                f"{base}/v1/chat/completions",
                data=b"not-json-and-must-not-be-read",
                headers=private_headers,
            ) as response:
                await response.read()
                checks["unauthenticated_post_rejected_before_upstream"] = (
                    response.status == 404 and observed["chat_count"] == 0
                )

            async with client.get(
                f"{base}/admin/audit/snapshot", headers=admin_headers
            ) as response:
                audit_before_auth = await response.json()
                checks["transport_rejections_are_not_audited"] = (
                    response.status == 200 and audit_before_auth["count"] == 0
                )

            async with client.get(
                f"{base}/v1/models", headers=invalid_benchmark_headers
            ) as response:
                await response.read()
                checks["invalid_benchmark_get_rejected_before_upstream"] = (
                    response.status == 404 and observed["models_count"] == 0
                )

            async with client.post(
                f"{base}/v1/chat/completions",
                data=b"unsigned-prefix-cache-probe",
                headers=transport_only_headers,
            ) as response:
                await response.read()
                checks["unsigned_candidate_probe_cannot_reach_upstream_cache"] = (
                    response.status == 404 and observed["chat_count"] == 0
                )

            async with client.post(
                f"{base}/v1/chat/completions",
                data=b"invalid-signed-prefix-cache-probe",
                headers=invalid_benchmark_headers,
            ) as response:
                await response.read()
                checks["invalid_benchmark_post_rejected_before_upstream"] = (
                    response.status == 404 and observed["chat_count"] == 0
                )

            async with client.get(
                f"{base}/admin/audit/snapshot", headers=admin_headers
            ) as response:
                rejected_audit = await response.json()
                checks["benchmark_auth_rejections_are_not_audited"] = (
                    response.status == 200 and rejected_audit["count"] == 0
                )

            signed_body = b"signed-controller-body"
            async with client.post(
                f"{base}/v1/chat/completions",
                data=b"candidate-substituted-body",
                headers=signed_headers("request-body-mismatch", signed_body),
            ) as response:
                await response.read()
                checks["signed_digest_body_mismatch_is_rejected_before_upstream"] = (
                    response.status == 404 and observed["chat_count"] == 0
                )

            async with client.get(
                f"{base}/v1/models", headers=signed_headers("request-models", b"")
            ) as response:
                models = await response.json()
                checks["models_over_uds"] = (
                    response.status == 200
                    and models["data"][0]["id"] == "target-model"
                    and observed["models_count"] == 1
                )

            payload = {
                "model": "target-model",
                "messages": [{"role": "user", "content": "hello"}],
                "stream": False,
                "max_tokens": 8,
            }
            payload_body = json.dumps(payload, separators=(",", ":")).encode()
            async with client.post(
                f"{base}/v1/chat/completions",
                data=payload_body,
                headers=signed_headers("request-chat", payload_body),
            ) as response:
                chat = await response.json()
                checks["chat_over_uds"] = (
                    response.status == 200
                    and chat["choices"][0]["message"]["content"] == "ok"
                    and observed["chat_count"] == 1
                )

            async with client.post(
                f"{base}/v1/chat/completions",
                data=payload_body,
                headers=signed_headers("request-chat", payload_body),
            ) as response:
                await response.read()
                checks["duplicate_signed_request_is_rejected_before_upstream"] = (
                    response.status == 404 and observed["chat_count"] == 1
                )

            async with client.get(f"{base}/admin/metrics/snapshot") as response:
                checks["admin_is_hidden_without_token"] = response.status == 404

            async with client.get(
                f"{base}/admin/metrics/snapshot", headers=admin_headers
            ) as response:
                metrics = await response.json()
                checks["metrics_over_uds_and_filtered"] = (
                    response.status == 200
                    and len(metrics["samples"]) == 3
                    and {sample["name"] for sample in metrics["samples"]}
                    == {
                        "vllm:kv_cache_usage_perc",
                        "vllm:num_requests_running",
                        "vllm:num_requests_waiting",
                    }
                    and metrics["active_backend_requests"] == 0
                    and metrics["audit_epoch"] == 0
                    and metrics["audit_count"] == 2
                    and metrics["admitted_request_count"] == 2
                )

            held_payload = {**payload, "hold": True}
            held_body = json.dumps(held_payload, separators=(",", ":")).encode()

            async def held_request() -> int:
                async with client.post(
                    f"{base}/v1/chat/completions",
                    data=held_body,
                    headers=signed_headers("request-held-chat", held_body),
                ) as response:
                    await response.read()
                    return response.status

            held_task = asyncio.create_task(held_request())
            await asyncio.wait_for(held_chat_entered.wait(), timeout=2)
            async with client.get(
                f"{base}/admin/metrics/snapshot", headers=admin_headers
            ) as response:
                active_metrics = await response.json()
                checks["metrics_include_lightweight_active_and_audit_state"] = (
                    response.status == 200
                    and active_metrics["active_backend_requests"] == 1
                    and active_metrics["audit_epoch"] == 0
                    and active_metrics["audit_count"] == 2
                )
            release_held_chat.set()
            checks["held_chat_completed"] = await asyncio.wait_for(held_task, timeout=2) == 200

            async with client.post(f"{base}/admin/cache/reset", headers=admin_headers) as response:
                reset = await response.json()
                checks["cache_reset_over_uds"] = (
                    response.status == 200
                    and reset == {"reset": True}
                    and observed["reset_count"] == 1
                )

            async with client.get(f"{base}/admin/audit/snapshot", headers=admin_headers) as response:
                audit = await response.json()
                records = audit["records"]
                checks["audit_preserved"] = (
                    response.status == 200
                    and audit["count"] == 3
                    and {record["method"] for record in records} == {"GET", "POST"}
                    and any(record.get("prompt_tokens") == 7 for record in records)
                )

            stale_epoch_headers = signed_headers("stale-epoch-request", payload_body)
            async with client.post(
                f"{base}/admin/measurement/reset", headers=admin_headers
            ) as response:
                measurement_reset = await response.json()
                checks["measurement_reset_is_atomic_and_advances_epoch"] = (
                    response.status == 200
                    and measurement_reset == {
                        "reset": True,
                        "audit_epoch": 1,
                        "kv_cache_usage": 0.0,
                    }
                    and observed["reset_count"] == 2
                )
            async with client.post(
                f"{base}/v1/chat/completions",
                data=payload_body,
                headers=stale_epoch_headers,
            ) as response:
                await response.read()
                checks["prior_epoch_signature_is_rejected_before_upstream"] = (
                    response.status == 404 and observed["chat_count"] == 2
                )

            held_chat_entered.clear()
            release_held_chat.clear()

            async def cutoff_held_request() -> str:
                try:
                    async with client.post(
                        f"{base}/v1/chat/completions",
                        data=held_body,
                        headers=signed_headers(
                            "request-cutoff-held-chat", held_body, audit_epoch=1
                        ),
                    ) as response:
                        await response.read()
                        return f"status:{response.status}"
                except Exception as exc:
                    return type(exc).__name__

            cutoff_task = asyncio.create_task(cutoff_held_request())
            await asyncio.wait_for(held_chat_entered.wait(), timeout=2)
            async with client.post(
                f"{base}/admin/measurement/cutoff",
                headers=admin_headers,
                json={"audit_epoch": 1},
            ) as response:
                cutoff = await response.json()
                checks["measurement_cutoff_atomically_seals_and_cancels"] = (
                    response.status == 200
                    and cutoff["sealed"] is True
                    and cutoff["audit_epoch"] == 1
                    and cutoff["cancelled_requests"] == 1
                    and cutoff["metrics"]["audit_epoch"] == 1
                    and cutoff["metrics"]["active_backend_requests"] == 0
                )
            release_held_chat.set()
            await asyncio.wait_for(cutoff_task, timeout=2)
            async with client.post(
                f"{base}/v1/chat/completions",
                data=payload_body,
                headers=signed_headers("request-after-cutoff", payload_body, audit_epoch=1),
            ) as response:
                await response.read()
                checks["sealed_epoch_rejects_delayed_admission"] = (
                    response.status == 404 and observed["chat_count"] == 3
                )

            async with client.post(
                f"{base}/admin/audit/reset", headers=admin_headers
            ) as response:
                reset_audit = await response.json()
                checks["audit_reset_advances_epoch"] = (
                    response.status == 200 and reset_audit == {"audit_epoch": 2}
                )
            async with client.get(
                f"{base}/admin/metrics/snapshot", headers=admin_headers
            ) as response:
                reset_metrics = await response.json()
                checks["lightweight_audit_count_resets_under_epoch_lock"] = (
                    response.status == 200
                    and reset_metrics["active_backend_requests"] == 0
                    and reset_metrics["audit_epoch"] == 2
                    and reset_metrics["audit_count"] == 0
                    and reset_metrics["admitted_request_count"] == 0
                )

        forwarded_headers = [
            observed.get("models_headers", {}),
            observed.get("chat_headers", {}),
        ]
        checks["private_headers_not_forwarded"] = all(
            not any(name in headers for name in server.PRIVATE_FORWARD_HEADERS)
            for headers in forwarded_headers
        )
        checks["request_body_preserved"] = observed.get("chat_bodies") == [
            payload,
            held_payload,
            held_payload,
        ]
    finally:
        release_held_chat.set()
        await proxy_runner.cleanup()
        await upstream_runner.cleanup()
    return checks


async def main() -> int:
    previous_socket = os.environ.pop("UPSTREAM_UNIX_SOCKET", None)
    missing_socket_rejected = rejected(None)
    if previous_socket is not None:
        os.environ["UPSTREAM_UNIX_SOCKET"] = previous_socket
    shape_checks = {
        "missing_socket_config_rejected": missing_socket_rejected,
        "relative_socket_config_rejected": rejected("runtime/vllm.sock"),
        "traversal_socket_config_rejected": rejected("/run/backend/../vllm.sock"),
        "absolute_socket_config_accepted": (
            configured_socket_path("/run/kvbench-vllm/vllm.sock")
            == Path("/run/kvbench-vllm/vllm.sock")
        ),
    }
    with tempfile.TemporaryDirectory(prefix="model-api-uds-") as raw_root:
        root = Path(raw_root)
        regular_file = root / "not-a-socket"
        regular_file.touch()
        try:
            require_live_socket(regular_file)
        except UpstreamConfigurationError:
            shape_checks["regular_file_rejected"] = True
        else:
            shape_checks["regular_file_rejected"] = False
        checks = shape_checks | await exercise_proxy(root)

    report = {
        "schema_version": 1,
        "kind": "model-api-uds-integration",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    import asyncio

    raise SystemExit(asyncio.run(main()))
