#!/usr/bin/env python3
"""CPU-only checks for live KV pressure sampling and validity gates."""

from __future__ import annotations

import json
import sys
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.metrics import (  # noqa: E402
    assess_pressure,
    metric_point,
    summarize_metric_delta,
    summarize_metric_series,
)


def snapshot(
    created: float,
    kv: float,
    running: float,
    waiting: float,
    capacity: int | None = 1600,
) -> dict:
    samples = [
        {"name": "vllm:kv_cache_usage_perc", "labels": 'engine="0"', "value": kv},
        {"name": "vllm:num_requests_running", "labels": 'engine="0"', "value": running},
        {"name": "vllm:num_requests_waiting", "labels": 'engine="0"', "value": waiting},
    ]
    if capacity is not None:
        assert capacity % 16 == 0
        samples.append(
            {
                "name": "vllm:cache_config_info",
                "labels": (
                    f'block_size="16",engine="0",kv_cache_size_tokens="{capacity}",'
                    f'num_gpu_blocks="{capacity // 16}"'
                ),
                "value": 1,
            }
        )
    return {
        "created_unix": created,
        "raw_sha256": f"raw-{created}",
        "samples": samples,
    }


def main() -> int:
    cases: list[dict] = []

    point = metric_point(snapshot(1.0, 0.91, 72, 18))
    cases.append(
        {
            "name": "current_metric_names_are_extracted",
            "passed": point
            == {
                "created_unix": 1.0,
                "kv_cache_usage": 0.91,
                "requests_running": 72.0,
                "requests_waiting": 18.0,
                "kv_token_capacity": 1600.0,
            },
            "observed": point,
        }
    )

    hybrid_point = metric_point(
        {
            "created_unix": 1.5,
            "samples": [
                {
                    "name": "vllm:cache_config_info",
                    "labels": (
                        'block_size="1568",engine="0",kv_cache_size_tokens="1887738",'
                        'num_gpu_blocks="2318"'
                    ),
                    "value": 1,
                }
            ],
        }
    )
    cases.append(
        {
            "name": "hybrid_alignment_block_size_does_not_overstate_capacity",
            "passed": hybrid_point["kv_token_capacity"] == 1887738.0,
            "observed": hybrid_point,
        }
    )

    legacy = metric_point(
        {
            "created_unix": 2.0,
            "samples": [
                {"name": "vllm_gpu_cache_usage_perc", "labels": "", "value": 0.87},
                {"name": "vllm_requests_running", "labels": "", "value": 12},
                {"name": "vllm_requests_waiting", "labels": "", "value": 3},
            ],
        }
    )
    cases.append(
        {
            "name": "legacy_metric_names_are_extracted",
            "passed": legacy["kv_cache_usage"] == 0.87
            and legacy["requests_running"] == 12
            and legacy["requests_waiting"] == 3,
            "observed": legacy,
        }
    )

    points = [metric_point(snapshot(float(index), kv, 72, index % 4)) for index, kv in enumerate(
        (0.40, 0.72, 0.81, 0.84, 0.87, 0.89, 0.91, 0.92, 0.93, 0.94)
    )]
    series = summarize_metric_series(
        points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    occupancy_only = assess_pressure(
        series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    cases.append(
        {
            "name": "sustained_occupancy_alone_fails_closed",
            "passed": occupancy_only["valid"] is False
            and "missing_active_working_set_or_contention_evidence"
            in occupancy_only["reasons"],
            "observed": {"series": series, "assessment": occupancy_only},
        }
    )

    active_points = [
        metric_point(snapshot(float(index), 0.92, 1, 0, capacity=1600))
        for index in range(10)
    ]
    active_intervals = [
        {
            "started_unix": -1.0,
            "ended_unix": 10.0,
            "prompt_tokens": 1400,
            "total_tokens": 1500,
        }
    ]
    active_series = summarize_metric_series(
        active_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
        request_intervals=active_intervals,
    )
    active_assessment = assess_pressure(
        active_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    cases.append(
        {
            "name": "audited_active_prompt_working_set_qualifies",
            "passed": active_assessment["valid"] is True
            and active_series["kv_token_capacity"] == 1600
            and active_series["kv_token_capacity_unit"] == "logical_tokens"
            and active_series["offered_prompt_tokens_to_capacity_p95"] == 0.875
            and active_assessment["contention_evidence"]["qualification_paths"]
            == ["audited_active_working_set"],
            "observed": {"series": active_series, "assessment": active_assessment},
        }
    )

    # Eviction can make physical occupancy fall even though the concurrently
    # live prompt set is larger than logical capacity.  Synchronized scheduler
    # waiting makes that sustained audited oversubscription a conservative,
    # occupancy-independent pressure qualification path.
    thrash_points = [
        metric_point(snapshot(float(index), 0.45, 2, 1, capacity=1600))
        for index in range(10)
    ]
    thrash_intervals = [
        {
            "started_unix": -1.0,
            "ended_unix": 10.0,
            "prompt_tokens": 2000,
            "total_tokens": 2100,
        }
    ]
    thrash_series = summarize_metric_series(
        thrash_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
        request_intervals=thrash_intervals,
    )
    thrash_assessment = assess_pressure(
        thrash_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    thrash_evidence = thrash_assessment["contention_evidence"][
        "oversubscribed_working_set"
    ]
    cases.append(
        {
            "name": "eviction_safe_oversubscription_with_waiting_qualifies",
            "passed": thrash_assessment["valid"] is True
            and thrash_series["kv_cache_usage_p95"] == 0.45
            and thrash_series["fraction_at_or_above_pressure_threshold"] == 0.0
            and thrash_series["oversubscribed_working_set_sample_count"] == 10
            and thrash_series[
                "fraction_backend_active_time_with_oversubscribed_working_set_waiting"
            ]
            == 1.0
            and thrash_assessment["occupancy_evidence"]["qualification"]
            == "audited_oversubscription_with_contention"
            and thrash_assessment["contention_evidence"]["qualification_paths"]
            == ["audited_oversubscribed_working_set"]
            and thrash_evidence["corroboration_paths"]
            == ["synchronized_waiting"],
            "observed": {"series": thrash_series, "assessment": thrash_assessment},
        }
    )

    oversubscribed_without_contention_series = summarize_metric_series(
        [
            metric_point(snapshot(float(index), 0.45, 2, 0, capacity=1600))
            for index in range(10)
        ],
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
        request_intervals=thrash_intervals,
    )
    oversubscribed_without_contention = assess_pressure(
        oversubscribed_without_contention_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    cases.append(
        {
            "name": "oversubscription_without_corroboration_fails_closed",
            "passed": oversubscribed_without_contention["valid"] is False
            and oversubscribed_without_contention["contention_evidence"][
                "oversubscribed_working_set"
            ]["valid"]
            is False
            and "missing_synchronized_waiting_or_leg_local_cache_churn"
            in oversubscribed_without_contention["contention_evidence"][
                "oversubscribed_working_set"
            ]["reasons"],
            "observed": oversubscribed_without_contention,
        }
    )

    cache_churn_assessment = assess_pressure(
        oversubscribed_without_contention_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
        counter_diagnostics={
            "prefix_cache_hits": 1000,
            "prefix_cache_queries": 5000,
            "generation_tokens": 0,
        },
    )
    cache_churn_evidence = cache_churn_assessment["contention_evidence"][
        "oversubscribed_working_set"
    ]
    cases.append(
        {
            "name": "sustained_oversubscription_with_leg_local_churn_qualifies",
            "passed": cache_churn_assessment["valid"] is True
            and cache_churn_evidence["corroboration_paths"]
            == ["leg_local_cache_churn"]
            and cache_churn_evidence["leg_local_cache_churn"]["valid"] is True
            and cache_churn_evidence["leg_local_cache_churn"][
                "cache_miss_prompt_tokens_delta"
            ]
            == 4000
            and cache_churn_evidence["leg_local_cache_churn"][
                "minimum_estimated_kv_write_tokens"
            ]
            == 3200,
            "observed": cache_churn_assessment,
        }
    )

    cold_start_assessment = assess_pressure(
        oversubscribed_without_contention_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
        counter_diagnostics={
            "prefix_cache_hits": 0,
            "prefix_cache_queries": 5000,
            "generation_tokens": 0,
        },
    )
    cases.append(
        {
            "name": "cold_start_misses_do_not_corroborate_oversubscription",
            "passed": cold_start_assessment["valid"] is False
            and "no_leg_local_cache_reuse_observed"
            in cold_start_assessment["contention_evidence"][
                "oversubscribed_working_set"
            ]["leg_local_cache_churn"]["reasons"],
            "observed": cold_start_assessment,
        }
    )

    low_volume_miss_assessment = assess_pressure(
        oversubscribed_without_contention_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
        counter_diagnostics={
            "prefix_cache_hits": 1,
            "prefix_cache_queries": 100,
            "generation_tokens": 0,
        },
    )
    cases.append(
        {
            "name": "unrelated_low_hit_ratio_does_not_qualify",
            "passed": low_volume_miss_assessment["valid"] is False
            and any(
                str(reason).startswith(
                    "leg_local_cache_miss_tokens_below_floor:"
                )
                for reason in low_volume_miss_assessment["contention_evidence"][
                    "oversubscribed_working_set"
                ]["leg_local_cache_churn"]["reasons"]
            ),
            "observed": low_volume_miss_assessment,
        }
    )

    missing_capacity_series = summarize_metric_series(
        [
            metric_point(snapshot(float(index), 0.92, 1, 0, capacity=None))
            for index in range(10)
        ],
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
        request_intervals=active_intervals,
    )
    missing_capacity_assessment = assess_pressure(
        missing_capacity_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    cases.append(
        {
            "name": "missing_capacity_labels_fail_active_demand_closed",
            "passed": missing_capacity_assessment["valid"] is False
            and "missing_or_ambiguous_kv_token_capacity"
            in missing_capacity_assessment["contention_evidence"][
                "active_working_set"
            ]["reasons"],
            "observed": missing_capacity_assessment,
        }
    )

    waiting_points = [
        metric_point(snapshot(float(index), 0.92, 1, 1 if index < 8 else 0))
        for index in range(10)
    ]
    waiting_series = summarize_metric_series(
        waiting_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    waiting_assessment = assess_pressure(
        waiting_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    cases.append(
        {
            "name": "waiting_synchronized_with_high_kv_is_diagnostic_only",
            "passed": waiting_assessment["valid"] is False
            and waiting_series["pressurized_waiting_duration_sec"] == 8.0
            and waiting_assessment["contention_evidence"]["waiting_at_high_kv"][
                "valid"
            ]
            is True
            and waiting_assessment["contention_evidence"]["qualification_paths"] == [],
            "observed": {"series": waiting_series, "assessment": waiting_assessment},
        }
    )

    disjoint_points = [
        *[
            metric_point(snapshot(float(index), 0.95, 1, 0))
            for index in range(5)
        ],
        *[
            metric_point(snapshot(float(index), 0.20, 1, 1))
            for index in range(5, 10)
        ],
    ]
    disjoint_series = summarize_metric_series(
        disjoint_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    disjoint_assessment = assess_pressure(
        disjoint_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.8,
        minimum_time_fraction=0.4,
    )
    cases.append(
        {
            "name": "disjoint_high_kv_and_waiting_do_not_qualify",
            "passed": disjoint_series["kv_cache_usage_max"] == 0.95
            and disjoint_series["requests_waiting_max"] == 1
            and disjoint_series["pressurized_waiting_duration_sec"] == 0.0
            and disjoint_assessment["valid"] is False,
            "observed": {"series": disjoint_series, "assessment": disjoint_assessment},
        }
    )

    preemption_assessment = assess_pressure(
        series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
        counter_diagnostics={"preemptions": 1.0},
    )
    cases.append(
        {
            "name": "per_leg_preemption_delta_is_strong_contention_evidence",
            "passed": preemption_assessment["valid"] is True
            and "vllm_preemption"
            in preemption_assessment["contention_evidence"]["qualification_paths"]
            and preemption_assessment["contention_evidence"]["preemption"][
                "preemptions_delta"
            ]
            == 1.0,
            "observed": preemption_assessment,
        }
    )

    weak_series = summarize_metric_series(
        points[:4],
        pressure_threshold=0.9,
        expected_sample_interval_sec=1.0,
    )
    invalid = assess_pressure(
        weak_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.5,
    )
    cases.append(
        {
            "name": "weak_profile_fails_closed",
            "passed": invalid["valid"] is False
            and invalid["status"] == "profile_not_pressurized"
            and len(invalid["reasons"]) >= 2,
            "observed": {"series": weak_series, "assessment": invalid},
        }
    )

    irregular_points = [
        metric_point(snapshot(0.0, 0.95, 1, 0)),
        metric_point(snapshot(1.0, 0.10, 1, 0)),
        metric_point(snapshot(2.5, 0.10, 1, 0)),
    ]
    irregular = summarize_metric_series(
        irregular_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    cases.append(
        {
            "name": "pressure_fraction_is_wall_clock_weighted",
            "passed": irregular["sample_fraction_at_or_above_pressure_threshold"] == 1 / 3
            and irregular["observed_metric_duration_sec"] == 2.5
            and irregular["pressurized_duration_sec"] == 1.0
            and irregular["fraction_at_or_above_pressure_threshold"] == 0.4,
            "observed": irregular,
        }
    )

    gap_points = [
        metric_point(snapshot(0.0, 0.95, 1, 0)),
        metric_point(snapshot(1.0, 0.95, 1, 0)),
        metric_point(snapshot(10.0, 0.10, 1, 0)),
        metric_point(snapshot(11.0, 0.10, 1, 0)),
    ]
    gap_series = summarize_metric_series(
        gap_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    gap_assessment = assess_pressure(
        gap_series,
        required=True,
        minimum_samples=4,
        minimum_kv_p95=0.8,
        minimum_time_fraction=0.8,
    )
    cases.append(
        {
            "name": "long_sampling_gap_is_excluded_and_fails_closed",
            "passed": gap_series["sampling_gap_limit_sec"] == 3.0
            and gap_series["sample_interval_sec_max"] == 9.0
            and gap_series["sampling_gap_count"] == 1
            and gap_series["sampling_gap_max_sec"] == 9.0
            and gap_series["sampling_gap_total_sec"] == 9.0
            and gap_series["sampler_span_sec"] == 11.0
            and gap_series["sampler_duration_sec"] == 2.0
            and gap_series["pressurized_duration_sec"] == 1.0
            and gap_series["fraction_at_or_above_pressure_threshold"] == 0.5
            and gap_assessment["valid"] is False
            and "metrics_sampling_gap" in gap_assessment["reasons"],
            "observed": {"series": gap_series, "assessment": gap_assessment},
        }
    )

    sampler_error_series = summarize_metric_series(
        points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
        sampler_errors=("TimeoutError: metrics read exceeded 30s I/O timeout",),
    )
    sampler_error_assessment = assess_pressure(
        sampler_error_series,
        required=True,
        minimum_samples=10,
        minimum_kv_p95=0.9,
        minimum_time_fraction=0.7,
    )
    cases.append(
        {
            "name": "sampler_error_invalidates_otherwise_pressurized_series",
            "passed": sampler_error_assessment["valid"] is False
            and sampler_error_series["sampler_error_count"] == 1
            and "metrics_sampler_error" in sampler_error_assessment["reasons"],
            "observed": {
                "series": sampler_error_series,
                "assessment": sampler_error_assessment,
            },
        }
    )

    bad_timestamp_points = [
        metric_point(snapshot(0.0, 0.95, 1, 0)),
        {
            "created_unix": None,
            "kv_cache_usage": 0.95,
            "requests_running": 1.0,
            "requests_waiting": 0.0,
        },
        metric_point(snapshot(2.0, 0.10, 1, 0)),
        metric_point(snapshot(3.0, 0.10, 1, 0)),
    ]
    bad_timestamp_series = summarize_metric_series(
        bad_timestamp_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    bad_timestamp_assessment = assess_pressure(
        bad_timestamp_series,
        required=True,
        minimum_samples=4,
        minimum_kv_p95=0.8,
        minimum_time_fraction=0.0,
    )
    cases.append(
        {
            "name": "missing_timestamp_is_not_bridged_and_fails_closed",
            "passed": bad_timestamp_series["sampling_timestamp_error_count"] == 1
            and bad_timestamp_series["sampler_duration_sec"] == 1.0
            and bad_timestamp_series["pressurized_duration_sec"] == 0.0
            and bad_timestamp_assessment["valid"] is False
            and "metrics_sampling_timestamp_error"
            in bad_timestamp_assessment["reasons"],
            "observed": {
                "series": bad_timestamp_series,
                "assessment": bad_timestamp_assessment,
            },
        }
    )

    # Prefix-cache residency while every workflow is in a shell/final-test
    # phase is not scheduler pressure.  The active series must ignore that
    # idle retained-cache plateau while preserving it as a diagnostic.
    retained_idle_points = [
        metric_point(snapshot(0.0, 0.20, 8, 0)),
        metric_point(snapshot(1.0, 0.95, 0, 0)),
        metric_point(snapshot(2.0, 0.96, 0, 0)),
        metric_point(snapshot(3.0, 0.25, 8, 0)),
        metric_point(snapshot(4.0, 0.25, 8, 0)),
    ]
    retained_idle = summarize_metric_series(
        retained_idle_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
    )
    retained_idle_assessment = assess_pressure(
        retained_idle,
        required=True,
        minimum_samples=2,
        minimum_kv_p95=0.8,
        minimum_time_fraction=0.1,
    )
    cases.append(
        {
            "name": "idle_retained_prefix_cache_is_not_pressure",
            "passed": retained_idle["retained_kv_cache_usage_max"] == 0.96
            and retained_idle["kv_cache_usage_max"] == 0.25
            and retained_idle["backend_active_duration_sec"] == 2.0
            and retained_idle["sampler_duration_sec"] == 4.0
            and retained_idle["backend_active_time_fraction"] == 0.5
            and retained_idle_assessment["valid"] is False,
            "observed": {
                "series": retained_idle,
                "assessment": retained_idle_assessment,
            },
        }
    )

    demand_points = [
        metric_point(snapshot(10.0, 0.50, 2, 0)),
        metric_point(snapshot(11.0, 0.60, 2, 0)),
        metric_point(snapshot(12.0, 0.70, 1, 0)),
    ]
    demand_intervals = [
        {
            "started_unix": 9.5,
            "ended_unix": 11.5,
            "prompt_tokens": 100,
            "total_tokens": 125,
        },
        {
            "started_unix": 10.5,
            "ended_unix": 12.5,
            "prompt_tokens": 300,
            "total_tokens": 350,
        },
    ]
    demand = summarize_metric_series(
        demand_points,
        pressure_threshold=0.8,
        expected_sample_interval_sec=1.0,
        request_intervals=demand_intervals,
    )
    cases.append(
        {
            "name": "offered_token_demand_uses_audited_request_intervals",
            "passed": demand["offered_token_demand_sample_count"] == 3
            and demand["offered_token_demand_incomplete_sample_count"] == 0
            and demand["offered_request_count_max"] == 2
            and demand["offered_prompt_tokens_p50"] == 300
            and demand["offered_prompt_tokens_p95"] == 390
            and demand["offered_prompt_tokens_max"] == 400
            and demand["offered_total_tokens_max"] == 475,
            "observed": demand,
        }
    )

    before = {
        "raw_sha256": "before",
        "samples": [
            {"name": "vllm:prefix_cache_hits_total", "labels": "", "value": 100},
            {"name": "vllm:prefix_cache_queries_total", "labels": "", "value": 200},
            {"name": "vllm:num_preemptions_total", "labels": "", "value": 2},
        ],
    }
    after = {
        "raw_sha256": "after",
        "samples": [
            {"name": "vllm:prefix_cache_hits_total", "labels": "", "value": 160},
            {"name": "vllm:prefix_cache_queries_total", "labels": "", "value": 300},
            {"name": "vllm:num_preemptions_total", "labels": "", "value": 5},
        ],
    }
    delta = summarize_metric_delta(before, after)
    cases.append(
        {
            "name": "counter_diagnostics_are_derived",
            "passed": delta["derived"]["prefix_cache_hit_ratio"] == 0.6
            and delta["derived"]["preemptions"] == 3,
            "observed": delta["derived"],
        }
    )

    token_after = {
        "raw_sha256": "token-after",
        "samples": [
            {"name": "vllm:prefix_cache_hits_total", "labels": "", "value": 160},
            {"name": "vllm:prefix_cache_queries_total", "labels": "", "value": 300},
            {"name": "vllm:prompt_tokens_total", "labels": "", "value": 1300},
            {"name": "vllm:generation_tokens_total", "labels": "", "value": 540},
        ],
    }
    token_before = {
        "raw_sha256": "token-before",
        "samples": [
            {"name": "vllm:prefix_cache_hits_total", "labels": "", "value": 100},
            {"name": "vllm:prefix_cache_queries_total", "labels": "", "value": 200},
            {"name": "vllm:prompt_tokens_total", "labels": "", "value": 1000},
            {"name": "vllm:generation_tokens_total", "labels": "", "value": 500},
        ],
    }
    token_delta = summarize_metric_delta(token_before, token_after)["derived"]
    cases.append(
        {
            "name": "kv_write_demand_is_reported",
            "passed": token_delta["computed_prompt_tokens"] == 40
            and token_delta["estimated_kv_write_tokens"] == 80
            and token_delta["prompt_tokens"] == 300
            and token_delta["generation_tokens"] == 40,
            "observed": token_delta,
        }
    )

    report = {
        "schema_version": 1,
        "kind": "pressure-metrics-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
