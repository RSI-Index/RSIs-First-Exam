#!/usr/bin/env python3
"""Fail-closed tests for the Qwen3.6-only release evidence allowlist."""

from __future__ import annotations

import importlib.util
import hashlib
import json
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = TASK_ROOT / "scripts" / "freeze-release-manifest.py"
SPEC = importlib.util.spec_from_file_location("freeze_release_manifest", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

PROFILE_SHA = MODULE.QWEN_PROFILE_SHA256
RELEASE_ID = "qwen36-test-release"
POLICY_CONTRACT_SHA = "4" * 64
CORPUS_SHA = "5" * 64
CALIBRATION_PROFILES_SHA = "6" * 64
CONTROLLER_CONFIG_SHA = "7" * 64
CONTROLLER_IMAGE_ID = "sha256:" + "2" * 64
REFERENCE_SUBMISSION_SHA = MODULE.reference_submission_sha256()
REFERENCE_SPEEDUPS = {"hidden-pressure-192": 1.2}
MAX_P99_STEP_LATENCY_RATIO = 1.25
SCORING_POLICY_SHA = "e" * 64
PUBLIC_DIRECT_ANCHOR_SHA = "f" * 64
PUBLIC_PAIR_SHA = "9" * 64
HIDDEN_WORKLOAD_NONCE_SHA = "b" * 64
RUNTIME_READY_UNIX = 1_721_000_000.25
RUNTIME_WRAPPER_PID = 12345
RUNTIME_WRAPPER_START_TICKS = 987654321
RUNTIME_CONTAINER_ID = "8" * 64
RUNTIME_LAUNCH_TOKEN_SHA256 = "9" * 64
RUNTIME_BOOT_IDENTITY_SHA256 = MODULE.runtime_boot_identity_sha256(
    {
        "schema_version": 1,
        "state": "ready",
        "ready_unix": RUNTIME_READY_UNIX,
        "process": {
            "wrapper_pid": RUNTIME_WRAPPER_PID,
            "wrapper_start_ticks": RUNTIME_WRAPPER_START_TICKS,
        },
        "container": {
            "id": RUNTIME_CONTAINER_ID,
            "launch_token_sha256": RUNTIME_LAUNCH_TOKEN_SHA256,
        },
    }
)
QUALITY_GATES = {
    "minimum_valid_step_ratio": 0.9,
    "minimum_workflow_progress": 1,
}
MODEL_ADAPTER = {
    "mode": "qwen36-text-bash-v1",
    "instruction_role": "system",
    "instruction_sha256": "75434201e849f434256fd3ad6cc5c936b4ac41dec988c3546e8532fc6fa73098",
    "instance_template_sha256": "dbafa361c3aa0c54e7d476773a8ae97bf585b728f1cd591a5da97f65b390a778",
    "format_error_sha256": "3a4c765859508b9f499353bb713f6c37b3bee170102e0872e9f206b37e82c7ae",
    "prompt_contract": "thunderagent-a989f24-mini-swe-agent-swebench-yaml-v1",
    "task_input": "raw-problem-statement",
    "offline_constraint": "sandbox-enforced-not-prompt-modified",
    "temperature": 0.0,
    "top_p": 1.0,
    "max_tokens_policy": "profile_cap",
    "response_protocol": "single-bash-fence",
    "function_tools": False,
    "reasoning_override": "qwen-chat-template-thinking-disabled",
    "chat_template_kwargs": {"enable_thinking": False},
}
MODEL_PROVENANCE = {
    "profile_id": MODULE.QWEN_PROFILE_ID,
    "profile_sha256": PROFILE_SHA,
    "model_revision": MODULE.QWEN_REVISION,
    "runtime_image_id": "sha256:" + "a" * 64,
    "tensor_parallel_size": 2,
    "kv_cache_dtype": "fp8",
    "runtime_boot_identity_sha256": RUNTIME_BOOT_IDENTITY_SHA256,
}
MODEL_REQUIRED_FILES = {
    "config.json": "c" * 64,
    "model.safetensors.index.json": "d" * 64,
}
CALIBRATION_PROFILE = MODULE.canonical_profile_config(
    "qwen36-pressure-192-deep24",
    {
        "enabled": True,
        "workflows": 192,
        "concurrency": 192,
        "max_steps": 24,
        "context_bytes": 0,
        "max_tokens": 2048,
        "workflow_timeout_sec": 3600,
        "request_timeout_sec": 2700,
        "tool_delay_min_sec": 0.0,
        "tool_delay_max_sec": 0.0,
        "seed": 436924,
        "warmup_requests": 4,
        "warmup_context_bytes": 0,
        "warmup_steps": 3,
        "workload_family": "swebench-lite",
        "corpus_partition": "public",
        "corpus_unique_instances_min": 6,
        "pressure_required": True,
        "pressure_kv_threshold": 0.8,
        "pressure_kv_p95_min": 0.9,
        "pressure_time_fraction_min": 0.25,
        "pressure_min_samples": 60,
        "backend_stall_timeout_sec": 180,
        "candidate_admission_stall_timeout_sec": 300,
    },
)


def finite_timing(*, include_samples: bool) -> dict:
    payload = {
        "started_unix": 100.0,
        "ended_unix": 160.0,
        "elapsed_sec": 60.0,
        "wall_elapsed_sec": 65.0,
        "valid_steps": 100,
        "valid_steps_per_min": 100.0,
        "p95_step_latency_sec": 90.0,
        "p99_step_latency_sec": 100.0,
        "measurement_window": {
            "configured": False,
            "deadline_reached": False,
            "termination": "finite_workload",
        },
        "agent_execution_interval": {
            "schema_version": 1,
            "start_event": "measured_leg_started",
            "end_event": "last_agent_run_termination",
            "duration_clock": "monotonic",
            "started_unix": 100.0,
            "ended_unix": 160.0,
            "elapsed_sec": 60.0,
            "expected_agent_runs": 192,
            "observed_agent_runs": 192,
            "complete": True,
        },
    }
    if include_samples:
        payload["vllm_metrics"] = {
            "live_series": {"sampler_error_count": 0},
            "live_samples": [{"created_unix": 160.0}],
        }
    return payload


def oversubscribed_pressure_validation() -> dict:
    return {
        "qualification_schema_version": 1,
        "required": True,
        "valid": True,
        "contention_evidence": {
            "required": True,
            "valid": True,
            "qualification_paths": ["audited_oversubscribed_working_set"],
            "active_working_set": {"valid": False},
            "oversubscribed_working_set": {
                "valid": True,
                "occupancy_independent": True,
                "demand_ratio_threshold": 1.0,
                "corroboration_paths": [
                    "synchronized_waiting",
                    "leg_local_cache_churn",
                ],
                "synchronized_waiting": {"valid": True},
                "leg_local_cache_churn": {"valid": True},
            },
            "preemption": {"valid": False, "preemptions_delta": 0.0},
        },
        "reasons": [],
    }


OVERSUBSCRIBED_MUTATIONS = {
    "invalid": lambda evidence: evidence.__setitem__("valid", False),
    "occupancy-dependent": lambda evidence: evidence.__setitem__(
        "occupancy_independent", False
    ),
    "wrong-threshold": lambda evidence: evidence.__setitem__(
        "demand_ratio_threshold", 0.99
    ),
    "boolean-threshold": lambda evidence: evidence.__setitem__(
        "demand_ratio_threshold", True
    ),
    "empty-corroboration": lambda evidence: evidence.__setitem__(
        "corroboration_paths", []
    ),
    "unknown-corroboration": lambda evidence: evidence.__setitem__(
        "corroboration_paths", ["scheduler_waiting_at_high_kv"]
    ),
    "invalid-synchronized-waiting": lambda evidence: evidence[
        "synchronized_waiting"
    ].__setitem__("valid", False),
    "invalid-cache-churn": lambda evidence: evidence[
        "leg_local_cache_churn"
    ].__setitem__("valid", False),
}


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value) + "\n")


def valid_sweep() -> dict:
    return {
        "schema_version": 1,
        "kind": "real-swe-baseline-calibration-sweep",
        "release_id": RELEASE_ID,
        "model_profile_sha256": PROFILE_SHA,
        "status": "complete",
        "errors": [],
        "controller_image_id": CONTROLLER_IMAGE_ID,
        "controller_readiness": {
            "release_id": RELEASE_ID,
            "controller_config_sha256": CONTROLLER_CONFIG_SHA,
            "policy_contract_sha256": POLICY_CONTRACT_SHA,
            "corpus_manifest_sha256": CORPUS_SHA,
            "model_adapter": MODEL_ADAPTER,
        },
        "calibration_profiles_sha256": CALIBRATION_PROFILES_SHA,
        "scoring_policy_contract_sha256": POLICY_CONTRACT_SHA,
        "corpus_manifest_sha256": CORPUS_SHA,
        "quality_gates": QUALITY_GATES,
        "profile_selection": {
            "mode": "release_qualification_allowlist",
            "profiles": ["qwen36-pressure-192-deep24"],
        },
        "profile_order": ["qwen36-pressure-192-deep24"],
        "runs": {
            "qwen36-pressure-192-deep24": {
                **finite_timing(include_samples=True),
                "run_id": "baseline-qwen36-pressure-192-deep24-test",
                "profile": "qwen36-pressure-192-deep24",
                "mode": "baseline",
                "profile_config": CALIBRATION_PROFILE,
                "release_id": RELEASE_ID,
                "controller_config_sha256": CONTROLLER_CONFIG_SHA,
                "model_provenance": MODEL_PROVENANCE,
                "model_adapter": {
                    **MODEL_ADAPTER,
                    "effective_max_tokens": 2048,
                },
                "infrastructure_failure": None,
                "backend_audit": {"passed": True},
                "warmup_audit": {"passed": True},
                "pressure_validation": {
                    "qualification_schema_version": 1,
                    "required": True,
                    "valid": True,
                    "contention_evidence": {
                        "required": True,
                        "valid": True,
                        "qualification_paths": ["audited_active_working_set"],
                        "active_working_set": {"valid": True},
                        "preemption": {"valid": False, "preemptions_delta": 0.0},
                    },
                    "reasons": [],
                },
                "request_success_rate": 1.0,
                "valid_step_ratio": 1.0,
                "jain_progress_fairness": 1.0,
                "minimum_workflow_progress": 1,
                "workload_nonce_sha256": "b" * 64,
            }
        },
    }


def tier_signals(value: int) -> dict[str, int]:
    return {name: value for name in MODULE.DEEP_SIGNAL_NAMES}


def tail_report() -> dict:
    return {
        "schema_version": 2,
        "metric": "p99_step_latency_sec",
        "pairing": "candidate_over_baseline:single_committed_pair",
        "baseline_p99_step_latency_sec": 100.0,
        "candidate_p99_step_latency_sec": 110.0,
        "ratio": 1.1,
        "maximum_allowed_ratio": MAX_P99_STEP_LATENCY_RATIO,
        "passed": True,
    }


def valid_full_verifier() -> dict:
    def leg(mode: str, index: int) -> dict:
        required = mode == "baseline"
        return {
            **finite_timing(include_samples=False),
            "mode": mode,
            "run_id": f"full-verifier-{index}",
            "p99_step_latency_sec": 110.0 if mode == "candidate" else 100.0,
            "profile_config": {"pressure_required": True, "workflows": 192},
            "pressure_validation": {
                "qualification_schema_version": 1,
                "required": required,
                "valid": True,
                "contention_evidence": {
                    "required": required,
                    "valid": True,
                    "qualification_paths": (
                        ["audited_active_working_set"] if required else []
                    ),
                    "active_working_set": {"valid": required},
                    "preemption": {"valid": False, "preemptions_delta": 0.0},
                },
                "reasons": [],
            },
        }

    return {
        "schema_version": 2,
        "kind": "sanitized-full-verifier-evidence",
        "release_id": RELEASE_ID,
        "model_profile_sha256": PROFILE_SHA,
        "status": "complete",
        "errors": [],
        "passed": True,
        "corpus_manifest_sha256": CORPUS_SHA,
        "run_kind": "oracle",
        "raw_private_report": {"sha256": "3" * 64, "bytes": 8192},
        "raw_public_pair": {
            "sha256": PUBLIC_PAIR_SHA,
            "bytes": 4096,
        },
        "public_direct_anchor": {
            "schema_version": 1,
            "kind": "kvbench-release-public-direct-anchor",
            "sha256": PUBLIC_DIRECT_ANCHOR_SHA,
            "bytes": 8192,
            "release_id": RELEASE_ID,
            "profile": "public-pressure-192",
            "source_report_sha256": PUBLIC_PAIR_SHA,
            "scoring_policy_sha256": SCORING_POLICY_SHA,
            "baseline_sha256": "a" * 64,
            "controller_config_sha256": CONTROLLER_CONFIG_SHA,
            "controller_image_id": CONTROLLER_IMAGE_ID,
            "corpus_fingerprint": "b" * 64,
            "model_provenance_sha256": hashlib.sha256(
                MODULE.canonical_json(MODEL_PROVENANCE).encode()
            ).hexdigest(),
        },
        "artifacts": {
            "reference_gateway_tree_sha256": "1" * 64,
            "reference_submission_sha256": REFERENCE_SUBMISSION_SHA,
            "bench_controller_image_id": CONTROLLER_IMAGE_ID,
        },
        "checks": {
            "attestation": {
                "schema_version": 1,
                "state": "ready",
                "runtime_boot_identity_sha256": RUNTIME_BOOT_IDENTITY_SHA256,
                "profile_id": MODULE.QWEN_PROFILE_ID,
                "profile_sha256": PROFILE_SHA,
                "model_revision": MODULE.QWEN_REVISION,
                "model_config_sha256": MODEL_REQUIRED_FILES["config.json"],
                "model_weight_index_sha256": MODEL_REQUIRED_FILES[
                    "model.safetensors.index.json"
                ],
                "runtime_image_id": MODEL_PROVENANCE["runtime_image_id"],
                "vllm_package_version": "0.24.0",
                "tensor_parallel_size": 2,
                "kv_cache_dtype": "fp8",
                "tool_call_parser": None,
                "reasoning_parser": "qwen3",
                "model_mount_read_only": True,
            }
        },
        "tier_qualification": {
            "schema_version": 2,
            "reference_gateway_tree_sha256": "1" * 64,
            "policy": dict(MODULE.EXPECTED_V5_TIER_POLICY),
            "public": {
                "profile": "public-pressure-192",
                "measurement_window_sec": 1800,
                "passed": True,
                "policy": dict(MODULE.EXPECTED_V5_TIER_POLICY),
                "deep_signals": tier_signals(1),
                "mixed_request_tier_ticks": 1,
                "release_id": RELEASE_ID,
                "controller_config_sha256": CONTROLLER_CONFIG_SHA,
                "model_provenance": dict(MODEL_PROVENANCE),
                "reference_gateway_tree_sha256": "1" * 64,
                "bench_controller_image_id": CONTROLLER_IMAGE_ID,
            },
            "hidden": {
                "profile": "hidden-pressure-192",
                "leg_order_protocol": "sha256-domain-separated-first-byte-lsb-v1",
                "leg_order": ["baseline", "candidate"],
                "candidate_leg_ordinal": 2,
                "candidate_process_epoch_count": 1,
                "observation": {
                    "leg_ordinal": 2,
                    "policy": dict(MODULE.EXPECTED_V5_TIER_POLICY),
                    "deep_signals": tier_signals(2),
                    "mixed_request_tier_ticks": 0,
                },
            },
        },
        "tail_anti_gaming": {
            "schema_version": 2,
            "metric": "p99_step_latency_sec",
            "pairing": "candidate_over_baseline:single_committed_pair",
            "maximum_allowed_ratio": MAX_P99_STEP_LATENCY_RATIO,
            "all_profiles_passed": True,
            "profiles": {"hidden-pressure-192": tail_report()},
        },
        "benchmark": {
            "schema_version": 2,
            "release_id": RELEASE_ID,
            "policy_contract_sha256": POLICY_CONTRACT_SHA,
            "controller_config_sha256": CONTROLLER_CONFIG_SHA,
            "corpus_manifest_sha256": CORPUS_SHA,
            "model_profile_sha256": PROFILE_SHA,
            "model_provenance": dict(MODEL_PROVENANCE),
            "candidate_lifecycle": {
                "schema_version": 1,
                "frozen_submission_sha256": REFERENCE_SUBMISSION_SHA,
                "network_egress_seal": {
                    "schema_version": 2,
                    "protocol": "same-compose-main-egress-hmac-v2",
                    "sealed": True,
                    "controller_image_id": CONTROLLER_IMAGE_ID,
                },
                "epoch_count": 2,
                "candidate_process_epoch_count": 1,
                "epochs": [
                    {"mode": "baseline", "leg_ordinal": 1},
                    {
                        "mode": "candidate",
                        "leg_ordinal": 2,
                        "gateway_process_identity_sha256": "c" * 64,
                    },
                ],
            },
            "hard_gates_passed": True,
            "status": "ok",
            "performance_score": 1.0,
            "profiles": {
                "hidden-pressure-192": {
                    "speedup": 1.25,
                    "reference_speedup": 1.2,
                    "performance_score": 1.0,
                    "leg_order_commitment": {
                        "schema_version": 1,
                        "protocol": "sha256-domain-separated-first-byte-lsb-v1",
                        "context": "kvbench-final-leg-order-v1",
                        "workload_nonce_sha256": HIDDEN_WORKLOAD_NONCE_SHA,
                        "order": ["baseline", "candidate"],
                    },
                    "tail_anti_gaming": tail_report(),
                    "legs": [
                        leg(mode, index)
                        for index, mode in enumerate(
                            ("baseline", "candidate")
                        )
                    ]
                }
            },
        },
    }


def write_index(root: Path, files: list[str], **overrides: object) -> Path:
    index = root / "qwen36-release" / "evidence-index.json"
    payload: dict[str, object] = {
        "schema_version": 1,
        "release_id": RELEASE_ID,
        "model_profile_sha256": PROFILE_SHA,
        "files": files,
    }
    payload.update(overrides)
    write_json(index, payload)
    return index


def collect(root: Path, index: Path) -> tuple[dict[str, str], str, str]:
    return MODULE.collect_release_evidence(
        root,
        index,
        root / "release-manifest.json",
        expected_release_id=RELEASE_ID,
        expected_profile_sha256=PROFILE_SHA,
        expected_reference_gateway_tree_sha256="1" * 64,
        expected_reference_submission_sha256=REFERENCE_SUBMISSION_SHA,
        expected_controller_image_id=CONTROLLER_IMAGE_ID,
        expected_scoring_policy_sha256=SCORING_POLICY_SHA,
        expected_policy_contract_sha256=POLICY_CONTRACT_SHA,
        expected_corpus_manifest_sha256=CORPUS_SHA,
        required_calibration_profiles=(),
        expected_calibration_profiles={},
        expected_calibration_profiles_sha256=CALIBRATION_PROFILES_SHA,
        expected_model_provenance=MODEL_PROVENANCE,
        expected_model_required_files=MODEL_REQUIRED_FILES,
        expected_publishable_model_identity=valid_full_verifier()["checks"][
            "attestation"
        ],
        expected_quality_gates=QUALITY_GATES,
        expected_hidden_profiles=frozenset({"hidden-pressure-192"}),
        expected_reference_speedups=REFERENCE_SPEEDUPS,
        expected_max_p99_step_latency_ratio=MAX_P99_STEP_LATENCY_RATIO,
    )


def rejects(callable_, label: str) -> None:
    try:
        callable_()
    except SystemExit:
        return
    raise AssertionError(f"expected fail-closed rejection: {label}")


# The calibration-sweep validator and full-verifier validator are separate
# release-freeze paths.  Exercise the former directly with the exact audited
# oversubscription contract before the file-collection tests below.
oversubscribed_sweep = valid_sweep()
oversubscribed_sweep_run = oversubscribed_sweep["runs"][
    "qwen36-pressure-192-deep24"
]
oversubscribed_sweep_run["pressure_validation"] = (
    oversubscribed_pressure_validation()
)
MODULE.validate_calibration_run(
    oversubscribed_sweep_run,
    profile_name="qwen36-pressure-192-deep24",
    expected_profile_config=CALIBRATION_PROFILE,
    expected_release_id=RELEASE_ID,
    expected_controller_config_sha256=CONTROLLER_CONFIG_SHA,
    expected_model_provenance=MODEL_PROVENANCE,
    expected_model_adapter=MODEL_ADAPTER,
    expected_quality_gates=QUALITY_GATES,
    evidence_name="oversubscribed-sweep-unit.json",
)
for label, mutate in OVERSUBSCRIBED_MUTATIONS.items():
    payload = json.loads(json.dumps(oversubscribed_sweep_run))
    evidence = payload["pressure_validation"]["contention_evidence"][
        "oversubscribed_working_set"
    ]
    mutate(evidence)
    rejects(
        lambda payload=payload: MODULE.validate_calibration_run(
            payload,
            profile_name="qwen36-pressure-192-deep24",
            expected_profile_config=CALIBRATION_PROFILE,
            expected_release_id=RELEASE_ID,
            expected_controller_config_sha256=CONTROLLER_CONFIG_SHA,
            expected_model_provenance=MODEL_PROVENANCE,
            expected_model_adapter=MODEL_ADAPTER,
            expected_quality_gates=QUALITY_GATES,
            evidence_name="oversubscribed-sweep-mutation.json",
        ),
        f"calibration sweep oversubscribed {label}",
    )


QUALIFICATION_PAYLOAD = {
    "release_qualification_profiles": ["second", "first"],
    "profiles": {
        "first": {"enabled": True},
        "second": {"enabled": True},
        "disabled": {"enabled": False},
    },
}
assert MODULE.release_qualification_profiles(QUALIFICATION_PAYLOAD) == (
    "second",
    "first",
)
assert MODULE.release_qualification_profiles(
    {**QUALIFICATION_PAYLOAD, "release_qualification_profiles": []}
) == ()
for label, payload in {
    "missing qualification allowlist": {"profiles": QUALIFICATION_PAYLOAD["profiles"]},
    "duplicate qualification profile": {
        **QUALIFICATION_PAYLOAD,
        "release_qualification_profiles": ["first", "first"],
    },
    "unknown qualification profile": {
        **QUALIFICATION_PAYLOAD,
        "release_qualification_profiles": ["unknown"],
    },
    "disabled qualification profile": {
        **QUALIFICATION_PAYLOAD,
        "release_qualification_profiles": ["disabled"],
    },
    "non-string qualification profile": {
        **QUALIFICATION_PAYLOAD,
        "release_qualification_profiles": [False],
    },
}.items():
    rejects(lambda payload=payload: MODULE.release_qualification_profiles(payload), label)


with tempfile.TemporaryDirectory(prefix="qwen-release-evidence-") as temporary:
    root = Path(temporary) / "calibration"
    root.mkdir()
    # These generic historical files deliberately do not rely on model names
    # for exclusion.  Only the dedicated explicit allowlist may be collected.
    write_json(root / "real-swe-baseline-sweep-20260716.json", {"model": "old"})
    write_json(root / "gpt-oss-history.json", {"model": "old"})
    write_json(root / "deepseek-history.json", {"model": "old"})
    release_dir = root / "qwen36-release"
    write_json(release_dir / "oracle.json", valid_full_verifier())
    index = write_index(root, ["oracle.json"])
    evidence, index_sha, anchor_sha = collect(root, index)
    assert list(evidence) == ["qwen36-release/oracle.json"]
    assert all("history" not in name and "20260716" not in name for name in evidence)
    assert index_sha == MODULE.digest(index)
    assert anchor_sha == PUBLIC_DIRECT_ANCHOR_SHA
    assert MODULE.RELEASE_EVIDENCE_POLICY == {
        "schema_version": 3,
        "policy_id": "single-oracle-public1800-anchor-hidden-committed-pair-v6-tier-qualified-v3",
        "minimum_sweep_series": 0,
        "minimum_frozen_candidate_reports": 0,
        "minimum_oracle_reports": 1,
        "public_pair_profile": "public-pressure-192",
        "public_measurement_window_sec": 1800,
        "public_direct_anchor_required": True,
        "hidden_leg_protocol": "nonce-committed-ab-or-ba",
        "hidden_leg_count": 2,
        "hidden_candidate_leg_count": 1,
        "candidate_epoch_reset_required": True,
        "deep_tier_required_in_hidden_candidate_leg": True,
        "deep_and_mixed_tiers_required_in_public_candidate_leg": True,
        "reference_source": "formal_public1800_anchor_and_hidden_committed_pair",
    }

    oversubscribed_oracle = valid_full_verifier()
    oversubscribed_oracle["benchmark"]["profiles"]["hidden-pressure-192"][
        "legs"
    ][0]["pressure_validation"] = oversubscribed_pressure_validation()
    write_json(release_dir / "oracle-oversubscribed.json", oversubscribed_oracle)
    oversubscribed_index = write_index(root, ["oracle-oversubscribed.json"])
    _, _, oversubscribed_anchor_sha = collect(root, oversubscribed_index)
    assert oversubscribed_anchor_sha == PUBLIC_DIRECT_ANCHOR_SHA

    ba_oracle = valid_full_verifier()
    ba_profile = ba_oracle["benchmark"]["profiles"]["hidden-pressure-192"]
    ba_profile["legs"].reverse()
    ba_profile["leg_order_commitment"] = {
        "schema_version": 1,
        "protocol": "sha256-domain-separated-first-byte-lsb-v1",
        "context": "kvbench-final-leg-order-v1",
        "workload_nonce_sha256": "8" * 64,
        "order": ["candidate", "baseline"],
    }
    ba_epochs = ba_oracle["benchmark"]["candidate_lifecycle"]["epochs"]
    ba_epochs.reverse()
    for ordinal, epoch in enumerate(ba_epochs, start=1):
        epoch["leg_ordinal"] = ordinal
    ba_hidden = ba_oracle["tier_qualification"]["hidden"]
    ba_hidden["leg_order"] = ["candidate", "baseline"]
    ba_hidden["candidate_leg_ordinal"] = 1
    ba_hidden["observation"]["leg_ordinal"] = 1
    write_json(release_dir / "oracle-ba.json", ba_oracle)
    ba_index = write_index(root, ["oracle-ba.json"])
    _ba_evidence, _ba_index_sha, ba_anchor_sha = collect(root, ba_index)
    assert ba_anchor_sha == PUBLIC_DIRECT_ANCHOR_SHA

    sweep_path = release_dir / "sweep-only.json"
    write_json(sweep_path, valid_sweep())
    sweep_index = write_index(root, ["sweep-only.json"])
    rejects(
        lambda: collect(root, sweep_index),
        "Direct sweep cannot substitute for the required Oracle pair",
    )

    candidate = valid_full_verifier()
    candidate["run_kind"] = "frozen-candidate"
    candidate["raw_private_report"]["sha256"] = "8" * 64
    write_json(release_dir / "candidate-only.json", candidate)
    candidate_index = write_index(root, ["candidate-only.json"])
    rejects(
        lambda: collect(root, candidate_index),
        "frozen candidate cannot substitute for the required Oracle pair",
    )

    legacy_abba = {
        "schema_version": 1,
        "kind": "hidden-profile-reference-abba-calibration",
        "release_id": RELEASE_ID,
        "model_profile_sha256": PROFILE_SHA,
        "status": "complete",
        "errors": [],
    }
    write_json(release_dir / "standalone-abba.json", legacy_abba)
    legacy_index = write_index(root, ["standalone-abba.json"])
    rejects(
        lambda: collect(root, legacy_index),
        "standalone exploratory ABBA is not final release evidence",
    )

    wrong_order = valid_full_verifier()
    wrong_order_legs = wrong_order["benchmark"]["profiles"]["hidden-pressure-192"][
        "legs"
    ]
    wrong_order_legs.reverse()
    write_json(release_dir / "wrong-order.json", wrong_order)
    wrong_order_index = write_index(root, ["wrong-order.json"])
    rejects(
        lambda: collect(root, wrong_order_index),
        "hidden order not matching its nonce commitment",
    )

    output = root / "new-release-manifest.json"
    MODULE.atomic_write_new(output, "{}\n")
    assert output.read_text() == "{}\n"
    rejects(lambda: MODULE.atomic_write_new(output, "changed\n"), "output overwrite")

with tempfile.TemporaryDirectory(prefix="qwen-release-evidence-invalid-") as temporary:
    root = Path(temporary) / "calibration"
    root.mkdir()
    release_dir = root / "qwen36-release"
    good = release_dir / "good.json"
    write_json(good, valid_full_verifier())

    development_index = write_index(root, ["good.json"])
    rejects(
        lambda: MODULE.collect_release_evidence(
            root,
            development_index,
            root / "release-manifest.json",
            expected_release_id="development-qwen36",
            expected_profile_sha256=PROFILE_SHA,
        ),
        "development release evidence",
    )

    for bad_name in ("../old.json", "/tmp/absolute.json", "nested/file.json"):
        index = write_index(root, [bad_name])
        rejects(lambda index=index: collect(root, index), bad_name)
    index = write_index(root, ["good.json", "good.json"])
    rejects(lambda: collect(root, index), "duplicate")
    index = write_index(root, ["missing.json"])
    rejects(lambda: collect(root, index), "missing")
    index = write_index(root, [])
    rejects(lambda: collect(root, index), "empty index")
    index = write_index(root, ["good.json"], release_id="wrong")
    rejects(lambda: collect(root, index), "release id")
    index = write_index(root, ["good.json"], schema_version=2)
    rejects(lambda: collect(root, index), "index schema")
    index = write_index(root, ["good.json"], schema_version=True)
    rejects(lambda: collect(root, index), "boolean index schema")
    index = write_index(root, ["good.json"], model_path="/home/unit/private/model")
    rejects(lambda: collect(root, index), "private/extra index field")
    index = write_index(root, ["good.json"], model_profile_sha256="0" * 64)
    rejects(lambda: collect(root, index), "index profile")
    index = write_index(root, [123])  # type: ignore[list-item]
    rejects(lambda: collect(root, index), "non-string entry")
    index = write_index(root, ["evidence-index.json"])
    rejects(lambda: collect(root, index), "index self-entry")

    outside = root / "outside.json"
    write_json(outside, valid_full_verifier())
    link = release_dir / "link.json"
    link.symlink_to(outside)
    index = write_index(root, ["link.json"])
    rejects(lambda: collect(root, index), "symlink")
    index_link = root / "index-link.json"
    index_link.symlink_to(index)
    rejects(lambda: collect(root, index_link), "index symlink")

    index = write_index(root, ["good.json"])
    rejects(
        lambda: MODULE.collect_release_evidence(
            root,
            index,
            good,
            expected_release_id=RELEASE_ID,
            expected_profile_sha256=PROFILE_SHA,
        ),
        "output collision",
    )

    forged_shape = json.loads(json.dumps(valid_sweep()))
    forged_shape["runs"]["qwen36-pressure-192-deep24"]["profile_config"][
        "max_steps"
    ] = 32
    no_pressure = json.loads(json.dumps(valid_sweep()))
    no_pressure["runs"]["qwen36-pressure-192-deep24"]["pressure_validation"] = {
        "qualification_schema_version": 1,
        "required": True,
        "valid": False,
        "contention_evidence": {"required": True, "valid": False},
        "reasons": ["pressure_duration_below_floor"],
    }
    occupancy_only = json.loads(json.dumps(valid_sweep()))
    occupancy_only["runs"]["qwen36-pressure-192-deep24"][
        "pressure_validation"
    ].pop(
        "contention_evidence"
    )
    occupancy_only_verifier = valid_full_verifier()
    occupancy_only_verifier["benchmark"]["profiles"]["hidden-pressure-192"][
        "legs"
    ][0]["pressure_validation"].pop("contention_evidence")
    wrong_reference_tree = valid_full_verifier()
    wrong_reference_tree["artifacts"]["reference_gateway_tree_sha256"] = "0" * 64
    speedup_below_baseline = valid_full_verifier()
    speedup_below_baseline["benchmark"]["profiles"]["hidden-pressure-192"][
        "speedup"
    ] = 0.99
    speedup_below_reference = valid_full_verifier()
    speedup_below_reference["benchmark"]["profiles"]["hidden-pressure-192"][
        "speedup"
    ] = 1.19
    mislabeled_candidate = valid_full_verifier()
    mislabeled_candidate["benchmark"]["candidate_lifecycle"][
        "frozen_submission_sha256"
    ] = "0" * 64
    submission_payload_drift = valid_full_verifier()
    submission_payload_drift["artifacts"]["reference_submission_sha256"] = "0" * 64
    submission_mode_drift = valid_full_verifier()
    submission_mode_drift["benchmark"]["candidate_lifecycle"][
        "frozen_submission_sha256"
    ] = "f" * 64
    controller_seal_drift = valid_full_verifier()
    controller_seal_drift["benchmark"]["candidate_lifecycle"][
        "network_egress_seal"
    ]["controller_image_id"] = "sha256:" + "0" * 64
    missing_controller_seal = valid_full_verifier()
    missing_controller_seal["benchmark"]["candidate_lifecycle"].pop(
        "network_egress_seal"
    )
    reference_speedup_drift = valid_full_verifier()
    reference_speedup_drift["benchmark"]["profiles"]["hidden-pressure-192"][
        "reference_speedup"
    ] = 1.1
    performance_drift = valid_full_verifier()
    performance_drift["benchmark"]["profiles"]["hidden-pressure-192"][
        "performance_score"
    ] = 0.99
    missing_tier_qualification = valid_full_verifier()
    missing_tier_qualification.pop("tier_qualification")
    missing_public_digest = valid_full_verifier()
    missing_public_digest.pop("raw_public_pair")
    missing_public_anchor = valid_full_verifier()
    missing_public_anchor.pop("public_direct_anchor")
    wrong_public_anchor_source = valid_full_verifier()
    wrong_public_anchor_source["public_direct_anchor"]["source_report_sha256"] = (
        "0" * 64
    )
    tampered_tier_policy = valid_full_verifier()
    tampered_tier_policy["tier_qualification"]["policy"][
        "deep_request_first_step"
    ] = 14
    public_deep_zero = valid_full_verifier()
    public_deep_zero["tier_qualification"]["public"]["deep_signals"][
        "offers"
    ] = 0
    hidden_deep_zero = valid_full_verifier()
    hidden_deep_zero["tier_qualification"]["hidden"]["observation"][
        "deep_signals"
    ]["sjf_ticks"] = 0
    qualification_wrong_tree = valid_full_verifier()
    qualification_wrong_tree["tier_qualification"][
        "reference_gateway_tree_sha256"
    ] = "0" * 64
    public_wrong_model = valid_full_verifier()
    public_wrong_model["tier_qualification"]["public"]["model_provenance"][
        "model_revision"
    ] = "old-model"
    wrong_corpus = json.loads(json.dumps(valid_sweep()))
    wrong_corpus["corpus_manifest_sha256"] = "0" * 64
    wrong_controller = json.loads(json.dumps(valid_sweep()))
    wrong_controller["runs"]["qwen36-pressure-192-deep24"][
        "controller_config_sha256"
    ] = "0" * 64
    wrong_model_provenance = json.loads(json.dumps(valid_sweep()))
    wrong_model_provenance["runs"]["qwen36-pressure-192-deep24"][
        "model_provenance"
    ]["model_revision"] = "old-model"
    wrong_selection_mode = json.loads(json.dumps(valid_sweep()))
    wrong_selection_mode["profile_selection"]["mode"] = "explicit_diagnostics"
    wrong_selection_order = json.loads(json.dumps(valid_sweep()))
    wrong_selection_order["profile_selection"]["profiles"] = []
    missing_interval_verifier = valid_full_verifier()
    missing_interval_verifier["benchmark"]["profiles"]["hidden-pressure-192"][
        "legs"
    ][0].pop("agent_execution_interval")
    interval_rate_tamper_verifier = valid_full_verifier()
    interval_rate_tamper_verifier["benchmark"]["profiles"]["hidden-pressure-192"][
        "legs"
    ][1]["valid_steps_per_min"] = 101.0
    post_end_sample_sweep = json.loads(json.dumps(valid_sweep()))
    post_end_sample_sweep["runs"]["qwen36-pressure-192-deep24"]["vllm_metrics"][
        "live_samples"
    ].append({"created_unix": 160.1})
    raw_identity_injection = valid_full_verifier()
    raw_identity_injection["checks"]["attestation"]["model_path"] = (
        "/home/unit/private/model"
    )
    forged_tail_leg = valid_full_verifier()
    forged_tail_leg["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][1][
        "p99_step_latency_sec"
    ] = 130.0
    forged_tail_export = valid_full_verifier()
    forged_tail_export["tail_anti_gaming"]["profiles"]["hidden-pressure-192"][
        "ratio"
    ] = 1.0
    single_pair_tail_failure = valid_full_verifier()
    aggregate_profile = single_pair_tail_failure["benchmark"]["profiles"][
        "hidden-pressure-192"
    ]
    aggregate_profile["legs"][1]["p99_step_latency_sec"] = 126.0
    failed_tail = {
        "schema_version": 2,
        "metric": "p99_step_latency_sec",
        "pairing": "candidate_over_baseline:single_committed_pair",
        "baseline_p99_step_latency_sec": 100.0,
        "candidate_p99_step_latency_sec": 126.0,
        "ratio": 1.26,
        "maximum_allowed_ratio": MAX_P99_STEP_LATENCY_RATIO,
        "passed": False,
    }
    aggregate_profile["tail_anti_gaming"] = failed_tail
    single_pair_tail_failure["tail_anti_gaming"]["profiles"]["hidden-pressure-192"] = (
        failed_tail
    )
    single_pair_tail_failure["tail_anti_gaming"]["all_profiles_passed"] = False
    invalid_oversubscribed_verifiers = {}
    for label, mutate in OVERSUBSCRIBED_MUTATIONS.items():
        payload = valid_full_verifier()
        pressure = oversubscribed_pressure_validation()
        payload["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][0][
            "pressure_validation"
        ] = pressure
        mutate(
            pressure["contention_evidence"]["oversubscribed_working_set"]
        )
        invalid_oversubscribed_verifiers[
            f"oversubscribed-verifier-{label}.json"
        ] = payload
    invalid_payloads = {
        **invalid_oversubscribed_verifiers,
        "forged-shape.json": forged_shape,
        "no-pressure.json": no_pressure,
        "occupancy-only.json": occupancy_only,
        "occupancy-only-verifier.json": occupancy_only_verifier,
        "wrong-reference-tree.json": wrong_reference_tree,
        "speedup-below-baseline.json": speedup_below_baseline,
        "speedup-below-reference.json": speedup_below_reference,
        "mislabeled-candidate.json": mislabeled_candidate,
        "submission-payload-drift.json": submission_payload_drift,
        "submission-mode-drift.json": submission_mode_drift,
        "controller-seal-drift.json": controller_seal_drift,
        "missing-controller-seal.json": missing_controller_seal,
        "reference-speedup-drift.json": reference_speedup_drift,
        "performance-drift.json": performance_drift,
        "missing-tier-qualification.json": missing_tier_qualification,
        "missing-public-digest.json": missing_public_digest,
        "missing-public-anchor.json": missing_public_anchor,
        "wrong-public-anchor-source.json": wrong_public_anchor_source,
        "tampered-tier-policy.json": tampered_tier_policy,
        "public-deep-zero.json": public_deep_zero,
        "hidden-deep-zero.json": hidden_deep_zero,
        "qualification-wrong-tree.json": qualification_wrong_tree,
        "public-wrong-model.json": public_wrong_model,
        "wrong-corpus.json": wrong_corpus,
        "wrong-controller.json": wrong_controller,
        "wrong-model-provenance.json": wrong_model_provenance,
        "wrong-selection-mode.json": wrong_selection_mode,
        "wrong-selection-order.json": wrong_selection_order,
        "missing-interval-verifier.json": missing_interval_verifier,
        "interval-rate-tamper-verifier.json": interval_rate_tamper_verifier,
        "post-end-sample-sweep.json": post_end_sample_sweep,
        "raw-runtime-identity.json": raw_identity_injection,
        "forged-tail-leg.json": forged_tail_leg,
        "forged-tail-export.json": forged_tail_export,
        "single-pair-tail-failure.json": single_pair_tail_failure,
        "wrong-profile.json": {**valid_sweep(), "model_profile_sha256": "0" * 64},
        "missing-profile.json": {
            "schema_version": 1,
            "kind": "real-swe-baseline-calibration-sweep",
            "release_id": RELEASE_ID,
            "status": "complete",
            "errors": [],
            "profile_order": ["qwen36-pressure-192-deep24"],
            "runs": {"qwen36-pressure-192-deep24": {}},
        },
        "running.json": {**valid_sweep(), "status": "running"},
        "errors.json": {**valid_sweep(), "errors": ["failed"]},
        "boolean-schema.json": {**valid_sweep(), "schema_version": True},
        "missing-errors.json": {
            key: value for key, value in valid_sweep().items() if key != "errors"
        },
        "old-gpt.json": {
            "schema_version": 1,
            "kind": "gpt-oss-public12-diagnostic",
            "release_id": RELEASE_ID,
            "model_profile_sha256": PROFILE_SHA,
            "status": "complete",
            "errors": [],
        },
        "old-abba.json": {
            "schema_version": 1,
            "kind": "hidden-profile-reference-abba-calibration",
            "release_id": RELEASE_ID,
            "model_profile_sha256": PROFILE_SHA,
            "status": "complete",
            "errors": [],
            "all_profiles_passed": False,
            "profiles": [{}],
        },
    }
    for name, payload in invalid_payloads.items():
        write_json(release_dir / name, payload)
        index = write_index(root, [name])
        rejects(lambda index=index: collect(root, index), name)

print("release manifest Qwen evidence unit: passed")
