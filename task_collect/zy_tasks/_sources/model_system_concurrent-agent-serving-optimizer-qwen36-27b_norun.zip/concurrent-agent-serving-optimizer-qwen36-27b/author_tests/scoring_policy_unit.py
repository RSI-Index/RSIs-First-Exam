#!/usr/bin/env python3
"""CPU-only policy-schema checks for semantic and release scoring gates."""

from __future__ import annotations

import ast
import copy
import json
import math
from pathlib import Path
from types import SimpleNamespace
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = TASK_ROOT / "environment" / "bench-controller" / "server.py"
POLICY_PATH = (
    TASK_ROOT / "environment" / "bench-controller" / "profiles" / "scoring-policy.json"
)


def load_validator():
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    selected = [
        node
        for node in parsed.body
        if isinstance(node, ast.FunctionDef) and node.name == "validate_policy"
    ]
    if len(selected) != 1:
        raise RuntimeError("scoring policy validator was not found")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "Profile": Any,
        "math": math,
        "swebench_partition_ready": lambda _partition, _minimum: True,
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102 - trusted source
    return namespace["validate_policy"]


def hidden_profiles(policy: dict[str, Any]) -> dict[str, SimpleNamespace]:
    return {
        entry["name"]: SimpleNamespace(
            enabled=True,
            workload_family="swebench-lite",
            pressure_required=True,
            corpus_partition="hidden",
            corpus_unique_instances_min=1,
        )
        for entry in policy["hidden_profiles"]
    }


def main() -> int:
    validate_policy = load_validator()
    development = json.loads(POLICY_PATH.read_text())

    def accepted(policy: dict[str, Any]) -> bool:
        try:
            validate_policy(policy, hidden_profiles(policy))
        except (KeyError, TypeError, ValueError):
            return False
        return True

    reference_one = copy.deepcopy(development)
    for entry in reference_one["hidden_profiles"]:
        entry["reference_speedup"] = 1.0

    release_reference_one = copy.deepcopy(reference_one)
    release_reference_one["release_ready"] = True
    release_reference_one["release_id"] = "qwen36-release-policy-unit"

    release_above_one = copy.deepcopy(release_reference_one)
    for entry in release_above_one["hidden_profiles"]:
        entry["reference_speedup"] = 1.000001

    cases = [
        {
            "name": "live_policy_is_valid_in_its_current_release_phase",
            "passed": accepted(development),
        },
        {
            "name": "fairness_is_absent_from_the_public_hidden_scoring_policy",
            "passed": "min_fairness" not in development
            and "fairness_target" not in development,
        },
        {
            "name": "live_qwen_identity_profile_and_reference_are_phase_coherent",
            "passed": isinstance(development.get("release_id"), str)
            and isinstance(development.get("release_ready"), bool)
            and len(development.get("hidden_profiles") or []) == 1
            and development["hidden_profiles"][0].get("name")
            == "hidden-pressure-192"
            and development["hidden_profiles"][0].get("weight") == 1.0
            and isinstance(
                development["hidden_profiles"][0].get("reference_speedup"),
                (int, float),
            )
            and not isinstance(
                development["hidden_profiles"][0].get("reference_speedup"), bool
            )
            and float(
                development["hidden_profiles"][0]["reference_speedup"]
            )
            > float(development["noise_floor"])
            and (
                (
                    development["release_ready"] is False
                    and bool(development["release_id"])
                    and bool(development.get("not_ready_reasons"))
                )
                or (
                    development["release_ready"] is True
                    and not development["release_id"].startswith("development")
                    and float(
                        development["hidden_profiles"][0]["reference_speedup"]
                    )
                    > 1.0
                )
            ),
        },
        {
            "name": "frozen_tail_policy_matches_hidden_evidence",
            "passed": development["max_p99_gateway_wait_sec"] == 720.0
            and development["tail_target_sec"] == 420.0
            and development["max_p99_step_latency_ratio"] == 1.25,
        },
        {
            "name": "development_reference_at_noise_floor_is_rejected",
            "passed": not accepted(reference_one),
        },
        {
            "name": "release_reference_one_is_rejected",
            "passed": not accepted(release_reference_one),
        },
        {
            "name": "release_reference_strictly_above_one_is_allowed",
            "passed": accepted(release_above_one),
        },
        {
            "name": "development_semantic_values_are_conservative",
            "passed": development["noise_floor"] == 1.0
            and development["min_tests_passed_workflows"] == 120
            and development["tests_passed_workflows_tolerance"] == 12
            and development["min_completed_workflows"] == 0
            and development["completed_workflows_tolerance"] == 1
            and development["minimum_workflow_progress"] == 24,
        },
    ]

    broken = copy.deepcopy(development)
    broken["min_tests_passed_workflows"] = 0
    cases.append(
        {
            "name": "nonpositive_min_tests_passed_workflows_is_rejected",
            "passed": not accepted(broken),
        }
    )
    for invalid_tail_ratio, label in (
        (True, "boolean"),
        (1.0, "one"),
        (0.9, "below_one"),
        (math.inf, "infinite"),
        (math.nan, "nan"),
        ("1.25", "string"),
    ):
        broken = copy.deepcopy(development)
        broken["max_p99_step_latency_ratio"] = invalid_tail_ratio
        cases.append(
            {
                "name": f"{label}_p99_step_latency_ratio_is_rejected",
                "passed": not accepted(broken),
            }
        )
    broken = copy.deepcopy(development)
    broken["min_completed_workflows"] = -1
    cases.append(
        {
            "name": "negative_min_completed_workflows_is_rejected",
            "passed": not accepted(broken),
        }
    )
    cases.append(
        {
            "name": "zero_completed_floor_is_valid_for_step_limited_workflows",
            "passed": accepted(development),
        }
    )
    for invalid_progress, label in (
        (True, "boolean"),
        (1.5, "fractional"),
        ("24", "string"),
        (-1, "negative"),
    ):
        broken = copy.deepcopy(development)
        broken["minimum_workflow_progress"] = invalid_progress
        cases.append(
            {
                "name": f"{label}_minimum_workflow_progress_is_rejected",
                "passed": not accepted(broken),
            }
        )
    above_one_noise = copy.deepcopy(development)
    above_one_noise["noise_floor"] = 1.000001
    cases.append(
        {
            "name": "noise_floor_above_one_is_rejected",
            "passed": not accepted(above_one_noise),
        }
    )
    for key in ("tests_passed_workflows_tolerance", "completed_workflows_tolerance"):
        broken = copy.deepcopy(development)
        broken[key] = -1
        cases.append(
            {
                "name": f"negative_{key}_is_rejected",
                "passed": not accepted(broken),
            }
        )
        fractional = copy.deepcopy(development)
        fractional[key] = 0.5
        cases.append(
            {
                "name": f"fractional_{key}_is_rejected",
                "passed": not accepted(fractional),
            }
        )

    report = {
        "schema_version": 1,
        "kind": "scoring-policy-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
