#!/usr/bin/env python3
"""Deterministic CPU checks for the extracted ThunderAgent Oracle scheduler."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
GATEWAY_PATH = TASK_ROOT / "solution" / "reference_gateway" / "gateway.py"
SCHEDULER_PATH = TASK_ROOT / "solution" / "reference_gateway" / "scheduler.py"
LICENSE_PATH = TASK_ROOT / "solution" / "reference_gateway" / "THIRD_PARTY_LICENSE.md"


def load_scheduler() -> Any:
    spec = importlib.util.spec_from_file_location("reference_thunder_scheduler", SCHEDULER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load reference scheduler")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def source_contract_checks() -> list[dict[str, Any]]:
    gateway = GATEWAY_PATH.read_text()
    scheduler = SCHEDULER_PATH.read_text()
    license_text = LICENSE_PATH.read_text()
    cases = {
        "oracle_is_bound_to_upstream_source_commit": (
            "7ddc8610270e56d3b109eed8796b3a4360fc67c9" in gateway
            and "ThunderAgent/scheduler/router.py" in scheduler
        ),
        "mit_attribution_is_retained": (
            "Copyright (c) 2026 Hao Kang" in license_text
            and "MIT License" in license_text
        ),
        "qwen_logical_kv_capacity_is_explicit": (
            'os.environ.get("THUNDER_KV_CAPACITY_TOKENS", "1887738")'
            in gateway
        ),
        "qwen_hybrid_kv_page_accounting_is_explicit": (
            'os.environ.get("THUNDER_KV_RAW_GPU_BLOCKS", "1253")' in gateway
            and 'os.environ.get("THUNDER_KV_RESERVED_NULL_BLOCKS", "1")'
            in gateway
            and 'os.environ.get("THUNDER_ATTENTION_PAGE_TOKENS", "1568")'
            in gateway
            and 'os.environ.get("THUNDER_MAMBA_GROUP_COUNT", "3")'
            in gateway
            and 'os.environ.get("THUNDER_MAMBA_RESIDENT_PAGES_PER_GROUP", "1")'
            in gateway
            and 'os.environ.get("THUNDER_MAMBA_PEAK_PAGES_PER_GROUP", "2")'
            in gateway
            and "hybrid_page_accounting=hybrid_page_accounting" in gateway
            and "class HybridPageAccounting:" in scheduler
        ),
        "qwen_decode_headroom_retains_thunderagent_default": (
            'os.environ.get("THUNDER_BUFFER_PER_PROGRAM", "100")' in gateway
            and "buffer_per_program: int = 100" in scheduler
            and "decode_headroom_tokens=self.buffer_per_program" in scheduler
        ),
        "hybrid_page_observability_contract_is_explicit": (
            '"decision_unit": "kv_pages"' in scheduler
            and '"tracked_pages_full"' in scheduler
            and '"first_pause_overflow_pages"' in scheduler
            and '"tracked_fixed_mamba_pages_peak"' in scheduler
            and '"tracked_reserved_transient_mamba_pages_peak"' in scheduler
            and '"reasoning_peak_reserved_programs_peak"' in scheduler
            and '"mamba_resident_pages_per_group"' in scheduler
            and '"transient_mamba_pages_per_program"' in scheduler
            and '"mamba_reservation_scope": "request_lifetime_peak"'
            in scheduler
            and '"mamba_reservation_uses_agent_step_count": False'
            in scheduler
        ),
        "paper_scheduler_defaults_are_explicit": (
            'os.environ.get("THUNDER_SCHEDULER_INTERVAL_SEC", "5.0")'
            in gateway
            and 'os.environ.get("THUNDER_ACTING_DECAY_BASE", "2.0")'
            in gateway
            and 'os.environ.get("THUNDER_HIGH_WATERMARK", "1.0")' in gateway
            and 'os.environ.get("THUNDER_LOW_WATERMARK", "1.0")' in gateway
        ),
        "scheduler_observability_covers_admission_and_loop_errors": (
            '"pause_admission": 0' in scheduler
            and '"pause_admission_new": 0' in scheduler
            and '"pause_admission_reentry": 0' in scheduler
            and '"scheduler_errors": 0' in scheduler
            and "except Exception as exc:" in scheduler
        ),
        "finite_cohort_bounded_request_age_policy_is_explicit": (
            'os.environ.get("THUNDER_FAIR_WAIT_THRESHOLD_SEC", "220")'
            in gateway
            and 'os.environ.get("THUNDER_AGED_RESUME_QUOTA_PER_TICK", "4")'
            in gateway
            and 'os.environ.get("THUNDER_FAIR_SERVICE_LAG_STEPS", "1")'
            in gateway
            and 'os.environ.get("THUNDER_FAIR_SERVICE_UNTIL_STEP", "12")'
            in gateway
            and '"scheduler_policy_schema_version": 4' in scheduler
            and '"thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"'
            in scheduler
            and '"fair_service_lag_steps"' in scheduler
            and '"fair_service_until_step"' in scheduler
            and '"deep_request_first_step"' in scheduler
            and '"protected-reentry-vs-feasible-blocked-request-ordinal"'
            in scheduler
            and '"aged-then-protected-request-ordinal-then-deep-total-tokens-"'
            in scheduler
            and '"total_tokens-then-request-wait-age-then-program-id"'
            in scheduler
            and '"request_age_scope": "blocked_gateway_request_only"'
            in scheduler
            and '"single-oldest-reservation-then-aged-quota-then-tiered-sjf"'
            in scheduler
            and '"full_phase_aware_decision_units"' in scheduler
            and '"active-idle-acting-shortest-context-first"' in scheduler
            and '"aged_reservation_inflight_reasoning_policy": "never_pause"'
            in scheduler
            and "request_wait_started_monotonic" in scheduler
            and '"resume_aged_pending": 0' in scheduler
            and '"pause_admission_service_lag": 0' in scheduler
            and '"deep_service_lag_bypass_decisions": 0' in scheduler
            and '"resume_least_service_request": 0' in scheduler
            and '"resume_protected_request": 0' in scheduler
            and '"resume_deep_request": 0' in scheduler
            and '"deep_sjf_priority_ticks": 0' in scheduler
            and '"aged_no_fit_ticks": 0' in scheduler
            and '"blocked_capacity_timeout": 0' in scheduler
            and "class ProgramAdmissionCapacityTimeout" in scheduler
            and "except ProgramAdmissionCapacityTimeout:" in gateway
            and '"type": "admission_capacity_timeout"' in gateway
            and "status=503" in gateway
            and "await scheduler.cancel_waiting_request(program)" in gateway
        ),
        "request_body_is_forwarded_without_reserialization": (
            "data=body" in gateway
            and "headers=filtered_headers(request.headers)" in gateway
            and "json=payload" not in gateway
        ),
        "response_observer_is_side_band": (
            "observer.feed(chunk)" in gateway
            and "await downstream.write(chunk)" in gateway
            and gateway.index("observer.feed(chunk)")
            < gateway.index("await downstream.write(chunk)")
        ),
        "streaming_usage_progress_is_bounded_and_reconciled": (
            "if self.stream_events_pending >= 20:" in gateway
            and "await scheduler.update_streaming_tokens(" in gateway
            and "total_tokens=observer.total_tokens" in gateway
        ),
        "opaque_run_header_is_the_program_key": (
            'request.headers.get("X-Agent-Run-ID")' in gateway
        ),
        "program_is_registered_and_admitted_before_backend_slot": (
            "await scheduler.get_or_create_program(program_id(request))" in gateway
            and "await scheduler.begin_request(program, request_context_chars(body))"
            in gateway
            and 'async with request.app["backend_slots"]' in gateway
            and gateway.index(
                "await scheduler.get_or_create_program(program_id(request))"
            )
            < gateway.index(
                "await scheduler.begin_request(program, request_context_chars(body))"
            )
            < gateway.index('async with request.app["backend_slots"]')
        ),
        "program_release_does_not_forward_to_backend": (
            'app.router.add_post("/programs/release", release_program)' in gateway
            and "await scheduler.release_program(value)" in gateway
        ),
        "data_and_control_connectors_are_independent": (
            "TCPConnector(limit=MAX_INFLIGHT, limit_per_host=0)" in gateway
            and "TCPConnector(limit=8, limit_per_host=0)" in gateway
            and 'await app["data_client"].close()' in gateway
            and 'await app["control_client"].close()' in gateway
        ),
        "strict_inbound_and_header_transport_contract": (
            "auto_decompress=False" in gateway
            and "handler_cancellation=True" in gateway
            and 'headers.getall("Connection", [])' in gateway
            and "list[tuple[str, str]]" in gateway
        ),
        "upstream_rewrite_layer_is_not_vendored": (
            "fastapi" not in gateway.lower()
            and "httpx" not in gateway.lower()
            and "remove_program_id" not in gateway
        ),
    }
    return [{"name": name, "passed": passed} for name, passed in cases.items()]


async def scheduler_checks() -> list[dict[str, Any]]:
    module = load_scheduler()
    Scheduler = module.ThunderScheduler
    Accounting = module.HybridPageAccounting
    Status = module.ProgramStatus
    Lifecycle = module.ProgramLifecycle
    PausedInfo = module.PausedInfo
    AdmissionCapacityTimeout = module.ProgramAdmissionCapacityTimeout
    results: list[dict[str, Any]] = []

    generic_scheduler = Scheduler(capacity_tokens=1000)
    generic_snapshot = await generic_scheduler.snapshot()
    results.append(
        {
            "name": "generic_scheduler_retains_upstream_decode_buffer_default",
            "passed": (
                generic_snapshot["buffer_per_program"] == 100
                and generic_snapshot["decision_unit"] == "tokens"
                and generic_snapshot["decision_capacity"] == 1000
                and generic_snapshot["tracked_pages_full"] is None
                and generic_snapshot["scheduler_policy_schema_version"] == 4
                and generic_snapshot["queue_policy"]
                == "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"
                and generic_snapshot["fair_service_lag_steps"] == 1
                and generic_snapshot["fair_service_until_step"] == 12
                and generic_snapshot["deep_request_first_step"] == 13
                and generic_snapshot["service_lag_scope"]
                == "protected-reentry-vs-feasible-blocked-request-ordinal"
                and generic_snapshot["normal_restore_order"]
                == "aged-then-protected-request-ordinal-then-deep-total-tokens-then-idle-acting"
                and generic_snapshot["deep_restore_order"]
                == "total_tokens-then-request-wait-age-then-program-id"
                and generic_snapshot["deep_reentry_bypasses_service_lag"]
                is True
                and generic_snapshot["fair_wait_threshold_sec"] == 220.0
                and generic_snapshot["aged_resume_quota_per_tick"] == 4
            ),
        }
    )

    invalid_service_lag_values: list[Any] = [-1, True, 1.0]
    rejected_service_lag_values: list[Any] = []
    for invalid_service_lag in invalid_service_lag_values:
        try:
            Scheduler(
                capacity_tokens=1000,
                fair_service_lag_steps=invalid_service_lag,
            )
        except ValueError:
            rejected_service_lag_values.append(invalid_service_lag)
    zero_lag_snapshot = await Scheduler(
        capacity_tokens=1000,
        fair_service_lag_steps=0,
    ).snapshot()
    results.append(
        {
            "name": "service_lag_contract_rejects_invalid_values_and_allows_zero",
            "passed": (
                rejected_service_lag_values == invalid_service_lag_values
                and zero_lag_snapshot["fair_service_lag_steps"] == 0
            ),
        }
    )

    invalid_cutoff_values: list[Any] = [0, -1, True, 12.0]
    rejected_cutoff_values: list[Any] = []
    for invalid_cutoff in invalid_cutoff_values:
        try:
            Scheduler(
                capacity_tokens=1000,
                fair_service_until_step=invalid_cutoff,
            )
        except ValueError:
            rejected_cutoff_values.append(invalid_cutoff)
    results.append(
        {
            "name": "protected_deep_cutoff_rejects_non_positive_or_non_integer_values",
            "passed": rejected_cutoff_values == invalid_cutoff_values,
        }
    )

    # The release default becomes aged at the exact 220-second boundary, not
    # one millisecond earlier.  Use a fixed monotonic instant so test runtime
    # cannot move either waiter across the boundary.
    boundary_scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    below_boundary = await boundary_scheduler.get_or_create_program(
        "age-boundary-below"
    )
    below_boundary.status = Status.REASONING
    below_boundary.step_count = 2
    below_boundary.request_pending = True
    boundary_scheduler._pause_locked(below_boundary)
    at_boundary = await boundary_scheduler.get_or_create_program(
        "age-boundary-at"
    )
    at_boundary.status = Status.REASONING
    at_boundary.step_count = 2
    at_boundary.request_pending = True
    boundary_scheduler._pause_locked(at_boundary)
    boundary_now = 10_000.0
    below_boundary.request_wait_started_monotonic = boundary_now - 219.999
    at_boundary.request_wait_started_monotonic = boundary_now - 220.0
    boundary_aged_ids = {
        program.program_id
        for program in boundary_scheduler._oldest_aged_waiters_locked(
            boundary_now
        )
    }
    boundary_snapshot = await boundary_scheduler.snapshot()
    results.append(
        {
            "name": "release_age_boundary_is_exactly_220_seconds",
            "passed": (
                below_boundary.program_id not in boundary_aged_ids
                and at_boundary.program_id in boundary_aged_ids
                and boundary_snapshot["fair_wait_threshold_sec"] == 220.0
                and boundary_snapshot["scheduler_interval_sec"] == 5.0
                and boundary_snapshot["aged_resume_quota_per_tick"] == 4
            ),
        }
    )

    qwen_accounting = Accounting(
        raw_gpu_blocks=1253,
        reserved_null_blocks=1,
        attention_page_tokens=1568,
        mamba_group_count=3,
        mamba_resident_pages_per_group=1,
        mamba_peak_pages_per_group=2,
        reported_logical_capacity_tokens=1887738,
    )
    qwen_contract = qwen_accounting.contract()
    results.append(
        {
            "name": "qwen_hybrid_page_cost_has_exact_rounding_boundaries",
            "passed": (
                qwen_accounting.capacity_pages == 1252
                and qwen_accounting.fixed_mamba_pages_per_program == 3
                and qwen_accounting.transient_mamba_pages_per_program == 3
                and qwen_accounting.peak_mamba_pages_per_reasoning_program == 6
                and qwen_accounting.program_pages(
                    0,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=False,
                )
                == 4
                and qwen_accounting.program_pages(
                    1468,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=False,
                )
                == 4
                and qwen_accounting.program_pages(
                    1469,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=False,
                )
                == 5
                and qwen_accounting.program_pages(
                    3036,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=False,
                )
                == 5
                and qwen_accounting.program_pages(
                    3037,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=False,
                )
                == 6
                # ACTING decay applies only to context tokens.  Fixed Mamba
                # pages and the 100-token decode headroom remain resident.
                and qwen_accounting.program_pages(
                    1469,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=False,
                    token_weight=0.0,
                )
                == 4
                # A whole REASONING request reserves the two-page/group peak,
                # even on agent step one; step_count is not vLLM allocator state.
                and qwen_accounting.program_pages(
                    0,
                    decode_headroom_tokens=100,
                    reserve_transient_mamba=True,
                )
                == 7
                and qwen_contract["accounting_schema_version"] == 3
                and qwen_contract["accounting_mode"]
                == "qwen36-vllm024-hybrid-state-aware-pages"
                and qwen_contract["mamba_resident_pages_per_group"] == 1
                and qwen_contract["mamba_peak_pages_per_group"] == 2
                and qwen_contract["fixed_mamba_pages_per_program"] == 3
                and qwen_contract["transient_mamba_pages_per_program"] == 3
                and qwen_contract["peak_mamba_pages_per_reasoning_program"]
                == 6
                and qwen_contract["mamba_initial_uncached_pages_per_program"]
                == 3
                and qwen_contract["mamba_reservation_scope"]
                == "request_lifetime_peak"
                and qwen_contract["mamba_reservation_phase"]
                == "reasoning_or_request_pending"
                and qwen_contract["mamba_reservation_uses_agent_step_count"]
                is False
                and qwen_contract["decision_pages_are_reservations"] is True
                and qwen_contract["acting_attention_decay_scope"]
                == "restore_only"
                and qwen_contract["reported_logical_capacity_is_informational"]
                is True
            ),
        }
    )

    invalid_reserved_null_block_rejected = False
    try:
        Accounting(
            raw_gpu_blocks=1253,
            reserved_null_blocks=1253,
            attention_page_tokens=1568,
            mamba_group_count=3,
            mamba_resident_pages_per_group=1,
            mamba_peak_pages_per_group=2,
            reported_logical_capacity_tokens=1887738,
        )
    except ValueError:
        invalid_reserved_null_block_rejected = True
    results.append(
        {
            "name": "hybrid_page_contract_rejects_non_allocatable_capacity",
            "passed": invalid_reserved_null_block_rejected,
        }
    )

    invalid_resident_peak_rejected = False
    try:
        Accounting(
            raw_gpu_blocks=1253,
            reserved_null_blocks=1,
            attention_page_tokens=1568,
            mamba_group_count=3,
            mamba_resident_pages_per_group=3,
            mamba_peak_pages_per_group=2,
            reported_logical_capacity_tokens=1887738,
        )
    except ValueError:
        invalid_resident_peak_rejected = True
    results.append(
        {
            "name": "hybrid_page_contract_rejects_resident_above_transient_peak",
            "passed": invalid_resident_peak_rejected,
        }
    )

    # A short ACTING program costs four decision pages (three resident Mamba +
    # one rounded attention).  A REASONING/request-pending program reserves the
    # request-lifetime two-page/group Mamba peak and costs seven.  312 ACTING
    # incumbents use 1,248 pages; a new REASONING program offers 1,255 pages and
    # must wait.  Releasing one incumbent leaves enough room to commit the full
    # seven-page pending request at 1,251 pages.
    qwen_scheduler = Scheduler(
        capacity_tokens=1887738,
        buffer_per_program=100,
        hybrid_page_accounting=qwen_accounting,
        force_resume_timeout_sec=1.0,
    )
    qwen_incumbents = []
    for index in range(312):
        incumbent = await qwen_scheduler.get_or_create_program(
            f"qwen-incumbent-{index}"
        )
        incumbent.total_tokens = 1
        incumbent.status = Status.ACTING
        incumbent.step_count = 1
        incumbent.acting_since = time.time()
        qwen_incumbents.append(incumbent)
    qwen_newcomer = await qwen_scheduler.get_or_create_program(
        "qwen-newcomer-313"
    )
    qwen_begin = asyncio.create_task(
        qwen_scheduler.begin_request(qwen_newcomer, 5)
    )
    for _ in range(10):
        if qwen_newcomer.lifecycle == Lifecycle.PAUSED:
            break
        await asyncio.sleep(0)
    qwen_paused_snapshot = await qwen_scheduler.snapshot()
    await qwen_scheduler.release_program(qwen_incumbents[0].program_id)
    await qwen_scheduler.schedule_once()
    await asyncio.wait_for(qwen_begin, timeout=1.0)
    qwen_restored_snapshot = await qwen_scheduler.snapshot()
    await qwen_scheduler.finish_request(
        qwen_newcomer,
        total_tokens=1,
        prompt_tokens=1,
    )
    results.append(
        {
            "name": "qwen_reasoning_peak_reservation_pauses_at_exact_page_boundary",
            "passed": (
                qwen_paused_snapshot["accounting_schema_version"] == 3
                and qwen_paused_snapshot["accounting_mode"]
                == "qwen36-vllm024-hybrid-state-aware-pages"
                and qwen_paused_snapshot["decision_unit"] == "kv_pages"
                and qwen_paused_snapshot["decision_capacity"] == 1252
                and qwen_paused_snapshot["raw_gpu_blocks"] == 1253
                and qwen_paused_snapshot["reserved_null_blocks"] == 1
                and qwen_paused_snapshot["capacity_pages"] == 1252
                and qwen_paused_snapshot["attention_page_tokens"] == 1568
                and qwen_paused_snapshot["mamba_group_count"] == 3
                and qwen_paused_snapshot["mamba_resident_pages_per_group"] == 1
                and qwen_paused_snapshot["mamba_peak_pages_per_group"] == 2
                and qwen_paused_snapshot["fixed_mamba_pages_per_program"] == 3
                and qwen_paused_snapshot["transient_mamba_pages_per_program"]
                == 3
                and qwen_paused_snapshot[
                    "peak_mamba_pages_per_reasoning_program"
                ]
                == 6
                and qwen_paused_snapshot["mamba_reservation_scope"]
                == "request_lifetime_peak"
                and qwen_paused_snapshot[
                    "mamba_reservation_uses_agent_step_count"
                ]
                is False
                and qwen_paused_snapshot["decision_pages_are_reservations"]
                is True
                and qwen_paused_snapshot["decode_headroom_tokens"] == 100
                and qwen_paused_snapshot["reported_logical_capacity_tokens"]
                == 1887738
                and qwen_paused_snapshot[
                    "reported_logical_capacity_is_informational"
                ]
                is True
                and qwen_paused_snapshot["active"] == 312
                and qwen_paused_snapshot["paused"] == 1
                and qwen_paused_snapshot["tracked_pages_full"] == 1248
                and qwen_paused_snapshot["tracked_pages_with_decay"] == 1248
                and qwen_paused_snapshot["tracked_attention_pages_full"] == 312
                and qwen_paused_snapshot[
                    "tracked_attention_pages_with_decay"
                ]
                == 312
                and qwen_paused_snapshot["tracked_fixed_mamba_pages"] == 936
                and qwen_paused_snapshot[
                    "tracked_reserved_transient_mamba_pages"
                ]
                == 0
                and qwen_paused_snapshot["reasoning_peak_reserved_programs"]
                == 0
                and qwen_paused_snapshot["capacity_overflow_pages"] == 0
                # The legacy first-pause field remains token-denominated.
                and qwen_paused_snapshot["first_pause_tracked_full"] == 31613.0
                and qwen_paused_snapshot["first_pause_tracked_pages_full"]
                == 1255
                and qwen_paused_snapshot["first_pause_overflow_pages"] == 3
                and qwen_paused_snapshot["first_pause_attention_pages_full"]
                == 313
                and qwen_paused_snapshot["first_pause_fixed_mamba_pages"]
                == 939
                and qwen_paused_snapshot[
                    "first_pause_reserved_transient_mamba_pages"
                ]
                == 3
                and qwen_paused_snapshot[
                    "first_pause_reasoning_peak_reserved_programs"
                ]
                == 1
                and qwen_paused_snapshot["first_pause_active"] == 313
                and qwen_paused_snapshot["first_pause_reason"]
                == "admission_capacity"
                and qwen_paused_snapshot["tracked_pages_full_peak"] == 1255
                and qwen_paused_snapshot["tracked_pages_with_decay_peak"]
                == 1255
                and qwen_paused_snapshot[
                    "tracked_attention_pages_full_peak"
                ]
                == 313
                and qwen_paused_snapshot[
                    "tracked_attention_pages_with_decay_peak"
                ]
                == 313
                and qwen_paused_snapshot["tracked_fixed_mamba_pages_peak"]
                == 939
                and qwen_paused_snapshot[
                    "tracked_reserved_transient_mamba_pages_peak"
                ]
                == 3
                and qwen_paused_snapshot[
                    "reasoning_peak_reserved_programs_peak"
                ]
                == 1
                and qwen_paused_snapshot["active_peak"] == 313
                and qwen_paused_snapshot["counters"]["pause_admission"] == 1
                and qwen_paused_snapshot["counters"]["pause_admission_new"]
                == 1
                and qwen_paused_snapshot["counters"][
                    "pause_admission_reentry"
                ]
                == 0
                and qwen_restored_snapshot["counters"]["resume_new"] == 1
                and qwen_newcomer.lifecycle == Lifecycle.ACTIVE
            ),
        }
    )

    # Decay makes only the ACTING context-token portion cheaper while choosing
    # a restore.  The pending REASONING program is committed at its full
    # eight-page cost (three resident + three transient + two attention);
    # full-cost safety then pauses the ACTING incumbent that no longer fits.
    small_qwen_accounting = Accounting(
        raw_gpu_blocks=13,
        reserved_null_blocks=1,
        attention_page_tokens=1568,
        mamba_group_count=3,
        mamba_resident_pages_per_group=1,
        mamba_peak_pages_per_group=2,
        reported_logical_capacity_tokens=1,
    )
    qwen_decay_scheduler = Scheduler(
        capacity_tokens=1,
        buffer_per_program=100,
        hybrid_page_accounting=small_qwen_accounting,
    )
    qwen_decay_acting = await qwen_decay_scheduler.get_or_create_program(
        "qwen-decayed-acting"
    )
    qwen_decay_acting.total_tokens = 1469
    qwen_decay_acting.status = Status.ACTING
    qwen_decay_acting.acting_since = time.time() - 1.1
    qwen_decay_waiting = await qwen_decay_scheduler.get_or_create_program(
        "qwen-decay-waiting"
    )
    qwen_decay_waiting.total_tokens = 1469
    qwen_decay_waiting.status = Status.REASONING
    qwen_decay_waiting.step_count = 1
    qwen_decay_waiting.request_pending = True
    qwen_decay_scheduler._pause_locked(
        qwen_decay_waiting, reason="decay_test_setup"
    )
    qwen_decay_before = await qwen_decay_scheduler.snapshot()
    await qwen_decay_scheduler.schedule_once()
    qwen_decay_after = await qwen_decay_scheduler.snapshot()
    results.append(
        {
            "name": "hybrid_restore_decays_tokens_but_commits_full_page_cost",
            "passed": (
                qwen_decay_before["tracked_pages_full"] == 5
                and qwen_decay_before["tracked_pages_with_decay"] == 4
                and qwen_decay_before["tracked_attention_pages_full"] == 2
                and qwen_decay_before["tracked_attention_pages_with_decay"]
                == 1
                and qwen_decay_before["tracked_fixed_mamba_pages"] == 3
                and qwen_decay_before[
                    "tracked_reserved_transient_mamba_pages"
                ]
                == 0
                and qwen_decay_before["reasoning_peak_reserved_programs"] == 0
                and qwen_decay_before["first_pause_tracked_full"] == 3138.0
                and qwen_decay_before["first_pause_tracked_pages_full"] == 13
                and qwen_decay_before["first_pause_overflow_pages"] == 1
                and qwen_decay_before["first_pause_attention_pages_full"] == 4
                and qwen_decay_before["first_pause_fixed_mamba_pages"] == 6
                and qwen_decay_before[
                    "first_pause_reserved_transient_mamba_pages"
                ]
                == 3
                and qwen_decay_before[
                    "first_pause_reasoning_peak_reserved_programs"
                ]
                == 1
                and qwen_decay_waiting.lifecycle == Lifecycle.ACTIVE
                and qwen_decay_acting.lifecycle == Lifecycle.PAUSED
                and qwen_decay_after["tracked_pages_full"] == 8
                and qwen_decay_after["tracked_pages_with_decay"] == 8
                and qwen_decay_after["tracked_fixed_mamba_pages"] == 3
                and qwen_decay_after[
                    "tracked_reserved_transient_mamba_pages"
                ]
                == 3
                and qwen_decay_after["reasoning_peak_reserved_programs"] == 1
                and qwen_decay_after["tracked_pages_full_peak"] == 13
                and qwen_decay_after["tracked_pages_with_decay_peak"] == 12
                and qwen_decay_after["tracked_attention_pages_full_peak"] == 4
                and qwen_decay_after[
                    "tracked_attention_pages_with_decay_peak"
                ]
                == 3
                and qwen_decay_after["tracked_fixed_mamba_pages_peak"] == 6
                and qwen_decay_after[
                    "tracked_reserved_transient_mamba_pages_peak"
                ]
                == 3
                and qwen_decay_after[
                    "reasoning_peak_reserved_programs_peak"
                ]
                == 1
                and qwen_decay_after["counters"]["resume_new"] == 1
                and qwen_decay_after["counters"]["pause_acting"] == 1
            ),
        }
    )

    # Capacity is re-checked on every agent step, not only when a program is
    # first registered.  Two short ACTING programs use eight pages; converting
    # one existing program to REASONING raises the reservation to eleven pages
    # and must pause it against a ten-page capacity.
    transition_accounting = Accounting(
        raw_gpu_blocks=11,
        reserved_null_blocks=1,
        attention_page_tokens=1568,
        mamba_group_count=3,
        mamba_resident_pages_per_group=1,
        mamba_peak_pages_per_group=2,
        reported_logical_capacity_tokens=1,
    )
    transition_scheduler = Scheduler(
        capacity_tokens=1,
        buffer_per_program=100,
        hybrid_page_accounting=transition_accounting,
        force_resume_timeout_sec=1.0,
    )
    reentry = await transition_scheduler.get_or_create_program("reentry")
    reentry.total_tokens = 1
    reentry.status = Status.ACTING
    reentry.step_count = 1
    reentry.acting_since = time.time()
    transition_blocker = await transition_scheduler.get_or_create_program(
        "reentry-blocker"
    )
    transition_blocker.total_tokens = 1
    transition_blocker.status = Status.ACTING
    transition_blocker.step_count = 1
    transition_blocker.acting_since = time.time()
    reentry_task = asyncio.create_task(
        transition_scheduler.begin_request(reentry, 5)
    )
    for _ in range(10):
        if reentry.lifecycle == Lifecycle.PAUSED:
            break
        await asyncio.sleep(0)
    reentry_paused = await transition_scheduler.snapshot()
    await transition_scheduler.release_program(transition_blocker.program_id)
    await transition_scheduler.schedule_once()
    await asyncio.wait_for(reentry_task, timeout=1.0)
    reentry_restored = await transition_scheduler.snapshot()
    await transition_scheduler.finish_request(
        reentry, total_tokens=1, prompt_tokens=1
    )
    results.append(
        {
            "name": "existing_request_transition_rechecks_peak_page_capacity",
            "passed": (
                reentry_paused["active"] == 1
                and reentry_paused["paused"] == 1
                and reentry_paused["tracked_pages_full"] == 4
                and reentry_paused["tracked_reserved_transient_mamba_pages"]
                == 0
                and reentry_paused["first_pause_tracked_pages_full"] == 11
                and reentry_paused["first_pause_attention_pages_full"] == 2
                and reentry_paused["first_pause_fixed_mamba_pages"] == 6
                and reentry_paused[
                    "first_pause_reserved_transient_mamba_pages"
                ]
                == 3
                and reentry_paused[
                    "first_pause_reasoning_peak_reserved_programs"
                ]
                == 1
                and reentry_paused["counters"]["pause_admission"] == 1
                and reentry_paused["counters"]["pause_admission_new"] == 0
                and reentry_paused["counters"]["pause_admission_reentry"] == 1
                and reentry_restored["counters"]["resume_pending"] == 1
                and reentry_restored["tracked_pages_full"] == 7
                and reentry_restored[
                    "tracked_reserved_transient_mamba_pages"
                ]
                == 3
                and reentry.lifecycle == Lifecycle.ACTIVE
            ),
        }
    )

    # Lag one permits an existing workflow to offer request ordinal two while a
    # feasible request at ordinal one waits.  The next ordinal would be blocked.
    queue_accounting = Accounting(
        raw_gpu_blocks=21,
        reserved_null_blocks=1,
        attention_page_tokens=1568,
        mamba_group_count=3,
        mamba_resident_pages_per_group=1,
        mamba_peak_pages_per_group=2,
        reported_logical_capacity_tokens=1,
    )
    queue_scheduler = Scheduler(
        capacity_tokens=1,
        buffer_per_program=100,
        hybrid_page_accounting=queue_accounting,
    )
    safe_reentry = await queue_scheduler.get_or_create_program("safe-reentry")
    safe_reentry.total_tokens = 1
    safe_reentry.status = Status.ACTING
    safe_reentry.step_count = 1
    safe_reentry.acting_since = time.time()
    unrelated_waiter = await queue_scheduler.get_or_create_program(
        "unrelated-waiter"
    )
    unrelated_waiter.total_tokens = 1
    unrelated_waiter.status = Status.REASONING
    unrelated_waiter.step_count = 1
    unrelated_waiter.request_pending = True
    queue_scheduler._pause_locked(unrelated_waiter, reason="queue_test_setup")
    await queue_scheduler.begin_request(safe_reentry, 5)
    queue_snapshot = await queue_scheduler.snapshot()
    safe_reentry_was_admitted = safe_reentry.inflight_requests == 1
    await queue_scheduler.finish_request(
        safe_reentry, total_tokens=1, prompt_tokens=1
    )
    results.append(
        {
            "name": "service_lag_allows_reentry_at_exact_one_ordinal_boundary",
            "passed": (
                safe_reentry.lifecycle == Lifecycle.ACTIVE
                and safe_reentry_was_admitted
                and unrelated_waiter.lifecycle == Lifecycle.PAUSED
                and queue_snapshot["active"] == 1
                and queue_snapshot["paused"] == 1
                and queue_snapshot["tracked_pages_full"] == 7
                and queue_snapshot["reasoning_peak_reserved_programs"] == 1
                and queue_snapshot["counters"]["pause_admission"] == 0
                and queue_snapshot["counters"]["pause_admission_new"] == 0
                and queue_snapshot["counters"]["pause_admission_reentry"] == 0
                and queue_snapshot["counters"][
                    "pause_admission_service_lag"
                ]
                == 0
            ),
        }
    )

    # A workflow offering ordinal three is too far ahead of an ordinal-one
    # waiter.  Even though its own re-entry fits, pause it, restore the lower
    # ordinal first, and later resume the leader after capacity is released.
    # Awaiting both begin_request tasks proves the adapter has no scheduler
    # deadlock in the exact cross-tier capacity case that old pending-first SJF
    # mishandled.
    lag_scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        force_resume_timeout_sec=1.0,
    )
    lag_anchor = await lag_scheduler.get_or_create_program("lag-anchor")
    lag_anchor.total_tokens = 700
    lag_anchor.status = Status.REASONING
    lag_leader = await lag_scheduler.get_or_create_program("lag-leader")
    lag_leader.total_tokens = 150
    lag_leader.status = Status.ACTING
    lag_leader.step_count = 2
    lag_leader.acting_since = time.time()
    lag_follower = await lag_scheduler.get_or_create_program("lag-follower")
    follower_task = asyncio.create_task(
        lag_scheduler.begin_request(lag_follower, 1250)
    )
    for _ in range(10):
        if lag_follower.lifecycle == Lifecycle.PAUSED:
            break
        await asyncio.sleep(0)
    leader_task = asyncio.create_task(
        lag_scheduler.begin_request(lag_leader, 750)
    )
    for _ in range(10):
        if lag_leader.lifecycle == Lifecycle.PAUSED:
            break
        await asyncio.sleep(0)
    lag_blocked_snapshot = await lag_scheduler.snapshot()
    await lag_scheduler.schedule_once()
    await asyncio.wait_for(follower_task, timeout=1.0)
    lag_priority_snapshot = await lag_scheduler.snapshot()
    await lag_scheduler.finish_request(
        lag_follower, total_tokens=250, prompt_tokens=250
    )
    await lag_scheduler.release_program(lag_anchor.program_id)
    await lag_scheduler.schedule_once()
    await asyncio.wait_for(leader_task, timeout=1.0)
    lag_resumed_snapshot = await lag_scheduler.snapshot()
    await lag_scheduler.finish_request(
        lag_leader, total_tokens=150, prompt_tokens=150
    )
    await lag_scheduler.release_program(lag_follower.program_id)
    await lag_scheduler.release_program(lag_leader.program_id)
    results.append(
        {
            "name": "service_lag_blocks_leader_restores_follower_and_has_no_deadlock",
            "passed": (
                lag_blocked_snapshot["service_lag_blocked"] == 1
                and lag_blocked_snapshot["service_lag_blocked_peak"] == 1
                and lag_blocked_snapshot["counters"][
                    "pause_admission_service_lag"
                ]
                == 1
                and lag_blocked_snapshot["counters"][
                    "pause_admission_reentry"
                ]
                == 1
                and lag_priority_snapshot["counters"][
                    "least_service_priority_ticks"
                ]
                == 1
                and lag_priority_snapshot["counters"][
                    "resume_least_service_request"
                ]
                == 1
                and lag_follower.step_count == 1
                and lag_priority_snapshot["active"] == 2
                and lag_priority_snapshot["paused"] == 1
                and lag_resumed_snapshot["service_lag_blocked"] == 0
                and lag_resumed_snapshot["counters"]["resume_pending"] == 1
                and lag_resumed_snapshot["counters"][
                    "blocked_capacity_timeout"
                ]
                == 0
                and lag_resumed_snapshot["counters"]["scheduler_errors"] == 0
                and lag_leader.lifecycle == Lifecycle.TERMINATED
                and lag_follower.lifecycle == Lifecycle.TERMINATED
            ),
        }
    )

    # A permanently oversized request cannot be admitted by any queue order and
    # therefore must not globally throttle healthy re-entry.
    oversize_lag_scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    oversize_leader = await oversize_lag_scheduler.get_or_create_program(
        "oversize-lag-leader"
    )
    oversize_leader.total_tokens = 100
    oversize_leader.status = Status.ACTING
    oversize_leader.step_count = 2
    oversize_leader.acting_since = time.time()
    impossible_waiter = await oversize_lag_scheduler.get_or_create_program(
        "impossible-lag-waiter"
    )
    impossible_waiter.total_tokens = 1001
    impossible_waiter.status = Status.REASONING
    impossible_waiter.step_count = 1
    impossible_waiter.request_pending = True
    oversize_lag_scheduler._pause_locked(
        impossible_waiter, reason="oversize_lag_test_setup"
    )
    await oversize_lag_scheduler.begin_request(oversize_leader, 500)
    oversize_lag_snapshot = await oversize_lag_scheduler.snapshot()
    await oversize_lag_scheduler.finish_request(
        oversize_leader, total_tokens=100, prompt_tokens=100
    )
    results.append(
        {
            "name": "oversized_waiter_cannot_deadlock_service_lag",
            "passed": (
                oversize_leader.lifecycle == Lifecycle.ACTIVE
                and oversize_lag_snapshot["service_lag_blocked"] == 0
                and oversize_lag_snapshot["counters"][
                    "pause_admission_service_lag"
                ]
                == 0
            ),
        }
    )

    # get_or_create_program inserts the newcomer into the active set before
    # begin_request checks capacity.  Its requirement must be counted once.
    scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    incumbent = await scheduler.get_or_create_program("incumbent")
    incumbent.total_tokens = 500
    incumbent.status = Status.ACTING
    incumbent.acting_since = time.time()
    newcomer = await scheduler.get_or_create_program("newcomer")
    await scheduler.begin_request(newcomer, 2000)  # 400 tokens at 5 chars/token.
    results.append(
        {
            "name": "new_admission_counts_working_set_once",
            "passed": newcomer.lifecycle == Lifecycle.ACTIVE,
        }
    )
    await scheduler.finish_request(
        newcomer, total_tokens=400, prompt_tokens=400
    )

    # A new program rejected at the logical-capacity boundary must be visible
    # in qualification evidence, then wake through the NEW restore path.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        force_resume_timeout_sec=1.0,
    )
    incumbent = await scheduler.get_or_create_program("admission-incumbent")
    incumbent.total_tokens = 800
    incumbent.status = Status.ACTING
    incumbent.acting_since = time.time()
    newcomer = await scheduler.get_or_create_program("admission-newcomer")
    begin_task = asyncio.create_task(scheduler.begin_request(newcomer, 2000))
    await asyncio.sleep(0)
    paused_snapshot = await scheduler.snapshot()
    await scheduler.release_program(incumbent.program_id)
    await scheduler.schedule_once()
    await asyncio.wait_for(begin_task, timeout=1.0)
    restored_snapshot = await scheduler.snapshot()
    newcomer_was_restored = newcomer.lifecycle == Lifecycle.ACTIVE
    await scheduler.finish_request(
        newcomer, total_tokens=400, prompt_tokens=400
    )
    await scheduler.release_program(newcomer.program_id)
    telemetry_after_release = await scheduler.snapshot()
    results.append(
        {
            "name": "new_capacity_admission_pause_and_restore_are_counted",
            "passed": (
                paused_snapshot["counters"]["pause_admission"] == 1
                and paused_snapshot["paused"] == 1
                and restored_snapshot["counters"]["resume_new"] == 1
                and newcomer_was_restored
                and paused_snapshot["first_pause_reason"] == "admission_capacity"
                and paused_snapshot["first_pause_elapsed_sec"] is not None
                and paused_snapshot["first_pause_tracked_full"] == 1200.0
                and paused_snapshot["first_pause_active"] == 2
                and paused_snapshot["active_peak"] == 2
                and paused_snapshot["paused_peak"] == 1
                and paused_snapshot["tracked_tokens_full_peak"] == 1200.0
                and restored_snapshot["first_resume_elapsed_sec"] is not None
                and restored_snapshot["pause_wait_count"] == 1
                and restored_snapshot["pause_wait_total_sec"] >= 0.0
                and restored_snapshot["pause_wait_max_sec"]
                == restored_snapshot["pause_wait_total_sec"]
                and restored_snapshot["scheduler_ticks"] == 1
                and telemetry_after_release["active_peak"] == 2
                and telemetry_after_release["paused_peak"] == 1
                and telemetry_after_release["tracked_tokens_full_peak"] == 1200.0
            ),
        }
    )

    # Restoration uses the paper's 2^-t estimate for ACTIVE acting KV.  With
    # full accounting the newcomer would remain paused; after one second of
    # decay it fits and the older acting program becomes the next pause target.
    scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    acting = await scheduler.get_or_create_program("decayed-acting")
    acting.total_tokens = 800
    acting.status = Status.ACTING
    acting.acting_since = time.time() - 1.1
    waiting = await scheduler.get_or_create_program("decay-waiting")
    waiting.total_tokens = 500
    waiting.status = Status.REASONING
    waiting.step_count = 1
    waiting.request_pending = True
    scheduler._pause_locked(waiting)
    await scheduler.schedule_once()
    decay_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "acting_token_decay_enables_shortest_fit_restore",
            "passed": (
                waiting.lifecycle == Lifecycle.ACTIVE
                and acting.lifecycle == Lifecycle.PAUSED
                and decay_snapshot["counters"]["resume_new"] == 1
                and decay_snapshot["counters"]["pause_acting"] == 1
            ),
        }
    )

    # A timed-out waiter may use the final liveness fallback only when its full
    # request-lifetime cost still fits.  Queue ordering, rather than capacity,
    # is what blocks this new request.
    scheduler = Scheduler(
        capacity_tokens=10,
        buffer_per_program=0,
        force_resume_timeout_sec=0.01,
    )
    incumbent = await scheduler.get_or_create_program("force-incumbent")
    incumbent.total_tokens = 1
    incumbent.status = Status.REASONING
    idle_waiter = await scheduler.get_or_create_program("force-idle-waiter")
    idle_waiter.total_tokens = 1
    idle_waiter.status = Status.ACTING
    idle_waiter.step_count = 1
    idle_waiter.acting_since = time.time()
    scheduler._pause_locked(idle_waiter, reason="force_safe_test_setup")
    forced = await scheduler.get_or_create_program("force-new")
    await scheduler.begin_request(forced, 5)
    force_snapshot = await scheduler.snapshot()
    await scheduler.finish_request(forced, total_tokens=1, prompt_tokens=1)
    results.append(
        {
            "name": "force_resume_timeout_requires_full_cost_capacity",
            "passed": (
                forced.lifecycle == Lifecycle.ACTIVE
                and force_snapshot["counters"]["pause_admission"] == 1
                and force_snapshot["counters"]["force_resume"] == 1
                and force_snapshot["counters"]["blocked_capacity_timeout"]
                == 0
                and force_snapshot["tracked_tokens_full"] == 2.0
                and force_snapshot["tracked_tokens_full"]
                <= force_snapshot["decision_capacity"]
            ),
        }
    )

    # If the same timeout cannot fit at full cost, fail closed: keep the
    # incumbent accounting intact, expose the blocked timeout, and let the
    # gateway's typed-503 path clear the pending request state.
    scheduler = Scheduler(
        capacity_tokens=1,
        buffer_per_program=0,
        force_resume_timeout_sec=0.01,
    )
    incumbent = await scheduler.get_or_create_program("blocked-incumbent")
    incumbent.total_tokens = 1
    incumbent.status = Status.REASONING
    blocked = await scheduler.get_or_create_program("blocked-new")
    blocked_error = False
    try:
        await scheduler.begin_request(blocked, 5)
    except AdmissionCapacityTimeout:
        blocked_error = True
    await scheduler.cancel_waiting_request(blocked)
    blocked_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "capacity_blocked_timeout_fails_closed_without_overflow",
            "passed": (
                blocked_error
                and blocked.lifecycle == Lifecycle.TERMINATED
                and blocked_snapshot["tracked_tokens_full"] == 1.0
                and blocked_snapshot["tracked_tokens_full"]
                <= blocked_snapshot["decision_capacity"]
                and blocked_snapshot["pending_request_waiters"] == 0
                and blocked_snapshot["oldest_pending_request_wait_sec"] == 0.0
                and blocked_snapshot["pause_wait_count"] == 1
                and blocked_snapshot["counters"]["force_resume"] == 0
                and blocked_snapshot["counters"]["blocked_capacity_timeout"]
                == 1
            ),
        }
    )

    # A normal scheduler resume that wins the timeout race is not a force
    # resume.  Exercise the locked timeout decision directly to keep the race
    # deterministic in a CPU unit test.
    scheduler = Scheduler(capacity_tokens=10, buffer_per_program=0)
    raced = await scheduler.get_or_create_program("normal-resume-race")
    raced.total_tokens = 1
    raced.status = Status.REASONING
    raced.step_count = 1
    raced.request_pending = True
    scheduler._pause_locked(raced, reason="normal_resume_race_setup")
    scheduler._resume_locked(raced)
    race_was_blocked = scheduler._handle_admission_timeout_locked(raced)
    race_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "normal_resume_timeout_race_is_not_counted_as_force",
            "passed": (
                race_was_blocked is False
                and raced.lifecycle == Lifecycle.ACTIVE
                and race_snapshot["counters"]["force_resume"] == 0
                and race_snapshot["counters"]["blocked_capacity_timeout"] == 0
            ),
        }
    )

    # Pause ACTING programs before REASONING and choose the shortest ACTING
    # context that relieves pressure.
    scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    long_acting = await scheduler.get_or_create_program("long-acting")
    long_acting.total_tokens = 600
    long_acting.status = Status.ACTING
    long_acting.acting_since = time.time()
    short_acting = await scheduler.get_or_create_program("short-acting")
    short_acting.total_tokens = 500
    short_acting.status = Status.ACTING
    short_acting.acting_since = time.time()
    await scheduler.schedule_once()
    results.append(
        {
            "name": "acting_first_shortest_context_pause",
            "passed": (
                short_acting.lifecycle == Lifecycle.PAUSED
                and long_acting.lifecycle == Lifecycle.ACTIVE
            ),
        }
    )

    # A future pause must count immediately in the projected working set so one
    # tick does not mark every in-flight reasoning request.
    scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    long_reasoning = await scheduler.get_or_create_program("long-reasoning")
    long_reasoning.total_tokens = 700
    long_reasoning.status = Status.REASONING
    short_reasoning = await scheduler.get_or_create_program("short-reasoning")
    short_reasoning.total_tokens = 400
    short_reasoning.status = Status.REASONING
    await scheduler.schedule_once()
    reasoning_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "reasoning_pause_marks_only_required_shortest_set",
            "passed": (
                short_reasoning.marked_for_pause
                and not long_reasoning.marked_for_pause
                and reasoning_snapshot["marked_for_pause_peak"] == 1
                and reasoning_snapshot["scheduler_ticks"] == 1
            ),
        }
    )

    # V4 restores the least-served request ordinal before a multi-turn pending
    # request, with idle ACTING state still last.
    scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    anchor = await scheduler.get_or_create_program("anchor")
    anchor.total_tokens = 600
    anchor.status = Status.REASONING
    pending = await scheduler.get_or_create_program("pending")
    pending.total_tokens = 400
    pending.status = Status.REASONING
    pending.step_count = 2
    pending.request_pending = True
    scheduler._pause_locked(pending)
    new = await scheduler.get_or_create_program("new")
    new.total_tokens = 300
    new.status = Status.REASONING
    new.step_count = 1
    new.request_pending = True
    scheduler._pause_locked(new)
    idle = await scheduler.get_or_create_program("idle")
    idle.total_tokens = 200
    idle.status = Status.ACTING
    idle.step_count = 3
    idle.acting_since = time.time()
    scheduler._pause_locked(idle)
    await scheduler.schedule_once()
    results.append(
        {
            "name": "least_service_request_ordinal_restore_priority",
            "passed": (
                pending.lifecycle == Lifecycle.PAUSED
                and new.lifecycle == Lifecycle.ACTIVE
                and idle.lifecycle == Lifecycle.PAUSED
                and scheduler._counters["least_service_priority_ticks"] == 1
                and scheduler._counters["resume_least_service_request"] == 1
            ),
        }
    )

    # The finite-cohort adapter is dormant below 240 seconds, then allows an
    # old long-context pending request to outrank a younger short one.  The
    # exact capacity calculation is unchanged: the 600-token anchor leaves
    # room for only the 400-token aged request.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
        aged_resume_quota_per_tick=4,
    )
    anchor = await scheduler.get_or_create_program("age-anchor")
    anchor.total_tokens = 600
    anchor.status = Status.REASONING
    old_long = await scheduler.get_or_create_program("age-old-long")
    old_long.total_tokens = 400
    old_long.status = Status.REASONING
    old_long.step_count = 2
    old_long.request_pending = True
    scheduler._pause_locked(old_long)
    old_long.request_wait_started_monotonic = time.monotonic() - 241.0
    young_short = await scheduler.get_or_create_program("age-young-short")
    young_short.total_tokens = 100
    young_short.status = Status.REASONING
    young_short.step_count = 2
    young_short.request_pending = True
    scheduler._pause_locked(young_short)
    await scheduler.schedule_once()
    aged_pending_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_pending_oldest_first_overrides_shortest_first",
            "passed": (
                old_long.lifecycle == Lifecycle.ACTIVE
                and young_short.lifecycle == Lifecycle.PAUSED
                and aged_pending_snapshot["tracked_tokens_full"] == 1000.0
                and aged_pending_snapshot["counters"]["resume_aged_pending"]
                == 1
                and aged_pending_snapshot["counters"]["resume_pending"] == 1
                and aged_pending_snapshot["counters"]["aged_priority_ticks"]
                == 1
                and aged_pending_snapshot["counters"]["force_resume"] == 0
            ),
        }
    )

    # Once the bound is crossed it applies to every blocked agent request,
    # including a never-admitted NEW program.  This cross-group promotion is
    # the explicit Harbor finite-cohort adapter; the below-threshold order
    # tested above remains the upstream pending > new > acting policy.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
        aged_resume_quota_per_tick=4,
    )
    anchor = await scheduler.get_or_create_program("aged-new-anchor")
    anchor.total_tokens = 600
    anchor.status = Status.REASONING
    aged_new = await scheduler.get_or_create_program("aged-new")
    aged_new.total_tokens = 400
    aged_new.status = Status.REASONING
    aged_new.step_count = 1
    aged_new.request_pending = True
    scheduler._pause_locked(aged_new)
    aged_new.request_wait_started_monotonic = time.monotonic() - 241.0
    young_pending = await scheduler.get_or_create_program("young-pending")
    young_pending.total_tokens = 100
    young_pending.status = Status.REASONING
    young_pending.step_count = 2
    young_pending.request_pending = True
    scheduler._pause_locked(young_pending)
    await scheduler.schedule_once()
    aged_new_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_new_crosses_normal_pending_priority",
            "passed": (
                aged_new.lifecycle == Lifecycle.ACTIVE
                and young_pending.lifecycle == Lifecycle.PAUSED
                and aged_new_snapshot["counters"]["resume_aged_new"] == 1
                and aged_new_snapshot["counters"]["resume_new"] == 1
                and aged_new_snapshot["counters"]["resume_pending"] == 0
            ),
        }
    )

    # Four is a strict per-tick age quota.  A fifth aged request remains in the
    # queue even when spare capacity exists, preventing one tail-repair tick
    # from replacing the upstream throughput policy wholesale.
    scheduler = Scheduler(
        capacity_tokens=100,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
        aged_resume_quota_per_tick=4,
    )
    quota_programs = []
    for index in range(5):
        program = await scheduler.get_or_create_program(f"aged-quota-{index}")
        program.total_tokens = 10
        program.status = Status.REASONING
        program.step_count = 2
        program.request_pending = True
        scheduler._pause_locked(program)
        program.request_wait_started_monotonic = (
            time.monotonic() - 245.0 + index * 0.001
        )
        quota_programs.append(program)
    quota_before = await scheduler.snapshot()
    await scheduler.schedule_once()
    quota_after = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_resume_quota_is_four_per_tick",
            "passed": (
                quota_before["pending_request_waiters"] == 5
                and quota_before["aged_request_waiters"] == 5
                and quota_before["aged_request_waiters_peak"] == 5
                and all(
                    program.lifecycle == Lifecycle.ACTIVE
                    for program in quota_programs[:4]
                )
                and quota_programs[4].lifecycle == Lifecycle.PAUSED
                and quota_after["pending_request_waiters"] == 1
                and quota_after["aged_request_waiters"] == 1
                and quota_after["counters"]["resume_aged_pending"] == 4
                and quota_after["counters"]["aged_quota_exhausted_ticks"]
                == 1
            ),
        }
    )

    # Eviction age is not request age.  Preserve PausedInfo.paused_at for the
    # upstream lifecycle metadata while starting the bounded-age clock only
    # when begin_request really blocks on the already-paused ACTING program.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        force_resume_timeout_sec=1.0,
        fair_wait_threshold_sec=240.0,
    )
    anchor = await scheduler.get_or_create_program("idle-age-anchor")
    anchor.total_tokens = 1000
    anchor.status = Status.REASONING
    idle = await scheduler.get_or_create_program("long-idle-before-request")
    idle.total_tokens = 1
    idle.status = Status.ACTING
    idle.step_count = 1
    idle.acting_since = time.time()
    scheduler._pause_locked(idle, reason="idle_age_test_setup")
    scheduler.waiting[idle.program_id] = PausedInfo(
        program_id=idle.program_id,
        total_tokens=idle.total_tokens,
        paused_at=time.time() - 500.0,
        step_count=idle.step_count,
    )
    idle_begin = asyncio.create_task(scheduler.begin_request(idle, 5))
    await asyncio.sleep(0)
    idle_waiting_snapshot = await scheduler.snapshot()
    preserved_idle_pause_age = time.time() - scheduler.waiting[idle.program_id].paused_at
    await scheduler.release_program(anchor.program_id)
    await scheduler.schedule_once()
    await asyncio.wait_for(idle_begin, timeout=1.0)
    idle_restored_snapshot = await scheduler.snapshot()
    idle_wait_clock_cleared = idle.request_wait_started_monotonic is None
    await scheduler.finish_request(idle, total_tokens=1, prompt_tokens=1)
    await scheduler.release_program(idle.program_id)
    idle_released_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "idle_pause_age_is_not_inherited_by_blocked_request",
            "passed": (
                preserved_idle_pause_age >= 499.0
                and idle_waiting_snapshot["pending_request_waiters"] == 1
                and idle_waiting_snapshot["aged_request_waiters"] == 0
                and 0.0
                <= idle_waiting_snapshot["oldest_pending_request_wait_sec"]
                < 1.0
                and idle_restored_snapshot["counters"]["resume_aged_pending"]
                == 0
                and idle_wait_clock_cleared
                and idle_released_snapshot["pending_request_waiters"] == 0
                and idle_released_snapshot["aged_request_waiters"] == 0
            ),
        }
    )

    # If an aged request cannot fit, selection remains capacity-neutral and
    # exposes the condition.  Once real capacity is released the same request
    # resumes normally without touching the 1,800-second fallback.
    scheduler = Scheduler(
        capacity_tokens=100,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
        aged_resume_quota_per_tick=4,
    )
    anchor = await scheduler.get_or_create_program("aged-no-fit-anchor")
    anchor.total_tokens = 90
    anchor.status = Status.REASONING
    no_fit = await scheduler.get_or_create_program("aged-no-fit")
    no_fit.total_tokens = 20
    no_fit.status = Status.REASONING
    no_fit.step_count = 2
    no_fit.request_pending = True
    scheduler._pause_locked(no_fit)
    no_fit.request_wait_started_monotonic = time.monotonic() - 241.0
    await scheduler.schedule_once()
    no_fit_snapshot = await scheduler.snapshot()
    await scheduler.release_program(anchor.program_id)
    await scheduler.schedule_once()
    fit_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_selection_is_exact_fit_and_capacity_neutral",
            "passed": (
                no_fit.lifecycle == Lifecycle.ACTIVE
                and no_fit_snapshot["tracked_tokens_full"] == 90.0
                and no_fit_snapshot["counters"]["aged_no_fit_ticks"] == 1
                and no_fit_snapshot["counters"]["aged_capacity_skip_count"]
                == 1
                and no_fit_snapshot["counters"]["resume_aged_pending"] == 0
                and fit_snapshot["tracked_tokens_full"] == 20.0
                and fit_snapshot["counters"]["resume_aged_pending"] == 1
                and fit_snapshot["counters"]["force_resume"] == 0
            ),
        }
    )

    scheduler = Scheduler(
        capacity_tokens=1,
        buffer_per_program=0,
        force_resume_timeout_sec=1.0,
        fair_wait_threshold_sec=240.0,
    )
    anchor = await scheduler.get_or_create_program("cancel-age-anchor")
    anchor.total_tokens = 1
    anchor.status = Status.REASONING
    cancelled = await scheduler.get_or_create_program("cancel-aged-wait")
    cancelled_begin = asyncio.create_task(scheduler.begin_request(cancelled, 5))
    await asyncio.sleep(0)
    cancellation_clock_started = (
        cancelled.request_wait_started_monotonic is not None
    )
    cancelled_begin.cancel()
    try:
        await cancelled_begin
    except asyncio.CancelledError:
        pass
    await scheduler.cancel_waiting_request(cancelled)
    cancelled_snapshot = await scheduler.snapshot()

    released = await scheduler.get_or_create_program("release-aged-wait")
    released.total_tokens = 1
    released.status = Status.REASONING
    released.step_count = 2
    released.request_pending = True
    scheduler._pause_locked(released)
    released.request_wait_started_monotonic = time.monotonic() - 241.0
    release_found, release_now = await scheduler.release_program(
        released.program_id
    )
    released_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "cancel_and_release_clear_blocked_request_age",
            "passed": (
                cancellation_clock_started
                and cancelled.request_wait_started_monotonic is None
                and cancelled.lifecycle == Lifecycle.TERMINATED
                and cancelled_snapshot["pending_request_waiters"] == 0
                and release_found
                and release_now
                and released.request_wait_started_monotonic is None
                and released.lifecycle == Lifecycle.TERMINATED
                and released_snapshot["pending_request_waiters"] == 0
                and released_snapshot["aged_request_waiters"] == 0
            ),
        }
    )

    # V2 reserves for one oldest aged request by planning exact full-capacity
    # swaps under the scheduler lock.  Two equal shortest ACTING contexts are
    # deterministic victims; the larger idle context and in-flight REASONING
    # remain active.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
        aged_resume_quota_per_tick=4,
    )
    anchor = await scheduler.get_or_create_program("reservation-anchor")
    anchor.total_tokens = 300
    anchor.status = Status.REASONING
    victim_a = await scheduler.get_or_create_program("reservation-victim-a")
    victim_a.total_tokens = 100
    victim_a.status = Status.ACTING
    victim_a.acting_since = time.time()
    victim_z = await scheduler.get_or_create_program("reservation-victim-z")
    victim_z.total_tokens = 100
    victim_z.status = Status.ACTING
    victim_z.acting_since = time.time()
    retained_long = await scheduler.get_or_create_program(
        "reservation-retained-long"
    )
    retained_long.total_tokens = 300
    retained_long.status = Status.ACTING
    retained_long.acting_since = time.time()
    reservation_owner = await scheduler.get_or_create_program(
        "reservation-owner"
    )
    reservation_owner.total_tokens = 400
    reservation_owner.status = Status.REASONING
    reservation_owner.step_count = 2
    reservation_owner.request_pending = True
    scheduler._pause_locked(reservation_owner)
    reservation_owner.request_wait_started_monotonic = time.monotonic() - 241.0
    await scheduler.schedule_once()
    reservation_swap_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_reservation_swaps_shortest_idle_acting_exactly",
            "passed": (
                reservation_owner.lifecycle == Lifecycle.ACTIVE
                and victim_a.lifecycle == Lifecycle.PAUSED
                and victim_z.lifecycle == Lifecycle.PAUSED
                and retained_long.lifecycle == Lifecycle.ACTIVE
                and anchor.lifecycle == Lifecycle.ACTIVE
                and anchor.status == Status.REASONING
                and reservation_swap_snapshot["tracked_tokens_full"] == 1000.0
                and reservation_swap_snapshot["aged_reservation_active"] == 0
                and reservation_swap_snapshot[
                    "aged_reservation_required_capacity_peak"
                ]
                == 400
                and reservation_swap_snapshot[
                    "aged_reservation_gap_capacity_peak"
                ]
                == 200
                and reservation_swap_snapshot["counters"][
                    "pause_acting_aged_reservation"
                ]
                == 2
                and reservation_swap_snapshot["counters"][
                    "aged_reservation_victims_paused"
                ]
                == 2
                and reservation_swap_snapshot["counters"][
                    "aged_reservation_capacity_freed"
                ]
                == 200
                and reservation_swap_snapshot["counters"][
                    "aged_reservation_satisfied"
                ]
                == 1
                and reservation_swap_snapshot[
                    "aged_rescue_post_commit_overflow_peak"
                ]
                == 0
            ),
        }
    )

    # If idle ACTING pages are insufficient, V2 commits only those safe
    # victims and retains the gap.  Younger work cannot consume it, and the
    # existing in-flight REASONING request is neither paused nor marked.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
    )
    inflight = await scheduler.get_or_create_program("reservation-inflight")
    await scheduler.begin_request(inflight, 4500)
    idle_victim = await scheduler.get_or_create_program(
        "reservation-partial-idle"
    )
    idle_victim.total_tokens = 50
    idle_victim.status = Status.ACTING
    idle_victim.acting_since = time.time()
    blocked_owner = await scheduler.get_or_create_program(
        "reservation-blocked-owner"
    )
    blocked_owner.total_tokens = 200
    blocked_owner.status = Status.REASONING
    blocked_owner.step_count = 2
    blocked_owner.request_pending = True
    scheduler._pause_locked(blocked_owner)
    blocked_owner.request_wait_started_monotonic = time.monotonic() - 241.0
    younger = await scheduler.get_or_create_program("reservation-younger")
    younger.total_tokens = 50
    younger.status = Status.REASONING
    younger.step_count = 2
    younger.request_pending = True
    scheduler._pause_locked(younger)
    await scheduler.schedule_once()
    partial_snapshot = await scheduler.snapshot()
    partial_state_safe = (
        blocked_owner.lifecycle == Lifecycle.PAUSED
        and younger.lifecycle == Lifecycle.PAUSED
        and idle_victim.lifecycle == Lifecycle.PAUSED
        and inflight.lifecycle == Lifecycle.ACTIVE
        and inflight.status == Status.REASONING
        and inflight.inflight_requests == 1
        and not inflight.marked_for_pause
        and partial_snapshot["aged_reservation_active"] == 1
        and partial_snapshot["aged_reservation_gap_capacity"] == 100
        and partial_snapshot["counters"]["aged_reservation_partial_ticks"] == 1
        and partial_snapshot["counters"][
            "aged_reservation_no_safe_victim_ticks"
        ]
        == 1
    )

    # Once that backend request finishes, an immediate ACTING->REASONING
    # re-entry is stopped before it becomes in-flight and cannot steal the
    # owner's reserved pages.
    await scheduler.finish_request(
        inflight, total_tokens=900, prompt_tokens=900
    )
    reentry_task = asyncio.create_task(scheduler.begin_request(inflight, 4500))
    await asyncio.sleep(0)
    reentry_blocked_before_backend = (
        inflight.lifecycle == Lifecycle.PAUSED
        and inflight.request_pending
        and inflight.inflight_requests == 0
    )
    await scheduler.schedule_once()
    reentry_snapshot = await scheduler.snapshot()
    reentry_task.cancel()
    try:
        await reentry_task
    except asyncio.CancelledError:
        pass
    await scheduler.cancel_waiting_request(inflight)
    results.append(
        {
            "name": "aged_reservation_blocks_reentry_without_pausing_inflight",
            "passed": (
                partial_state_safe
                and reentry_blocked_before_backend
                and blocked_owner.lifecycle == Lifecycle.ACTIVE
                and reentry_snapshot["aged_reservation_active"] == 0
                and reentry_snapshot["counters"][
                    "pause_admission_aged_reservation"
                ]
                == 1
                and reentry_snapshot["counters"][
                    "aged_reservation_blocked_reentry"
                ]
                == 1
                and reentry_snapshot["counters"][
                    "pause_admission_reentry"
                ]
                == 1
                and reentry_snapshot["counters"][
                    "aged_reservation_post_commit_capacity_violations"
                ]
                == 0
            ),
        }
    )

    # Rescue victims are a deliberately narrower set than generic pressure
    # victims.  Even malformed/transition-edge ACTING states must be excluded
    # if they are pending, in-flight, releasing, or already marked.
    scheduler = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
    )
    reasoning = await scheduler.get_or_create_program("victim-filter-reasoning")
    reasoning.total_tokens = 700
    reasoning.status = Status.REASONING
    reasoning.inflight_requests = 1
    unsafe_inflight = await scheduler.get_or_create_program(
        "victim-filter-inflight-acting"
    )
    unsafe_inflight.total_tokens = 50
    unsafe_inflight.status = Status.ACTING
    unsafe_inflight.inflight_requests = 1
    unsafe_pending = await scheduler.get_or_create_program(
        "victim-filter-pending-acting"
    )
    unsafe_pending.total_tokens = 50
    unsafe_pending.status = Status.ACTING
    unsafe_pending.request_pending = True
    unsafe_releasing = await scheduler.get_or_create_program(
        "victim-filter-releasing-acting"
    )
    unsafe_releasing.total_tokens = 50
    unsafe_releasing.status = Status.ACTING
    unsafe_releasing.release_requested = True
    unsafe_marked = await scheduler.get_or_create_program(
        "victim-filter-marked-acting"
    )
    unsafe_marked.total_tokens = 50
    unsafe_marked.status = Status.ACTING
    unsafe_marked.marked_for_pause = True
    filter_owner = await scheduler.get_or_create_program("victim-filter-owner")
    filter_owner.total_tokens = 400
    filter_owner.status = Status.REASONING
    filter_owner.step_count = 2
    filter_owner.request_pending = True
    scheduler._pause_locked(filter_owner)
    filter_owner.request_wait_started_monotonic = time.monotonic() - 241.0
    await scheduler.schedule_once()
    victim_filter_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_reservation_never_pauses_unsafe_victim_states",
            "passed": (
                filter_owner.lifecycle == Lifecycle.PAUSED
                and reasoning.lifecycle == Lifecycle.ACTIVE
                and unsafe_inflight.lifecycle == Lifecycle.ACTIVE
                and unsafe_pending.lifecycle == Lifecycle.ACTIVE
                and unsafe_releasing.lifecycle == Lifecycle.ACTIVE
                and unsafe_marked.lifecycle == Lifecycle.ACTIVE
                and victim_filter_snapshot["aged_reservation_active"] == 1
                and victim_filter_snapshot["counters"][
                    "aged_reservation_victims_paused"
                ]
                == 0
                and victim_filter_snapshot["counters"][
                    "aged_reservation_no_safe_victim_ticks"
                ]
                == 1
            ),
        }
    )

    # Hybrid rescue uses full phase-aware pages, not decayed ACTING attention.
    # 1,469 tokens crosses an attention-page boundary: the ACTING victim costs
    # five pages and the pending REASONING owner costs seven.
    small_qwen_accounting = Accounting(
        raw_gpu_blocks=11,
        reserved_null_blocks=0,
        attention_page_tokens=1568,
        mamba_group_count=3,
        mamba_resident_pages_per_group=1,
        mamba_peak_pages_per_group=2,
        reported_logical_capacity_tokens=1,
    )
    scheduler = Scheduler(
        capacity_tokens=1,
        buffer_per_program=100,
        hybrid_page_accounting=small_qwen_accounting,
        fair_wait_threshold_sec=240.0,
    )
    decayed_victim = await scheduler.get_or_create_program(
        "qwen-full-page-victim"
    )
    decayed_victim.total_tokens = 1469
    decayed_victim.status = Status.ACTING
    decayed_victim.acting_since = time.time() - 10.0
    qwen_owner = await scheduler.get_or_create_program("qwen-full-page-owner")
    qwen_owner.total_tokens = 1468
    qwen_owner.status = Status.REASONING
    qwen_owner.step_count = 2
    qwen_owner.request_pending = True
    scheduler._pause_locked(qwen_owner)
    qwen_owner.request_wait_started_monotonic = time.monotonic() - 241.0
    await scheduler.schedule_once()
    qwen_reservation_snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "aged_reservation_uses_full_qwen_phase_aware_pages",
            "passed": (
                decayed_victim.lifecycle == Lifecycle.PAUSED
                and qwen_owner.lifecycle == Lifecycle.ACTIVE
                and qwen_reservation_snapshot["tracked_pages_full"] == 7
                and qwen_reservation_snapshot["capacity_overflow_pages"] == 0
                and qwen_reservation_snapshot[
                    "aged_reservation_required_capacity_peak"
                ]
                == 7
                and qwen_reservation_snapshot[
                    "aged_reservation_gap_capacity_peak"
                ]
                == 1
                and qwen_reservation_snapshot["counters"][
                    "aged_reservation_capacity_freed"
                ]
                == 5
            ),
        }
    )

    # An impossible oldest request must not create permanent head-of-line
    # blocking.  It is recorded once, skipped, and the next feasible aged
    # request becomes the single reservation owner in the same tick.
    scheduler = Scheduler(
        capacity_tokens=100,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
    )
    anchor = await scheduler.get_or_create_program("oversize-transfer-anchor")
    anchor.total_tokens = 60
    anchor.status = Status.REASONING
    oversize = await scheduler.get_or_create_program("oversize-aged-owner")
    oversize.total_tokens = 150
    oversize.status = Status.REASONING
    oversize.step_count = 2
    oversize.request_pending = True
    scheduler._pause_locked(oversize)
    oversize.request_wait_started_monotonic = time.monotonic() - 242.0
    feasible = await scheduler.get_or_create_program("feasible-aged-owner")
    feasible.total_tokens = 40
    feasible.status = Status.REASONING
    feasible.step_count = 2
    feasible.request_pending = True
    scheduler._pause_locked(feasible)
    feasible.request_wait_started_monotonic = time.monotonic() - 241.0
    await scheduler.schedule_once()
    oversize_snapshot = await scheduler.snapshot()
    await scheduler.schedule_once()
    oversize_snapshot_second = await scheduler.snapshot()
    results.append(
        {
            "name": "oversize_aged_owner_is_skipped_and_transferred_once",
            "passed": (
                oversize.lifecycle == Lifecycle.PAUSED
                and feasible.lifecycle == Lifecycle.ACTIVE
                and oversize_snapshot["aged_reservation_active"] == 0
                and oversize_snapshot["counters"][
                    "aged_reservation_oversize"
                ]
                == 1
                and oversize_snapshot_second["counters"][
                    "aged_reservation_oversize"
                ]
                == 1
                and oversize_snapshot["counters"][
                    "aged_reservation_started"
                ]
                == 1
                and oversize_snapshot["counters"][
                    "aged_reservation_satisfied"
                ]
                == 1
            ),
        }
    )

    # Releasing an unsatisfied owner clears its reservation.  The next oldest
    # feasible request can take ownership and resume after real capacity is
    # released; no stale owner/gap gauge survives.
    scheduler = Scheduler(
        capacity_tokens=100,
        buffer_per_program=0,
        fair_wait_threshold_sec=240.0,
    )
    anchor = await scheduler.get_or_create_program("cancel-transfer-anchor")
    anchor.total_tokens = 100
    anchor.status = Status.REASONING
    cancelled_owner = await scheduler.get_or_create_program(
        "cancelled-reservation-owner"
    )
    cancelled_owner.total_tokens = 20
    cancelled_owner.status = Status.REASONING
    cancelled_owner.step_count = 2
    cancelled_owner.request_pending = True
    scheduler._pause_locked(cancelled_owner)
    cancelled_owner.request_wait_started_monotonic = time.monotonic() - 242.0
    next_owner = await scheduler.get_or_create_program("next-reservation-owner")
    next_owner.total_tokens = 30
    next_owner.status = Status.REASONING
    next_owner.step_count = 2
    next_owner.request_pending = True
    scheduler._pause_locked(next_owner)
    next_owner.request_wait_started_monotonic = time.monotonic() - 241.0
    await scheduler.schedule_once()
    before_owner_release = await scheduler.snapshot()
    await scheduler.release_program(cancelled_owner.program_id)
    immediately_transferred_snapshot = await scheduler.snapshot()
    await scheduler.schedule_once()
    transferred_snapshot = await scheduler.snapshot()
    await scheduler.release_program(anchor.program_id)
    await scheduler.schedule_once()
    after_transfer_resume = await scheduler.snapshot()
    results.append(
        {
            "name": "reservation_owner_release_clears_and_transfers",
            "passed": (
                before_owner_release["aged_reservation_active"] == 1
                and immediately_transferred_snapshot[
                    "aged_reservation_active"
                ]
                == 1
                and immediately_transferred_snapshot[
                    "aged_reservation_required_capacity"
                ]
                == 30
                and transferred_snapshot["aged_reservation_active"] == 1
                and transferred_snapshot["counters"][
                    "aged_reservation_started"
                ]
                == 2
                and transferred_snapshot["counters"][
                    "aged_reservation_cancelled"
                ]
                == 1
                and next_owner.lifecycle == Lifecycle.ACTIVE
                and after_transfer_resume["aged_reservation_active"] == 0
                and after_transfer_resume["aged_reservation_required_capacity"]
                == 0
                and after_transfer_resume["aged_reservation_gap_capacity"] == 0
                and after_transfer_resume["counters"][
                    "aged_reservation_satisfied"
                ]
                == 1
            ),
        }
    )

    # Backend usage replaces the request-side estimate and updates the global
    # chars/token estimator with ThunderAgent's 0.2/0.8 momentum rule.
    scheduler = Scheduler(capacity_tokens=10_000, buffer_per_program=0)
    program = await scheduler.get_or_create_program("usage")
    await scheduler.begin_request(program, 1000)
    estimated = program.total_tokens
    await scheduler.finish_request(
        program, total_tokens=321, prompt_tokens=200
    )
    first_ratio = scheduler.char_to_token_ratio
    await scheduler.begin_request(program, 1200)
    await scheduler.finish_request(
        program, total_tokens=400, prompt_tokens=200
    )
    results.append(
        {
            "name": "usage_reconciles_estimate_and_updates_ratio",
            "passed": (
                estimated == 200
                and first_ratio == 5.0
                and abs(scheduler.char_to_token_ratio - 5.2) < 1e-9
                and program.total_tokens == 400
                and program.status == Status.ACTING
            ),
        }
    )

    scheduler = Scheduler(capacity_tokens=10_000, buffer_per_program=0)
    program = await scheduler.get_or_create_program("streaming-usage")
    await scheduler.begin_request(program, 1000)
    estimate_before_stream = program.total_tokens
    await scheduler.update_streaming_tokens(program, 20)
    estimate_during_stream = program.total_tokens
    await scheduler.finish_request(
        program, total_tokens=333, prompt_tokens=200
    )
    results.append(
        {
            "name": "streaming_progress_grows_then_final_usage_reconciles",
            "passed": (
                estimate_during_stream == estimate_before_stream + 20
                and program.total_tokens == 333
            ),
        }
    )

    # Explicit lifecycle termination is the upstream mini-SWE integration's GC
    # signal and must free both active and waiting bookkeeping.
    scheduler._pause_locked(program)
    found, released = await scheduler.release_program("streaming-usage")
    snapshot = await scheduler.snapshot()
    results.append(
        {
            "name": "program_release_clears_working_set",
            "passed": (
                found
                and released
                and "streaming-usage" not in scheduler.programs
                and "streaming-usage" not in scheduler.waiting
                and snapshot["programs"] == 0
            ),
        }
    )

    # A release that races an admitted backend request must retain accounting
    # until the request's completion path runs.
    scheduler = Scheduler(capacity_tokens=10_000, buffer_per_program=0)
    program = await scheduler.get_or_create_program("inflight-release")
    await scheduler.begin_request(program, 1000)
    found, released = await scheduler.release_program("inflight-release")
    retained = "inflight-release" in scheduler.programs
    await scheduler.finish_request(
        program, total_tokens=250, prompt_tokens=200
    )
    results.append(
        {
            "name": "inflight_release_is_deferred_until_request_finishes",
            "passed": (
                found
                and not released
                and retained
                and "inflight-release" not in scheduler.programs
            ),
        }
    )

    # The qualification evidence is sampled after every program has sent its
    # lifecycle release.  Preserve the high-water mark across that cleanup,
    # and expose whether the background scheduling loop was actually alive.
    scheduler = Scheduler(
        capacity_tokens=10_000,
        buffer_per_program=0,
        scheduler_interval_sec=3600.0,
    )
    before_start = await scheduler.snapshot()
    await scheduler.start()
    after_start = await scheduler.snapshot()
    peak_one = await scheduler.get_or_create_program("peak-one")
    peak_two = await scheduler.get_or_create_program("peak-two")
    at_peak = await scheduler.snapshot()
    await scheduler.release_program(peak_one.program_id)
    await scheduler.release_program(peak_two.program_id)
    after_release = await scheduler.snapshot()
    await scheduler.stop()
    after_stop = await scheduler.snapshot()
    results.append(
        {
            "name": "program_peak_survives_release_and_scheduler_liveness_tracks_task",
            "passed": (
                before_start["scheduler_task_alive"] is False
                and after_start["scheduler_task_alive"] is True
                and at_peak["programs"] == 2
                and at_peak["programs_peak"] == 2
                and after_release["programs"] == 0
                and after_release["programs_peak"] == 2
                and after_release["scheduler_task_alive"] is True
                and after_stop["programs_peak"] == 2
                and after_stop["scheduler_task_alive"] is False
            ),
        }
    )

    # Match upstream liveness: one unexpected tick exception is recorded but
    # does not permanently terminate the background scheduler.
    scheduler = Scheduler(
        capacity_tokens=10_000,
        buffer_per_program=0,
        scheduler_interval_sec=0.001,
    )
    scheduler_calls = 0

    async def flaky_schedule_once() -> None:
        nonlocal scheduler_calls
        scheduler_calls += 1
        if scheduler_calls == 1:
            raise RuntimeError("injected scheduler tick failure")

    scheduler.schedule_once = flaky_schedule_once
    await scheduler.start()
    for _ in range(100):
        if scheduler_calls >= 2:
            break
        await asyncio.sleep(0.001)
    after_recovery = await scheduler.snapshot()
    await scheduler.stop()
    results.append(
        {
            "name": "scheduler_tick_exception_is_counted_and_loop_recovers",
            "passed": (
                scheduler_calls >= 2
                and after_recovery["scheduler_task_alive"] is True
                and after_recovery["counters"]["scheduler_errors"] == 1
                and after_recovery["last_scheduler_error"] == "RuntimeError"
            ),
        }
    )

    return results


def tree_sha256() -> str:
    root = GATEWAY_PATH.parent
    records: list[bytes] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink() or (not path.is_dir() and not path.is_file()):
            raise RuntimeError(f"invalid entry in Oracle reference tree: {relative.as_posix()}")
        if path.is_dir():
            continue
        payload = path.read_bytes()
        records.append(
            json.dumps(
                {
                    "path": relative.as_posix(),
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "size": len(payload),
                },
                separators=(",", ":"),
                sort_keys=True,
            ).encode()
        )
    digest = hashlib.sha256(b"reference-gateway-tree-v1\n")
    for record in records:
        digest.update(record)
        digest.update(b"\n")
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    cases = source_contract_checks() + asyncio.run(scheduler_checks())
    report = {
        "schema_version": 2,
        "kind": "reference-thunderagent-scheduler-unit",
        "reference_gateway_tree_sha256": tree_sha256(),
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered, end="")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
