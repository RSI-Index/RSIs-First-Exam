#!/usr/bin/env python3
"""Ensure human-readable kvbench output preserves public pair lineage."""

from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import os
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
CLI_PATH = TASK_ROOT / "environment" / "kvbench.py"
SPEC = importlib.util.spec_from_file_location("kvbench_public_cli_unit", CLI_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def invoke(argv: list[str], payload: dict[str, Any]) -> tuple[int, str, list[tuple[Any, ...]]]:
    original_request = MODULE.request
    original_argv = sys.argv
    original_submission_root = MODULE.SUBMISSION_ROOT
    original_eval_root = MODULE.EVAL_ROOT
    original_capture = os.environ.get("KVBENCH_CAPTURE_CANDIDATE_EVAL")
    calls: list[tuple[Any, ...]] = []

    def fake_request(*args: Any, **kwargs: Any) -> dict[str, Any]:
        calls.append((*args, kwargs))
        return payload

    output = io.StringIO()
    try:
        with tempfile.TemporaryDirectory(prefix="kvbench-cli-unit-") as raw:
            root = Path(raw)
            submission = root / "submission"
            submission.mkdir()
            (submission / "launch.sh").write_text("#!/bin/sh\nexec true\n")
            (submission / "launch.sh").chmod(0o755)
            (submission / "gateway.py").write_text("print('unit')\n")
            MODULE.SUBMISSION_ROOT = submission
            MODULE.EVAL_ROOT = root / "public_evals"
            os.environ["KVBENCH_CAPTURE_CANDIDATE_EVAL"] = "1"
            MODULE.request = fake_request
            sys.argv = ["kvbench", *argv]
            with contextlib.redirect_stdout(output):
                return_code = MODULE.main()
    finally:
        MODULE.request = original_request
        MODULE.SUBMISSION_ROOT = original_submission_root
        MODULE.EVAL_ROOT = original_eval_root
        if original_capture is None:
            os.environ.pop("KVBENCH_CAPTURE_CANDIDATE_EVAL", None)
        else:
            os.environ["KVBENCH_CAPTURE_CANDIDATE_EVAL"] = original_capture
        sys.argv = original_argv
    return return_code, output.getvalue(), calls


def main() -> int:
    candidate_payload = {
        "pair_id": "public-pressure-192-candidate",
        "baseline_anchor_pair_id": "public-pressure-192-anchor",
        "parent_pair_id": "public-pressure-192-parent",
        "summary": {"run_id": "candidate-run"},
        "text": "candidate metrics",
    }
    run_rc, run_output, run_calls = invoke(
        ["run", "--mode", "candidate", "--profile", "public-pressure-192"],
        candidate_payload,
    )
    debug_rc, debug_output, debug_calls = invoke(
        ["run", "--mode", "candidate", "--profile", "public-12"],
        candidate_payload,
    )
    compare_payload = {
        **candidate_payload,
        "kind": "kvbench-public-compare",
        "status": "valid",
        "speedup": 1.1,
        "text": "comparison metrics",
    }
    compare_rc, compare_output, compare_calls = invoke(
        ["compare", "--profile", "public-pressure-192"],
        compare_payload,
    )
    json_rc, json_output, json_calls = invoke(
        ["compare", "--profile", "public-pressure-192", "--json"],
        compare_payload,
    )
    baseline_payload = {
        "pair_id": "public-pressure-192-anchor",
        "baseline_anchor_pair_id": "public-pressure-192-anchor",
        "parent_pair_id": None,
        "text": "baseline metrics",
    }
    baseline_rc, baseline_output, _baseline_calls = invoke(
        ["run", "--mode", "baseline", "--profile", "public-pressure-192"],
        baseline_payload,
    )

    original_submission_root = MODULE.SUBMISSION_ROOT
    original_eval_root = MODULE.EVAL_ROOT
    artifact_checks: dict[str, bool] = {}
    try:
        with tempfile.TemporaryDirectory(prefix="kvbench-eval-artifact-unit-") as raw:
            root = Path(raw)
            submission = root / "submission"
            submission.mkdir()
            gateway = submission / "gateway.py"
            gateway.write_text("VERSION = 1\n")
            launch = submission / "launch.sh"
            launch.write_text("#!/bin/sh\nexec python3 gateway.py\n")
            launch.chmod(0o755)
            MODULE.SUBMISSION_ROOT = submission
            MODULE.EVAL_ROOT = root / "public_evals"
            evaluation = MODULE.begin_candidate_eval("public-pressure-192")
            gateway.write_text("VERSION = 2\n")
            completed = MODULE.finish_candidate_eval(
                *evaluation,
                candidate_result={
                    "pair_id": "pair-unit",
                    "summary": {"run_id": "candidate-unit"},
                },
                comparison={"status": "valid", "speedup": 1.125},
                error=None,
            )
            metadata = json.loads((completed / "metadata.json").read_text())
            with tarfile.open(completed / "code_snapshot.tar.gz") as archive:
                archived_gateway = archive.extractfile("submission/gateway.py")
                archived_text = archived_gateway.read().decode() if archived_gateway else ""
            artifact_checks = {
                "candidate_eval_has_monotonic_version": (
                    completed.name == "eval_000001.COMPLETE"
                    and metadata["eval_id"] == 1
                    and metadata["version"] == "v000001"
                ),
                "snapshot_precedes_live_candidate_run": (
                    (completed / "code" / "gateway.py").read_text() == "VERSION = 1\n"
                    and archived_text == "VERSION = 1\n"
                    and gateway.read_text() == "VERSION = 2\n"
                ),
                "result_and_comparison_are_self_contained": (
                    json.loads((completed / "candidate_result.json").read_text())["pair_id"]
                    == "pair-unit"
                    and json.loads((completed / "compare.json").read_text())["speedup"]
                    == 1.125
                    and metadata["speedup"] == 1.125
                    and metadata["comparison_status"] == "valid"
                ),
                "latest_and_history_point_to_completed_eval": (
                    json.loads((MODULE.EVAL_ROOT / "latest.json").read_text())["artifact_dir"]
                    == str(completed)
                    and len((MODULE.EVAL_ROOT / "history.jsonl").read_text().splitlines()) == 1
                ),
            }
    finally:
        MODULE.SUBMISSION_ROOT = original_submission_root
        MODULE.EVAL_ROOT = original_eval_root

    checks = {
        "run_text_preserves_full_lineage": run_rc == 0
        and run_output
        == (
            "pair_id: public-pressure-192-candidate\n"
            "baseline_anchor_pair_id: public-pressure-192-anchor\n"
            "parent_pair_id: public-pressure-192-parent\n"
            "candidate metrics\n"
        ),
        "compare_text_preserves_full_lineage": compare_rc == 0
        and compare_output
        == (
            "pair_id: public-pressure-192-candidate\n"
            "baseline_anchor_pair_id: public-pressure-192-anchor\n"
            "parent_pair_id: public-pressure-192-parent\n"
            "comparison metrics\n"
        ),
        "baseline_text_preserves_explicit_root_parent": baseline_rc == 0
        and "parent_pair_id: none\n" in baseline_output,
        "json_mode_is_lossless": json_rc == 0
        and json.loads(json_output) == compare_payload,
        "candidate_run_snapshots_then_collects_comparison": (
            len(run_calls) == 2
            and run_calls[0][0:3]
            == ("POST", "/public/run", {"mode": "candidate", "profile": "public-pressure-192"})
            and run_calls[1][0:2]
            == ("GET", "/public/compare?profile=public-pressure-192")
        ),
        "only_pressure_candidate_runs_are_snapshotted": (
            debug_rc == 0
            and len(debug_calls) == 1
            and debug_calls[0][0:3]
            == ("POST", "/public/run", {"mode": "candidate", "profile": "public-12"})
            and "candidate_eval_artifact" not in debug_output
            and MODULE.SNAPSHOT_PROFILE == "public-pressure-192"
        ),
        "other_commands_keep_existing_controller_routes": (
            len(compare_calls) == len(json_calls) == 1
            and compare_calls[0][0:2]
            == ("GET", "/public/compare?profile=public-pressure-192")
            and json_calls[0][0:2]
            == ("GET", "/public/compare?profile=public-pressure-192")
        ),
        **artifact_checks,
    }
    report = {
        "schema_version": 1,
        "kind": "public-cli-lineage-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
