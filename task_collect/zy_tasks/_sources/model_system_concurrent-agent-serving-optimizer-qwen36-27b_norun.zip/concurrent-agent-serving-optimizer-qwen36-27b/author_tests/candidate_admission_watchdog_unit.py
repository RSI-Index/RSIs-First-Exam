#!/usr/bin/env python3
"""Cancellation and chunked-stream contracts for candidate admission watchdogs."""

from __future__ import annotations

import hashlib
import hmac
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from runner.ledger import Ledger
from runner.model import (
    BenchmarkVllmModel,
    ModelConfig,
    RequestCancelled,
    ResponseLimitExceeded,
    benchmark_auth_message,
    cancellable_connection,
)
import runner.workload as workload
from runner.workload import (
    candidate_leg_wall_timeout_sec,
    model_response_limit_failure,
    verify_audit,
)


EVENT_STREAM = (
    b'data: {"choices":[{"delta":{"content":"chunked-ok"}}]}\n\n'
    b'data: {"choices":[],"usage":{"prompt_tokens":5,"completion_tokens":2,"total_tokens":7}}\n\n'
    b"data: [DONE]\n\n"
)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 16
    mode: str
    received: threading.Event
    release: threading.Event
    request_count: int
    request_bodies: list[dict[str, Any]]
    request_headers: list[dict[str, str]]
    audit_records: list[dict[str, Any]]

    def handle_error(self, _request: object, _client_address: object) -> None:
        # Expected when the watchdog shuts down a connection concurrently with
        # this intentionally stalled test server's first keep-alive write.
        return


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def write_chunk(self, body: bytes) -> None:
        self.wfile.write(f"{len(body):x}\r\n".encode() + body + b"\r\n")
        self.wfile.flush()

    def do_POST(self) -> None:  # noqa: N802
        started = time.time()
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        self.server.request_count += 1  # type: ignore[attr-defined]
        self.server.request_bodies.append(json.loads(raw))  # type: ignore[attr-defined]
        self.server.request_headers.append(  # type: ignore[attr-defined]
            {
                "auth": self.headers.get("X-KVBench-Auth", ""),
                "audit_epoch": self.headers.get("X-KVBench-Audit-Epoch", ""),
                "body_digest": self.headers.get("X-KVBench-Body-SHA256", ""),
                "request_id": self.headers.get("X-KVBench-Request-ID", ""),
            }
        )
        self.server.received.set()  # type: ignore[attr-defined]
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()
        if self.server.mode == "chunked":  # type: ignore[attr-defined]
            # Split in the middle of SSE lines.  HTTPResponse must remove the
            # transfer framing while preserving the logical byte stream.
            for start, end in ((0, 7), (7, 41), (41, 89), (89, len(EVENT_STREAM))):
                self.write_chunk(EVENT_STREAM[start:end])
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
            usage = {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7}
            self.server.audit_records.append(  # type: ignore[attr-defined]
                {
                    "audit_epoch": 7,
                    "request_id": self.headers.get("X-KVBench-Request-ID"),
                    "run_id": self.headers.get("X-Agent-Run-ID"),
                    "profile": self.headers.get("X-KVBench-Profile"),
                    "leg_id": self.headers.get("X-KVBench-Leg"),
                    "cache_namespace": self.headers.get("X-KVBench-Cache-Namespace"),
                    "canonical_body_digest": hashlib.sha256(raw).hexdigest(),
                    "response_digest": hashlib.sha256(EVENT_STREAM).hexdigest(),
                    "status": 200,
                    **usage,
                    "sse_done": True,
                    "benchmark_auth_valid": True,
                    "client_disconnected": False,
                    "error": None,
                    "started_unix": started,
                    "ended_unix": time.time(),
                }
            )
            return
        if self.server.mode == "long-line":  # type: ignore[attr-defined]
            self.write_chunk(b"data: " + b"x" * 256)
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
            return
        if self.server.mode == "large-total":  # type: ignore[attr-defined]
            for index in range(20):
                self.write_chunk(f": keepalive-{index:02d}-abcdefghijklmnop\n".encode())
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
            return
        # Send a legal keep-alive/comment chunk before stalling.  A plain
        # socket timeout is not a trusted cancellation mechanism because an
        # untrusted gateway can continue to trickle such chunks.
        self.write_chunk(b": candidate-keepalive\n\n")
        self.server.release.wait(10)  # type: ignore[attr-defined]


def model(
    server: Server,
    ledger: Ledger,
    *,
    cancel_event: threading.Event | None = None,
    max_sse_line_bytes: int = 1024 * 1024,
    max_response_bytes: int = 8 * 1024 * 1024,
) -> BenchmarkVllmModel:
    return BenchmarkVllmModel(
        endpoint=f"http://127.0.0.1:{server.server_port}/v1",
        run_id="opaque-run",
        profile="opaque-profile",
        leg_id="opaque-leg",
        cache_namespace="opaque-cache",
        seed=7,
        admin_token="unit-token",
        audit_epoch=7,
        ledger=ledger,
        config=ModelConfig(max_tokens=16),
        request_timeout_sec=30,
        cancel_event=cancel_event,
        max_sse_line_bytes=max_sse_line_bytes,
        max_response_bytes=max_response_bytes,
    )


def make_server(mode: str) -> tuple[Server, threading.Thread]:
    server = Server(("127.0.0.1", 0), Handler)
    server.mode = mode
    server.received = threading.Event()
    server.release = threading.Event()
    server.request_count = 0
    server.request_bodies = []
    server.request_headers = []
    server.audit_records = []
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


def stop_server(server: Server, thread: threading.Thread) -> None:
    server.release.set()
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)


def chunked_stream_case() -> dict[str, Any]:
    server, thread = make_server("chunked")
    ledger = Ledger()
    try:
        response = model(server, ledger).query([{"role": "user", "content": "hello"}])
    finally:
        stop_server(server, thread)
    records = ledger.snapshot()
    record = records[0] if records else {}
    audit = verify_audit(records, server.audit_records)
    sent_headers = server.request_headers[0] if server.request_headers else {}
    expected_auth = hmac.new(
        b"unit-token",
        benchmark_auth_message(
            audit_epoch=7,
            method="POST",
            path="/v1/chat/completions",
            request_id=sent_headers.get("request_id", ""),
            run_id="opaque-run",
            profile="opaque-profile",
            leg_id="opaque-leg",
            cache_namespace="opaque-cache",
            body_digest=str(record.get("canonical_body_digest", "")),
        ),
        hashlib.sha256,
    ).hexdigest()
    return {
        "name": "chunked_sse_preserves_payload_digest_usage_and_one_to_one_ledger",
        "passed": response == {"content": "chunked-ok"}
        and server.request_count == 1
        and len(records) == 1
        and ledger.activity_snapshot()["active_requests"] == 0
        and record.get("status") == 200
        and record.get("total_tokens") == 7
        and record.get("first_token_unix") is not None
        and record.get("sse_done") is True
        and record.get("response_bytes") == len(EVENT_STREAM)
        and record.get("response_digest") == hashlib.sha256(EVENT_STREAM).hexdigest()
        and sent_headers.get("audit_epoch") == "7"
        and sent_headers.get("body_digest") == record.get("canonical_body_digest")
        and hmac.compare_digest(sent_headers.get("auth", ""), expected_auth)
        and audit["passed"] is True
        and audit["client_requests"] == audit["audited_backend_requests"] == 1,
        "record": record,
        "audit": audit,
    }


def active_connection_cancellation_case() -> dict[str, Any]:
    server, server_thread = make_server("stall")
    ledger = Ledger()
    observed: dict[str, Any] = {}

    def query() -> None:
        try:
            model(server, ledger).query([{"role": "user", "content": "stall"}])
            observed["result"] = "unexpected-success"
        except Exception as exc:
            observed["type"] = type(exc).__name__
            observed["error"] = str(exc)

    query_thread = threading.Thread(target=query)
    query_thread.start()
    try:
        received = server.received.wait(2)
        deadline = time.monotonic() + 2
        while ledger.activity_snapshot()["active_requests"] != 1 and time.monotonic() < deadline:
            time.sleep(0.001)
        started = time.monotonic()
        cancellation = ledger.cancel_active("candidate_gateway_admission_stall:test")
        query_thread.join(timeout=2)
        cancellation_latency = time.monotonic() - started
    finally:
        stop_server(server, server_thread)
        query_thread.join(timeout=2)
    records = ledger.snapshot()
    record = records[0] if records else {}
    return {
        "name": "watchdog_shutdown_interrupts_a_trickling_candidate_connection",
        "passed": received
        and not query_thread.is_alive()
        and cancellation_latency < 1.0
        and observed.get("type") == RequestCancelled.__name__
        and "candidate_gateway_admission_stall:test" in observed.get("error", "")
        and cancellation["active_requests"] == 1
        and cancellation["newly_cancelled_requests"] == 1
        and cancellation["cancel_callbacks"] == 1
        and len(records) == 1
        and record.get("status") in {200, 599}
        and str(record.get("error", "")).startswith("RequestCancelled:")
        and ledger.activity_snapshot()["active_requests"] == 0
        and server.request_count == 1,
        "cancellation_latency_sec": cancellation_latency,
        "cancellation": cancellation,
        "observed": observed,
        "record": record,
    }


def response_limit_case(
    mode: str,
    *,
    line_limit: int,
    total_limit: int,
    expected_kind: str,
) -> dict[str, Any]:
    server, server_thread = make_server(mode)
    ledger = Ledger()
    cancel_event = threading.Event()
    observed: dict[str, Any] = {}
    try:
        try:
            model(
                server,
                ledger,
                cancel_event=cancel_event,
                max_sse_line_bytes=line_limit,
                max_response_bytes=total_limit,
            ).query([{"role": "user", "content": mode}])
            observed["result"] = "unexpected-success"
        except Exception as exc:
            observed["type"] = type(exc).__name__
            observed["error"] = str(exc)
    finally:
        stop_server(server, server_thread)
    records = ledger.snapshot()
    record = records[0] if records else {}
    failure = model_response_limit_failure(records)
    limit = record.get("response_limit") or {}
    return {
        "name": f"{mode}_is_bounded_and_classified",
        "passed": observed.get("type") == ResponseLimitExceeded.__name__
        and cancel_event.is_set()
        and ledger.activity_snapshot()["active_requests"] == 0
        and server.request_count == 1
        and len(records) == 1
        and limit.get("kind") == expected_kind
        and isinstance(limit.get("observed_bytes"), int)
        and limit["observed_bytes"] > limit.get("limit_bytes", 0)
        and failure is not None
        and failure["type"] == "model_response_limit_exceeded"
        and expected_kind in failure["detail"],
        "observed": observed,
        "record": record,
        "failure": failure,
    }


def cancellation_registration_race_case() -> dict[str, Any]:
    ledger = Ledger()
    ledger.begin({"request_id": "race", "started_unix": time.time()})
    cancellation = ledger.cancel_active("race-cancel")
    observed: list[str] = []
    registered = ledger.register_canceller("race", observed.append)
    ledger.complete({"request_id": "race", "status": 599})
    return {
        "name": "cancellation_before_socket_registration_is_not_lost",
        "passed": registered is False
        and observed == ["race-cancel"]
        and cancellation["newly_cancelled_requests"] == 1
        and ledger.activity_snapshot()["active_requests"] == 0
        and len(ledger.snapshot()) == 1,
    }


def preconnect_cancellation_case() -> dict[str, Any]:
    connection, path = cancellable_connection("http://127.0.0.1:9/v1", 30)
    connection.cancel("cancel-before-connect")
    started = time.monotonic()
    error: str | None = None
    try:
        connection.request("POST", path, body=b"{}")
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    elapsed = time.monotonic() - started
    return {
        "name": "preconnect_cancellation_cannot_reopen_the_connection",
        "passed": error == "RequestCancelled: cancel-before-connect" and elapsed < 0.1,
        "elapsed_sec": elapsed,
        "error": error,
    }


def live_sampler_wiring_case() -> dict[str, Any]:
    ledger = Ledger()
    ledger.begin({"request_id": "sampler-active", "started_unix": time.time()})
    cancelled = threading.Event()
    ledger.register_canceller("sampler-active", lambda _reason: cancelled.set())
    calls: list[str] = []
    original_admin_json = workload.admin_json
    original_metric_point = workload.metric_point

    def fake_admin_json(
        method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
    ) -> dict[str, Any]:
        del timeout
        calls.append(f"{method}:{path}")
        if path == "/admin/metrics/snapshot":
            return {
                "active_backend_requests": 0,
                "audit_count": 0,
                "audit_epoch": 7,
            }
        if path == "/admin/requests/cancel":
            return {"cancelled_requests": 0}
        raise AssertionError(path)

    workload.admin_json = fake_admin_json
    workload.metric_point = lambda _snapshot: {
        "requests_running": 0.0,
        "requests_waiting": 0.0,
        "kv_cache_usage": 0.0,
    }
    sampler = workload.LiveMetricsSampler(
        "http://model-api:8100",
        "unit-token",
        0.01,
        5,
        30,
        mode="candidate",
        ledger=ledger,
        candidate_stall_timeout_sec=0.03,
        expected_audit_epoch=7,
    )
    try:
        sampler.start()
        fatal_observed = sampler.abort_event.wait(2)
        sampler.stop()
    finally:
        workload.admin_json = original_admin_json
        workload.metric_point = original_metric_point
    reason = ledger.cancellation_reason("sampler-active")
    ledger.complete({"request_id": "sampler-active", "status": 599})
    return {
        "name": "measured_candidate_sampler_cancels_zero_admission_client_requests",
        "passed": fatal_observed
        and cancelled.is_set()
        and sampler.fatal_type == "candidate_gateway_admission_stall"
        and reason is not None
        and "client_active=1" in reason
        and sampler.client_cancellation is not None
        and sampler.client_cancellation["newly_cancelled_requests"] == 1
        and "GET:/admin/quiescent" not in calls
        and "GET:/admin/audit/snapshot" not in calls
        and "POST:/admin/requests/cancel" in calls,
        "fatal_type": sampler.fatal_type,
        "fatal_error": sampler.fatal_error,
        "calls": calls,
    }


def invalid_lightweight_telemetry_case() -> dict[str, Any]:
    ledger = Ledger()
    calls: list[str] = []
    original_admin_json = workload.admin_json
    original_metric_point = workload.metric_point

    def fake_admin_json(
        method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
    ) -> dict[str, Any]:
        del timeout
        calls.append(f"{method}:{path}")
        if path == "/admin/metrics/snapshot":
            return {"active_backend_requests": 0, "audit_epoch": 3}
        if path == "/admin/requests/cancel":
            return {"cancelled_requests": 0}
        raise AssertionError(path)

    workload.admin_json = fake_admin_json
    workload.metric_point = lambda _snapshot: {
        "requests_running": 0.0,
        "requests_waiting": 0.0,
        "kv_cache_usage": 0.0,
    }
    sampler = workload.LiveMetricsSampler(
        "http://model-api:8100",
        "unit-token",
        0.01,
        5,
        30,
        mode="candidate",
        ledger=ledger,
        candidate_stall_timeout_sec=1,
        expected_audit_epoch=3,
    )
    try:
        sampler.start()
        fatal_observed = sampler.abort_event.wait(2)
        sampler.stop()
    finally:
        workload.admin_json = original_admin_json
        workload.metric_point = original_metric_point
    return {
        "name": "missing_lightweight_activity_field_fails_closed_without_full_audit_poll",
        "passed": fatal_observed
        and sampler.fatal_type == "candidate_watchdog_telemetry_invalid"
        and sampler.fatal_error is not None
        and "audit_count" in sampler.fatal_error
        and "GET:/admin/audit/snapshot" not in calls
        and "GET:/admin/quiescent" not in calls,
        "fatal_type": sampler.fatal_type,
        "fatal_error": sampler.fatal_error,
        "calls": calls,
    }


def candidate_leg_wall_deadline_case() -> dict[str, Any]:
    ledger = Ledger()
    ledger.begin({"request_id": "deadline-active", "started_unix": time.time()})
    socket_cancelled = threading.Event()
    ledger.register_canceller(
        "deadline-active", lambda _reason: socket_cancelled.set()
    )
    calls: list[str] = []
    original_admin_json = workload.admin_json
    original_metric_point = workload.metric_point

    def fake_admin_json(
        method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
    ) -> dict[str, Any]:
        del timeout
        calls.append(f"{method}:{path}")
        if path == "/admin/metrics/snapshot":
            return {
                "active_backend_requests": 1,
                "audit_count": 0,
                "audit_epoch": 9,
            }
        if path == "/admin/requests/cancel":
            return {"cancelled_requests": 1}
        raise AssertionError(path)

    workload.admin_json = fake_admin_json
    workload.metric_point = lambda _snapshot: {
        "requests_running": 1.0,
        "requests_waiting": 0.0,
        "kv_cache_usage": 0.1,
    }
    sampler = workload.LiveMetricsSampler(
        "http://model-api:8100",
        "unit-token",
        0.01,
        5,
        30,
        mode="candidate",
        ledger=ledger,
        candidate_stall_timeout_sec=1,
        candidate_leg_wall_timeout_sec=0.05,
        expected_audit_epoch=9,
    )
    started = time.monotonic()
    try:
        sampler.start()
        fatal_observed = sampler.abort_event.wait(2)
        sampler.stop()
    finally:
        workload.admin_json = original_admin_json
        workload.metric_point = original_metric_point
    elapsed = time.monotonic() - started
    reason = ledger.cancellation_reason("deadline-active")
    ledger.complete({"request_id": "deadline-active", "status": 599})
    return {
        "name": "candidate_leg_wall_timer_actively_cancels_client_and_backend",
        "passed": fatal_observed
        and elapsed < 1.0
        and socket_cancelled.is_set()
        and sampler.fatal_type == "candidate_leg_wall_timeout"
        and reason is not None
        and "timeout_sec=0.1" in reason
        and sampler.client_cancellation is not None
        and sampler.client_cancellation["newly_cancelled_requests"] == 1
        and "POST:/admin/requests/cancel" in calls,
        "elapsed_sec": elapsed,
        "fatal_type": sampler.fatal_type,
        "fatal_error": sampler.fatal_error,
        "calls": calls,
    }


def completed_agent_interval_disarms_deadline_case() -> dict[str, Any]:
    ledger = Ledger()
    complete = threading.Event()
    complete.set()
    calls: list[str] = []
    original_admin_json = workload.admin_json

    def fake_admin_json(
        method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
    ) -> dict[str, Any]:
        del timeout
        calls.append(f"{method}:{path}")
        raise AssertionError("completed agent execution must not poll or cancel")

    workload.admin_json = fake_admin_json
    sampler = workload.LiveMetricsSampler(
        "http://model-api:8100",
        "unit-token",
        0.01,
        5,
        30,
        mode="candidate",
        ledger=ledger,
        candidate_stall_timeout_sec=1,
        candidate_leg_wall_timeout_sec=0.05,
        expected_audit_epoch=9,
        agent_execution_complete_event=complete,
    )
    try:
        sampler.start()
        time.sleep(0.08)
        sampler.stop()
        # Exercise the second check inside _abort, representing completion
        # racing after the timer's first check but before it owns cancellation.
        sampler._abort("candidate_leg_wall_timeout", "late-race")
    finally:
        workload.admin_json = original_admin_json
    return {
        "name": "completed_agent_interval_disarms_candidate_deadline",
        "passed": not sampler.abort_event.is_set()
        and sampler.fatal_error is None
        and sampler.errors == []
        and calls == [],
        "fatal_error": sampler.fatal_error,
        "errors": sampler.errors,
        "calls": calls,
    }


def sampler_ignores_post_agent_completion_error_case() -> dict[str, Any]:
    complete = threading.Event()
    entered = threading.Event()
    release = threading.Event()
    original_admin_json = workload.admin_json

    def fake_admin_json(
        _method: str,
        _base: str,
        _path: str,
        _token: str,
        timeout: int = 60,
    ) -> dict[str, Any]:
        del timeout
        entered.set()
        if not release.wait(2):
            raise AssertionError("test did not release metrics request")
        raise RuntimeError("post-agent-teardown-error")

    workload.admin_json = fake_admin_json
    sampler = workload.LiveMetricsSampler(
        "http://model-api:8100",
        "unit-token",
        0.01,
        5,
        30,
        agent_execution_complete_event=complete,
    )
    try:
        sampler.start()
        request_started = entered.wait(2)
        complete.set()
        release.set()
        sampler.stop()
    finally:
        workload.admin_json = original_admin_json
    return {
        "name": "post_agent_completion_poll_error_is_not_measurement_error",
        "passed": request_started
        and sampler.errors == []
        and sampler.fatal_error is None
        and not sampler.abort_event.is_set(),
        "errors": sampler.errors,
    }


def model_response_limit_escalation_case() -> dict[str, Any]:
    ledger = Ledger()
    ledger.begin({"request_id": "limit-peer", "started_unix": time.time()})
    peer_cancelled = threading.Event()
    ledger.register_canceller("limit-peer", lambda _reason: peer_cancelled.set())
    calls: list[str] = []
    original_admin_json = workload.admin_json
    original_metric_point = workload.metric_point

    def fake_admin_json(
        method: str,
        _base: str,
        path: str,
        _token: str,
        timeout: int = 60,
    ) -> dict[str, Any]:
        del timeout
        calls.append(f"{method}:{path}")
        if path == "/admin/requests/cancel":
            return {"cancelled_requests": 2}
        if path == "/admin/metrics/snapshot":
            return {
                "active_backend_requests": 2,
                "audit_count": 0,
                "audit_epoch": 11,
            }
        raise AssertionError(path)

    workload.admin_json = fake_admin_json
    workload.metric_point = lambda _snapshot: {
        "requests_running": 2.0,
        "requests_waiting": 0.0,
        "kv_cache_usage": 0.1,
    }
    sampler = workload.LiveMetricsSampler(
        "http://model-api:8100",
        "unit-token",
        0.01,
        5,
        30,
        mode="candidate",
        ledger=ledger,
        candidate_stall_timeout_sec=1,
        expected_audit_epoch=11,
    )
    try:
        sampler.start()
        sampler.abort_event.set()
        fatal_observed = peer_cancelled.wait(2)
        sampler.stop()
    finally:
        workload.admin_json = original_admin_json
        workload.metric_point = original_metric_point
    reason = ledger.cancellation_reason("limit-peer")
    ledger.complete({"request_id": "limit-peer", "status": 599})
    return {
        "name": "client_response_limit_escalates_to_trusted_backend_cancellation",
        "passed": fatal_observed
        and sampler.fatal_type == "model_response_limit_exceeded"
        and reason is not None
        and "client_parser_limit" in reason
        and "POST:/admin/requests/cancel" in calls
        and sampler.fatal_error is not None
        and "backend_cancelled_requests=2" in sampler.fatal_error,
        "fatal_type": sampler.fatal_type,
        "fatal_error": sampler.fatal_error,
        "calls": calls,
    }


def derived_candidate_leg_deadline_case() -> dict[str, Any]:
    class ProfileShape:
        workflows = 192
        concurrency = 192
        workflow_timeout_sec = 4800

    observed = candidate_leg_wall_timeout_sec(ProfileShape())  # type: ignore[arg-type]
    return {
        "name": "candidate_leg_wall_is_derived_from_frozen_wave_and_workflow_budgets",
        "passed": observed == 4800,
        "observed_sec": observed,
    }


def main() -> int:
    cases = [
        chunked_stream_case(),
        response_limit_case(
            "long-line",
            line_limit=64,
            total_limit=256,
            expected_kind="sse_line_bytes",
        ),
        response_limit_case(
            "large-total",
            line_limit=64,
            total_limit=160,
            expected_kind="response_bytes",
        ),
        active_connection_cancellation_case(),
        cancellation_registration_race_case(),
        preconnect_cancellation_case(),
        live_sampler_wiring_case(),
        invalid_lightweight_telemetry_case(),
        candidate_leg_wall_deadline_case(),
        completed_agent_interval_disarms_deadline_case(),
        sampler_ignores_post_agent_completion_error_case(),
        model_response_limit_escalation_case(),
        derived_candidate_leg_deadline_case(),
    ]
    report = {
        "schema_version": 1,
        "kind": "candidate-admission-watchdog-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
