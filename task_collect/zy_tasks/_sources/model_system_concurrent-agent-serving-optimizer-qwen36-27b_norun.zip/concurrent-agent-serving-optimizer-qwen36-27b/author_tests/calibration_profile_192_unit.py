#!/usr/bin/env python3
"""CPU-only contract for the staged Qwen3.6 TP2 calibration matrix."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Callable

from runner.workload import Profile, candidate_leg_wall_timeout_sec, load_profiles


TASK_ROOT = Path(__file__).resolve().parents[1]
PROFILE_ROOT = TASK_ROOT / "environment" / "bench-controller" / "profiles"


def profile_config(
    *,
    workflows: int,
    concurrency: int,
    max_steps: int,
    workflow_timeout_sec: int,
    request_timeout_sec: int,
    seed: int,
    warmup_requests: int = 4,
    warmup_steps: int = 3,
    backend_stall_timeout_sec: int,
    candidate_admission_stall_timeout_sec: int,
    pressure: bool = False,
) -> dict[str, Any]:
    config: dict[str, Any] = {
        "enabled": True,
        "workflows": workflows,
        "concurrency": concurrency,
        "max_steps": max_steps,
        "context_bytes": 0,
        "max_tokens": 2048,
        "workflow_timeout_sec": workflow_timeout_sec,
        "request_timeout_sec": request_timeout_sec,
        "tool_delay_min_sec": 0.0,
        "tool_delay_max_sec": 0.0,
        "seed": seed,
        "warmup_requests": warmup_requests,
        "warmup_context_bytes": 0,
        "warmup_steps": warmup_steps,
        "workload_family": "swebench-lite",
        "corpus_partition": "public",
        "corpus_unique_instances_min": 6,
        "metrics_sample_interval_sec": 1.0,
        "metrics_request_timeout_sec": 30,
        "backend_stall_timeout_sec": backend_stall_timeout_sec,
        "candidate_admission_stall_timeout_sec": (
            candidate_admission_stall_timeout_sec
        ),
    }
    if pressure:
        config.update(
            {
                "pressure_required": True,
                "pressure_kv_threshold": 0.8,
                "pressure_kv_p95_min": 0.9,
                "pressure_time_fraction_min": 0.25,
                "pressure_min_samples": 60,
            }
        )
    return config


EXPECTED_PROFILES = {
    "qwen36-adapter-8": profile_config(
        workflows=8,
        concurrency=8,
        max_steps=8,
        workflow_timeout_sec=600,
        request_timeout_sec=480,
        seed=436008,
        warmup_requests=2,
        warmup_steps=2,
        backend_stall_timeout_sec=60,
        candidate_admission_stall_timeout_sec=120,
    ),
    "qwen36-trajectory-24-deep48": profile_config(
        workflows=24,
        concurrency=24,
        max_steps=48,
        workflow_timeout_sec=1800,
        request_timeout_sec=1200,
        seed=436248,
        backend_stall_timeout_sec=90,
        candidate_admission_stall_timeout_sec=180,
    ),
    "qwen36-low-control-48-deep64": profile_config(
        workflows=48,
        concurrency=48,
        max_steps=64,
        workflow_timeout_sec=2700,
        request_timeout_sec=1800,
        seed=436864,
        backend_stall_timeout_sec=120,
        candidate_admission_stall_timeout_sec=240,
    ),
    "qwen36-hybrid-page-probe-192-deep8": profile_config(
        workflows=192,
        concurrency=192,
        max_steps=8,
        workflow_timeout_sec=1800,
        request_timeout_sec=1200,
        seed=436908,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
    ),
    "qwen36-pressure-192-deep24": profile_config(
        workflows=192,
        concurrency=192,
        max_steps=24,
        workflow_timeout_sec=3600,
        request_timeout_sec=2700,
        seed=436924,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    ),
    "qwen36-pressure-192-deep32": profile_config(
        workflows=192,
        concurrency=192,
        max_steps=32,
        workflow_timeout_sec=3600,
        request_timeout_sec=2700,
        seed=436932,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    ),
    "qwen36-pressure-192-deep48": profile_config(
        workflows=192,
        concurrency=192,
        max_steps=48,
        workflow_timeout_sec=4500,
        request_timeout_sec=3300,
        seed=436948,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    ),
    "qwen36-pressure-192-deep64": profile_config(
        workflows=192,
        concurrency=192,
        max_steps=64,
        workflow_timeout_sec=5400,
        request_timeout_sec=4200,
        seed=436964,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    ),
    "qwen36-pressure-192-deep96": profile_config(
        workflows=192,
        concurrency=192,
        max_steps=96,
        workflow_timeout_sec=7200,
        request_timeout_sec=6000,
        seed=436996,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    ),
    "qwen36-paper-control-96-deep135": profile_config(
        workflows=96,
        concurrency=96,
        max_steps=135,
        workflow_timeout_sec=7200,
        request_timeout_sec=6000,
        seed=436135,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    ),
}

EXPECTED_CALL_BUDGETS = {
    "qwen36-adapter-8": 64,
    "qwen36-trajectory-24-deep48": 1152,
    "qwen36-low-control-48-deep64": 3072,
    "qwen36-hybrid-page-probe-192-deep8": 1536,
    "qwen36-pressure-192-deep24": 4608,
    "qwen36-pressure-192-deep32": 6144,
    "qwen36-pressure-192-deep48": 9216,
    "qwen36-pressure-192-deep64": 12288,
    "qwen36-pressure-192-deep96": 18432,
    "qwen36-paper-control-96-deep135": 12960,
}


def rejects(action: Callable[[], object], expected: str) -> bool:
    try:
        action()
    except ValueError as exc:
        return expected in str(exc)
    return False


def main() -> int:
    calibration_path = PROFILE_ROOT / "calibration.json"
    calibration_payload = json.loads(calibration_path.read_text())
    public_payload = json.loads((PROFILE_ROOT / "public.json").read_text())
    hidden_payload = json.loads((PROFILE_ROOT / "hidden.json").read_text())
    observed = calibration_payload.get("profiles")

    instantiated = {
        name: Profile(name=name, **config)
        for name, config in EXPECTED_PROFILES.items()
    }
    with tempfile.TemporaryDirectory(prefix="qwen36-calibration-profiles-") as raw:
        staged = Path(raw) / "profiles.json"
        staged.write_text(
            json.dumps(
                {
                    "schema_version": 2,
                    "profiles": EXPECTED_PROFILES,
                }
            )
        )
        default_loader_rejects_192 = rejects(
            lambda: load_profiles(staged),
            "profiles exceed concurrency limit 128",
        )
        widened = load_profiles(staged, concurrency_limit=192)

    invalid_193 = dict(EXPECTED_PROFILES["qwen36-pressure-192-deep32"])
    invalid_193.update({"workflows": 193, "concurrency": 193})
    pressure_names = {
        "qwen36-pressure-192-deep24",
        "qwen36-pressure-192-deep32",
        "qwen36-pressure-192-deep48",
        "qwen36-pressure-192-deep64",
        "qwen36-pressure-192-deep96",
        "qwen36-paper-control-96-deep135",
    }
    promoted_public = profile_config(
        workflows=192,
        concurrency=192,
        max_steps=24,
        workflow_timeout_sec=4500,
        request_timeout_sec=2700,
        seed=314159,
        backend_stall_timeout_sec=180,
        candidate_admission_stall_timeout_sec=300,
        pressure=True,
    )
    promoted_public["measurement_window_sec"] = 1800
    promoted_hidden = {
        **profile_config(
            workflows=192,
            concurrency=192,
            max_steps=24,
            workflow_timeout_sec=4500,
            request_timeout_sec=2700,
            seed=730073,
            backend_stall_timeout_sec=180,
            candidate_admission_stall_timeout_sec=300,
            pressure=True,
        ),
        "corpus_partition": "hidden",
    }
    checks = {
        "matrix_is_exact": observed == EXPECTED_PROFILES,
        "release_qualification_allowlist_stays_empty": (
            calibration_payload.get("release_qualification_profiles") == []
        ),
        "all_profiles_validate": set(instantiated) == set(EXPECTED_PROFILES),
        "default_loader_rejects_author_192_shapes": default_loader_rejects_192,
        "calibration_loader_accepts_entire_matrix": (
            set(widened) == set(EXPECTED_PROFILES)
        ),
        "profile_rejects_193": rejects(
            lambda: Profile(name="invalid-193", **invalid_193),
            "invalid workflow/concurrency shape",
        ),
        "single_wave_shapes": all(
            profile.workflows == profile.concurrency
            for profile in instantiated.values()
        ),
        "call_budgets_are_frozen": {
            name: profile.workflows * profile.max_steps
            for name, profile in instantiated.items()
        }
        == EXPECTED_CALL_BUDGETS,
        "one_wave_wall_timeouts_are_frozen": all(
            candidate_leg_wall_timeout_sec(profile)
            == profile.workflow_timeout_sec
            for profile in instantiated.values()
        ),
        "real_trajectory_without_padding_or_delay": all(
            profile.workload_family == "swebench-lite"
            and profile.context_bytes == 0
            and profile.tool_delay_min_sec == 0
            and profile.tool_delay_max_sec == 0
            for profile in instantiated.values()
        ),
        "completion_cap_is_paper_aligned": all(
            profile.max_tokens == 2048 for profile in instantiated.values()
        ),
        "pressure_stages_have_strict_development_gates": all(
            instantiated[name].pressure_required
            and instantiated[name].pressure_kv_threshold == 0.8
            and instantiated[name].pressure_kv_p95_min == 0.9
            and instantiated[name].pressure_time_fraction_min == 0.25
            and instantiated[name].pressure_min_samples == 60
            for name in pressure_names
        ),
        "adapter_trajectory_and_low_control_do_not_assume_pressure": all(
            not instantiated[name].pressure_required
            for name in set(instantiated) - pressure_names
        ),
        "paper_control_uses_96_agents_135_steps": (
            instantiated["qwen36-paper-control-96-deep135"].concurrency == 96
            and instantiated["qwen36-paper-control-96-deep135"].max_steps == 135
        ),
        "public_smoke_and_pressure_names_are_exact": (
            set(public_payload["profiles"])
            == {"smoke-api", "public-12", "public-pressure-192"}
        ),
        "heldout_profile_name_is_exact": (
            set(hidden_payload["profiles"]) == {"hidden-pressure-192"}
        ),
        "public_window_and_complete_hidden_shapes_are_promoted_exactly": (
            public_payload["profiles"]["public-pressure-192"] == promoted_public
            and hidden_payload["profiles"]["hidden-pressure-192"]
            == promoted_hidden
            and "measurement_window_sec" not in promoted_hidden
        ),
        "candidate_facing_192_profiles_require_explicit_loader_opt_in": (
            rejects(
                lambda: load_profiles(PROFILE_ROOT / "public.json"),
                "profiles exceed concurrency limit 128",
            )
            and rejects(
                lambda: load_profiles(PROFILE_ROOT / "hidden.json"),
                "profiles exceed concurrency limit 128",
            )
            and set(
                load_profiles(
                    PROFILE_ROOT / "public.json", concurrency_limit=192
                )
            )
            == {"smoke-api", "public-12", "public-pressure-192"}
            and set(
                load_profiles(
                    PROFILE_ROOT / "hidden.json", concurrency_limit=192
                )
            )
            == {"hidden-pressure-192"}
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "qwen36-staged-calibration-profile-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "profile_names": list(EXPECTED_PROFILES),
        "maximum_call_budgets": EXPECTED_CALL_BUDGETS,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
