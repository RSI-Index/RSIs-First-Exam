#!/usr/bin/env python3
"""CPU-only contracts for the author exploratory hidden ABBA runner."""

from __future__ import annotations

import importlib.util
import json
import os
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = TASK_ROOT / "scripts" / "run-exploratory-hidden-abba.py"
PAIR_PATH = TASK_ROOT / "scripts" / "run-reference-pair.py"
STACK_PATH = TASK_ROOT / "scripts" / "calibration-stack.sh"
COMPOSE_PATH = TASK_ROOT / "scripts" / "compose-calibration.yaml"


def load(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def leg(label: str, mode: str, rate: float) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "run_id": f"run-{label}",
        "mode": mode,
        "profile": "hidden-pressure-192",
        "profile_config": {
            "workflows": 192,
            "concurrency": 192,
            "warmup_requests": 4,
        },
        "corpus_namespace": "hidden-hidden-pressure-192",
        "corpus_fingerprint": "a" * 64,
        "model_adapter": {"mode": "qwen36-text-bash-v1"},
        "model_provenance": {
            "profile_sha256": "d" * 64,
            "runtime_boot_identity_sha256": "f" * 64,
        },
        "release_id": "development-qwen36-27b-tp2-external-v2",
        "controller_config_sha256": "c" * 64,
        "workload_nonce_sha256": "b" * 64,
        "request_count": 1000,
        "valid_steps_per_min": rate,
        "valid_steps": 1000,
        "valid_step_ratio": 0.99,
        "jain_progress_fairness": 0.99,
        "minimum_workflow_progress": 24,
        "p99_step_latency_sec": 100.0 if mode == "baseline" else 110.0,
        "tests_passed_workflows": 150,
        # Step-limited mini-SWE runs normally terminate as LimitsExceeded even
        # after reaching the full 24-step scheduling target.
        "completed_workflows": 0,
        "backend_tokens_per_valid_step": 100.0,
        "request_success_rate": 1.0,
        "infrastructure_failure": None,
        "candidate_failure": None,
        "backend_audit": {
            "passed": True,
            "p95_gateway_wait_sec": 0.0,
            "p99_gateway_wait_sec": 10.0 if mode == "candidate" else 0.0,
            "max_gateway_wait_sec": 12.0 if mode == "candidate" else 0.0,
        },
        "warmup_audit": {"passed": True},
        "pressure_validation": {"valid": True, "reasons": []},
        "vllm_metrics": {"live_series": {"sampler_error_count": 0}},
    }


def main() -> int:
    runner = load(RUNNER_PATH, "exploratory_hidden_abba_runner")
    pair = load(PAIR_PATH, "reference_pair_for_abba_unit")
    policy = json.loads(runner.SCORING_POLICY.read_text())
    legs = [
        leg("A1", "baseline", 100.0),
        leg("B1", "candidate", 120.0),
        leg("B2", "candidate", 121.0),
        leg("A2", "baseline", 102.0),
    ]
    pair_diagnostics = [
        {"contracts_passed": True, "quality_passed": True},
        {"contracts_passed": True, "quality_passed": True},
    ]
    valid = runner.evaluate_exploratory_abba(
        legs,
        pair_diagnostics=pair_diagnostics,
        policy=policy,
        profile="hidden-pressure-192",
        nonce_sha256="b" * 64,
        minimum_speedup=1.0,
    )
    bad_nonce = [dict(item) for item in legs]
    bad_nonce[2] = {**bad_nonce[2], "workload_nonce_sha256": "e" * 64}
    invalid = runner.evaluate_exploratory_abba(
        bad_nonce,
        pair_diagnostics=pair_diagnostics,
        policy=policy,
        profile="hidden-pressure-192",
        nonce_sha256="b" * 64,
        minimum_speedup=1.0,
    )
    bad_boot = [dict(item) for item in legs]
    bad_boot[3] = {
        **bad_boot[3],
        "model_provenance": {
            **bad_boot[3]["model_provenance"],
            "runtime_boot_identity_sha256": "0" * 64,
        },
    }
    boot_drift = runner.evaluate_exploratory_abba(
        bad_boot,
        pair_diagnostics=pair_diagnostics,
        policy=policy,
        profile="hidden-pressure-192",
        nonce_sha256="b" * 64,
        minimum_speedup=1.0,
    )
    paired_tail_regression_legs = [dict(item) for item in legs]
    paired_tail_regression_legs[1] = {
        **paired_tail_regression_legs[1],
        "p99_step_latency_sec": 126.0,
    }
    paired_tail_regression_legs[2] = {
        **paired_tail_regression_legs[2],
        "p99_step_latency_sec": 100.0,
    }
    paired_tail_regression_legs[3] = {
        **paired_tail_regression_legs[3],
        "p99_step_latency_sec": 200.0,
    }
    paired_tail_regression = runner.evaluate_exploratory_abba(
        paired_tail_regression_legs,
        pair_diagnostics=pair_diagnostics,
        policy=policy,
        profile="hidden-pressure-192",
        nonce_sha256="b" * 64,
        minimum_speedup=1.0,
    )

    snapshot_passed = False
    atomic_private_passed = False
    lock_collision_passed = False
    lock_path_passed = False
    with tempfile.TemporaryDirectory(prefix="kvbench-abba-unit-") as raw:
        root = Path(raw)
        source = root / "source"
        source.mkdir()
        launch = source / "launch.sh"
        launch.write_text("#!/bin/sh\nexit 0\n")
        launch.chmod(0o755)
        (source / "gateway.py").write_text("VALUE = 1\n")
        pycache = source / "__pycache__"
        pycache.mkdir()
        (pycache / "gateway.pyc").write_bytes(b"runtime-only")
        snapshot = root / "snapshot"
        snapshot_record = runner.copy_immutable_snapshot(source, snapshot)
        snapshot_passed = (
            snapshot_record["all_entries_nonwritable"] is True
            and snapshot_record["source_tree_sha256_before_copy"]
            == snapshot_record["snapshot_tree_sha256"]
            and snapshot_record["runtime_bytecode_caches_excluded"] is True
            and not (snapshot / "__pycache__").exists()
            and stat.S_IMODE(launch.stat().st_mode) == 0o755
            and stat.S_IMODE((snapshot / "launch.sh").stat().st_mode) == 0o555
            and stat.S_IMODE((snapshot / "gateway.py").stat().st_mode) == 0o444
        )

        evidence = root / "private.json"
        pair.atomic_write(evidence, {"private": True}, initial=True)
        overwrite_rejected = False
        try:
            pair.atomic_write(evidence, {"private": False}, initial=True)
        except RuntimeError:
            overwrite_rejected = True
        atomic_private_passed = (
            stat.S_IMODE(evidence.stat().st_mode) == 0o600
            and overwrite_rejected
            and not list(root.glob(f".{evidence.name}.*"))
        )

        runtime = root / "runtime"
        previous_runtime = os.environ.get("HARBOR_VLLM_RUNTIME_DIR")
        os.environ["HARBOR_VLLM_RUNTIME_DIR"] = str(runtime)
        try:
            lock_path_passed = pair.measurement_lock_path() == (
                runtime / "benchmark-measurement.lock"
            )
            with pair.host_measurement_lock():
                try:
                    with pair.host_measurement_lock():
                        pass
                except RuntimeError as exc:
                    lock_collision_passed = "already held" in str(exc)
        finally:
            if previous_runtime is None:
                os.environ.pop("HARBOR_VLLM_RUNTIME_DIR", None)
            else:
                os.environ["HARBOR_VLLM_RUNTIME_DIR"] = previous_runtime

    source = RUNNER_PATH.read_text()
    pair_source = PAIR_PATH.read_text()
    stack_source = STACK_PATH.read_text()
    compose_source = COMPOSE_PATH.read_text()
    checks = {
        "valid_abba_math_and_quality_pass": valid["passed"] is True
        and valid["effect"]["speedup"] > 1.0
        and valid["effect"]["baseline_cv"] < policy["max_baseline_cv"],
        "nonce_drift_fails": invalid["passed"] is False
        and invalid["checks"]["same_workload_nonce"] is False,
        "host_boot_drift_fails": boot_drift["passed"] is False
        and boot_drift["checks"]["same_model_provenance"] is False,
        "position_paired_tail_gate_rejects_aggregate_max_masking": (
            paired_tail_regression["passed"] is False
            and paired_tail_regression["checks"][
                "position_paired_p99_step_tail_passed"
            ]
            is False
            and paired_tail_regression["quality"]["tail_anti_gaming"][
                "max_position_paired_ratio"
            ]
            == 1.26
            and paired_tail_regression["quality"]["tail_anti_gaming"][
                "diagnostic_max_candidate_over_max_baseline_ratio"
            ]
            == 0.63
        ),
        "immutable_snapshot_is_content_bound_and_nonwritable": snapshot_passed,
        "private_json_is_atomic_0600_and_no_overwrite": atomic_private_passed,
        "runtime_bound_measurement_lock_path": lock_path_passed,
        "measurement_lock_is_exclusive": lock_collision_passed,
        "reference_pair_joins_same_lock_with_parent_escape_hatch": (
            "def host_measurement_lock" in pair_source
            and '"--no-lock"' in pair_source
            and "with host_measurement_lock(enabled=not args.no_lock)" in pair_source
        ),
        "runner_is_hidden_only_and_does_not_use_controller_abba_endpoint": (
            '"suite": "hidden"' in source
            and '"/admin/run"' in source
            and "/admin/abba/run" not in source
        ),
        "runner_has_exact_direct_oracle_oracle_direct_plan": (
            runner.LEG_PLAN
            == (
                ("A1", "baseline", "direct"),
                ("B1", "candidate", "oracle"),
                ("B2", "candidate", "oracle"),
                ("A2", "baseline", "direct"),
            )
        ),
        "runner_resets_model_between_legs": all(
            marker in source
            for marker in (
                '"between_A1_B1"',
                '"between_B1_B2"',
                '"between_B2_A2"',
                '"/admin/quiescent"',
                '"/admin/measurement/reset"',
            )
        ),
        "runner_proves_direct_gateway_absence_and_fresh_oracles": (
            "gateway_absent(" in source
            and "start_fresh_oracle(" in source
            and "fresh-recreated Oracle container" in source
        ),
        "calibration_stack_accepts_only_explicit_author_snapshot_mount": (
            'REFERENCE_GATEWAY_DIR="${KV_AUTHOR_REFERENCE_GATEWAY_DIR:-$TASK_DIR/solution/reference_gateway}"'
            in stack_source
            and 'source: "${KV_AUTHOR_REFERENCE_GATEWAY_DIR:?set by calibration-stack.sh}"'
            in compose_source
            and "read_only: true" in compose_source
        ),
        "output_is_explicitly_nonrelease_prefreeze_evidence": all(
            marker in source
            for marker in (
                '"release_evidence_eligible": False',
                '"release_ready_at_run": False',
                "refuses release_ready=true",
                "never final release evidence",
            )
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "exploratory-hidden-abba-runner-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "valid_effect": valid["effect"],
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
