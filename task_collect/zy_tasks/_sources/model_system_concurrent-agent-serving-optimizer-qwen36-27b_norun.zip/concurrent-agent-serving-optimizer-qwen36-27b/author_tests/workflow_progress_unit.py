#!/usr/bin/env python3
"""Focused checks for starvation/completion progress normalization."""

from __future__ import annotations

from runner.metrics import jain
from runner.workload import effective_scheduling_progress


MAX_STEPS = 48


def progress(workflow: dict[str, object]) -> int:
    return effective_scheduling_progress(workflow, MAX_STEPS)


submitted_early = {"status": "Submitted", "valid_steps": 3, "model_calls": 3}
limit_reached = {"status": "LimitsExceeded", "valid_steps": 47, "model_calls": 48}
runner_error = {"status": "RunnerError", "valid_steps": 2, "model_calls": 3}
unfinished_timeout = {"status": "JobTimeoutError", "valid_steps": 1, "model_calls": 2}

# Natural termination means there is no remaining work for the scheduler.  It
# must not look starved just because the agent submitted before the step cap.
assert progress(submitted_early) == MAX_STEPS
assert progress(limit_reached) == MAX_STEPS
assert min(map(progress, (submitted_early, limit_reached))) == MAX_STEPS
assert jain(map(progress, (submitted_early, limit_reached))) == 1.0

# Abnormal and unfinished workflows keep the scheduling opportunities they
# actually received, so a low-progress failure still depresses the progress and
# progress signals.
mixed = [submitted_early, limit_reached, runner_error, unfinished_timeout]
effective = list(map(progress, mixed))
assert effective == [MAX_STEPS, MAX_STEPS, 3, 2]
assert min(effective) == 2
assert jain(effective) < 0.6

# Legacy workflow evidence remains interpretable when model-call counts are
# absent, but only Submitted receives terminal normalization.
assert progress({"status": "RunnerError", "valid_steps": 2}) == 2

# Computing scheduling progress does not rewrite raw throughput accounting.
assert sum(int(item["valid_steps"]) for item in mixed) == 53
assert [item["valid_steps"] for item in mixed] == [3, 47, 2, 1]

print("workflow progress unit: passed")
