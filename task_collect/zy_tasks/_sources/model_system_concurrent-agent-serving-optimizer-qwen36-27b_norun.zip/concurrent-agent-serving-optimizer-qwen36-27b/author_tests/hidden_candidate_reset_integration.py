#!/usr/bin/env python3
"""Disposable-container integration for the root candidate lifecycle reset."""

from __future__ import annotations

import json
import os
import stat
import subprocess
import time
from pathlib import Path

from verify import (
    CandidateSharedOutputRootSeal,
    candidate_pids,
    candidate_sysv_ipc,
    frozen_submission_sha256,
    reset_candidate_runtime,
)
from verify_phase0 import launch_gateway, wait_gateway


FROZEN = Path("/run/kvbench-isolation-frozen")
CANARY_FROZEN = Path("/run/kvbench-hidden-stdout-canary")


def as_candidate(command: str) -> None:
    subprocess.run(
        [
            "setpriv",
            "--reuid",
            "candidate",
            "--regid",
            "candidate",
            "--init-groups",
            "--no-new-privs",
            "sh",
            "-ceu",
            command,
        ],
        check=True,
    )


def tree_contains(root: Path, marker: bytes) -> bool:
    if not root.is_dir():
        return False
    for path in root.rglob("*"):
        try:
            info = path.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISREG(info.st_mode) and marker in path.read_bytes():
            return True
    return False


def main() -> int:
    if os.geteuid() != 0:
        raise RuntimeError("candidate reset integration must run as root")
    if not (FROZEN / "launch.sh").is_file():
        raise RuntimeError("frozen integration submission was not staged")
    before = frozen_submission_sha256(FROZEN)
    output_roots = (Path("/logs/agent"), Path("/logs/artifacts"))
    original_output_metadata = {
        root: (root.stat().st_uid, root.stat().st_gid, stat.S_IMODE(root.stat().st_mode))
        for root in output_roots
    }
    process = None
    seal = None
    try:
        process = launch_gateway(
            FROZEN,
            "http://127.0.0.1:9/v1",
            log_name="gateway-isolation-integration.log",
        )
        wait_gateway(process)
        Path("/tmp/kvbench-root-parent").mkdir(mode=0o777, exist_ok=True)
        os.chmod("/tmp/kvbench-root-parent", 0o777)
        os.chmod("/run/lock", 0o1777)
        as_candidate(
            "mkdir -p /home/candidate/carry /tmp/kvbench-root-parent/nested "
            "/var/tmp/kvbench-carry /dev/shm/kvbench-carry /run/lock/kvbench-carry "
            "/logs/agent/carry /logs/artifacts/carry; "
            "printf memory > /home/candidate/carry/state; "
            "printf nested > /tmp/kvbench-root-parent/nested/state; "
            "printf vartmp > /var/tmp/kvbench-carry/state; "
            "printf shm > /dev/shm/kvbench-carry/state; "
            "printf lock > /run/lock/kvbench-carry/state; "
            "printf agent-state > /logs/agent/carry/state; "
            "printf artifact-state > /logs/artifacts/carry/state; "
            "ipcmk -M 4096 >/dev/null; ipcmk -Q >/dev/null; ipcmk -S 1 >/dev/null"
        )
        ipc_before = candidate_sysv_ipc()
        if len(ipc_before) != 3:
            raise RuntimeError(f"expected three candidate SysV IPC objects, got {ipc_before}")
        live_before = candidate_pids()
        if process.pid not in live_before:
            raise RuntimeError("candidate gateway was not visible before reset")

        reset = reset_candidate_runtime(process)
        process = None
        seal = CandidateSharedOutputRootSeal.acquire()
        first_seal = seal.attest()

        marker_text = f"kvbench-heldout-stdout-canary-{os.urandom(16).hex()}"
        marker = marker_text.encode()
        CANARY_FROZEN.mkdir(mode=0o700, exist_ok=False)
        canary_launch = CANARY_FROZEN / "launch.sh"
        canary_launch.write_text(
            "#!/usr/bin/env bash\n"
            "set -eu\n"
            "test \"$0\" = /run/kvbench-candidate/submission/launch.sh\n"
            "test \"$PWD\" = /run/kvbench-candidate/submission\n"
            "test \"$(readlink /proc/self/cwd)\" = /run/kvbench-candidate/submission\n"
            f"printf '%s\\n' '{marker_text}'\n"
            f"printf '%s\\n' '{marker_text}' >&2\n"
            f"printf '%s\\n' '{marker_text}' > /logs/agent/hidden-canary 2>/dev/null || true\n"
            f"printf '%s\\n' '{marker_text}' > /logs/artifacts/hidden-canary 2>/dev/null || true\n"
            "exec sleep 300\n"
        )
        os.chown(CANARY_FROZEN, 0, 0)
        os.chown(canary_launch, 0, 0)
        os.chmod(canary_launch, 0o555)
        os.chmod(CANARY_FROZEN, 0o555)
        process = launch_gateway(
            CANARY_FROZEN,
            "http://127.0.0.1:9/v1",
            log_name=None,
        )
        time.sleep(0.25)
        if process.poll() is not None or process.pid not in candidate_pids():
            raise RuntimeError("hidden stdout canary gateway did not remain alive")
        canary_reset = reset_candidate_runtime(process)
        process = None
        second_seal = seal.attest()

        # Exercise another final-style fresh process epoch with the real Oracle
        # implementation after the malicious stdout/stderr canary is gone.
        process = launch_gateway(
            FROZEN,
            "http://127.0.0.1:9/v1",
            log_name=None,
        )
        wait_gateway(process)
        fresh_gateway_pid = process.pid
        fresh_reset = reset_candidate_runtime(process)
        process = None
        third_seal = seal.attest()
        after = frozen_submission_sha256(FROZEN)
        marker_absent = not any(
            tree_contains(root, marker)
            for root in (Path("/logs/verifier"), *output_roots)
        )
        no_hidden_gateway_log = not any(
            Path("/logs/verifier").glob("gateway-final-leg-*.log")
        )
    finally:
        try:
            if process is not None:
                reset_candidate_runtime(process)
        finally:
            if seal is not None:
                seal.restore()

    restored_output_metadata = {
        root: (root.stat().st_uid, root.stat().st_gid, stat.S_IMODE(root.stat().st_mode))
        for root in output_roots
    }
    log_root = Path("/logs/verifier")
    log_path = log_root / "gateway-isolation-integration.log"
    checks = {
        "candidate_processes_are_gone": candidate_pids() == [],
        "candidate_sysv_ipc_is_gone": candidate_sysv_ipc() == [],
        "nested_candidate_file_is_gone": not Path(
            "/tmp/kvbench-root-parent/nested/state"
        ).exists(),
        "home_state_is_gone": not Path("/home/candidate/carry").exists(),
        "var_tmp_state_is_gone": not Path("/var/tmp/kvbench-carry").exists(),
        "dev_shm_state_is_gone": not Path("/dev/shm/kvbench-carry").exists(),
        "run_lock_state_is_gone": not Path("/run/lock/kvbench-carry").exists(),
        "shared_agent_state_is_blocked_not_mutated": (
            (Path("/logs/agent/carry/state").read_text() == "agent-state")
            and (Path("/logs/artifacts/carry/state").read_text() == "artifact-state")
        ),
        "shared_output_mount_roots_were_sealed_for_each_epoch": (
            first_seal["candidate_shared_output_roots_sealed"] is True
            and second_seal["candidate_shared_output_roots_sealed"] is True
            and third_seal["candidate_shared_output_roots_sealed"] is True
            and first_seal["candidate_shared_output_roots_candidate_accessible"] == []
            and second_seal["candidate_shared_output_roots_candidate_accessible"] == []
            and third_seal["candidate_shared_output_roots_candidate_accessible"] == []
        ),
        "shared_output_mount_metadata_is_exactly_restored": (
            restored_output_metadata == original_output_metadata
        ),
        "hidden_gateway_stdout_stderr_canary_is_absent": marker_absent,
        "hidden_final_gateway_log_is_not_created": no_hidden_gateway_log,
        "candidate_launch_path_is_phase_independent": (
            not Path("/run/kvbench-candidate/submission").exists()
            and stat.S_IMODE(Path("/run/kvbench-candidate").stat().st_mode) == 0o711
        ),
        "frozen_snapshot_is_unchanged": before == after,
        "frozen_snapshot_remains_root_owned_read_only": (
            FROZEN.stat().st_uid == 0
            and stat.S_IMODE(FROZEN.stat().st_mode) == 0o555
            and all(
                entry.lstat().st_uid == 0
                and stat.S_IMODE(entry.lstat().st_mode) in {0o444, 0o555}
                for entry in FROZEN.rglob("*")
            )
        ),
        "gateway_log_directory_is_root_only": (
            log_root.stat().st_uid == 0 and stat.S_IMODE(log_root.stat().st_mode) == 0o700
        ),
        "gateway_log_is_root_only": (
            log_path.stat().st_uid == 0 and stat.S_IMODE(log_path.stat().st_mode) == 0o600
        ),
        "reset_attests_closed_and_scrubbed": (
            reset["port_closed_before_launch"] is True
            and reset["runtime_state_scrubbed"] is True
            and reset["prelaunch_candidate_pids"] == []
            and reset["candidate_owned_runtime_entries"] == []
            and reset["candidate_owned_ipc_objects"] == []
            and canary_reset["runtime_state_scrubbed"] is True
            and fresh_reset["runtime_state_scrubbed"] is True
            and fresh_gateway_pid in fresh_reset["terminated_candidate_pids"]
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "hidden-candidate-reset-container-integration",
        "passed": all(checks.values()),
        "checks": checks,
        "candidate_pids_before": live_before,
        "sysv_ipc_objects_before": len(ipc_before),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
