#!/usr/bin/env python3
"""CPU-only checks for trusted candidate-vs-infrastructure attribution."""

from __future__ import annotations

import ast
import asyncio
import hashlib
import json
import math
import re
import secrets
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = TASK_ROOT / "environment" / "bench-controller" / "server.py"
VERIFIER_PATH = TASK_ROOT / "tests" / "verify.py"


class VerificationError(RuntimeError):
    pass


def extract(path: Path, function_name: str, namespace: dict[str, Any]):
    parsed = ast.parse(path.read_text(), filename=str(path))
    selected = [
        node
        for node in parsed.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == function_name
    ]
    if len(selected) != 1:
        raise RuntimeError(f"could not extract {function_name} from {path}")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    exec(compile(module, str(path), "exec"), namespace)  # noqa: S102 - trusted local source
    return namespace[function_name]


def rejected(callable_) -> bool:
    try:
        callable_()
    except (ValueError, VerificationError):
        return True
    return False


def execution_namespace() -> dict[str, Any]:
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    selected = [
        node
        for node in parsed.body
        if (
            isinstance(node, ast.ClassDef)
            and node.name == "ClassifiedLegFailure"
        )
        or (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name
            in {
                "candidate_leg_failure",
                "infrastructure_leg_failure",
                "execute_leg",
            }
        )
    ]
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "asyncio": asyncio,
        "re": re,
        "BASELINE_URL": "http://model-api:8100/v1",
        "CANDIDATE_URL": "http://main:9000/v1",
        "MODEL_API_URL": "http://model-api:8100",
        "token_text": lambda: "trusted-token",
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102 - trusted source
    return namespace


def terminal_report_case() -> dict[str, Any]:
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    selected = [
        node
        for node in parsed.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name in {"classified_failure_fields", "build_terminal_failure_report"}
    ]
    persisted: list[tuple[str, str, dict[str, Any]]] = []
    namespace: dict[str, Any] = {
        "Any": Any,
        "re": re,
        "hashlib": __import__("hashlib"),
        "CORPUS_MANIFEST": Path("/opaque/manifest.json"),
        "policy_contract_sha256": lambda _policy: "policy-sha",
        "file_sha256": lambda _path: "corpus-sha",
        "persist_trusted_result": (
            lambda kind, identifier, report: persisted.append((kind, identifier, report))
        ),
    }
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102 - trusted source

    class Failure:
        classification = "candidate_failed"
        failure_type = "candidate_gateway_exited"
        detail = "gateway exited after health"

    lifecycle_epoch = {"mode": "candidate", "leg_ordinal": 2}
    report = namespace["build_terminal_failure_report"](
        {
            "policy": {"release_id": "unit-release"},
            "config_sha256": "controller-sha",
        },
        {
            "lifecycle_epochs": [{"mode": "baseline", "leg_ordinal": 1}],
            "measurement_attempts": {},
            "profile_legs": {"hidden-profile": [{"run_id": "baseline-run"}]},
            "suite_nonce": "suite-nonce",
            "frozen_submission_sha256": "f" * 64,
        },
        profile_name="hidden-profile",
        mode="candidate",
        leg_ordinal=2,
        lifecycle_epoch=lifecycle_epoch,
        failure=Failure(),
    )
    return {
        "passed": report["status"] == "candidate_failed"
        and report["reward"] == 0.0
        and report["candidate_lifecycle"]["epochs"][-1] == lifecycle_epoch
        and report["measurement_attempts"]["hidden-profile"][0]["status"]
        == "candidate_failed"
        and report["failure_attribution"]["authority"]
        == "trusted-bench-controller"
        and report["candidate_lifecycle"]["epoch_count"] == 2
        and report["candidate_lifecycle"]["candidate_process_epoch_count"] == 1
        and len(persisted) == 1
        and persisted[0][0] == "final-failure",
        "report": report,
    }


def formal_order_case() -> dict[str, Any]:
    """Exercise both committed orders through the actual next-leg controller."""

    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    selected = [
        node
        for node in parsed.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name in {"_hex_text", "formal_leg_order", "final_next_leg"}
    ]
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "hashlib": hashlib,
        "re": re,
        "secrets": secrets,
        "FINAL_LEG_ORDER_CONTEXT": b"kvbench-final-leg-order-v1\n",
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102
    derive = namespace["formal_leg_order"]
    next_leg = namespace["final_next_leg"]
    observed: dict[str, list[str]] = {}
    for label, wanted in (
        ("ab", ("baseline", "candidate")),
        ("ba", ("candidate", "baseline")),
    ):
        for index in range(10_000):
            nonce = f"controller-order-{index}"
            commitment = hashlib.sha256(nonce.encode()).hexdigest()
            if derive(commitment) == wanted:
                break
        else:
            raise AssertionError(f"no nonce found for {wanted}")
        session = {
            "profile_index": 0,
            "profile_nonces": {"hidden-profile": nonce},
            "leg_index": 0,
            "lifecycle_epochs": [],
            "pending_challenge": None,
        }
        policy = {"hidden_profiles": [{"name": "hidden-profile"}]}
        first = next_leg(session, policy)
        session["leg_index"] = 1
        session["lifecycle_epochs"].append({"mode": first["mode"]})
        session["pending_challenge"] = None
        second = next_leg(session, policy)
        observed[label] = [first["mode"], second["mode"]]
    return {
        "passed": observed
        == {"ab": ["baseline", "candidate"], "ba": ["candidate", "baseline"]},
        "observed": observed,
    }


async def captured_execution_failure(
    *,
    mode: str,
    candidate_health: list[bool],
    runner_error: Exception | None,
    model_healthy: bool = True,
    provenance_error: Exception | None = None,
) -> tuple[str, str]:
    namespace = execution_namespace()
    health_values = iter(candidate_health)

    async def candidate_healthy(_app: object) -> bool:
        return next(health_values)

    async def model_provenance(_app: object) -> dict[str, str]:
        if provenance_error is not None:
            raise provenance_error
        return {"profile": "fixed"}

    async def model_status(_app: object) -> tuple[bool, bool]:
        return model_healthy, model_healthy

    def run_benchmark(**_kwargs: object) -> dict[str, Any]:
        if runner_error is not None:
            raise runner_error
        return {}

    namespace.update(
        {
            "candidate_healthy": candidate_healthy,
            "model_provenance": model_provenance,
            "model_status": model_status,
            "run_benchmark": run_benchmark,
        }
    )
    try:
        await namespace["execute_leg"](
            object(),
            profile=object(),
            mode=mode,
            corpus_namespace="heldout",
            workload_nonce="nonce",
        )
    except namespace["ClassifiedLegFailure"] as exc:
        return exc.classification, exc.failure_type
    raise AssertionError("execution unexpectedly succeeded")


def main() -> int:
    classified = extract(
        SERVER_PATH,
        "classified_failure_fields",
        {"Any": Any, "re": re},
    )
    validate = extract(
        VERIFIER_PATH,
        "validate_trusted_final_report",
        {"Any": Any, "math": math, "VerificationError": VerificationError},
    )
    candidate = classified(
        "candidate_failed",
        "candidate_gateway_exited",
        "gateway closed after its trusted health probe",
    )
    infrastructure = classified(
        "infra_invalid",
        "model_provenance_preflight_failed",
        "trusted model attestation unavailable",
    )
    ok = {
        "schema_version": 2,
        "status": "ok",
        "hard_gates_passed": True,
        "infra_failures": [],
        "candidate_failures": [],
        "reward": 0.2,
    }
    candidate_report = {"schema_version": 2, **candidate}
    infrastructure_report = {"schema_version": 2, **infrastructure}
    candidate_score = validate(candidate_report)
    infrastructure_score = validate(infrastructure_report)
    ok_score = validate(ok)
    contradictory_candidate = {
        **candidate_report,
        "infra_failures": ["candidate-controlled failure mislabeled as infra"],
    }
    server_source = SERVER_PATH.read_text()
    verifier_source = VERIFIER_PATH.read_text()
    health_exit = asyncio.run(
        captured_execution_failure(
            mode="candidate",
            candidate_health=[True, False],
            runner_error=RuntimeError("gateway disconnected"),
        )
    )
    runtime_failure = asyncio.run(
        captured_execution_failure(
            mode="candidate",
            candidate_health=[True, True],
            runner_error=RuntimeError("malformed candidate stream"),
        )
    )
    baseline_failure = asyncio.run(
        captured_execution_failure(
            mode="baseline",
            candidate_health=[],
            runner_error=RuntimeError("baseline control failure"),
        )
    )
    model_failure = asyncio.run(
        captured_execution_failure(
            mode="candidate",
            candidate_health=[True],
            runner_error=RuntimeError("request failed"),
            model_healthy=False,
        )
    )
    terminal = terminal_report_case()
    formal_order = formal_order_case()
    cases = [
        {
            "name": "candidate_terminal_failure_is_not_infrastructure_invalid",
            "passed": candidate["status"] == "candidate_failed"
            and candidate["candidate_failures"]
            and not candidate["infra_failures"]
            and candidate_score
            == {"reward": 0.0, "backend_audit": 0.0, "infra_valid": 1.0},
        },
        {
            "name": "trusted_infrastructure_failure_remains_explicit",
            "passed": infrastructure["status"] == "infra_invalid"
            and infrastructure["infra_failures"]
            and not infrastructure["candidate_failures"]
            and infrastructure_score
            == {"reward": 0.0, "backend_audit": 0.0, "infra_valid": 0.0},
        },
        {
            "name": "successful_typed_report_is_accepted",
            "passed": ok_score
            == {"reward": 0.2, "backend_audit": 1.0, "infra_valid": 1.0},
        },
        {
            "name": "contradictory_or_unknown_status_fails_closed",
            "passed": rejected(lambda: validate(contradictory_candidate))
            and rejected(
                lambda: validate(
                    {
                        **candidate_report,
                        "status": "unknown",
                    }
                )
            ),
        },
        {
            "name": "candidate_health_and_runtime_exceptions_are_typed",
            "passed": health_exit
            == ("candidate_failed", "candidate_gateway_exited")
            and runtime_failure
            == ("candidate_failed", "candidate_runtime_failed")
            and baseline_failure
            == ("infra_invalid", "baseline_runtime_failed")
            and model_failure
            == ("infra_invalid", "model_api_unhealthy_during_candidate_leg")
            and all(
                marker in server_source
                for marker in (
                    '"candidate_gateway_unavailable"',
                    '"candidate_health_protocol_failure"',
                    '"candidate_runtime_failed"',
                    '"candidate_gateway_exited"',
                    '"baseline_runtime_failed"',
                    '"model_provenance_preflight_failed"',
                    '"done": True, "report": report',
                )
            ),
        },
        {
            "name": "typed_failure_is_returnable_as_a_persisted_terminal_report",
            "passed": terminal["passed"],
        },
        {
            "name": "formal_next_leg_uses_both_nonce_committed_orders",
            "passed": formal_order["passed"],
        },
        {
            "name": "verifier_does_not_guess_classification_from_exception_text",
            "passed": '"infra" in str(exc).lower()' not in verifier_source
            and '"unclassified_verifier_failure"' in verifier_source,
        },
    ]
    report = {
        "schema_version": 1,
        "kind": "failure-attribution-unit",
        "passed": all(bool(case["passed"]) for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
