#!/usr/bin/env python3
"""Exercise 72 concurrent fresh-workspace lifecycles without a model server."""

from __future__ import annotations

import concurrent.futures
import json
import sys
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
WORKER_SOURCE = (TASK_ROOT / "environment" / "sandbox-worker" / "worker.py").read_text()
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.corpus import make_specs  # noqa: E402
from runner import sandbox as sandbox_module  # noqa: E402
from runner.workload import Profile, cleanup_sandboxes, prepare_sandboxes  # noqa: E402


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="kvbench-72way-") as raw:
        sandbox_module.WORKSPACE_ROOT = Path(raw) / "workspaces"
        specs = make_specs("parallel-unit", 144)

        def lifecycle(index: int) -> str:
            spec = specs[index]
            environment = sandbox_module.TimedSandbox(
                spec,
                delay_seed=7,
                minimum_delay=0,
                maximum_delay=0,
                command_timeout_sec=5,
            )
            try:
                marker = environment.workspace / "runtime-state" / "queue.sqlite"
                marker.parent.mkdir()
                marker.write_text(spec.task_id)
                if marker.read_text() != spec.task_id:
                    raise RuntimeError("workspace marker mismatch")
                return environment.workspace.name
            finally:
                environment.cleanup()

        names: list[str] = []
        # Two waves keep exactly 72 worker slots busy while proving that slot
        # reuse cannot reintroduce files from the first wave.
        with concurrent.futures.ThreadPoolExecutor(max_workers=72) as pool:
            for name in pool.map(lifecycle, range(144)):
                names.append(name)
        first_leftovers = list(sandbox_module.WORKSPACE_ROOT.iterdir())

        profile = Profile(
            name="prewarm-unit",
            enabled=True,
            workflows=144,
            concurrency=72,
            max_steps=1,
            context_bytes=0,
            max_tokens=32,
            workflow_timeout_sec=30,
            request_timeout_sec=20,
            tool_delay_min_sec=0,
            tool_delay_max_sec=0,
            seed=11,
            warmup_requests=0,
            warmup_context_bytes=0,
            warmup_steps=1,
        )
        # Only the first worker wave is allowed to exist before measurement;
        # queued workflow lifecycle coverage lives in sandbox_pool_unit.py.
        prewarmed = prepare_sandboxes(
            make_specs("prewarm-unit", profile.workflows)[: profile.concurrency],
            profile,
        )
        prewarm_names = [environment.workspace.name for environment in prewarmed if environment.workspace]
        all_present_before_measurement = len(prewarm_names) == profile.concurrency and all(
            environment.workspace and environment.workspace.exists() for environment in prewarmed
        )
        cleanup_sandboxes(prewarmed)
        leftovers = list(sandbox_module.WORKSPACE_ROOT.iterdir())

    report = {
        "schema_version": 1,
        "kind": "sandbox-parallel-unit",
        "parallel_workers": 72,
        "workflow_lifecycles": 144,
        "unique_workspaces": len(set(names)),
        "initial_prewarmed_workspaces": len(set(prewarm_names)),
        "all_initial_sandboxes_present_before_measurement": all_present_before_measurement,
        "first_wave_leftovers": [path.name for path in first_leftovers],
        "leftover_workspaces": [path.name for path in leftovers],
        "forced_non_gpu_runtime": 'runtime="runc"' in WORKER_SOURCE,
        "passed": (
            len(set(names)) == 144
            and len(set(prewarm_names)) == 72
            and all_present_before_measurement
            and 'runtime="runc"' in WORKER_SOURCE
            and not first_leftovers
            and not leftovers
        ),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
