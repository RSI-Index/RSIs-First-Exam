#!/usr/bin/env python3
"""CPU-only scope checks for the standalone Qwen3.6-27B host launcher."""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
LAUNCHER = TASK_ROOT / "scripts" / "host-vllm-qwen36-27b.sh"
PREFLIGHT = TASK_ROOT / "scripts" / "preflight-host.py"


def load_preflight_module():
    spec = importlib.util.spec_from_file_location("kvbench_preflight_host", PREFLIGHT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load preflight-host.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def container(
    *,
    identifier: str,
    name: str,
    running: bool = True,
    runtime: str = "runc",
    requests: list[dict] | None = None,
    devices: list[dict] | None = None,
    visible_devices: str | None = None,
) -> dict:
    environment = []
    if visible_devices is not None:
        environment.append(f"NVIDIA_VISIBLE_DEVICES={visible_devices}")
    return {
        "Id": identifier,
        "Name": f"/{name}",
        "State": {"Running": running},
        "Config": {"Image": "test-image", "Env": environment},
        "HostConfig": {
            "Runtime": runtime,
            "DeviceRequests": requests or [],
            "Devices": devices or [],
        },
    }


def main() -> int:
    launcher_source = LAUNCHER.read_text()
    preflight = load_preflight_module()
    cases: list[dict[str, object]] = []

    cases.append(
        {
            "name": "standalone_create_overrides_inherited_compose_labels",
            "passed": all(
                marker in launcher_source
                for marker in (
                    'STANDALONE_COMPOSE_PROJECT="harbor-kv-external-qwen36"',
                    'STANDALONE_COMPOSE_SERVICE="external-vllm"',
                    '--label "com.docker.compose.project=$STANDALONE_COMPOSE_PROJECT"',
                    '--label "com.docker.compose.service=$STANDALONE_COMPOSE_SERVICE"',
                )
            ),
        }
    )
    cases.append(
        {
            "name": "live_identity_checks_standalone_compose_labels",
            "passed": all(
                marker in launcher_source
                for marker in (
                    'observed_compose_project="$(docker container inspect',
                    'observed_compose_service="$(docker container inspect',
                    '[[ "$observed_compose_project" == "$STANDALONE_COMPOSE_PROJECT" ]]',
                    '[[ "$observed_compose_service" == "$STANDALONE_COMPOSE_SERVICE" ]]',
                )
            ),
        }
    )

    count_request = {
        "Driver": "nvidia",
        "Count": 2,
        "DeviceIDs": None,
        "Capabilities": [["gpu"]],
    }
    inventory = [
        container(
            identifier="a" * 64,
            name="gpu-owner",
            runtime="nvidia",
            requests=[count_request],
        ),
        container(
            identifier="b" * 64,
            name="cpu-on-default-nvidia-runtime",
            runtime="nvidia",
            visible_devices="void",
        ),
        container(
            identifier="c" * 64,
            name="stopped-gpu-owner",
            running=False,
            runtime="nvidia",
            requests=[count_request],
        ),
    ]
    observed = preflight.gpu_reserving_containers_from_inspect(inventory)
    cases.append(
        {
            "name": "running_device_request_blocks_during_compute_pid_gap",
            "passed": [item["name"] for item in observed] == ["gpu-owner"]
            and observed[0]["device_requests"][0]["count"] == 2,
            "observed": observed,
        }
    )

    legacy = preflight.gpu_reserving_containers_from_inspect(
        [
            container(
                identifier="d" * 64,
                name="legacy-visible-all",
                runtime="nvidia",
                visible_devices="all",
            ),
            container(
                identifier="e" * 64,
                name="legacy-device-node",
                devices=[
                    {
                        "PathOnHost": "/dev/nvidia0",
                        "PathInContainer": "/dev/nvidia0",
                    }
                ],
            ),
        ]
    )
    cases.append(
        {
            "name": "legacy_gpu_reservations_are_fail_closed",
            "passed": [item["name"] for item in legacy]
            == ["legacy-visible-all", "legacy-device-node"],
            "observed": legacy,
        }
    )

    calls: list[list[str]] = []
    original_run = preflight.run

    def fake_run(command: list[str], timeout: int = 60) -> str:
        del timeout
        calls.append(command)
        if command == ["docker", "ps", "--quiet", "--no-trunc"]:
            return "a" * 64
        if command[:3] == ["docker", "container", "inspect"]:
            return json.dumps([inventory[0]])
        raise AssertionError(f"unexpected command: {command}")

    try:
        preflight.run = fake_run
        queried = preflight.running_gpu_reserving_containers()
    finally:
        preflight.run = original_run
    cases.append(
        {
            "name": "launcher_exposes_only_physical_gpus_6_and_7",
            "passed": '--gpus \'"device=6,7"\'' in launcher_source
            and "--gpus all" not in launcher_source
            and "--gpu-indices 6,7" in launcher_source,
        }
    )
    cases.append(
        {
            "name": "preflight_queries_only_running_container_inventory",
            "passed": len(queried) == 1
            and calls[0] == ["docker", "ps", "--quiet", "--no-trunc"]
            and calls[1][:3] == ["docker", "container", "inspect"],
            "calls": calls,
        }
    )

    with tempfile.TemporaryDirectory(prefix="kvbench-host-vllm-scope-") as raw:
        fake_bin = Path(raw)
        fake_docker = fake_bin / "docker"
        fake_docker.write_text("#!/usr/bin/env bash\nexit 99\n")
        fake_docker.chmod(0o755)
        environment = os.environ.copy()
        environment["PATH"] = f"{fake_bin}:{environment['PATH']}"
        environment["HARBOR_VLLM_IMAGE"] = "same-content-under-another-tag"
        rejected = subprocess.run(
            [str(LAUNCHER), "logs"],
            cwd=TASK_ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=30,
        )
    cases.append(
        {
            "name": "alternate_image_tag_is_rejected_before_docker",
            "passed": rejected.returncode == 2
            and "HARBOR_VLLM_IMAGE overrides are forbidden" in rejected.stdout,
            "command_output": rejected.stdout[-2000:],
        }
    )

    report = {
        "schema_version": 1,
        "kind": "host-vllm-runtime-scope-unit",
        "passed": all(bool(case["passed"]) for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
