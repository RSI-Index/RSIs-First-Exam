#!/usr/bin/env python3
"""CPU-only state-machine tests for persisted public benchmark pairs."""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import stat
import sys
import tempfile
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))
sys.path.insert(0, str(CONTROLLER_ROOT))


class FakeResponse:
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        self.payload = payload
        self.status = status


def json_response(payload: dict[str, Any], *, status: int = 200) -> FakeResponse:
    return FakeResponse(payload, status)


# The host CPU test environment intentionally does not install aiohttp.  The
# selected controller functions only need json_response; provide a minimal
# import-time facade rather than weakening the production dependency.
aiohttp = ModuleType("aiohttp")
aiohttp.ClientSession = object
aiohttp.ClientTimeout = object
aiohttp.web = SimpleNamespace(json_response=json_response, middleware=lambda function: function)
sys.modules.setdefault("aiohttp", aiohttp)

import server as server_module  # noqa: E402


class FakeRequest:
    def __init__(
        self,
        app: dict[str, Any],
        *,
        payload: object | None = None,
        query: dict[str, str] | None = None,
    ) -> None:
        self.app = app
        self._payload = {} if payload is None else payload
        self.query = query or {}

    async def json(self) -> object:
        return self._payload


PROFILE = "public-pressure-192"
NONCE_DIGEST = "1" * 64
CORPUS_DIGEST = "2" * 64
CONTROLLER_DIGEST = "3" * 64


def trusted_result(
    mode: str,
    *,
    provenance_revision: str = "revision-a",
    runtime_boot_identity_sha256: str = "a" * 64,
    run_id: str | None = None,
    fairness: float = 0.97,
    zero_progress: float = 0.01,
    request_success: float = 1.0,
    rate: float = 100.0,
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "run_id": run_id or f"{mode}-run",
        "mode": mode,
        "profile": PROFILE,
        "profile_config": {"measurement_window_sec": 1800},
        "model_adapter": {"contract": "unit"},
        "model_provenance": {
            "model": "Qwen/Qwen3.6-27B",
            "revision": provenance_revision,
            "profile_sha256": "4" * 64,
            "runtime_boot_identity_sha256": runtime_boot_identity_sha256,
        },
        "model_protocol_diagnostics": {"private": True},
        "workflows": [{"private": True}],
        "corpus_namespace": "public",
        "corpus_fingerprint": CORPUS_DIGEST,
        "workload_nonce_sha256": NONCE_DIGEST,
        "controller_config_sha256": CONTROLLER_DIGEST,
        "release_id": "unit-release",
        "backend_audit": {
            "passed": True,
            "client_requests": 10,
            "audited_backend_requests": 10,
            "mismatches": [],
        },
        "warmup_audit": {"passed": True},
        "vllm_metrics": {
            "live_samples": [{"private": True}],
            "counter_deltas": [],
            "gauge_end": [],
            "live_series": {},
            "derived": {},
        },
        "measurement_window": {
            "configured": True,
            "duration_sec": 1800,
            "deadline_reached": True,
            "passed": True,
            "zero_progress_fraction": zero_progress,
            "_trusted_cutoff_request_ids": ["private-id"],
        },
        "pressure_validation": {"valid": True},
        "infrastructure_failure": None,
        "candidate_failure": None,
        "request_success_rate": request_success,
        "jain_progress_fairness": fairness,
        "valid_steps_per_min": rate,
        "p99_ttft_sec": 1.0,
    }


def finite_trusted_result(
    mode: str,
    *,
    run_id: str | None = None,
    valid_steps: int = 200,
) -> dict[str, Any]:
    result = trusted_result(mode, run_id=run_id, rate=valid_steps / 2)
    result.update(
        {
            "started_unix": 1_000.0,
            "ended_unix": 1_120.0,
            "elapsed_sec": 120.0,
            "wall_elapsed_sec": 125.0,
            "valid_steps": valid_steps,
            "valid_steps_per_min": valid_steps * 60.0 / 120.0,
            "profile_config": {
                "workflows": 12,
                "measurement_window_sec": None,
            },
            "agent_execution_interval": {
                "schema_version": 1,
                "start_event": "measured_leg_started",
                "end_event": "last_agent_run_termination",
                "duration_clock": "monotonic",
                "started_unix": 1_000.0,
                "ended_unix": 1_120.0,
                "elapsed_sec": 120.0,
                "expected_agent_runs": 12,
                "observed_agent_runs": 12,
                "complete": True,
            },
            "measurement_window": {
                "configured": False,
                "duration_sec": None,
                "deadline_reached": False,
                "termination": "finite_workload",
            },
        }
    )
    result["vllm_metrics"] = {
        "live_samples": [
            {"created_unix": 1_001.0, "private_metric": 1},
            {"created_unix": 1_119.0, "private_metric": 2},
        ],
        "counter_deltas": [],
        "gauge_end": [],
        "live_series": {"sampler_error_count": 0},
        "derived": {},
    }
    return result


def completed_pair(
    baseline: dict[str, Any],
    candidate: dict[str, Any] | None,
    *,
    status: str = "candidate_complete",
) -> dict[str, Any]:
    pair_id = f"{PROFILE}-unitpair"
    return {
        "pair_id": pair_id,
        "baseline_anchor_pair_id": pair_id,
        "parent_pair_id": None,
        "profile": PROFILE,
        "status": status,
        "created_unix": 100.0,
        "updated_unix": 101.0,
        "controller_config_sha256": CONTROLLER_DIGEST,
        "workload_nonce": "private-raw-nonce",
        "baseline": baseline,
        "candidate": candidate,
        "baseline_model_provenance_sha256": baseline.get(
            "model_provenance_sha256"
        ),
        "candidate_model_provenance_sha256": (
            candidate.get("model_provenance_sha256")
            if isinstance(candidate, dict)
            else None
        ),
        "failure": None,
        "comparison": None,
    }


def app_with_pair(pair: dict[str, Any] | None) -> dict[str, Any]:
    return {
        "profile_sets": {
            "public": {
                PROFILE: SimpleNamespace(
                    enabled=True,
                    pressure_required=True,
                    measurement_window_sec=1800,
                )
            }
        },
        "lease": asyncio.Lock(),
        "final_session": None,
        "config_sha256": CONTROLLER_DIGEST,
        "public_pair": ({PROFILE: pair} if pair is not None else {}),
        "history": [],
    }


async def exercise_state_machine(feedback_root: Path) -> list[dict[str, Any]]:
    cases: list[dict[str, Any]] = []
    baseline = server_module.public_summary(trusted_result("baseline"))
    old_candidate = server_module.public_summary(
        trusted_result("candidate", run_id="old-candidate", rate=110.0)
    )

    missing_baseline_pair = completed_pair(baseline, None, status="baseline_failed")
    missing_baseline_pair["baseline"] = None
    missing_app = app_with_pair(missing_baseline_pair)
    execute_calls = 0

    async def must_not_execute(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
        nonlocal execute_calls
        execute_calls += 1
        raise AssertionError("candidate executed without a completed baseline")

    original_execute = server_module.execute_leg
    original_feedback = server_module.persist_feedback
    original_format = server_module.format_run
    original_model_provenance = server_module.model_provenance
    original_trusted_result = server_module.persist_trusted_result

    async def current_model_provenance(_app: dict[str, Any]) -> dict[str, Any]:
        return trusted_result("baseline")["model_provenance"]

    server_module.execute_leg = must_not_execute
    server_module.persist_feedback = lambda _summary: None
    server_module.format_run = lambda _summary: "unit"
    server_module.model_provenance = current_model_provenance
    server_module.persist_trusted_result = lambda *_args, **_kwargs: None
    try:
        malformed = [
            (
                [],
                400,
                "invalid_json",
            ),
            (
                {"mode": ["candidate"], "profile": PROFILE},
                400,
                "invalid_mode",
            ),
            (
                {"mode": "candidate", "profile": [PROFILE]},
                400,
                "invalid_profile",
            ),
        ]
        malformed_responses = [
            await server_module.public_run(FakeRequest(missing_app, payload=payload))
            for payload, _status, _error in malformed
        ]
        cases.append(
            {
                "name": "public_run_rejects_non_object_and_non_string_fields",
                "passed": all(
                    response.status == status
                    and response.payload
                    == {
                        "schema_version": 1,
                        "error": error,
                        "message": server_module.PUBLIC_ERROR_SPECS[error][1],
                    }
                    for response, (_payload, status, error) in zip(
                        malformed_responses, malformed
                    )
                )
                and execute_calls == 0,
            }
        )
        response = await server_module.public_run(
            FakeRequest(
                missing_app,
                payload={"mode": "candidate", "profile": PROFILE},
            )
        )
        cases.append(
            {
                "name": "candidate_requires_completed_baseline_without_500",
                "passed": response.status == 409
                and response.payload.get("error") == "baseline_required"
                and "pair_id" not in response.payload
                and execute_calls == 0,
            }
        )

        retry_pair = completed_pair(baseline, old_candidate)
        retry_pair["failure"] = {"type": "old-failure"}
        retry_pair["comparison"] = {"status": "valid", "speedup": 1.1}
        retry_app = app_with_pair(retry_pair)
        pair_dir = feedback_root / "pairs" / retry_pair["pair_id"]
        server_module.persist_public_pair_state(retry_pair)
        (pair_dir / "compare.json").write_text('{"status":"historical"}\n')
        source_pair_before = (pair_dir / "pair.json").read_bytes()
        source_compare_before = (pair_dir / "compare.json").read_bytes()
        isolated_before_execute = False

        async def fail_fresh_candidate(
            _app: dict[str, Any], **_kwargs: Any
        ) -> dict[str, Any]:
            nonlocal isolated_before_execute
            current = retry_app["public_pair"][PROFILE]
            isolated_before_execute = (
                current["pair_id"] != retry_pair["pair_id"]
                and current["baseline_anchor_pair_id"] == retry_pair["pair_id"]
                and current["parent_pair_id"] == retry_pair["pair_id"]
                and current["status"] == "candidate_running"
                and current["candidate"] is None
                and current["candidate_model_provenance_sha256"] is None
                and current["failure"] is None
                and current["comparison"] is None
                and (pair_dir / "pair.json").read_bytes() == source_pair_before
                and (pair_dir / "compare.json").read_bytes() == source_compare_before
            )
            raise RuntimeError("fresh candidate failed")

        server_module.execute_leg = fail_fresh_candidate
        response = await server_module.public_run(
            FakeRequest(
                retry_app,
                payload={"mode": "candidate", "profile": PROFILE},
            )
        )
        failed_pair = retry_app["public_pair"][PROFILE]
        failed_pair_dir = feedback_root / "pairs" / failed_pair["pair_id"]
        failed_pair_before_retry = (failed_pair_dir / "pair.json").read_bytes()
        failed_compare = await server_module.compare(
            FakeRequest(retry_app, query={"profile": PROFILE})
        )
        cases.append(
            {
                "name": "failed_candidate_is_a_new_record_and_preserves_parent_bytes",
                "passed": response.status == 500
                and response.payload.get("pair_id") == failed_pair["pair_id"]
                and "fresh candidate failed"
                not in json.dumps(response.payload, sort_keys=True)
                and response.payload.get("baseline_anchor_pair_id")
                == retry_pair["pair_id"]
                and response.payload.get("parent_pair_id")
                == retry_pair["pair_id"]
                and isolated_before_execute
                and failed_pair["status"] == "candidate_failed"
                and failed_pair["candidate"] is None
                and failed_pair["failure"]["type"] == "RuntimeError"
                and failed_pair["pair_id"] != retry_pair["pair_id"]
                and failed_pair["parent_pair_id"] == retry_pair["pair_id"]
                and failed_pair["baseline_anchor_pair_id"] == retry_pair["pair_id"]
                and failed_compare.status == 409
                and failed_compare.payload.get("error") == "pair_not_ready"
                and "failure" not in failed_compare.payload
                and "fresh candidate failed"
                not in json.dumps(failed_compare.payload, sort_keys=True)
                and failed_compare.payload.get("baseline_anchor_pair_id")
                == retry_pair["pair_id"]
                and failed_compare.payload.get("parent_pair_id")
                == retry_pair["pair_id"]
                and not (failed_pair_dir / "compare.json").exists()
                and (pair_dir / "pair.json").read_bytes() == source_pair_before
                and (pair_dir / "compare.json").read_bytes() == source_compare_before,
            }
        )

        async def successful_candidate(
            _app: dict[str, Any], **_kwargs: Any
        ) -> dict[str, Any]:
            return trusted_result("candidate", run_id="fresh-candidate", rate=120.0)

        server_module.execute_leg = successful_candidate
        response = await server_module.public_run(
            FakeRequest(
                retry_app,
                payload={"mode": "candidate", "profile": PROFILE},
            )
        )
        successful_pair = retry_app["public_pair"][PROFILE]
        first_compare = await server_module.compare(
            FakeRequest(retry_app, query={"profile": PROFILE})
        )
        successful_compare_path = (
            feedback_root
            / "pairs"
            / successful_pair["pair_id"]
            / "compare.json"
        )
        first_compare_bytes = successful_compare_path.read_bytes()
        second_compare = await server_module.compare(
            FakeRequest(retry_app, query={"profile": PROFILE})
        )
        second_compare_bytes = successful_compare_path.read_bytes()
        cases.append(
            {
                "name": "successful_candidate_is_digest_bound_and_compare_is_repeatable",
                "passed": response.status == 200
                and response.payload.get("pair_id") == successful_pair["pair_id"]
                and response.payload.get("baseline_anchor_pair_id")
                == retry_pair["pair_id"]
                and response.payload.get("parent_pair_id")
                == failed_pair["pair_id"]
                and successful_pair["pair_id"] != failed_pair["pair_id"]
                and successful_pair["parent_pair_id"] == failed_pair["pair_id"]
                and successful_pair["baseline_anchor_pair_id"] == retry_pair["pair_id"]
                and successful_pair["status"] == "candidate_complete"
                and successful_pair["failure"] is None
                and successful_pair["baseline_model_provenance_sha256"]
                == successful_pair["candidate_model_provenance_sha256"]
                and first_compare.status == second_compare.status == 200
                and first_compare.payload["speedup"] == 1.2
                and first_compare.payload.get("baseline_anchor_pair_id")
                == retry_pair["pair_id"]
                and first_compare.payload.get("parent_pair_id")
                == failed_pair["pair_id"]
                and second_compare.payload == first_compare.payload
                and second_compare_bytes == first_compare_bytes
                and successful_pair["status"] == "candidate_complete"
                and successful_pair["comparison"]["status"] == "valid",
            }
        )
        cases.append(
            {
                "name": "successful_retry_preserves_all_older_attempt_artifacts",
                "passed": (pair_dir / "pair.json").read_bytes() == source_pair_before
                and (pair_dir / "compare.json").read_bytes() == source_compare_before
                and (failed_pair_dir / "pair.json").read_bytes()
                == failed_pair_before_retry
                and not (failed_pair_dir / "compare.json").exists(),
            }
        )

        async def restarted_model_provenance(
            _app: dict[str, Any],
        ) -> dict[str, Any]:
            # Every static model/runtime field is identical; only the opaque
            # launch identity differs, as it does after a host-vLLM restart.
            return trusted_result(
                "baseline",
                runtime_boot_identity_sha256="b" * 64,
            )["model_provenance"]

        server_module.model_provenance = restarted_model_provenance
        calls_before_restart_preflight = execute_calls
        pair_before_restart_preflight = retry_app["public_pair"][PROFILE]["pair_id"]
        restarted_attempt = await server_module.public_run(
            FakeRequest(
                retry_app,
                payload={"mode": "candidate", "profile": PROFILE},
            )
        )
        cases.append(
            {
                "name": "candidate_preflight_rejects_static_equal_restarted_vllm_boot",
                "passed": restarted_attempt.status == 409
                and restarted_attempt.payload.get("error")
                == "baseline_model_identity_invalid"
                and "runtime_boot_identity_sha256"
                not in json.dumps(restarted_attempt.payload, sort_keys=True)
                and retry_app["public_pair"][PROFILE]["pair_id"]
                == pair_before_restart_preflight
                and execute_calls == calls_before_restart_preflight,
            }
        )
        server_module.model_provenance = current_model_provenance

        changed = server_module.public_summary(
            trusted_result(
                "candidate",
                provenance_revision="revision-b",
                run_id="changed-model",
            )
        )
        successful_pair["candidate"] = changed
        successful_pair["candidate_model_provenance_sha256"] = changed[
            "model_provenance_sha256"
        ]
        successful_pair["status"] = "candidate_complete"
        successful_pair["failure"] = None
        changed_compare = await server_module.compare(
            FakeRequest(retry_app, query={"profile": PROFILE})
        )
        cases.append(
            {
                "name": "compare_rejects_cross_leg_model_change",
                "passed": changed_compare.status == 409
                and "model_provenance_mismatch"
                in changed_compare.payload.get("gates", []),
            }
        )

        healthy = server_module.public_summary(trusted_result("candidate"))
        successful_pair["candidate"] = healthy
        successful_pair["candidate_model_provenance_sha256"] = healthy[
            "model_provenance_sha256"
        ]
        unhealthy_baseline = dict(baseline)
        unhealthy_baseline["measurement_window"] = dict(
            baseline["measurement_window"], zero_progress_fraction=0.06
        )
        unhealthy_baseline["request_success_rate"] = 0.97
        successful_pair["baseline"] = unhealthy_baseline
        health_compare = await server_module.compare(
            FakeRequest(retry_app, query={"profile": PROFILE})
        )
        expected_health_reasons = {
            "baseline_window_zero_progress_above_0.05",
            "baseline_window_request_success_below_0.98",
        }
        cases.append(
            {
                "name": "fixed_window_health_gates_are_symmetric",
                "passed": health_compare.status == 409
                and expected_health_reasons.issubset(
                    set(health_compare.payload.get("gates", []))
                ),
            }
        )
        unhealthy_pair_id = successful_pair["pair_id"]
        unhealthy_candidate_attempt = await server_module.public_run(
            FakeRequest(
                retry_app,
                payload={"mode": "candidate", "profile": PROFILE},
            )
        )
        cases.append(
            {
                "name": "candidate_preflight_requires_replacement_for_bad_baseline_quality",
                "passed": unhealthy_candidate_attempt.status == 409
                and unhealthy_candidate_attempt.payload.get("error")
                == "baseline_quality_invalid"
                and "pair_id" not in unhealthy_candidate_attempt.payload
                and retry_app["public_pair"][PROFILE]["pair_id"]
                == unhealthy_pair_id
                and {
                    "baseline_window_zero_progress_above_0.05",
                    "baseline_window_request_success_below_0.98",
                }.issubset(
                    set(unhealthy_candidate_attempt.payload.get("gates", []))
                ),
            }
        )

        finite_baseline = server_module.public_summary(
            finite_trusted_result("baseline", run_id="finite-baseline")
        )
        finite_candidate = server_module.public_summary(
            finite_trusted_result(
                "candidate", run_id="finite-candidate", valid_steps=220
            )
        )
        finite_pair = completed_pair(finite_baseline, finite_candidate)
        finite_pair["pair_id"] = f"{PROFILE}-finite-unitpair"
        finite_pair["baseline_anchor_pair_id"] = finite_pair["pair_id"]
        finite_app = app_with_pair(finite_pair)
        finite_app["profile_sets"]["public"][PROFILE].measurement_window_sec = None
        finite_compare = await server_module.compare(
            FakeRequest(finite_app, query={"profile": PROFILE})
        )
        projected_samples = finite_baseline["vllm_metrics"].get("live_samples")
        cases.append(
            {
                "name": "finite_public_compare_validates_interval_and_timestamp_only_samples",
                "passed": finite_compare.status == 200
                and finite_compare.payload.get("speedup") == 1.1
                and projected_samples
                == [{"created_unix": 1_001.0}, {"created_unix": 1_119.0}],
            }
        )
        finite_candidate["vllm_metrics"]["live_samples"].append(
            {"created_unix": 1_121.0}
        )
        finite_pair["comparison"] = None
        invalid_finite_compare = await server_module.compare(
            FakeRequest(finite_app, query={"profile": PROFILE})
        )
        cases.append(
            {
                "name": "finite_public_compare_rejects_post_interval_metric_sample",
                "passed": invalid_finite_compare.status == 409
                and "candidate_agent_execution_interval_post_end_live_sample"
                in invalid_finite_compare.payload.get("gates", []),
            }
        )

        await retry_app["lease"].acquire()
        try:
            busy_compare = await server_module.compare(
                FakeRequest(retry_app, query={"profile": PROFILE})
            )
        finally:
            retry_app["lease"].release()
        cases.append(
            {
                "name": "compare_refuses_an_active_benchmark_lease",
                "passed": busy_compare.status == 409
                and busy_compare.payload.get("error") == "benchmark_lease_busy",
            }
        )
    finally:
        server_module.execute_leg = original_execute
        server_module.persist_feedback = original_feedback
        server_module.format_run = original_format
        server_module.model_provenance = original_model_provenance
        server_module.persist_trusted_result = original_trusted_result
    return cases


def main() -> int:
    cases: list[dict[str, Any]] = []
    original_feedback_root = server_module.FEEDBACK_ROOT
    original_trusted_results_root = server_module.TRUSTED_RESULTS_ROOT
    try:
        with tempfile.TemporaryDirectory(prefix="kvbench-public-pair-") as raw:
            feedback_root = Path(raw)
            server_module.FEEDBACK_ROOT = feedback_root
            server_module.TRUSTED_RESULTS_ROOT = feedback_root / "trusted"
            server_module._PUBLIC_FAILURE_SATURATED = False
            cases.extend(asyncio.run(exercise_state_machine(feedback_root)))

            secret_detail = "PRIVATE_EXCEPTION_DETAIL:/root/only/marker"
            failed_raw = trusted_result("candidate")
            failed_raw["candidate_failure"] = {
                "type": "future_unreviewed_failure",
                "detail": secret_detail,
                "cancelled": True,
            }
            failed_raw["measurement_window"]["errors"] = [secret_detail]
            failed_public = server_module.public_summary(failed_raw)
            cases.append(
                {
                    "name": "recursive_public_summary_strips_raw_abnormal_detail",
                    "passed": secret_detail
                    not in json.dumps(failed_public, sort_keys=True)
                    and failed_public["candidate_failure"]
                    == {
                        "type": "workload_watchdog_failure",
                        "cancelled": True,
                    }
                    and "errors" not in failed_public["measurement_window"],
                }
            )
            failure_count_before = len(
                list(server_module.TRUSTED_RESULTS_ROOT.glob("public-failure-*.json"))
            )
            server_module.persist_public_failure_artifact(
                error="public_internal_error",
                raw_detail=secret_detail,
                context={"test": True},
            )
            raw_failure_files = list(
                server_module.TRUSTED_RESULTS_ROOT.glob("public-failure-*.json")
            )
            cases.append(
                {
                    "name": "raw_public_failure_detail_is_root_only_artifact",
                    "passed": len(raw_failure_files) == failure_count_before + 1
                    and any(
                        secret_detail in path.read_text()
                        for path in raw_failure_files
                    )
                    and stat.S_IMODE(
                        server_module.TRUSTED_RESULTS_ROOT.stat().st_mode
                    )
                    == 0o700
                    and all(
                        stat.S_IMODE(path.stat().st_mode) == 0o600
                        for path in raw_failure_files
                    ),
                }
            )

            middleware_secret = "PRIVATE_UNCAUGHT_PUBLIC_EXCEPTION"

            async def failing_public_handler(_request: Any) -> Any:
                raise RuntimeError(middleware_secret)

            middleware_response = asyncio.run(
                server_module.sanitize_public_exceptions(
                    SimpleNamespace(path="/public/run", method="POST"),
                    failing_public_handler,
                )
            )
            middleware_artifacts = list(
                server_module.TRUSTED_RESULTS_ROOT.glob("public-failure-*.json")
            )
            cases.append(
                {
                    "name": "uncaught_public_exception_is_fixed_and_privately_persisted",
                    "passed": middleware_response.status == 500
                    and middleware_response.payload
                    == {
                        "schema_version": 1,
                        "error": "public_internal_error",
                        "message": "the trusted public controller failed",
                    }
                    and middleware_secret
                    not in json.dumps(middleware_response.payload, sort_keys=True)
                    and len(middleware_artifacts) == len(raw_failure_files) + 1
                    and any(
                        middleware_secret in path.read_text()
                        for path in middleware_artifacts
                    ),
                }
            )

            for index in range(32):
                server_module.persist_public_failure_artifact(
                    error="public_internal_error",
                    raw_detail=f"bounded-{index}-" + ("x" * 20000),
                    pair={"pair_id": f"unit-{index}", "raw": "y" * 20000},
                    context={"index": index, "raw": "z" * 20000},
                )
            bounded_files = sorted(
                server_module.TRUSTED_RESULTS_ROOT.glob(
                    "public-failure-slot-*.json"
                )
            )
            before_drop = {
                path.name: (
                    path.stat().st_ino,
                    path.stat().st_mtime_ns,
                    path.read_bytes(),
                )
                for path in bounded_files
            }
            for index in range(100):
                server_module.persist_public_failure_artifact(
                    error="public_internal_error",
                    raw_detail=f"must-drop-{index}",
                )
            after_drop = {
                path.name: (
                    path.stat().st_ino,
                    path.stat().st_mtime_ns,
                    path.read_bytes(),
                )
                for path in bounded_files
            }
            cases.append(
                {
                    "name": "private_public_failure_store_has_hard_count_byte_and_write_caps",
                    "passed": len(bounded_files)
                    == server_module.PUBLIC_FAILURE_SLOT_COUNT
                    and all(
                        path.stat().st_size
                        <= server_module.PUBLIC_FAILURE_FILE_MAX_BYTES
                        and stat.S_IMODE(path.stat().st_mode) == 0o600
                        for path in bounded_files
                    )
                    and sum(path.stat().st_size for path in bounded_files)
                    <= server_module.PUBLIC_FAILURE_TOTAL_MAX_BYTES
                    and before_drop == after_drop
                    and not list(
                        server_module.TRUSTED_RESULTS_ROOT.glob(
                            ".public-failure-slot-*.tmp"
                        )
                    ),
                }
            )

            baseline = server_module.public_summary(trusted_result("baseline"))
            candidate = server_module.public_summary(trusted_result("candidate"))
            pair = completed_pair(baseline, candidate)
            payload = server_module.public_pair_payload(pair)
            rendered_payload = json.dumps(payload, sort_keys=True)
            cases.append(
                {
                    "name": "persisted_pair_exposes_only_provenance_digest_and_nonce_digest",
                    "passed": "workload_nonce" not in payload
                    and '"model_provenance":' not in rendered_payload
                    and payload["workload_nonce_sha256"] == NONCE_DIGEST
                    and payload["baseline_model_provenance_sha256"]
                    == payload["candidate_model_provenance_sha256"]
                    and payload["baseline_anchor_pair_id"] == pair["pair_id"]
                    and payload["parent_pair_id"] is None
                    and "_trusted_cutoff_request_ids" not in rendered_payload,
                }
            )

            failures: list[str] = []

            def persist_once(_index: int) -> None:
                try:
                    server_module.persist_public_pair_state(pair)
                except Exception as exc:  # pragma: no cover - reported below
                    failures.append(f"{type(exc).__name__}: {exc}")

            with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
                list(pool.map(persist_once, range(128)))
            destination = feedback_root / "pairs" / pair["pair_id"] / "pair.json"
            persisted = json.loads(destination.read_text())
            leftovers = list(destination.parent.glob(".*.tmp"))
            cases.append(
                {
                    "name": "concurrent_pair_persistence_uses_unique_atomic_temporaries",
                    "passed": not failures
                    and persisted["pair_id"] == pair["pair_id"]
                    and not leftovers,
                    "failures": failures[:5],
                    "leftovers": [path.name for path in leftovers],
                }
            )
            cases.append(
                {
                    "name": "raw_pair_backing_records_are_root_only",
                    "passed": stat.S_IMODE(destination.parent.stat().st_mode)
                    == 0o700
                    and stat.S_IMODE(destination.stat().st_mode) == 0o600,
                    "directory_mode": oct(
                        stat.S_IMODE(destination.parent.stat().st_mode)
                    ),
                    "file_mode": oct(stat.S_IMODE(destination.stat().st_mode)),
                }
            )
    finally:
        server_module.FEEDBACK_ROOT = original_feedback_root
        server_module.TRUSTED_RESULTS_ROOT = original_trusted_results_root

    report = {
        "schema_version": 1,
        "kind": "public-pair-state-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
