#!/usr/bin/env python3
"""Ensure Harbor uploads only the generic verifier harness to shared main."""

from __future__ import annotations

import json
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
VERIFIER_ROOT = TASK_ROOT / "tests"
TEST_SH = VERIFIER_ROOT / "test.sh"
PROFILE_PATHS = (
    TASK_ROOT / "environment" / "bench-controller" / "profiles" / "hidden.json",
    TASK_ROOT / "environment" / "bench-controller" / "profiles" / "calibration.json",
)
EXPECTED_FILES = {
    "protocol_cases.py",
    "test.sh",
    "verify.py",
    "verify_phase0.py",
}
FORBIDDEN_MARKERS = {
    b"profiles/hidden.json",
    b"profiles/calibration.json",
    b"release-manifest-pre-oracle",
    b"reference_gateway",
    b"ThunderAgent",
    b"solution/",
    b"scheduler.py",
    b"author_tests",
}


def private_profile_markers() -> set[bytes]:
    markers = set(FORBIDDEN_MARKERS)
    for path in PROFILE_PATHS:
        payload = json.loads(path.read_text())
        for name, profile in (payload.get("profiles") or {}).items():
            markers.add(str(name).encode())
            if isinstance(profile, dict) and isinstance(profile.get("seed"), int):
                markers.add(str(profile["seed"]).encode())
    return markers


def first_verifier_command(shell: str) -> str | None:
    for raw_line in shell.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line == "set -euo pipefail":
            continue
        return line
    return None


def main() -> int:
    entries = list(VERIFIER_ROOT.iterdir())
    observed_files = {entry.name for entry in entries if entry.is_file()}
    payload = b"\n".join(
        entry.read_bytes() for entry in sorted(entries) if entry.is_file()
    )
    shell = TEST_SH.read_text()
    forbidden_markers = private_profile_markers()
    checks = {
        "shared_bundle_has_exact_generic_allowlist": observed_files == EXPECTED_FILES,
        "shared_bundle_has_no_subdirectories_or_symlinks": all(
            entry.is_file() and not entry.is_symlink() for entry in entries
        ),
        "shared_bundle_has_no_hidden_profile_or_seed_markers": not any(
            marker in payload for marker in forbidden_markers
        ),
        "shared_bundle_does_not_reference_author_tests": b"author_tests" not in payload,
        "candidate_processes_are_killed_before_other_verifier_work": (
            first_verifier_command(shell)
            == "pkill -KILL -u candidate 2>/dev/null || true"
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "verifier-bundle-isolation-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "uploaded_files": sorted(observed_files),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
