#!/usr/bin/env python3
"""CPU-only mutations for host-vLLM boot/process provenance binding."""

from __future__ import annotations

import asyncio
import copy
import json
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT / "vendor"))
sys.path.insert(0, str(CONTROLLER_ROOT))
sys.path.insert(0, str(TASK_ROOT / "scripts"))

# The host CPU suite intentionally has no aiohttp dependency.
aiohttp = ModuleType("aiohttp")
aiohttp.ClientSession = object
aiohttp.ClientTimeout = object
aiohttp.web = SimpleNamespace(middleware=lambda function: function)
sys.modules.setdefault("aiohttp", aiohttp)

import server as controller  # noqa: E402
from evidence_contract import runtime_boot_identity_sha256 as evidence_boot_digest  # noqa: E402


def attestation() -> dict[str, Any]:
    return {
        "schema_version": 1,
        "state": "ready",
        "ready_unix": 1_721_000_000.25,
        "profile_id": controller.QWEN_PROFILE_ID,
        "profile_sha256": controller.QWEN_PROFILE_SHA256,
        "model": {"revision": controller.QWEN_REVISION},
        "runtime": {
            "runtime_image_id": "sha256:" + "d" * 64,
            "tensor_parallel_size": 2,
            "kv_cache_dtype": "fp8",
        },
        "process": {
            "wrapper_pid": 12345,
            "wrapper_start_ticks": 987654321,
        },
        "container": {
            "id": "a" * 64,
            "launch_token_sha256": "b" * 64,
        },
    }


class FakeResponse:
    status = 200

    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload

    async def __aenter__(self) -> "FakeResponse":
        return self

    async def __aexit__(self, *_args: Any) -> None:
        return None

    async def json(self) -> dict[str, Any]:
        return copy.deepcopy(self.payload)


class FakeClient:
    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload

    def get(self, *_args: Any, **_kwargs: Any) -> FakeResponse:
        return FakeResponse(self.payload)


async def provenance(payload: dict[str, Any]) -> dict[str, Any]:
    original_admin_headers = controller.admin_headers
    controller.admin_headers = lambda: {"Authorization": "Bearer unit"}
    try:
        return await controller.model_provenance({"client": FakeClient(payload)})
    finally:
        controller.admin_headers = original_admin_headers


def rejected(callable_: Any) -> bool:
    try:
        callable_()
    except (RuntimeError, ValueError):
        return True
    return False


def main() -> int:
    base = attestation()
    base_provenance = asyncio.run(provenance(base))
    base_digest = base_provenance["runtime_boot_identity_sha256"]
    cases: list[dict[str, Any]] = [
        {
            "name": "ready_attestation_yields_only_opaque_boot_digest",
            "passed": len(base_digest) == 64
            and set(base_digest) <= set("0123456789abcdef")
            and set(base_provenance)
            == {
                "profile_id",
                "profile_sha256",
                "model_revision",
                "runtime_image_id",
                "tensor_parallel_size",
                "kv_cache_dtype",
                "runtime_boot_identity_sha256",
            }
            and str(base["process"]["wrapper_pid"])
            not in json.dumps(base_provenance, sort_keys=True)
            and base["container"]["id"]
            not in json.dumps(base_provenance, sort_keys=True)
            and base["container"]["launch_token_sha256"]
            not in json.dumps(base_provenance, sort_keys=True)
            and evidence_boot_digest(base) == base_digest,
        }
    ]

    mutations = (
        ("ready_epoch", lambda value: value.__setitem__("ready_unix", 1_721_000_001.25)),
        ("wrapper_pid", lambda value: value["process"].__setitem__("wrapper_pid", 12346)),
        (
            "wrapper_start_ticks",
            lambda value: value["process"].__setitem__("wrapper_start_ticks", 987654322),
        ),
        ("container_id", lambda value: value["container"].__setitem__("id", "c" * 64)),
        (
            "launch_token",
            lambda value: value["container"].__setitem__(
                "launch_token_sha256", "e" * 64
            ),
        ),
    )
    changed_provenance: dict[str, Any] | None = None
    for label, mutate in mutations:
        changed = copy.deepcopy(base)
        mutate(changed)
        observed = asyncio.run(provenance(changed))
        cases.append(
            {
                "name": f"{label}_mutation_changes_boot_digest",
                "passed": {
                    key: value
                    for key, value in observed.items()
                    if key != "runtime_boot_identity_sha256"
                }
                == {
                    key: value
                    for key, value in base_provenance.items()
                    if key != "runtime_boot_identity_sha256"
                }
                and observed["runtime_boot_identity_sha256"] != base_digest,
            }
        )
        changed_provenance = observed

    assert changed_provenance is not None
    same_static_different_boot = [
        {"model_provenance": base_provenance},
        {"model_provenance": changed_provenance},
    ]
    cases.append(
        {
            "name": "hidden_formal_pair_rejects_static_equal_cross_boot_legs",
            "passed": rejected(
                lambda: controller.require_single_model_provenance(
                    same_static_different_boot,
                    context="hidden mutation",
                )
            ),
        }
    )
    cases.append(
        {
            "name": "same_boot_hidden_legs_pass",
            "passed": controller.require_single_model_provenance(
                [
                    {"model_provenance": copy.deepcopy(base_provenance)},
                    {"model_provenance": copy.deepcopy(base_provenance)},
                ],
                context="hidden unit",
            )
            == base_provenance,
        }
    )

    invalid = copy.deepcopy(base)
    invalid["process"]["wrapper_start_ticks"] = 0
    cases.append(
        {
            "name": "invalid_process_identity_is_rejected",
            "passed": rejected(lambda: asyncio.run(provenance(invalid))),
        }
    )

    report = {
        "schema_version": 1,
        "kind": "runtime-boot-provenance-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
