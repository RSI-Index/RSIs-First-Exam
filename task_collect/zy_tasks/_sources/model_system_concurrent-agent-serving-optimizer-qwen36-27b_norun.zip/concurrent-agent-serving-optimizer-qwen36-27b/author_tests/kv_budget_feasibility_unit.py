#!/usr/bin/env python3
"""CPU-only regression checks for fixed-KV feasibility fail-closed behavior."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
DERIVE = TASK_ROOT / "scripts" / "derive-kv-budget.py"
ASSESS = TASK_ROOT / "scripts" / "assess-kv-feasibility.py"
GIB = 1024**3


def write_sweep(path: Path, *, kv_usage: float, total_token_max: int) -> None:
    run: dict[str, Any] = {
        "profile_config": {
            "pressure_kv_threshold": 0.8,
            "pressure_kv_p95_min": 0.8,
            "pressure_time_fraction_min": 0.15,
        },
        "backend_audit": {"passed": True},
        "request_success_rate": 1.0,
        "infrastructure_failure": None,
        "vllm_metrics": {
            "live_samples": [{"kv_cache_usage": kv_usage} for _ in range(20)],
            "live_series": {
                "kv_cache_usage_p95": kv_usage,
                "kv_cache_usage_max": kv_usage,
            },
        },
        "request_token_distribution": {"total_tokens": {"max": total_token_max}},
    }
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "kind": "real-swe-baseline-calibration-sweep",
                "status": "complete",
                "errors": [],
                "runs": {"calibration-72": run},
            }
        )
    )


def command(script: Path, source: Path, output: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            str(script),
            "--input",
            str(source),
            "--output",
            str(output),
            "--available-kv-gib",
            "60",
            "--observed-token-capacity",
            "48000",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def main() -> int:
    cases: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="kvbench-kv-feasibility-") as raw:
        root = Path(raw)

        unsafe_source = root / "unsafe.json"
        unsafe_output = root / "unsafe-decision.json"
        write_sweep(unsafe_source, kv_usage=0.0625, total_token_max=14000)
        unsafe = command(DERIVE, unsafe_source, unsafe_output)
        cases.append(
            {
                "name": "pressure_budget_below_single_request_bound_is_rejected",
                "passed": (
                    unsafe.returncode != 0
                    and not unsafe_output.exists()
                    and "below the single-request safety bound" in unsafe.stderr
                ),
            }
        )

        assessment_output = root / "assessment.json"
        assessment = command(ASSESS, unsafe_source, assessment_output)
        assessment_payload = json.loads(assessment_output.read_text()) if assessment_output.exists() else {}
        cases.append(
            {
                "name": "formal_assessment_records_non_overlapping_bounds",
                "passed": (
                    assessment.returncode == 0
                    and assessment_payload.get("status") == "infeasible_at_current_model_and_workload"
                    and assessment_payload.get("bounds_overlap") is False
                    and assessment_payload.get("selected_budget_bytes_per_gpu") is None
                ),
            }
        )

        feasible_source = root / "feasible.json"
        feasible_output = root / "feasible-decision.json"
        write_sweep(feasible_source, kv_usage=0.315, total_token_max=2000)
        feasible = command(DERIVE, feasible_source, feasible_output)
        feasible_payload = json.loads(feasible_output.read_text()) if feasible_output.exists() else {}
        selected = feasible_payload.get("derivation", {}).get("selected_budget_bytes_per_gpu", 0)
        cases.append(
            {
                "name": "overlapping_bounds_produce_probe_only_evidence",
                "passed": (
                    feasible.returncode == 0
                    and feasible_payload.get("status") == "probe_required"
                    and 1 * GIB <= selected < 60 * GIB
                ),
            }
        )

    report = {
        "schema_version": 1,
        "kind": "kv-budget-feasibility-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
