#!/usr/bin/env python3
"""Check that disjoint six-image partitions expand into independent 192-way rollouts."""

from __future__ import annotations

import json
import sys
import tempfile
from collections import Counter
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
SELECTION_PATH = TASK_ROOT / "scripts" / "swebench-compact-selection.json"
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.corpus import EXPECTED_DATASET, EXPECTED_DATASET_REVISION, make_swebench_specs  # noqa: E402


def instance_for_task(task_id: str, instance_ids: set[str]) -> str:
    matches = [
        instance_id
        for instance_id in instance_ids
        if task_id == instance_id or task_id.startswith(f"{instance_id}-r")
    ]
    if len(matches) != 1:
        raise RuntimeError(f"task ID does not map to exactly one compact instance: {task_id}")
    return matches[0]


def main() -> int:
    selection = json.loads(SELECTION_PATH.read_text())
    partitions = selection["partitions"]
    all_ids = set(partitions["public"]) | set(partitions["hidden"])
    entries = []
    for partition in ("public", "hidden"):
        for instance_id in partitions[partition]:
            entries.append(
                {
                    "instance_id": instance_id,
                    "repo": instance_id.split("__", 1)[0],
                    "partition": partition,
                    "problem_statement": f"Offline issue for {instance_id}",
                    "image_name": f"docker.io/swebench/{instance_id}:latest",
                    "official_manifest_digest": "sha256:" + "0" * 64,
                    "image_digest": "sha256:" + "1" * 64,
                    "base_commit": "2" * 40,
                    "runtime_head_commit": "3" * 40,
                    "verification_command": "git diff --check",
                }
            )
    manifest = {
        "schema_version": 1,
        "corpus_mode": "compact-repeated-rollouts",
        "dataset": EXPECTED_DATASET,
        "dataset_revision": EXPECTED_DATASET_REVISION,
        "instances": entries,
    }
    with tempfile.TemporaryDirectory(prefix="kvbench-compact-corpus-") as raw:
        root = Path(raw)
        (root / "manifest.json").write_text(json.dumps(manifest))
        public_specs = make_swebench_specs(
            "public-pressure",
            192,
            partition="public",
            seed=314159,
            root=root,
        )
        hidden_specs = make_swebench_specs(
            "hidden-pressure",
            192,
            partition="hidden",
            seed=730073,
            root=root,
        )

    public_ids = set(partitions["public"])
    hidden_ids = set(partitions["hidden"])
    public_reuse = Counter(instance_for_task(spec.task_id, public_ids) for spec in public_specs)
    hidden_reuse = Counter(instance_for_task(spec.task_id, hidden_ids) for spec in hidden_specs)
    report = {
        "schema_version": 1,
        "kind": "compact-corpus-unit",
        "passed": (
            len(all_ids) == 12
            and not (public_ids & hidden_ids)
            and len({entry["repo"] for entry in entries}) == 12
            and len(public_specs) == 192
            and len({spec.task_id for spec in public_specs}) == 192
            and set(public_reuse.values()) == {32}
            and len(hidden_specs) == 192
            and len({spec.task_id for spec in hidden_specs}) == 192
            and set(hidden_reuse.values()) == {32}
        ),
        "selected_instances": len(all_ids),
        "public_unique_instances": len(public_ids),
        "hidden_unique_instances": len(hidden_ids),
        "public_workflows": len(public_specs),
        "public_rollouts_per_instance": sorted(set(public_reuse.values())),
        "hidden_workflows": len(hidden_specs),
        "hidden_rollouts_per_instance": sorted(set(hidden_reuse.values())),
        "public_task_ids_unique": len({spec.task_id for spec in public_specs}),
        "hidden_task_ids_unique": len({spec.task_id for spec in hidden_specs}),
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
