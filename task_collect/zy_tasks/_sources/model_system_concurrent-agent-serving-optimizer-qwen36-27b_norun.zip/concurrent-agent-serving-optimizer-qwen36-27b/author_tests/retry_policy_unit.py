#!/usr/bin/env python3
"""Ensure the frozen hidden protocol never selectively retries a profile."""

from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
SERVER_PATH = TASK_ROOT / "environment" / "bench-controller" / "server.py"


def load_function():
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    selected = [
        node
        for node in parsed.body
        if isinstance(node, ast.FunctionDef) and node.name == "retryable_measurement_failure"
    ]
    if len(selected) != 1:
        raise RuntimeError("retry policy function was not found")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {"Any": Any}
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102 - trusted source
    return namespace["retryable_measurement_failure"]


def result(*, infra: list[str] | None = None, candidate: list[str] | None = None) -> dict:
    return {"infra_failures": infra or [], "candidate_failures": candidate or []}


def main() -> int:
    retryable = load_function()
    cases = [
        {
            "name": "candidate_failure_never_retries",
            "passed": retryable(result(candidate=["p:valid_step_ratio=0.993169<1.0000"])) is False,
        },
        {
            "name": "infra_failure_does_not_change_frozen_attempt_count",
            "passed": retryable(result(infra=["p:leg1:backend_audit"])) is False,
        },
        {
            "name": "metrics_sampler_error_does_not_trigger_selective_retry",
            "passed": retryable(
                result(infra=["p:leg1:profile_not_pressurized:metrics_sampler_error"])
            )
            is False,
        },
        {
            "name": "genuine_low_kv_pressure_never_retries",
            "passed": retryable(
                result(infra=["p:leg1:profile_not_pressurized:kv_p95_below_floor"])
            )
            is False,
        },
        {
            "name": "starvation_never_retries",
            "passed": retryable(result(candidate=["p:minimum_progress=0"])) is False,
        },
        {
            "name": "backend_work_shortcut_never_retries",
            "passed": retryable(result(candidate=["p:backend_work_ratio=0.5000"])) is False,
        },
    ]
    report = {
        "schema_version": 1,
        "kind": "clean-retry-policy-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
