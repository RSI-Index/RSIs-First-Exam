#!/usr/bin/env python3
"""Fail-closed tests for release evidence exporters."""

from __future__ import annotations

import contextlib
import copy
import importlib.util
import io
import json
import sys
import tempfile
from pathlib import Path
from unittest import mock


TASK_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = TASK_ROOT / "scripts" / "export-full-verifier-evidence.py"
SPEC = importlib.util.spec_from_file_location("export_full_verifier_evidence", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

ABBA_SCRIPT = TASK_ROOT / "scripts" / "export-abba-evidence.py"
ABBA_SPEC = importlib.util.spec_from_file_location("export_abba_evidence", ABBA_SCRIPT)
assert ABBA_SPEC and ABBA_SPEC.loader
ABBA_MODULE = importlib.util.module_from_spec(ABBA_SPEC)
ABBA_SPEC.loader.exec_module(ABBA_MODULE)

FREEZE_SCRIPT = TASK_ROOT / "scripts" / "freeze-release-manifest.py"
FREEZE_SPEC = importlib.util.spec_from_file_location("freeze_release_manifest", FREEZE_SCRIPT)
assert FREEZE_SPEC and FREEZE_SPEC.loader
FREEZE_MODULE = importlib.util.module_from_spec(FREEZE_SPEC)
FREEZE_SPEC.loader.exec_module(FREEZE_MODULE)

PROFILE_SHA = FREEZE_MODULE.QWEN_PROFILE_SHA256
RELEASE_ID = "qwen36-test-release"
CORPUS_SHA = "2" * 64
CONTROLLER_CONFIG_SHA = "3" * 64
RUNTIME_IMAGE_ID = "sha256:" + "4" * 64
CONTROLLER_IMAGE_ID = "sha256:" + "5" * 64
RUNTIME_READY_UNIX = 1_721_000_000.25
RUNTIME_WRAPPER_PID = 12345
RUNTIME_WRAPPER_START_TICKS = 987654321
RUNTIME_CONTAINER_ID = "6" * 64
RUNTIME_LAUNCH_TOKEN_SHA256 = "7" * 64
RUNTIME_BOOT_IDENTITY_SHA256 = MODULE.runtime_boot_identity_sha256(
    {
        "schema_version": 1,
        "state": "ready",
        "ready_unix": RUNTIME_READY_UNIX,
        "process": {
            "wrapper_pid": RUNTIME_WRAPPER_PID,
            "wrapper_start_ticks": RUNTIME_WRAPPER_START_TICKS,
        },
        "container": {
            "id": RUNTIME_CONTAINER_ID,
            "launch_token_sha256": RUNTIME_LAUNCH_TOKEN_SHA256,
        },
    }
)
REFERENCE_GATEWAY_TREE_SHA = MODULE.reference_gateway_tree_sha256()
REFERENCE_SUBMISSION_SHA = MODULE.reference_submission_sha256()
assert REFERENCE_GATEWAY_TREE_SHA == ABBA_MODULE.reference_gateway_tree_sha256()
assert REFERENCE_GATEWAY_TREE_SHA == FREEZE_MODULE.reference_gateway_tree_sha256()
assert REFERENCE_SUBMISSION_SHA == FREEZE_MODULE.reference_submission_sha256()
ORACLE_POLICY = {
    "schema_version": 2,
    "release_id": RELEASE_ID,
    "release_ready": True,
    "not_ready_reasons": [],
    "max_p99_step_latency_ratio": 1.25,
    "hidden_profiles": [
        {
            "name": "hidden-pressure-192",
            "weight": 1.0,
            "reference_speedup": 1.2,
        }
    ],
}
POLICY_SHA = MODULE.policy_contract_sha256(ORACLE_POLICY)
PUBLIC_WORKLOAD_NONCE = "unit-private-public-anchor-nonce"
PUBLIC_WORKLOAD_NONCE_SHA = MODULE.hashlib.sha256(
    PUBLIC_WORKLOAD_NONCE.encode()
).hexdigest()
SCORING_POLICY_FILE_SHA = MODULE.hashlib.sha256(
    MODULE.SCORING_POLICY.read_bytes()
).hexdigest()
HIDDEN_WORKLOAD_NONCE_SHA = "b" * 64


def model_provenance() -> dict:
    return {
        "profile_id": MODULE.QWEN_PROFILE_ID,
        "profile_sha256": PROFILE_SHA,
        "model_revision": MODULE.QWEN_REVISION,
        "runtime_image_id": RUNTIME_IMAGE_ID,
        "tensor_parallel_size": 2,
        "kv_cache_dtype": "fp8",
        "runtime_boot_identity_sha256": RUNTIME_BOOT_IDENTITY_SHA256,
    }


def pressure_validation(required: bool) -> dict:
    paths = ["audited_active_working_set"] if required else []
    return {
        "qualification_schema_version": 1,
        "required": required,
        "valid": True,
        "contention_evidence": {
            "required": required,
            "valid": True,
            "qualification_paths": paths,
            "active_working_set": {"valid": required},
            "preemption": {"valid": False, "preemptions_delta": 0.0},
        },
        "reasons": [],
    }


def oversubscribed_pressure_validation() -> dict:
    return {
        "qualification_schema_version": 1,
        "required": True,
        "valid": True,
        "contention_evidence": {
            "required": True,
            "valid": True,
            "qualification_paths": ["audited_oversubscribed_working_set"],
            "active_working_set": {"valid": False},
            "oversubscribed_working_set": {
                "valid": True,
                "occupancy_independent": True,
                "demand_ratio_threshold": 1.0,
                "corroboration_paths": [
                    "synchronized_waiting",
                    "leg_local_cache_churn",
                ],
                "synchronized_waiting": {"valid": True},
                "leg_local_cache_churn": {"valid": True},
            },
            "preemption": {"valid": False, "preemptions_delta": 0.0},
        },
        "reasons": [],
    }


def finite_timing() -> dict:
    return {
        "started_unix": 100.0,
        "ended_unix": 160.0,
        "elapsed_sec": 60.0,
        "wall_elapsed_sec": 65.0,
        "valid_steps": 100,
        "valid_steps_per_min": 100.0,
        "p95_step_latency_sec": 90.0,
        "p99_step_latency_sec": 100.0,
        "measurement_window": {
            "configured": False,
            "deadline_reached": False,
            "termination": "finite_workload",
        },
        "agent_execution_interval": {
            "schema_version": 1,
            "start_event": "measured_leg_started",
            "end_event": "last_agent_run_termination",
            "duration_clock": "monotonic",
            "started_unix": 100.0,
            "ended_unix": 160.0,
            "elapsed_sec": 60.0,
            "expected_agent_runs": 192,
            "observed_agent_runs": 192,
            "complete": True,
        },
    }


def tail_report() -> dict:
    return {
        "schema_version": 2,
        "metric": "p99_step_latency_sec",
        "pairing": "candidate_over_baseline:single_committed_pair",
        "baseline_p99_step_latency_sec": 100.0,
        "candidate_p99_step_latency_sec": 110.0,
        "ratio": 1.1,
        "maximum_allowed_ratio": 1.25,
        "passed": True,
    }


def v5_health(*, deep: int) -> dict:
    return {
        "status": "ok",
        "oracle": "thunderagent-extracted",
        "thunderagent_source_commit": MODULE.THUNDERAGENT_SOURCE_COMMIT,
        "reference_gateway_tree_sha256_at_start": REFERENCE_GATEWAY_TREE_SHA,
        "scheduler": {
            **copy.deepcopy(MODULE.EXPECTED_V5_TIER_POLICY),
            "deep_pending_request_waiters_peak": deep,
            "deep_pause_wait_count": deep,
            "counters": {
                "deep_request_offers": deep,
                "deep_service_lag_bypass_decisions": deep,
                "resume_deep_request": deep,
                "deep_sjf_priority_ticks": deep,
                "mixed_request_tier_ticks": deep,
            },
        },
    }


def candidate_health_observation(ordinal: int) -> dict:
    return {
        "schema_version": 1,
        "leg_ordinal": ordinal,
        "capture_status": "ok",
        "http_status": 200,
        "response_bytes": 2048,
        "selected": v5_health(deep=ordinal),
    }


def public_pair() -> dict:
    def leg(mode: str) -> dict:
        return {
            "mode": mode,
            "run_id": f"public-{mode}",
            "profile": MODULE.PUBLIC_ORACLE_PROFILE,
            "corpus_namespace": "public-public-pressure-192",
            "corpus_fingerprint": "a" * 64,
            "release_id": RELEASE_ID,
            "controller_config_sha256": CONTROLLER_CONFIG_SHA,
            "model_provenance": model_provenance(),
            "workload_nonce_sha256": PUBLIC_WORKLOAD_NONCE_SHA,
            "elapsed_sec": 1800.0,
            "valid_step_ratio": 0.99,
            "jain_progress_fairness": 0.95,
            "request_success_rate": 0.98,
            "profile_config": {
                "name": MODULE.PUBLIC_ORACLE_PROFILE,
                "measurement_window_sec": 1800,
                "workflows": 192,
                "concurrency": 192,
                "max_steps": 24,
                "corpus_partition": "public",
            },
            "measurement_window": {
                "schema_version": 1,
                "configured": True,
                "duration_sec": 1800,
                "deadline_reached": True,
                "termination": "trusted_fixed_window",
                "control_passed": True,
                "passed": True,
                "measurement_elapsed_sec": 1800.0,
                "zero_progress_fraction": 0.05,
            },
        }

    return {
        "schema_version": 1,
        "kind": "isolated-reference-thunderagent-pair",
        "status": "complete",
        "passed": True,
        "errors": [],
        "suite": "public",
        "profile": MODULE.PUBLIC_ORACLE_PROFILE,
        "order": ["direct_baseline", "fresh_thunderagent_oracle"],
        "workload_nonce_sha256": PUBLIC_WORKLOAD_NONCE_SHA,
        "reference_gateway_tree_sha256": REFERENCE_GATEWAY_TREE_SHA,
        "thunderagent_source_commit": MODULE.THUNDERAGENT_SOURCE_COMMIT,
        "controller": {"image_id": CONTROLLER_IMAGE_ID},
        "controller_readiness": {
            "release_id": RELEASE_ID,
            "controller_config_sha256": CONTROLLER_CONFIG_SHA,
            "policy_contract_sha256": POLICY_SHA,
            "corpus_manifest_sha256": CORPUS_SHA,
        },
        "legs": {
            "baseline": leg("baseline"),
            "candidate": leg("candidate"),
        },
        "evaluation": {
            "passed": True,
            "contracts_passed": True,
            "quality_passed": True,
            "contracts": {
                "oracle_deep_tier_matches_measurement_shape": True,
                "all_other_pair_contracts": True,
            },
            "effect": {
                "passed": True,
                "minimum_speedup": 1.0,
                "speedup": 1.1,
            },
        },
        "lifecycle": {"gateway_health_after_candidate": v5_health(deep=1)},
    }


def public_direct_anchor(pair: dict, pair_raw: bytes) -> dict:
    baseline = pair["legs"]["baseline"]
    provenance = baseline["model_provenance"]
    return {
        "schema_version": 1,
        "kind": MODULE.PUBLIC_DIRECT_ANCHOR_KIND,
        "created_at_utc": "2026-07-19T00:00:00Z",
        "release_id": RELEASE_ID,
        "policy_release_id": RELEASE_ID,
        "suite": "public",
        "profile": MODULE.PUBLIC_ORACLE_PROFILE,
        "workload_nonce": PUBLIC_WORKLOAD_NONCE,
        "workload_nonce_sha256": PUBLIC_WORKLOAD_NONCE_SHA,
        "baseline_run_id": baseline["run_id"],
        "baseline": copy.deepcopy(baseline),
        "source_report_sha256": MODULE.hashlib.sha256(pair_raw).hexdigest(),
        "scoring_policy_sha256": SCORING_POLICY_FILE_SHA,
        "controller_config_sha256": CONTROLLER_CONFIG_SHA,
        "controller_image_id": CONTROLLER_IMAGE_ID,
        "corpus_namespace": baseline["corpus_namespace"],
        "corpus_fingerprint": baseline["corpus_fingerprint"],
        "model_provenance": copy.deepcopy(provenance),
        "model_provenance_sha256": MODULE.canonical_object_sha256(provenance),
    }


def report() -> dict:
    provenance = model_provenance()
    return {
        "schema_version": 1,
        "phase": "final",
        # A stale top-level value must never override the trusted controller's
        # nested benchmark value.
        "corpus_manifest_sha256": "9" * 64,
        "reward": 1.0,
        "correctness": 1.0,
        "backend_audit": 1.0,
        "infra_valid": 1.0,
        "artifacts": {"bench_controller_image_id": CONTROLLER_IMAGE_ID},
        "benchmark": {
            "schema_version": 2,
            "release_id": RELEASE_ID,
            "policy_contract_sha256": POLICY_SHA,
            "controller_config_sha256": CONTROLLER_CONFIG_SHA,
            "corpus_manifest_sha256": CORPUS_SHA,
            "model_profile_sha256": PROFILE_SHA,
            "model_provenance": provenance,
            "suite_nonce_sha256": "6" * 64,
            "candidate_lifecycle": {
                "schema_version": 1,
                "frozen_submission_sha256": REFERENCE_SUBMISSION_SHA,
                "network_egress_seal": {
                    "schema_version": 2,
                    "protocol": "same-compose-main-egress-hmac-v2",
                    "sealed": True,
                    "controller_image_id": CONTROLLER_IMAGE_ID,
                },
                "epoch_count": 2,
                "candidate_process_epoch_count": 1,
                "epochs": [
                    {
                        "mode": mode,
                        "leg_ordinal": index,
                        **(
                            {"gateway_process_identity_sha256": f"{index}" * 64}
                            if mode == "candidate"
                            else {}
                        ),
                    }
                    for index, mode in enumerate(
                        ("baseline", "candidate"),
                        start=1,
                    )
                ],
            },
            "hard_gates_passed": True,
            "status": "ok",
            "performance_score": 1.0,
            "reward": 1.0,
            "profiles": {
                "hidden-pressure-192": {
                    "weight": 1.0,
                    "speedup": 1.25,
                    "reference_speedup": 1.2,
                    "performance_score": 1.0,
                    "leg_order_commitment": {
                        "schema_version": 1,
                        "protocol": MODULE.FINAL_LEG_ORDER_PROTOCOL,
                        "context": "kvbench-final-leg-order-v1",
                        "workload_nonce_sha256": HIDDEN_WORKLOAD_NONCE_SHA,
                        "order": ["baseline", "candidate"],
                    },
                    "tail_anti_gaming": tail_report(),
                    "legs": [
                        {
                            **finite_timing(),
                            "mode": mode,
                            "workload_nonce_sha256": HIDDEN_WORKLOAD_NONCE_SHA,
                            "run_id": f"test-{index}",
                            "p99_step_latency_sec": (
                                110.0 if mode == "candidate" else 100.0
                            ),
                            "model_provenance": copy.deepcopy(provenance),
                            "profile_config": {
                                "pressure_required": True,
                                "workflows": 192,
                            },
                            "pressure_validation": pressure_validation(
                                mode == "baseline"
                            ),
                            "backend_audit": {"passed": True},
                            "warmup_audit": {"passed": True},
                            "vllm_metrics": {
                                "counter_deltas": [],
                                "live_samples": [{"created_unix": 160.0}],
                                "live_series": {"sampler_error_count": 0},
                            },
                        }
                        for index, mode in enumerate(
                            ("baseline", "candidate")
                        )
                    ],
                }
            },
        },
        "checks": {
            "attestation": {
                "schema_version": 1,
                "state": "ready",
                "ready_unix": RUNTIME_READY_UNIX,
                "profile_id": MODULE.QWEN_PROFILE_ID,
                "profile_sha256": PROFILE_SHA,
                "model_mount_read_only": True,
                "observed_vllm_package_version": "0.24.0",
                "model": {
                    "profile_id": MODULE.QWEN_PROFILE_ID,
                    "revision": MODULE.QWEN_REVISION,
                    "model_path": "/home/unit/private/model",
                    "file_hashes": {
                        "config.json": MODULE.QWEN_CONFIG_SHA256,
                        "model.safetensors.index.json": (
                            MODULE.QWEN_WEIGHT_INDEX_SHA256
                        ),
                    },
                },
                "runtime": {
                    "runtime_image_id": RUNTIME_IMAGE_ID,
                    "vllm_package_version": MODULE.QWEN_VLLM_PACKAGE_VERSION,
                    "tensor_parallel_size": 2,
                    "kv_cache_dtype": "fp8",
                    "tool_call_parser": None,
                    "reasoning_parser": "qwen3",
                },
                "process": {
                    "wrapper_pid": RUNTIME_WRAPPER_PID,
                    "wrapper_start_ticks": RUNTIME_WRAPPER_START_TICKS,
                },
                "container": {
                    "id": RUNTIME_CONTAINER_ID,
                    "launch_token_sha256": RUNTIME_LAUNCH_TOKEN_SHA256,
                },
                "gpus": [{"index": 6}, {"index": 7}],
            },
            "isolation": {},
            "protocol": {},
            "real_protocol_audit": {"requests": []},
            "candidate_post_leg_health": {
                "schema_version": 1,
                "observations": {
                    "2": candidate_health_observation(2),
                },
            },
        },
    }


def rejects(callable_, label: str) -> None:
    try:
        callable_()
    except SystemExit:
        return
    raise AssertionError(f"expected fail-closed rejection: {label}")


def rejects_oserror(callable_, label: str) -> None:
    try:
        callable_()
    except OSError:
        return
    raise AssertionError(f"expected tree hashing rejection: {label}")


def validate(payload: dict) -> dict:
    return MODULE.validate_qwen_provenance(payload, RELEASE_ID, PROFILE_SHA)


valid = report()
assert validate(valid)["corpus_manifest_sha256"] == CORPUS_SHA
cleaned_attestation = MODULE.clean_attestation(valid["checks"]["attestation"])
assert (
    cleaned_attestation["runtime_boot_identity_sha256"]
    == RUNTIME_BOOT_IDENTITY_SHA256
)
assert set(cleaned_attestation) == MODULE.PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS
cleaned_rendered = json.dumps(cleaned_attestation, sort_keys=True)
assert "process" not in cleaned_attestation and "container" not in cleaned_attestation
assert RUNTIME_CONTAINER_ID not in cleaned_rendered
assert "/home/unit/private/model" not in cleaned_rendered

restarted_host = report()
restarted_host["checks"]["attestation"]["process"][
    "wrapper_start_ticks"
] += 1
rejects(lambda: validate(restarted_host), "static-equal restarted host runtime")

for field in (
    "policy_contract_sha256",
    "controller_config_sha256",
    "corpus_manifest_sha256",
    "model_profile_sha256",
    "model_provenance",
):
    missing = report()
    missing["benchmark"].pop(field)
    rejects(lambda missing=missing: validate(missing), f"missing benchmark {field}")

top_level_only_corpus = report()
top_level_only_corpus["benchmark"].pop("corpus_manifest_sha256")
assert top_level_only_corpus["corpus_manifest_sha256"] == "9" * 64
rejects(lambda: validate(top_level_only_corpus), "top-level corpus digest fallback")

old_model = report()
old_model["checks"]["attestation"]["profile_id"] = "deepseek-v4-flash-h100-nvl-tp8-v1"
rejects(lambda: validate(old_model), "old model")

wrong_release = report()
wrong_release["benchmark"]["release_id"] = "old-release"
rejects(lambda: validate(wrong_release), "old release")

wrong_phase = report()
wrong_phase["phase"] = "phase0"
rejects(lambda: validate(wrong_phase), "non-final report")

boolean_schema = report()
boolean_schema["benchmark"]["schema_version"] = True
rejects(lambda: validate(boolean_schema), "boolean benchmark schema")

bad_policy_digest = report()
bad_policy_digest["benchmark"]["policy_contract_sha256"] = "not-a-digest"
rejects(lambda: validate(bad_policy_digest), "invalid policy digest")

for field, value in (
    ("profile_sha256", "0" * 64),
    ("model_revision", "0" * 40),
    ("runtime_image_id", "sha256:" + "0" * 64),
    ("tensor_parallel_size", 4),
    ("kv_cache_dtype", "auto"),
    ("runtime_boot_identity_sha256", "8" * 64),
):
    mismatch = report()
    mismatch["benchmark"]["model_provenance"][field] = value
    rejects(lambda mismatch=mismatch: validate(mismatch), f"benchmark provenance {field}")

leg_mismatch = report()
leg_mismatch["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][0][
    "model_provenance"
]["runtime_image_id"] = "sha256:" + "0" * 64
rejects(lambda: validate(leg_mismatch), "leg provenance")

missing_legs = report()
missing_legs["benchmark"]["profiles"]["hidden-pressure-192"]["legs"] = []
rejects(lambda: validate(missing_legs), "missing benchmark legs")

missing_interval = report()
missing_interval["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][0].pop(
    "agent_execution_interval"
)
rejects(lambda: validate(missing_interval), "missing finite agent interval")

rate_tamper = report()
rate_tamper["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][1][
    "valid_steps_per_min"
] = 101.0
rejects(lambda: validate(rate_tamper), "finite throughput identity tamper")

post_end_sample = report()
post_end_sample["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][1][
    "vllm_metrics"
]["live_samples"].append({"created_unix": 160.1})
rejects(lambda: validate(post_end_sample), "post-agent-end live metric sample")

occupancy_only = report()
occupancy_only["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][0][
    "pressure_validation"
].pop("contention_evidence")
rejects(lambda: validate(occupancy_only), "legacy occupancy-only pressure")

waiting_only = report()
waiting_pressure = waiting_only["benchmark"]["profiles"]["hidden-pressure-192"][
    "legs"
][0]["pressure_validation"]
waiting_pressure["contention_evidence"]["qualification_paths"] = [
    "scheduler_waiting_at_high_kv"
]
rejects(lambda: validate(waiting_only), "waiting-only KV qualification")

oversubscribed = report()
oversubscribed_leg = oversubscribed["benchmark"]["profiles"][
    "hidden-pressure-192"
]["legs"][0]
oversubscribed_leg["pressure_validation"] = oversubscribed_pressure_validation()
assert validate(oversubscribed)["corpus_manifest_sha256"] == CORPUS_SHA


def oversubscribed_evidence(payload: dict) -> dict:
    return payload["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][0][
        "pressure_validation"
    ]["contention_evidence"]["oversubscribed_working_set"]


oversubscribed_mutations = {
    "oversubscribed valid": lambda item: oversubscribed_evidence(item).__setitem__(
        "valid", False
    ),
    "oversubscribed occupancy independence": lambda item: oversubscribed_evidence(
        item
    ).__setitem__("occupancy_independent", False),
    "oversubscribed demand threshold": lambda item: oversubscribed_evidence(
        item
    ).__setitem__("demand_ratio_threshold", 0.99),
    "oversubscribed boolean demand threshold": lambda item: oversubscribed_evidence(
        item
    ).__setitem__("demand_ratio_threshold", True),
    "oversubscribed empty corroboration": lambda item: oversubscribed_evidence(
        item
    ).__setitem__("corroboration_paths", []),
    "oversubscribed unknown corroboration": lambda item: oversubscribed_evidence(
        item
    ).__setitem__("corroboration_paths", ["scheduler_waiting_at_high_kv"]),
    "oversubscribed synchronized waiting": lambda item: oversubscribed_evidence(
        item
    )["synchronized_waiting"].__setitem__("valid", False),
    "oversubscribed cache churn": lambda item: oversubscribed_evidence(item)[
        "leg_local_cache_churn"
    ].__setitem__("valid", False),
}
for label, mutate in oversubscribed_mutations.items():
    payload = copy.deepcopy(oversubscribed)
    mutate(payload)
    rejects(lambda payload=payload: validate(payload), label)

# The exploratory ABBA sanitizer uses the same release qualification contract.
abba_leg = copy.deepcopy(oversubscribed_leg)
ABBA_MODULE.validate_pressure_qualification(abba_leg, Path("unit-abba.json"))
for label, mutate in oversubscribed_mutations.items():
    payload = copy.deepcopy(oversubscribed)
    mutate(payload)
    mutated_leg = payload["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][0]
    rejects(
        lambda mutated_leg=mutated_leg: ABBA_MODULE.validate_pressure_qualification(
            mutated_leg, Path("unit-abba.json")
        ),
        f"ABBA {label}",
    )

MODULE.validate_cli_bindings(
    report(),
    run_kind="oracle",
    gateway_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
    controller_image_id=CONTROLLER_IMAGE_ID,
)
rejects(
    lambda: MODULE.validate_cli_bindings(
        report(),
        run_kind="oracle",
        gateway_tree_sha256="0" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "Oracle tree digest not bound to local reference",
)


def validate_oracle(payload: dict, *, run_kind: str = "oracle") -> None:
    MODULE.validate_oracle_identity_and_performance(
        payload["benchmark"],
        run_kind=run_kind,
        release_id=RELEASE_ID,
        reference_submission_sha256_value=REFERENCE_SUBMISSION_SHA,
        scoring_policy=ORACLE_POLICY,
    )


validate_oracle(report())
recomputed_tail = MODULE.recompute_hidden_tail_anti_gaming(
    report()["benchmark"], ORACLE_POLICY
)
assert recomputed_tail["all_profiles_passed"] is True
assert recomputed_tail["profiles"]["hidden-pressure-192"] == tail_report()

forged_tail_leg = report()
forged_tail_leg["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][1][
    "p99_step_latency_sec"
] = 130.0
rejects(
    lambda: MODULE.recompute_hidden_tail_anti_gaming(
        forged_tail_leg["benchmark"], ORACLE_POLICY
    ),
    "forged passing tail report with regressed raw candidate leg",
)

forged_tail_declaration = report()
forged_tail_declaration["benchmark"]["profiles"]["hidden-pressure-192"][
    "tail_anti_gaming"
]["ratio"] = 1.0
rejects(
    lambda: MODULE.recompute_hidden_tail_anti_gaming(
        forged_tail_declaration["benchmark"], ORACLE_POLICY
    ),
    "forged declared tail ratio",
)

single_pair_failure = report()
single_pair_profile = single_pair_failure["benchmark"]["profiles"]["hidden-pressure-192"]
single_pair_profile["legs"][1]["p99_step_latency_sec"] = 126.0
single_pair_profile["tail_anti_gaming"] = {
    "schema_version": 2,
    "metric": "p99_step_latency_sec",
    "pairing": "candidate_over_baseline:single_committed_pair",
    "baseline_p99_step_latency_sec": 100.0,
    "candidate_p99_step_latency_sec": 126.0,
    "ratio": 1.26,
    "maximum_allowed_ratio": 1.25,
    "passed": False,
}
rejects(
    lambda: MODULE.recompute_hidden_tail_anti_gaming(
        single_pair_failure["benchmark"], ORACLE_POLICY
    ),
    "single committed pair tail failure",
)
low_speedup = report()
low_speedup["benchmark"]["profiles"]["hidden-pressure-192"]["speedup"] = 0.99
rejects(lambda: validate_oracle(low_speedup), "Oracle speedup below baseline")

below_reference = report()
below_reference["benchmark"]["profiles"]["hidden-pressure-192"]["speedup"] = 1.19
rejects(lambda: validate_oracle(below_reference), "Oracle speedup below frozen reference")

mislabeled_candidate = report()
mislabeled_candidate["benchmark"]["candidate_lifecycle"][
    "frozen_submission_sha256"
] = "a" * 64
rejects(lambda: validate_oracle(mislabeled_candidate), "passing candidate relabeled Oracle")
# A normal candidate report is not required to be byte-identical to the Oracle.
validate_oracle(mislabeled_candidate, run_kind="frozen-candidate")

reference_drift = report()
reference_drift["benchmark"]["profiles"]["hidden-pressure-192"][
    "reference_speedup"
] = 1.1
rejects(lambda: validate_oracle(reference_drift), "Oracle reference speedup drift")

performance_drift = report()
performance_drift["benchmark"]["profiles"]["hidden-pressure-192"][
    "performance_score"
] = 0.99
rejects(lambda: validate_oracle(performance_drift), "Oracle profile performance drift")

hidden_tier = MODULE.validate_hidden_oracle_tier_qualification(
    report(),
    report()["benchmark"],
    expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
)
assert hidden_tier["candidate_leg_ordinal"] == 2
assert all(value > 0 for value in hidden_tier["observation"]["deep_signals"].values())

ba = report()
ba_profile = ba["benchmark"]["profiles"]["hidden-pressure-192"]
ba_profile["legs"].reverse()
ba_profile["leg_order_commitment"] = {
    "schema_version": 1,
    "protocol": MODULE.FINAL_LEG_ORDER_PROTOCOL,
    "context": "kvbench-final-leg-order-v1",
    "workload_nonce_sha256": "8" * 64,
    "order": ["candidate", "baseline"],
}
for leg_item in ba_profile["legs"]:
    leg_item["workload_nonce_sha256"] = "8" * 64
ba["benchmark"]["candidate_lifecycle"]["epochs"].reverse()
for ordinal, epoch in enumerate(
    ba["benchmark"]["candidate_lifecycle"]["epochs"], start=1
):
    epoch["leg_ordinal"] = ordinal
ba["checks"]["candidate_post_leg_health"]["observations"] = {
    "1": candidate_health_observation(1)
}
assert MODULE.validate_hidden_oracle_tier_qualification(
    ba, ba["benchmark"], expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA
)["candidate_leg_ordinal"] == 1
assert MODULE.recompute_hidden_tail_anti_gaming(
    ba["benchmark"], ORACLE_POLICY
)["all_profiles_passed"] is True
public_tier = MODULE.validate_public_oracle_pair(
    public_pair(),
    report()["benchmark"],
    expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
    expected_controller_image_id=CONTROLLER_IMAGE_ID,
    expected_release_id=RELEASE_ID,
)
assert all(value > 0 for value in public_tier["deep_signals"].values())
assert public_tier["mixed_request_tier_ticks"] > 0

anchor_pair = public_pair()
anchor_pair_raw = (json.dumps(anchor_pair, sort_keys=True) + "\n").encode()
anchor_payload = public_direct_anchor(anchor_pair, anchor_pair_raw)
anchor_raw = (json.dumps(anchor_payload, sort_keys=True) + "\n").encode()
anchor_binding = MODULE.validate_public_direct_anchor(
    anchor_payload,
    anchor_raw=anchor_raw,
    public_pair=anchor_pair,
    public_pair_raw=anchor_pair_raw,
    benchmark=report()["benchmark"],
    scoring_policy=ORACLE_POLICY,
    expected_controller_image_id=CONTROLLER_IMAGE_ID,
    expected_release_id=RELEASE_ID,
)
assert anchor_binding["sha256"] == MODULE.hashlib.sha256(anchor_raw).hexdigest()
assert anchor_binding["source_report_sha256"] == MODULE.hashlib.sha256(
    anchor_pair_raw
).hexdigest()
assert "workload_nonce" not in anchor_binding and "baseline" not in anchor_binding
for field in (
    "source_report_sha256",
    "scoring_policy_sha256",
    "controller_config_sha256",
    "controller_image_id",
    "corpus_fingerprint",
    "model_provenance_sha256",
):
    mutated_anchor = copy.deepcopy(anchor_payload)
    mutated_anchor[field] = "0" * 64
    rejects(
        lambda mutated_anchor=mutated_anchor: MODULE.validate_public_direct_anchor(
            mutated_anchor,
            anchor_raw=anchor_raw,
            public_pair=anchor_pair,
            public_pair_raw=anchor_pair_raw,
            benchmark=report()["benchmark"],
            scoring_policy=ORACLE_POLICY,
            expected_controller_image_id=CONTROLLER_IMAGE_ID,
            expected_release_id=RELEASE_ID,
        ),
        f"public Direct anchor {field} drift",
    )
mutated_anchor_baseline = copy.deepcopy(anchor_payload)
mutated_anchor_baseline["baseline"]["run_id"] = "forged-baseline"
rejects(
    lambda: MODULE.validate_public_direct_anchor(
        mutated_anchor_baseline,
        anchor_raw=anchor_raw,
        public_pair=anchor_pair,
        public_pair_raw=anchor_pair_raw,
        benchmark=report()["benchmark"],
        scoring_policy=ORACLE_POLICY,
        expected_controller_image_id=CONTROLLER_IMAGE_ID,
        expected_release_id=RELEASE_ID,
    ),
    "public Direct anchor raw baseline drift",
)

for label, leg_name, field_path, value in (
    (
        "candidate zero progress above 0.05",
        "candidate",
        ("measurement_window", "zero_progress_fraction"),
        0.051,
    ),
    (
        "baseline request success below 0.98",
        "baseline",
        ("request_success_rate",),
        0.979,
    ),
    ("candidate valid-step ratio below 0.90", "candidate", ("valid_step_ratio",), 0.899),
):
    mutated_public = public_pair()
    target = mutated_public["legs"][leg_name]
    for key in field_path[:-1]:
        target = target[key]
    target[field_path[-1]] = value
    # Keep the self-declared aggregate booleans true: the exporter must reject
    # from raw leg values, not by trusting evaluation.quality_passed.
    assert mutated_public["evaluation"]["quality_passed"] is True
    rejects(
        lambda mutated_public=mutated_public: MODULE.validate_public_oracle_pair(
            mutated_public,
            report()["benchmark"],
            expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
            expected_controller_image_id=CONTROLLER_IMAGE_ID,
            expected_release_id=RELEASE_ID,
        ),
        label,
    )

missing_hidden_observation = report()
missing_hidden_observation["checks"]["candidate_post_leg_health"][
    "observations"
].pop("2")
rejects(
    lambda: MODULE.validate_hidden_oracle_tier_qualification(
        missing_hidden_observation,
        missing_hidden_observation["benchmark"],
        expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
    ),
    "missing hidden B observation",
)

hidden_zero = report()
hidden_zero["checks"]["candidate_post_leg_health"]["observations"]["2"][
    "selected"
]["scheduler"]["counters"]["resume_deep_request"] = 0
rejects(
    lambda: MODULE.validate_hidden_oracle_tier_qualification(
        hidden_zero,
        hidden_zero["benchmark"],
        expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
    ),
    "zero hidden deep signal",
)

hidden_wrong_tree = report()
hidden_wrong_tree["checks"]["candidate_post_leg_health"]["observations"]["2"][
    "selected"
]["reference_gateway_tree_sha256_at_start"] = "0" * 64
rejects(
    lambda: MODULE.validate_hidden_oracle_tier_qualification(
        hidden_wrong_tree,
        hidden_wrong_tree["benchmark"],
        expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
    ),
    "wrong hidden Oracle tree",
)

public_missing_deep = public_pair()
public_missing_deep["lifecycle"]["gateway_health_after_candidate"]["scheduler"][
    "counters"
]["deep_request_offers"] = 0
rejects(
    lambda: MODULE.validate_public_oracle_pair(
        public_missing_deep,
        report()["benchmark"],
        expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
        expected_controller_image_id=CONTROLLER_IMAGE_ID,
        expected_release_id=RELEASE_ID,
    ),
    "missing public deep signal",
)

public_wrong_tree = public_pair()
public_wrong_tree["reference_gateway_tree_sha256"] = "0" * 64
rejects(
    lambda: MODULE.validate_public_oracle_pair(
        public_wrong_tree,
        report()["benchmark"],
        expected_tree_sha256=REFERENCE_GATEWAY_TREE_SHA,
        expected_controller_image_id=CONTROLLER_IMAGE_ID,
        expected_release_id=RELEASE_ID,
    ),
    "wrong public Oracle tree",
)

raw_labels = report()
raw_labels["run_kind"] = "frozen-candidate"
raw_labels["artifacts"] = {
    "reference_gateway_tree_sha256": "7" * 64,
    "bench_controller_image_id": CONTROLLER_IMAGE_ID,
}
MODULE.validate_cli_bindings(
    raw_labels,
    run_kind="frozen-candidate",
    gateway_tree_sha256="7" * 64,
    controller_image_id=CONTROLLER_IMAGE_ID,
)

wrong_kind = copy.deepcopy(raw_labels)
wrong_kind["run_kind"] = "oracle"
rejects(
    lambda: MODULE.validate_cli_bindings(
        wrong_kind,
        run_kind="frozen-candidate",
        gateway_tree_sha256="7" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "raw run_kind relabel",
)

wrong_gateway = copy.deepcopy(raw_labels)
wrong_gateway["artifacts"]["reference_gateway_tree_sha256"] = "8" * 64
rejects(
    lambda: MODULE.validate_cli_bindings(
        wrong_gateway,
        run_kind="frozen-candidate",
        gateway_tree_sha256="7" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "raw gateway relabel",
)

wrong_controller = copy.deepcopy(raw_labels)
wrong_controller["artifacts"]["bench_controller_image_id"] = "sha256:" + "8" * 64
rejects(
    lambda: MODULE.validate_cli_bindings(
        wrong_controller,
        run_kind="frozen-candidate",
        gateway_tree_sha256="7" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "raw controller relabel",
)

wrong_attested_controller = copy.deepcopy(raw_labels)
wrong_attested_controller["benchmark"]["candidate_lifecycle"][
    "network_egress_seal"
]["controller_image_id"] = "sha256:" + "8" * 64
rejects(
    lambda: MODULE.validate_cli_bindings(
        wrong_attested_controller,
        run_kind="frozen-candidate",
        gateway_tree_sha256="7" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "trusted raw controller image relabel",
)

missing_controller_seal = copy.deepcopy(raw_labels)
missing_controller_seal["benchmark"]["candidate_lifecycle"].pop(
    "network_egress_seal"
)
rejects(
    lambda: MODULE.validate_cli_bindings(
        missing_controller_seal,
        run_kind="frozen-candidate",
        gateway_tree_sha256="7" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "missing trusted raw controller image seal",
)

partial_artifacts = copy.deepcopy(raw_labels)
partial_artifacts["artifacts"].pop("bench_controller_image_id")
rejects(
    lambda: MODULE.validate_cli_bindings(
        partial_artifacts,
        run_kind="frozen-candidate",
        gateway_tree_sha256="7" * 64,
        controller_image_id=CONTROLLER_IMAGE_ID,
    ),
    "partial raw artifacts",
)

with tempfile.TemporaryDirectory(prefix="full-exporter-current-schema-") as temporary:
    root = Path(temporary)
    raw_path = root / "raw.json"
    public_path = root / "public-pair.json"
    anchor_path = root / "private-public-direct-anchor.json"
    output_path = root / "evidence.json"
    raw_path.write_text(json.dumps(report()) + "\n")
    pair_payload = public_pair()
    public_path.write_text(json.dumps(pair_payload) + "\n")
    anchor_path.write_text(
        json.dumps(public_direct_anchor(pair_payload, public_path.read_bytes())) + "\n"
    )
    argv = [
        str(SCRIPT),
        "--input",
        str(raw_path),
        "--public-pair-input",
        str(public_path),
        "--public-direct-anchor-input",
        str(anchor_path),
        "--output",
        str(output_path),
        "--run-kind",
        "oracle",
        "--gateway-tree-sha256",
        REFERENCE_GATEWAY_TREE_SHA,
        "--controller-image-id",
        CONTROLLER_IMAGE_ID,
        "--release-id",
        RELEASE_ID,
        "--model-profile-sha256",
        PROFILE_SHA,
    ]
    with (
        mock.patch.object(sys, "argv", argv),
        mock.patch.object(MODULE, "load_scoring_policy", return_value=ORACLE_POLICY),
        contextlib.redirect_stdout(io.StringIO()),
    ):
        assert MODULE.main() == 0
    exported = json.loads(output_path.read_text())
    assert exported["corpus_manifest_sha256"] == CORPUS_SHA
    assert exported["corpus_manifest_sha256"] != report()["corpus_manifest_sha256"]
    assert exported["artifacts"] == {
        "reference_gateway_tree_sha256": REFERENCE_GATEWAY_TREE_SHA,
        "reference_submission_sha256": REFERENCE_SUBMISSION_SHA,
        "bench_controller_image_id": CONTROLLER_IMAGE_ID,
    }
    assert exported["raw_public_pair"]["sha256"] == MODULE.hashlib.sha256(
        public_path.read_bytes()
    ).hexdigest()
    assert set(exported["raw_private_report"]) == {"sha256", "bytes"}
    assert set(exported["raw_public_pair"]) == {"sha256", "bytes"}
    assert exported["public_direct_anchor"]["sha256"] == MODULE.hashlib.sha256(
        anchor_path.read_bytes()
    ).hexdigest()
    assert exported["public_direct_anchor"]["source_report_sha256"] == exported[
        "raw_public_pair"
    ]["sha256"]
    exported_text = output_path.read_text()
    for private_value in (
        "/home/unit/private/model",
        str(RUNTIME_WRAPPER_PID),
        str(RUNTIME_WRAPPER_START_TICKS),
        RUNTIME_CONTAINER_ID,
        RUNTIME_LAUNCH_TOKEN_SHA256,
        PUBLIC_WORKLOAD_NONCE,
        "public-baseline",
    ):
        assert private_value not in exported_text
    assert set(exported["checks"]["attestation"]) == (
        MODULE.PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS
    )
    assert exported["tier_qualification"]["public"]["measurement_window_sec"] == 1800
    assert exported["tail_anti_gaming"] == recomputed_tail
    assert exported["benchmark"]["profiles"]["hidden-pressure-192"]["legs"][1][
        "p99_step_latency_sec"
    ] == 110.0
    assert exported["tier_qualification"]["hidden"]["candidate_leg_ordinal"] == 2

with tempfile.TemporaryDirectory(prefix="reference-tree-digest-") as temporary:
    tree = Path(temporary) / "reference_gateway"
    tree.mkdir()
    authored = {
        "gateway.py": b"gateway-v1\n",
        "scheduler.py": b"scheduler-v1\n",
        "launch.sh": b"#!/bin/sh\n",
        "THIRD_PARTY_LICENSE.md": b"MIT\n",
    }
    for name, payload in authored.items():
        (tree / name).write_bytes(payload)
    initial = MODULE.reference_gateway_tree_sha256(tree)
    assert initial == ABBA_MODULE.reference_gateway_tree_sha256(tree)
    assert initial == FREEZE_MODULE.reference_gateway_tree_sha256(tree)

    solve_sh = Path(temporary) / "solve.sh"
    solve_sh.write_bytes(MODULE.REFERENCE_SOLVE_SH_BYTES)
    reference_submission = MODULE.reference_submission_sha256(tree, solve_sh)
    assert reference_submission == FREEZE_MODULE.reference_submission_sha256(
        tree, solve_sh
    )
    installed = Path(temporary) / "installed-submission"
    installed.mkdir(mode=0o755)
    for name, mode in MODULE.REFERENCE_SUBMISSION_FILES.items():
        (installed / name).write_bytes(authored[name])
        (installed / name).chmod(mode)
    assert MODULE.frozen_submission_sha256(installed) == reference_submission

    (installed / "gateway.py").write_bytes(b"payload drift\n")
    assert MODULE.frozen_submission_sha256(installed) != reference_submission
    (installed / "gateway.py").write_bytes(authored["gateway.py"])
    (installed / "gateway.py").chmod(0o755)
    assert MODULE.frozen_submission_sha256(installed) != reference_submission
    (installed / "gateway.py").chmod(0o644)
    assert MODULE.frozen_submission_sha256(installed) == reference_submission

    wrong_mode_solve = Path(temporary) / "wrong-mode-solve.sh"
    wrong_mode_solve.write_bytes(
        MODULE.REFERENCE_SOLVE_SH_BYTES.replace(b"install -m 0755", b"install -m 0644")
    )
    rejects_oserror(
        lambda: MODULE.reference_submission_sha256(tree, wrong_mode_solve),
        "solve.sh mode drift",
    )

    cache = tree / "__pycache__"
    cache.mkdir()
    (cache / "scheduler.cpython-test.pyc").write_bytes(b"runtime-only")
    assert MODULE.reference_gateway_tree_sha256(tree) == initial

    for name, payload in authored.items():
        path = tree / name
        path.write_bytes(payload + b"changed")
        assert MODULE.reference_gateway_tree_sha256(tree) != initial, name
        path.write_bytes(payload)

    (tree / "scheduler.py").rename(tree / "scheduler-renamed.py")
    assert MODULE.reference_gateway_tree_sha256(tree) != initial
    (tree / "scheduler-renamed.py").rename(tree / "scheduler.py")
    (tree / "outside").symlink_to(Path(temporary) / "external")
    rejects_oserror(
        lambda: MODULE.reference_gateway_tree_sha256(tree),
        "symlink in Oracle tree",
    )

abba_wrong_tree_argv = [
    str(ABBA_SCRIPT),
    "--input",
    "/does/not/need/to/exist.json",
    "--output",
    "/does/not/need/to/be/written.json",
    "--gateway-tree-sha256",
    "0" * 64,
    "--controller-image-id",
    CONTROLLER_IMAGE_ID,
    "--release-id",
    RELEASE_ID,
    "--model-profile-sha256",
    PROFILE_SHA,
]
with mock.patch.object(sys, "argv", abba_wrong_tree_argv):
    rejects(ABBA_MODULE.main, "ABBA Oracle tree digest not bound to local reference")

with tempfile.TemporaryDirectory(prefix="old-abba-stamp-") as temporary:
    old_abba = Path(temporary) / "old-abba.json"
    old_abba.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "profile": "hidden-pressure-72",
                "all_audits_passed": True,
                "minimum_request_success_rate": 1.0,
                "legs": [],
            }
        )
        + "\n"
    )
    rejects(
        lambda: ABBA_MODULE.sanitized(
            old_abba,
            expected_release_id=RELEASE_ID,
            expected_profile_sha256=PROFILE_SHA,
        ),
        "old ABBA report",
    )

print("release exporter current-schema provenance unit: passed")
