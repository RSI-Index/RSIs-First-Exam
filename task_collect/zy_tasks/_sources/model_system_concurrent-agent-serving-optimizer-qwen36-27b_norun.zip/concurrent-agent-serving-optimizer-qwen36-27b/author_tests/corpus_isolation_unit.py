#!/usr/bin/env python3
"""CPU-only checks for pinned SWE-bench manifests and clean workspace reuse."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.corpus import (  # noqa: E402
    EXPECTED_DATASET,
    EXPECTED_DATASET_REVISION,
    make_swebench_specs,
)
from runner import sandbox as sandbox_module  # noqa: E402


def make_repo(path: Path) -> None:
    path.mkdir(parents=True)
    (path / "module.py").write_text("VALUE = 1\n")
    (path / "test_module.py").write_text(
        "import unittest\nfrom module import VALUE\n"
        "class T(unittest.TestCase):\n    def test_value(self): self.assertEqual(VALUE, 2)\n"
    )
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=path, check=True)
    subprocess.run(["git", "add", "--all"], cwd=path, check=True)
    subprocess.run(
        [
            "git",
            "-c",
            "user.name=KVBench",
            "-c",
            "user.email=kvbench@invalid",
            "commit",
            "-q",
            "-m",
            "baseline",
        ],
        cwd=path,
        check=True,
    )


def main() -> int:
    cases: list[dict] = []
    bounded, elided = sandbox_module.truncate_agent_output("a" * 6000 + "z" * 6000)
    cases.append(
        {
            "name": "large_tool_output_keeps_bounded_head_and_tail",
            "passed": elided and len(bounded) < 10_100 and bounded.startswith("a" * 100) and bounded.endswith("z" * 100),
        }
    )
    with tempfile.TemporaryDirectory(prefix="kvbench-corpus-unit-") as raw:
        root = Path(raw) / "corpus"
        source = root / "workspaces" / "example"
        make_repo(source)
        digest = hashlib.sha256(b"pinned-example-workspace").hexdigest()
        manifest = {
            "schema_version": 1,
            "dataset": EXPECTED_DATASET,
            "dataset_revision": EXPECTED_DATASET_REVISION,
            "instances": [
                {
                    "instance_id": "example__project-1",
                    "repo": "example/project",
                    "partition": "public",
                    "problem_statement": "Change VALUE to 2.",
                    "workspace": "example",
                    "workspace_sha256": digest,
                    "test_command": "python3 -m unittest -q",
                }
            ],
        }
        (root / "manifest.json").write_text(json.dumps(manifest))

        specs = make_swebench_specs("public", 3, partition="public", seed=7, root=root)
        cases.append(
            {
                "name": "pinned_manifest_loads_and_rollouts_repeat_cleanly",
                "passed": len(specs) == 3
                and specs[0].workload_family == "swebench-lite"
                and specs[1].task_id.endswith("-r01")
                and Path(specs[0].workspace_template or "").resolve() == source.resolve(),
                "task_ids": [spec.task_id for spec in specs],
            }
        )

        sandbox_module.WORKSPACE_ROOT = Path(raw) / "runs"
        first = sandbox_module.TimedSandbox(
            specs[0],
            delay_seed=1,
            minimum_delay=0,
            maximum_delay=0,
            command_timeout_sec=5,
        )
        (first.workspace / "historical-queue.sqlite").write_text("dirty")
        (first.workspace / "module.py").write_text("VALUE = 2\n")
        first.cleanup()
        second = sandbox_module.TimedSandbox(
            specs[1],
            delay_seed=1,
            minimum_delay=0,
            maximum_delay=0,
            command_timeout_sec=5,
        )
        isolated = (
            not (second.workspace / "historical-queue.sqlite").exists()
            and (second.workspace / "module.py").read_text() == "VALUE = 1\n"
            and (source / "module.py").read_text() == "VALUE = 1\n"
        )
        second.cleanup()
        cases.append(
            {
                "name": "runtime_state_never_reenters_a_fresh_workflow",
                "passed": isolated and not any(sandbox_module.WORKSPACE_ROOT.iterdir()),
            }
        )

        image_entry = {
            "instance_id": "example__project-2",
            "repo": "example/project",
            "partition": "hidden",
            "problem_statement": "Fix the image-backed example.",
            "image_name": "docker.io/swebench/example:latest",
            "official_manifest_digest": "sha256:" + "0" * 64,
            "image_digest": "sha256:" + "1" * 64,
            "base_commit": "2" * 40,
            "runtime_head_commit": "3" * 40,
            "verification_command": "git diff --check",
        }
        manifest["instances"] = [image_entry]
        (root / "manifest.json").write_text(json.dumps(manifest))
        image_spec = make_swebench_specs("hidden", 1, partition="hidden", seed=9, root=root)[0]
        cases.append(
            {
                "name": "image_runtime_locks_dataset_base_and_runtime_head",
                "passed": (
                    image_spec.runtime_image == image_entry["image_name"]
                    and image_spec.runtime_manifest_digest == image_entry["official_manifest_digest"]
                    and image_spec.runtime_image_digest == image_entry["image_digest"]
                    and image_spec.runtime_base_commit == image_entry["base_commit"]
                    and image_spec.runtime_head_commit == image_entry["runtime_head_commit"]
                ),
            }
        )

        del image_entry["runtime_head_commit"]
        (root / "manifest.json").write_text(json.dumps(manifest))
        missing_head_rejected = False
        try:
            make_swebench_specs("hidden", 1, partition="hidden", seed=9, root=root)
        except RuntimeError:
            missing_head_rejected = True
        cases.append({"name": "missing_runtime_head_is_rejected", "passed": missing_head_rejected})

        manifest["dataset_revision"] = "unpinned"
        (root / "manifest.json").write_text(json.dumps(manifest))
        rejected = False
        try:
            make_swebench_specs("public", 1, partition="public", seed=7, root=root)
        except RuntimeError:
            rejected = True
        cases.append({"name": "unpinned_dataset_revision_is_rejected", "passed": rejected})

    report = {
        "schema_version": 1,
        "kind": "corpus-isolation-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
