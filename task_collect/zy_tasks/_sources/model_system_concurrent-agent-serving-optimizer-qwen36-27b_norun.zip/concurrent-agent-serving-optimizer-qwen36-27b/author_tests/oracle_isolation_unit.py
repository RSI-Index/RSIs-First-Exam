#!/usr/bin/env python3
"""CPU-only contracts for candidate/Oracle source isolation.

The repository contains an author reference implementation, but Harbor's normal
agent path builds only ``environment/`` and supplies ``instruction.md``.  The
Oracle agent is the separate path that uploads ``solution/`` at ``/solution``
and executes ``solve.sh``.  These checks fail closed if task-owned image or
Compose configuration starts exposing the reference implementation to the
candidate container.
"""

from __future__ import annotations

import json
import re
import shlex
import tomllib
from pathlib import Path, PurePosixPath
from typing import Any

import yaml


TASK_ROOT = Path(__file__).resolve().parents[1]
ENVIRONMENT_ROOT = TASK_ROOT / "environment"
TASK_CONFIG_PATH = TASK_ROOT / "task.toml"
INSTRUCTION_PATH = TASK_ROOT / "instruction.md"
BASE_COMPOSE_PATH = ENVIRONMENT_ROOT / "docker-compose.yaml"
AUTHOR_COMPOSE_PATH = TASK_ROOT / "scripts" / "compose-calibration.yaml"
CALIBRATION_STACK_PATH = TASK_ROOT / "scripts" / "calibration-stack.sh"
SOLVE_PATH = TASK_ROOT / "solution" / "solve.sh"
REFERENCE_ROOT = TASK_ROOT / "solution" / "reference_gateway"

ORACLE_NEEDLES = (
    "/solution",
    "solution/reference_gateway",
    "reference_gateway",
    "reference-gateway",
)


def load_yaml(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text())
    if not isinstance(value, dict):
        raise TypeError(f"expected mapping in {path}")
    return value


def flattened_strings(value: Any) -> list[str]:
    if isinstance(value, dict):
        return [
            item
            for key, child in value.items()
            for item in (str(key), *flattened_strings(child))
        ]
    if isinstance(value, list):
        return [item for child in value for item in flattened_strings(child)]
    if isinstance(value, str):
        return [value]
    return []


def has_oracle_reference(value: Any) -> bool:
    return any(
        needle in text.lower()
        for text in flattened_strings(value)
        for needle in ORACLE_NEEDLES
    )


def volume_target(volume: Any) -> str:
    if isinstance(volume, dict):
        return str(volume.get("target", ""))
    if not isinstance(volume, str):
        return ""
    # Named-volume and bind short syntax both put the container target second.
    pieces = volume.split(":")
    return pieces[1] if len(pieces) >= 2 else pieces[0]


def dockerfile_copy_sources(path: Path) -> list[str]:
    sources: list[str] = []
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        match = re.match(r"^(?:COPY|ADD)\s+(.+)$", line, re.IGNORECASE)
        if match is None:
            continue
        payload = match.group(1).strip()
        if payload.startswith("["):
            values = json.loads(payload)
            if not isinstance(values, list) or len(values) < 2:
                raise ValueError(f"invalid JSON COPY/ADD in {path}: {line}")
            sources.extend(str(value) for value in values[:-1])
            continue
        tokens = shlex.split(payload)
        tokens = [token for token in tokens if not token.startswith("--")]
        if len(tokens) < 2:
            raise ValueError(f"invalid COPY/ADD in {path}: {line}")
        sources.extend(tokens[:-1])
    return sources


def source_stays_in_build_context(source: str) -> bool:
    # Docker itself rejects escaping COPY sources.  Keep that boundary explicit
    # here so a future build-context or Dockerfile rewrite cannot silently turn
    # the sibling author solution into image content.
    if source.startswith(("/", "~")):
        return False
    parts = PurePosixPath(source).parts
    return ".." not in parts and not any(
        needle in source.lower() for needle in ORACLE_NEEDLES
    )


def main() -> int:
    task_config = tomllib.loads(TASK_CONFIG_PATH.read_text())
    base_compose = load_yaml(BASE_COMPOSE_PATH)
    author_compose = load_yaml(AUTHOR_COMPOSE_PATH)
    instruction = INSTRUCTION_PATH.read_text()
    solve = SOLVE_PATH.read_text()
    calibration_stack = CALIBRATION_STACK_PATH.read_text()

    services = base_compose.get("services", {})
    if not isinstance(services, dict):
        raise TypeError("base Compose services must be a mapping")
    main_service = services.get("main", {})
    if not isinstance(main_service, dict):
        raise TypeError("base Compose main service must be a mapping")
    main_volumes = main_service.get("volumes", [])
    if not isinstance(main_volumes, list):
        raise TypeError("base Compose main volumes must be a list")

    dockerfiles = sorted(ENVIRONMENT_ROOT.glob("**/Dockerfile"))
    copy_sources = {
        str(path.relative_to(TASK_ROOT)): dockerfile_copy_sources(path)
        for path in dockerfiles
    }

    artifacts = task_config.get("artifacts", [])
    environment_config = task_config.get("environment", {})
    agent_config = task_config.get("agent", {})
    author_main = author_compose.get("services", {}).get("main", {})
    author_volumes = author_main.get("volumes", [])
    author_reference_mounts = [
        volume
        for volume in author_volumes
        if isinstance(volume, dict)
        and "KV_AUTHOR_REFERENCE_GATEWAY_DIR" in str(volume.get("source", ""))
    ]

    checks = {
        # Normal Harbor image construction is rooted at environment/.  Every
        # COPY/ADD source stays inside that tree, whose sibling is solution/.
        "environment_build_context_excludes_solution_tree": (
            REFERENCE_ROOT.is_dir()
            and ENVIRONMENT_ROOT.is_dir()
            and REFERENCE_ROOT.parent.parent == TASK_ROOT
            and not REFERENCE_ROOT.is_relative_to(ENVIRONMENT_ROOT)
            and bool(dockerfiles)
            and all(
                source_stays_in_build_context(source)
                for sources in copy_sources.values()
                for source in sources
            )
            and all(
                not any(needle in path.read_text().lower() for needle in ORACLE_NEEDLES)
                for path in dockerfiles
            )
        ),
        "base_compose_never_mounts_or_names_oracle_source": (
            not has_oracle_reference(base_compose)
            and all(
                not any(needle in volume_target(volume).lower() for needle in ORACLE_NEEDLES)
                for service in services.values()
                if isinstance(service, dict)
                for volume in service.get("volumes", [])
            )
        ),
        "task_config_declares_no_solution_mount": (
            not has_oracle_reference(environment_config)
            and all(
                not any(
                    needle in str(artifact.get("source", "")).lower()
                    for needle in ORACLE_NEEDLES
                )
                for artifact in artifacts
                if isinstance(artifact, dict)
            )
        ),
        "candidate_contract_exposes_only_submission_path": (
            agent_config.get("user") == "candidate"
            and task_config.get("environment", {}).get("workdir") == "/app"
            and "/app/submission/launch.sh" in instruction
            and "/app/submission" in instruction
            and not any(needle in instruction.lower() for needle in ORACLE_NEEDLES)
        ),
        # Harbor's OracleAgent alone uploads the host solution directory to
        # /solution.  solve.sh is therefore a deployment recipe for that path,
        # not content in the normal candidate image.
        "solve_script_is_oracle_only_deployer": (
            solve.startswith("#!/usr/bin/env bash\n")
            and "set -euo pipefail" in solve
            and "rm -rf /app/submission" in solve
            and "install -d -m 0755 /app/submission" in solve
            and all(
                f"/solution/reference_gateway/{name}" in solve
                for name in (
                    "gateway.py",
                    "scheduler.py",
                    "THIRD_PARTY_LICENSE.md",
                    "launch.sh",
                )
            )
            and "/app/submission/launch.sh" in solve
            and "cp -a /solution/reference_gateway" not in solve
            and "__pycache__" not in solve
            and "/solution/reference_gateway" not in instruction
            and "/solution/reference_gateway" not in BASE_COMPOSE_PATH.read_text()
        ),
        # Local calibration intentionally bypasses Harbor's OracleAgent.  Keep
        # its author-only mount explicit, read-only, and outside task.toml/base
        # Compose so it cannot leak into a normal Codex trial.
        "author_calibration_overlay_is_explicit_and_read_only": (
            len(author_reference_mounts) == 1
            and author_reference_mounts[0].get("target") == "/opt/reference-gateway"
            and author_reference_mounts[0].get("read_only") is True
            and "/opt/reference-gateway/launch.sh" in flattened_strings(
                author_main.get("command", [])
            )
            and 'REFERENCE_GATEWAY_DIR="${KV_AUTHOR_REFERENCE_GATEWAY_DIR:-$TASK_DIR/solution/reference_gateway}"'
            in calibration_stack
            and 'export KV_AUTHOR_REFERENCE_GATEWAY_DIR="$REFERENCE_GATEWAY_DIR"'
            in calibration_stack
            and '"$TASK_DIR/scripts/compose-calibration.yaml"' in calibration_stack
            and "compose-calibration.yaml" not in TASK_CONFIG_PATH.read_text()
            and "compose-calibration.yaml" not in BASE_COMPOSE_PATH.read_text()
            and "compose-calibration.yaml" not in instruction
        ),
        "artifacts_export_candidate_output_not_oracle_input": (
            any(
                isinstance(artifact, dict)
                and artifact.get("source") == "/app/submission"
                and artifact.get("destination") == "submission"
                for artifact in artifacts
            )
            and all(
                isinstance(artifact, dict)
                and (
                    str(artifact.get("source", "")).startswith("/app/")
                    or (
                        artifact.get("source") == "/logs/agent/kvbench_training"
                        and artifact.get("destination") == "kvbench-training"
                    )
                )
                for artifact in artifacts
            )
        ),
    }

    report = {
        "schema_version": 1,
        "kind": "oracle-isolation-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "evidence": {
            "normal_build_context": "environment/",
            "candidate_visible_contract": "instruction.md + environment image",
            "oracle_upload_target": "/solution",
            "oracle_deployer": "solution/solve.sh",
            "author_calibration_overlay": "scripts/compose-calibration.yaml",
            "dockerfile_copy_sources": copy_sources,
            "base_main_volume_targets": [volume_target(volume) for volume in main_volumes],
        },
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
