#!/usr/bin/env python3
"""Author-only contracts for the candidate Direct/FIFO starter gateway."""

from __future__ import annotations

import argparse
import ast
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
STARTER_ROOT = TASK_ROOT / "environment" / "starter_submission"
GATEWAY = STARTER_ROOT / "gateway.py"
LAUNCH = STARTER_ROOT / "launch.sh"
DOCKERFILE = TASK_ROOT / "environment" / "Dockerfile"
COMPOSE = TASK_ROOT / "environment" / "docker-compose.yaml"
INSTRUCTION = TASK_ROOT / "instruction.md"

FORBIDDEN_ORACLE_MARKERS = (
    "thunderagent",
    "reference_gateway",
    "priority",
    "decay",
    "watermark",
    "kv_capacity",
    "attention_page",
    "mamba",
    "1887738",
    "1252",
    "1568",
)


def static_checks() -> dict[str, bool]:
    gateway = GATEWAY.read_text()
    launch = LAUNCH.read_text()
    dockerfile = DOCKERFILE.read_text()
    compose = COMPOSE.read_text()
    instruction = INSTRUCTION.read_text()
    normalized_instruction = " ".join(instruction.split())
    ast.parse(gateway, filename=str(GATEWAY))
    return {
        "starter_has_launch_and_gateway": LAUNCH.is_file() and GATEWAY.is_file(),
        "launch_is_foreground_and_parameterized": (
            launch.startswith("#!/usr/bin/env bash\n")
            and "exec python3" in launch
            and "BACKEND_URL" in launch
            and "PORT" in launch
            and "8100" not in launch
            and "8100" not in gateway
        ),
        "starter_has_no_oracle_policy_or_capacity_markers": not any(
            marker in gateway.lower() for marker in FORBIDDEN_ORACLE_MARKERS
        ),
        "starter_does_not_interpret_workflow_identity": "x-agent-run-id"
        not in gateway.lower(),
        "starter_has_no_admission_queue": all(
            marker not in gateway
            for marker in ("asyncio.Queue", "asyncio.Semaphore", "PriorityQueue")
        ),
        "starter_opens_unbounded_direct_client_connections": (
            "TCPConnector(limit=0)" in gateway
        ),
        "starter_declares_all_required_routes": all(
            route in gateway
            for route in (
                'add_get("/health"',
                'add_get("/v1/models"',
                'add_post("/v1/chat/completions"',
                'add_post("/programs/release"',
            )
        ),
        "dockerfile_installs_candidate_owned_editable_starter": (
            "COPY --chown=candidate:candidate starter_submission/ /app/submission/"
            in dockerfile
            and "/app/submission/launch.sh" in dockerfile
            and "/app/submission/gateway.py" in dockerfile
        ),
        "instruction_starts_from_direct_gateway": (
            "A working Direct/FIFO starter gateway is installed" in instruction
            and "protocol-correct no-scheduler starting point" in instruction
            and "Baseline leg calls the trusted backend directly" in instruction
        ),
        "instruction_makes_backend_url_authoritative": (
            "Always use the supplied `BACKEND_URL`" in instruction
            and "do not hard-code the normal backend" in instruction
            and "verifier-selected OpenAI-compatible /v1 endpoint" in instruction
        ),
        "instruction_frames_the_real_system_problem_without_benchmark_shape": (
            "many independent agents working on different tasks at the same time"
            in normalized_instruction
            and "finite model KV cache" in normalized_instruction
            and "valid executable agent steps per minute (`valid_steps_per_min`)"
            in normalized_instruction
            and "X-Agent-Run-ID" in instruction
            and not any(
                marker in instruction.lower()
                for marker in (
                    "mini-swe-agent",
                    "swe-bench",
                    "held-out",
                    "hidden",
                    "disjoint",
                    "final scoring",
                    "192",
                    "1800",
                    "at most 24",
                )
            )
        ),
        "instruction_exposes_generic_debug_and_pressure_test_interfaces": (
            '--profile "$KVBENCH_DEBUG_PROFILE"' in instruction
            and '--profile "$KVBENCH_PUBLIC_PROFILE"' in instruction
            and "Use the pressure profile before making performance conclusions"
            in instruction
            and "pressure-profile Candidate run snapshots" in instruction
            and "KVBENCH_DEBUG_PROFILE: public-12" in compose
            and "KVBENCH_PUBLIC_PROFILE: public-pressure-192" in compose
        ),
    }


def wait_for_health(process: subprocess.Popen[bytes]) -> None:
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        if process.poll() is not None:
            output = process.stdout.read().decode(errors="replace") if process.stdout else ""
            raise RuntimeError(
                f"starter exited during startup: {process.returncode}: {output}"
            )
        try:
            with urllib.request.urlopen("http://127.0.0.1:9000/health", timeout=1) as response:
                if response.status == 200:
                    return
        except OSError:
            pass
        time.sleep(0.05)
    raise RuntimeError("starter did not become healthy")


def integration_case() -> dict[str, Any]:
    sys.path.insert(0, str(TASK_ROOT / "tests"))
    from protocol_cases import run_protocol_cases

    environment = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": "/tmp",
        "PYTHONDONTWRITEBYTECODE": "1",
        "BACKEND_URL": "http://127.0.0.1:18080/v1",
        "PORT": "9000",
    }
    process = subprocess.Popen(
        [str(LAUNCH)],
        cwd=STARTER_ROOT,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        wait_for_health(process)
        report = run_protocol_cases(include_disconnect=True)
        required = {
            "models",
            "lifecycle_control_not_forwarded",
            "nonstream_unicode",
            "compressed_body_bytes",
            "compressed_request_bytes",
            "duplicate_and_dynamic_hop_headers",
            "sse_order_done_usage",
            "status_429_500",
            "malformed_body",
            "backend_delay_large_header",
            "large_unicode_body",
            "concurrent_32",
            "pre_header_disconnect",
            "active_disconnect",
            "one_to_one_and_opaque_headers",
        }
        report["all_required_checks_observed"] = required <= set(report["checks"])
        report["passed"] = bool(report["passed"] and report["all_required_checks_observed"])
        return report
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--integration",
        action="store_true",
        help="run the aiohttp starter against the full in-process protocol mock",
    )
    args = parser.parse_args()
    checks = static_checks()
    integration: dict[str, Any] | None = None
    if args.integration:
        integration = integration_case()
        checks["full_protocol_integration"] = bool(integration["passed"])

    report = {
        "schema_version": 1,
        "kind": "starter-gateway-unit",
        "passed": all(checks.values()),
        "checks": checks,
        "integration": integration,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
