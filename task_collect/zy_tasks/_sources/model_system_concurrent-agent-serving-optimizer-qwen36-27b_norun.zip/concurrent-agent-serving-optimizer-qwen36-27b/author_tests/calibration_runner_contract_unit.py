#!/usr/bin/env python3
"""Fail-closed checks for trusted calibration checkpoint completion."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = TASK_ROOT / "scripts" / "run-real-swe-calibration.py"
SPEC = importlib.util.spec_from_file_location("run_real_swe_calibration", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

PROFILE_NAME = "qwen36-pressure-192-deep24"
RELEASE_ID = "qwen36-test-release"
CONTROLLER_SHA = "1" * 64
PROFILE_CONFIG = MODULE.canonical_profile_config(
    PROFILE_NAME,
    {
        "enabled": True,
        "workflows": 192,
        "concurrency": 192,
        "max_steps": 24,
        "context_bytes": 0,
        "max_tokens": 2048,
        "workflow_timeout_sec": 3600,
        "request_timeout_sec": 2700,
        "tool_delay_min_sec": 0.0,
        "tool_delay_max_sec": 0.0,
        "seed": 436924,
        "warmup_requests": 4,
        "warmup_context_bytes": 0,
        "warmup_steps": 3,
        "workload_family": "swebench-lite",
        "corpus_partition": "public",
        "corpus_unique_instances_min": 6,
        "pressure_required": True,
        "pressure_kv_threshold": 0.8,
        "pressure_kv_p95_min": 0.9,
        "pressure_time_fraction_min": 0.25,
        "pressure_min_samples": 60,
        "backend_stall_timeout_sec": 180,
        "candidate_admission_stall_timeout_sec": 300,
    },
)
PROVENANCE = {
    "profile_id": "qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2",
    "profile_sha256": "3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46",
    "model_revision": "6a9e13bd6fc8f0983b9b99948120bc37f49c13e9",
    "runtime_image_id": "sha256:1d8369b9e3c91aa8cba5c7aeeef26e3c4afd455e5d2ce9aebe6f30f6dd9344bd",
    "tensor_parallel_size": 2,
    "kv_cache_dtype": "fp8",
}
MODEL_ADAPTER = {
    "mode": "qwen36-text-bash-v1",
    "instruction_role": "system",
    "instruction_sha256": "75434201e849f434256fd3ad6cc5c936b4ac41dec988c3546e8532fc6fa73098",
    "instance_template_sha256": "dbafa361c3aa0c54e7d476773a8ae97bf585b728f1cd591a5da97f65b390a778",
    "format_error_sha256": "3a4c765859508b9f499353bb713f6c37b3bee170102e0872e9f206b37e82c7ae",
    "prompt_contract": "thunderagent-a989f24-mini-swe-agent-swebench-yaml-v1",
    "task_input": "raw-problem-statement",
    "offline_constraint": "sandbox-enforced-not-prompt-modified",
    "temperature": 0.0,
    "top_p": 1.0,
    "max_tokens_policy": "profile_cap",
    "response_protocol": "single-bash-fence",
    "function_tools": False,
    "reasoning_override": "qwen-chat-template-thinking-disabled",
    "chat_template_kwargs": {"enable_thinking": False},
}
QUALITY_GATES = {
    "minimum_valid_step_ratio": 0.9,
    "minimum_workflow_progress": 1,
}


def result() -> dict:
    return {
        "profile": PROFILE_NAME,
        "mode": "baseline",
        "profile_config": PROFILE_CONFIG,
        "release_id": RELEASE_ID,
        "controller_config_sha256": CONTROLLER_SHA,
        "model_provenance": PROVENANCE,
        "model_adapter": {**MODEL_ADAPTER, "effective_max_tokens": 2048},
        "infrastructure_failure": None,
        "backend_audit": {"passed": True},
        "warmup_audit": {"passed": True},
        "pressure_validation": {
            "qualification_schema_version": 1,
            "required": True,
            "valid": True,
            "contention_evidence": {
                "required": True,
                "valid": True,
                "qualification_paths": ["audited_active_working_set"],
                "active_working_set": {"valid": True},
                "preemption": {"valid": False, "preemptions_delta": 0.0},
            },
            "reasons": [],
        },
        "request_success_rate": 1.0,
        "valid_step_ratio": 0.99,
        "jain_progress_fairness": 0.99,
        "minimum_workflow_progress": 10,
        "vllm_metrics": {"live_series": {"sampler_error_count": 0}},
    }


def failures(payload: dict) -> list[str]:
    return MODULE.calibration_result_failures(
        payload,
        profile_name=PROFILE_NAME,
        expected_profile_config=PROFILE_CONFIG,
        expected_release_id=RELEASE_ID,
        expected_controller_config_sha256=CONTROLLER_SHA,
        expected_provenance=PROVENANCE,
        expected_model_adapter=MODEL_ADAPTER,
        quality_gates=QUALITY_GATES,
    )


assert failures(result()) == []

# The eviction-safe path is accepted only with its auditable threshold and at
# least one validated corroboration path.  This guards the release checkpoint
# allowlist against a forged low-occupancy/low-hit aggregate.
oversubscribed_result = result()
oversubscribed_result["pressure_validation"]["contention_evidence"] = {
    "required": True,
    "valid": True,
    "qualification_paths": ["audited_oversubscribed_working_set"],
    "active_working_set": {"valid": False},
    "oversubscribed_working_set": {
        "valid": True,
        "occupancy_independent": True,
        "demand_ratio_threshold": 1.0,
        "corroboration_paths": ["synchronized_waiting"],
        "synchronized_waiting": {"valid": True},
        "leg_local_cache_churn": {"valid": False},
    },
    "preemption": {"valid": False, "preemptions_delta": 0.0},
}
assert failures(oversubscribed_result) == []

forged_oversubscribed = json.loads(json.dumps(oversubscribed_result))
forged_oversubscribed["pressure_validation"]["contention_evidence"][
    "oversubscribed_working_set"
]["synchronized_waiting"]["valid"] = False
assert "oversubscribed_synchronized_waiting_evidence_invalid" in failures(
    forged_oversubscribed
)

mutations = {
    "forged shape": lambda item: item["profile_config"].__setitem__("max_steps", 32),
    "no pressure": lambda item: item["pressure_validation"].__setitem__("valid", False),
    "legacy occupancy-only pressure": lambda item: item["pressure_validation"].pop(
        "contention_evidence"
    ),
    "waiting-only pressure": lambda item: item["pressure_validation"][
        "contention_evidence"
    ].__setitem__("qualification_paths", ["scheduler_waiting_at_high_kv"]),
    "backend audit": lambda item: item["backend_audit"].__setitem__("passed", False),
    "warmup audit": lambda item: item["warmup_audit"].__setitem__("passed", False),
    "wrong controller": lambda item: item.__setitem__("controller_config_sha256", "0" * 64),
    "wrong model": lambda item: item["model_provenance"].__setitem__("model_revision", "old"),
    "wrong adapter": lambda item: item["model_adapter"].__setitem__(
        "effective_max_tokens", 512
    ),
    "sampler error": lambda item: item["vllm_metrics"]["live_series"].__setitem__(
        "sampler_error_count", 1
    ),
}
for label, mutate in mutations.items():
    payload = json.loads(json.dumps(result()))
    mutate(payload)
    assert failures(payload), f"calibration runner accepted {label}"


SELECTION_PAYLOAD = {
    "release_qualification_profiles": [
        "qwen36-pressure-192-deep24",
        "qwen36-pressure-192-deep64",
    ],
    "profiles": {
        "qwen36-pressure-192-deep24": {"enabled": True},
        "qwen36-pressure-192-deep64": {"enabled": True},
        "diagnostic-disabled": {"enabled": False},
    },
}
selected, mode = MODULE.select_profiles(SELECTION_PAYLOAD, None, True)
assert selected == (
    "qwen36-pressure-192-deep24",
    "qwen36-pressure-192-deep64",
)
assert mode == "release_qualification_allowlist"
assert MODULE.select_profiles(SELECTION_PAYLOAD, None, False) == (
    MODULE.DEFAULT_PROFILES,
    "default_diagnostics",
)
assert MODULE.select_profiles(
    SELECTION_PAYLOAD, ["qwen36-pressure-192-deep24"], False
) == (("qwen36-pressure-192-deep24",), "explicit_diagnostics")

DEVELOPMENT_POLICY = {
    "release_id": "development-qwen36-27b-tp2-external-v2",
    "release_ready": False,
}
FINAL_POLICY = {
    "release_id": "qwen36-27b-release-policy-unit",
    "release_ready": True,
}
FINAL_CONTROLLER_READINESS = {
    "phase": 1,
    "release_id": FINAL_POLICY["release_id"],
    "model_api": True,
    "infrastructure_attested": True,
    "public_profiles": True,
    "real_swebench_workload": True,
    "hidden_profiles": True,
    "oracle_calibrated": True,
    "real_agent_test_allowed": True,
}

# Development runs are deliberately unambiguous: only an explicit --profile
# selection is permitted.  The frozen allowlist becomes runnable only after
# the one-way final-ready transition to a non-development release ID.
MODULE.validate_selection_policy(DEVELOPMENT_POLICY, "explicit_diagnostics")
MODULE.validate_selection_policy(
    FINAL_POLICY, "release_qualification_allowlist"
)
MODULE.validate_final_controller_readiness(
    FINAL_POLICY,
    FINAL_CONTROLLER_READINESS,
    "release_qualification_allowlist",
)


def policy_phase_rejects(policy: dict, mode: str, label: str) -> None:
    try:
        MODULE.validate_selection_policy(policy, mode)
    except ValueError:
        return
    raise AssertionError(f"calibration runner accepted invalid selection phase: {label}")


policy_phase_rejects(
    DEVELOPMENT_POLICY,
    "default_diagnostics",
    "implicit development sweep",
)
policy_phase_rejects(
    DEVELOPMENT_POLICY,
    "release_qualification_allowlist",
    "development release qualification",
)
policy_phase_rejects(
    {"release_id": "development-final-looking", "release_ready": True},
    "release_qualification_allowlist",
    "development release ID after readiness flip",
)
policy_phase_rejects(
    {"release_id": "", "release_ready": True},
    "release_qualification_allowlist",
    "empty release ID",
)
policy_phase_rejects(
    FINAL_POLICY,
    "unknown_mode",
    "unknown profile-selection mode",
)


def final_readiness_rejects(readiness: dict, label: str) -> None:
    try:
        MODULE.validate_final_controller_readiness(
            FINAL_POLICY,
            readiness,
            "release_qualification_allowlist",
        )
    except RuntimeError:
        return
    raise AssertionError(
        f"calibration runner accepted non-final controller readiness: {label}"
    )


for key in (
    "model_api",
    "infrastructure_attested",
    "public_profiles",
    "real_swebench_workload",
    "hidden_profiles",
    "oracle_calibrated",
    "real_agent_test_allowed",
):
    broken = dict(FINAL_CONTROLLER_READINESS)
    broken[key] = False
    final_readiness_rejects(broken, f"{key}=false")

wrong_phase = dict(FINAL_CONTROLLER_READINESS)
wrong_phase["phase"] = 0
final_readiness_rejects(wrong_phase, "non-final phase")
wrong_release = dict(FINAL_CONTROLLER_READINESS)
wrong_release["release_id"] = "qwen36-other-release"
final_readiness_rejects(wrong_release, "controller release ID drift")

# Diagnostic runs do not claim final-release provenance and therefore do not
# depend on the final-only readiness fields.
MODULE.validate_final_controller_readiness(
    DEVELOPMENT_POLICY,
    {},
    "explicit_diagnostics",
)

# Diagnostic names are intentionally resolved from the selected profile file,
# not frozen in argparse.  This lets paired public/hidden pressure probes be
# added without creating a second, drifting name allowlist in the runner.
DYNAMIC_SELECTION_PAYLOAD = {
    "release_qualification_profiles": [],
    "profiles": {
        "public-pressure-probe": {"enabled": True},
        "hidden-pressure-probe": {"enabled": True},
        "disabled-pressure-probe": {"enabled": False},
    },
}
assert MODULE.select_profiles(
    DYNAMIC_SELECTION_PAYLOAD,
    ["public-pressure-probe", "hidden-pressure-probe"],
    False,
) == (
    ("public-pressure-probe", "hidden-pressure-probe"),
    "explicit_diagnostics",
)
assert MODULE.validate_selected_profiles(
    DYNAMIC_SELECTION_PAYLOAD,
    ("public-pressure-probe", "hidden-pressure-probe"),
) == DYNAMIC_SELECTION_PAYLOAD["profiles"]
for selected, label in (
    (("missing-pressure-probe",), "missing dynamic profile"),
    (("disabled-pressure-probe",), "disabled dynamic profile"),
):
    try:
        MODULE.validate_selected_profiles(DYNAMIC_SELECTION_PAYLOAD, selected)
    except ValueError:
        pass
    else:
        raise AssertionError(f"dynamic profile validation accepted {label}")


def selection_rejects(payload: dict, label: str) -> None:
    try:
        MODULE.select_profiles(payload, None, True)
    except ValueError:
        return
    raise AssertionError(f"release qualification selection accepted {label}")


invalid_selections = {
    "missing list": {"profiles": SELECTION_PAYLOAD["profiles"]},
    "empty list": {
        **SELECTION_PAYLOAD,
        "release_qualification_profiles": [],
    },
    "non-list": {
        **SELECTION_PAYLOAD,
        "release_qualification_profiles": "qwen36-pressure-192-deep24",
    },
    "duplicate": {
        **SELECTION_PAYLOAD,
        "release_qualification_profiles": [
            "qwen36-pressure-192-deep24",
            "qwen36-pressure-192-deep24",
        ],
    },
    "unknown": {
        **SELECTION_PAYLOAD,
        "release_qualification_profiles": ["missing"],
    },
    "disabled": {
        **SELECTION_PAYLOAD,
        "release_qualification_profiles": ["diagnostic-disabled"],
    },
    "non-string": {
        **SELECTION_PAYLOAD,
        "release_qualification_profiles": [True],
    },
}
for label, payload in invalid_selections.items():
    selection_rejects(payload, label)

try:
    MODULE.select_profiles(
        SELECTION_PAYLOAD, ["qwen36-pressure-192-deep24"], True
    )
except ValueError:
    pass
else:
    raise AssertionError("combined explicit/release selection did not fail closed")

print("calibration runner contract unit: passed")
