#!/usr/bin/env python3
"""Focused private health-observation checks for formal Oracle qualification."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from unittest import mock


TASK_ROOT = Path(__file__).resolve().parents[1]
TEST_ROOT = TASK_ROOT / "tests"
sys.path.insert(0, str(TEST_ROOT))
SPEC = importlib.util.spec_from_file_location("formal_tier_verify", TEST_ROOT / "verify.py")
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


health = {
    "status": "ok",
    "oracle": "thunderagent-extracted",
    "thunderagent_source_commit": "7" * 40,
    "reference_gateway_tree_sha256_at_start": "8" * 64,
    "candidate_private_programs": ["must-not-persist"],
    "scheduler": {
        "algorithm": "thunderagent-program-aware-single-backend",
        "scheduler_policy_schema_version": 4,
        "queue_policy": "v5",
        "fair_service_until_step": 12,
        "deep_request_first_step": 13,
        "protected_request_policy": "protected",
        "deep_request_policy": "deep",
        "normal_restore_order": "normal",
        "deep_restore_order": "deep-order",
        "deep_reentry_bypasses_service_lag": True,
        "programs": {"hidden-workflow": "must-not-persist"},
        "deep_pending_request_waiters_peak": 9,
        "deep_pause_wait_count": 8,
        "counters": {
            "deep_request_offers": 7,
            "deep_service_lag_bypass_decisions": 6,
            "resume_deep_request": 5,
            "deep_sjf_priority_ticks": 4,
            "mixed_request_tier_ticks": 3,
            "unselected_counter": 999,
        },
    },
}
selected = MODULE.sanitize_candidate_health(health)
assert "candidate_private_programs" not in selected
assert "programs" not in selected["scheduler"]
assert "unselected_counter" not in selected["scheduler"]["counters"]
assert selected["scheduler"]["deep_request_first_step"] == 13

# An ordinary candidate is allowed to expose no Oracle scheduler fields.
assert MODULE.sanitize_candidate_health({"status": "ok", "implementation": "plain"}) == {
    "status": "ok"
}


class Response:
    def __init__(self, raw: bytes, *, declared: str | None = None) -> None:
        self.status = 200
        self.headers = {} if declared is None else {"Content-Length": declared}
        self.raw = raw
        self.read_called = False

    def __enter__(self) -> "Response":
        return self

    def __exit__(self, *_: object) -> None:
        return None

    def read(self, limit: int) -> bytes:
        self.read_called = True
        assert limit == MODULE.MAX_CANDIDATE_HEALTH_RESPONSE_BYTES + 1
        return self.raw[:limit]


raw = json.dumps(health, separators=(",", ":")).encode()
response = Response(raw)
with mock.patch.object(MODULE.urllib.request, "urlopen", return_value=response):
    # B/A is valid, so the sole candidate observation may be ordinal 1.
    observation = MODULE.observe_candidate_post_leg_health(1)
assert observation["capture_status"] == "ok"
assert observation["leg_ordinal"] == 1
assert observation["response_bytes"] == len(raw)
assert observation["selected"] == selected

oversize = Response(b"", declared=str(MODULE.MAX_CANDIDATE_HEALTH_RESPONSE_BYTES + 1))
with mock.patch.object(MODULE.urllib.request, "urlopen", return_value=oversize):
    # A/B is also valid, so ordinal 2 must remain accepted.
    observation = MODULE.observe_candidate_post_leg_health(2)
assert observation["capture_status"] == "response_too_large"
assert observation["leg_ordinal"] == 2
assert oversize.read_called is False
assert observation["selected"] == {}

print("formal tier private health observation unit: passed")
