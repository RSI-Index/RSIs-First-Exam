#!/usr/bin/env python3
"""Pure-Python security contract checks for data-plane credentials."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import sys
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.model import (  # noqa: E402
    TRANSPORT_AUTH_CONTEXT,
    TRANSPORT_AUTH_HEADER,
    derive_transport_credential,
    transport_headers_for_endpoint,
)


def main() -> int:
    token = "security-unit-admin-token"
    expected = hmac.new(
        token.encode(),
        b"kvbench-model-api-transport-v1",
        hashlib.sha256,
    ).hexdigest()
    previous = os.environ.get("TRUSTED_MODEL_API_DATA_URL")
    os.environ["TRUSTED_MODEL_API_DATA_URL"] = "http://model-api:8100/v1"
    try:
        direct = transport_headers_for_endpoint("http://model-api:8100/v1", token)
        direct_slash = transport_headers_for_endpoint("http://model-api:8100/v1/", token)
        candidate = transport_headers_for_endpoint("http://main:9000/v1", token)
        lookalike_host = transport_headers_for_endpoint(
            "http://model-api.attacker:8100/v1",
            token,
        )
        lookalike_path = transport_headers_for_endpoint(
            "http://model-api:8100/v1/chat/completions",
            token,
        )
    finally:
        if previous is None:
            os.environ.pop("TRUSTED_MODEL_API_DATA_URL", None)
        else:
            os.environ["TRUSTED_MODEL_API_DATA_URL"] = previous

    model_api_source = (TASK_ROOT / "environment" / "model-api" / "server.py").read_text()
    bridge_source = (TASK_ROOT / "environment" / "loopback_bridge.py").read_text()
    entrypoint_source = (TASK_ROOT / "environment" / "container-entrypoint.sh").read_text()
    checks = {
        "derivation_is_domain_separated_hmac_sha256": (
            TRANSPORT_AUTH_CONTEXT == b"kvbench-model-api-transport-v1"
            and derive_transport_credential(token) == expected
        ),
        "exact_direct_url_receives_credential": direct == {
            TRANSPORT_AUTH_HEADER: expected
        } and direct_slash == direct,
        "candidate_and_lookalikes_receive_nothing": (
            candidate == {} and lookalike_host == {} and lookalike_path == {}
        ),
        "all_three_components_share_header_and_context": (
            'TRANSPORT_AUTH_HEADER = "X-KVBench-Transport-Auth"' in model_api_source
            and 'TRANSPORT_AUTH_HEADER = "X-KVBench-Transport-Auth"' in bridge_source
            and 'TRANSPORT_AUTH_CONTEXT = b"kvbench-model-api-transport-v1"'
            in model_api_source
            and 'TRANSPORT_AUTH_CONTEXT = b"kvbench-model-api-transport-v1"'
            in bridge_source
        ),
        "rejection_precedes_handler_and_audit": (
            model_api_source.index("middlewares=[require_data_plane_transport]")
            < model_api_source.index('app.router.add_get("/v1/models"')
            and model_api_source.index("if not transport_allowed(request):")
            < model_api_source.index("async def proxy_get")
        ),
        "transport_auth_does_not_authorize_unsigned_cache_probes": (
            'claimed_body_digest = request.headers.get("X-KVBench-Body-SHA256", "")'
            in model_api_source
            and 'request.headers.get("X-KVBench-Audit-Epoch", "")'
            in model_api_source
            and 'request.headers.get("X-KVBench-Auth")' in model_api_source
            and 'request_id not in request.app["seen_request_ids"]'
            in model_api_source
            and "if not valid:" in model_api_source
            and 'actual_body_digest = hashlib.sha256(await request.read()).hexdigest()'
            in model_api_source
            and model_api_source.index("if not valid:")
            < model_api_source.index(
                'actual_body_digest = hashlib.sha256(await request.read()).hexdigest()'
            )
            < model_api_source.index("async def proxy_get")
        ),
        "candidate_value_is_removed_before_bridge_injection": (
            'lowered == TRANSPORT_AUTH_HEADER.lower()' in bridge_source
            and bridge_source.index('headers = filtered_headers(request.headers, request_headers=True)')
            < bridge_source.index('headers[TRANSPORT_AUTH_HEADER] = app["transport_credential"]')
        ),
        "credential_is_not_in_process_arguments_or_environment": (
            '--credential-file "$BRIDGE_CREDENTIAL_FILE"' in entrypoint_source
            and "--transport-credential" not in entrypoint_source
            and "TRANSPORT_AUTH_HEADER" not in entrypoint_source
        ),
    }
    report = {
        "schema_version": 1,
        "kind": "transport-credential-security-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
