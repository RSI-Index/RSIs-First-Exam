#!/usr/bin/env python3
"""CPU-only guard for candidate-visible final-verifier artifacts."""

from __future__ import annotations

import ast
import json
import math
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
VERIFIER_PATH = TASK_ROOT / "tests" / "verify.py"
TEST_SH_PATH = TASK_ROOT / "tests" / "test.sh"
LOCAL_OVERLAY_PATH = TASK_ROOT / "scripts" / "compose-local-verifier.yaml"
BASE_COMPOSE_PATH = TASK_ROOT / "environment" / "docker-compose.yaml"
TASK_CONFIG_PATH = TASK_ROOT / "task.toml"
STACK_PATH = TASK_ROOT / "scripts" / "calibration-stack.sh"
ENTRYPOINT_PATH = TASK_ROOT / "environment" / "container-entrypoint.sh"


def load_public_artifact_functions() -> dict[str, Any]:
    parsed = ast.parse(VERIFIER_PATH.read_text(), filename=str(VERIFIER_PATH))
    wanted = {
        "compact_verifier_report",
        "public_benchmark_result",
        "public_verifier_report",
        "public_reward",
    }
    selected = [
        node
        for node in parsed.body
        if isinstance(node, ast.FunctionDef) and node.name in wanted
    ]
    if {node.name for node in selected} != wanted:
        raise RuntimeError("public verifier artifact functions are incomplete")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {"Any": Any, "math": math}
    exec(compile(module, str(VERIFIER_PATH), "exec"), namespace)  # noqa: S102
    return namespace


def main() -> int:
    namespace = load_public_artifact_functions()
    secret_profile = "hidden-secret-profile-730073"
    secret_task = "secret__heldout-task-r31"
    secret_detail = f"{secret_profile}:{secret_task}:raw-workflow-detail"
    secret_tier_counter = 730074
    secret_host_path = "/home/private/.cache/huggingface/hidden-model"
    secret_uds_path = "/tmp/private-runtime/vllm.sock"
    secret_container_id = "c" * 64
    secret_controller_image_id = "sha256:" + "d" * 64
    secret_gpu_uuid = "GPU-private-hidden-uuid"
    secret_request_id = "private-protocol-request-id"
    secret_cache_namespace = "private-cache-namespace"
    secret_pid = 424242
    report = {
        "schema_version": 1,
        "phase": "final",
        "checks": {
            "isolation": {
                "forbidden_paths_present": [],
                "gpu_devices": [],
                "candidate_can_read_admin_token": False,
                "candidate_capabilities": {
                    "permitted": "0000000000000000",
                    "effective": "0000000000000000",
                    "no_new_privs": "1",
                },
                "future_private_field": secret_host_path,
            },
            "attestation": {
                "schema_version": 1,
                "state": "ready",
                "preflight_status": "ok",
                "model_mount_read_only": True,
                "model": {"model_path": secret_host_path},
                "transport": {"socket_path": secret_uds_path},
                "process": {"wrapper_pid": secret_pid},
                "container": {"id": secret_container_id},
                "gpus": [{"uuid": secret_gpu_uuid}],
                "vllm_command": ["vllm", "serve", secret_host_path],
                "runtime": {"kv_cache_memory_bytes": 32212254720},
            },
            "initial_candidate_reset": {
                "terminated_candidate_pids": [secret_pid],
                "prelaunch_candidate_pids": [],
                "port_closed_before_launch": True,
                "runtime_state_scrubbed": True,
                "candidate_owned_runtime_entries": [],
                "candidate_owned_ipc_objects": [],
                "future_private_field": secret_uds_path,
            },
            "candidate_shared_output_roots": {
                "candidate_shared_output_roots_sealed": True,
                "candidate_shared_output_roots_candidate_accessible": [],
                "future_private_field": secret_host_path,
            },
            "protocol": {
                "passed": True,
                "checks": [secret_request_id],
                "expected_backend_requests": 39,
                "observed_backend_requests": 39,
                "cancelled_backend_request_observed": True,
                "future_private_field": secret_cache_namespace,
            },
            "real_protocol_audit": {
                "passed": True,
                "requests": [
                    {
                        "request_id": secret_request_id,
                        "cache_namespace": secret_cache_namespace,
                        "profile": secret_profile,
                        "response_digest": secret_container_id,
                    }
                ],
                "future_private_field": secret_uds_path,
            },
            "candidate_post_leg_health": {
                "schema_version": 1,
                "observations": {
                    # In a B/A formal pair, the one private candidate health
                    # observation is attached to ordinal 1.
                    "1": {
                        "selected": {
                            "scheduler": {
                                "counters": {
                                    "deep_request_offers": secret_tier_counter
                                }
                            }
                        }
                    }
                },
            },
            "future_private_check": {"raw": secret_detail},
        },
        "reward": 0.75,
        "correctness": 1.0,
        "backend_audit": 1.0,
        "infra_valid": 1.0,
        "classification_status": "ok",
        "artifacts": {
            "bench_controller_image_id": secret_controller_image_id,
        },
        "future_private_top_level": secret_host_path,
        "error": f"VerificationError: {secret_detail}",
        "benchmark": {
            "schema_version": 2,
            "release_id": "unit-release",
            "status": "ok",
            "hard_gates_passed": True,
            "reward": 0.75,
            "performance_score": 0.88,
            "tail_score": 0.99,
            "infra_failures": [],
            "candidate_failures": [],
            "candidate_lifecycle": {
                "network_egress_seal": {
                    "schema_version": 2,
                    "protocol": "same-compose-main-egress-hmac-v2",
                    "sealed": True,
                    "controller_image_id": secret_controller_image_id,
                }
            },
            "failure_attribution": {
                "authority": "trusted-bench-controller",
                "classification": "candidate_failed",
                "type": "candidate_gateway_exited",
                "detail": secret_detail,
                "profile": secret_profile,
            },
            "profiles": {
                secret_profile: {
                    "weight": 1.0,
                    "baseline_geomean": 80.919,
                    "candidate_geomean": 80.622,
                    "speedup": 1.234,
                    "reference_speedup": 1.2,
                    "legs": [
                        {
                            "profile_config": {
                                "seed": 730073,
                                "workflows": 192,
                            },
                            "workflows": [{"task_id": secret_task}],
                            "vllm_metrics": {"live_samples": [secret_detail]},
                        }
                    ],
                }
            },
        },
    }
    public_reward = namespace["public_reward"](report)
    compact_report = namespace["compact_verifier_report"](report)
    rendered = json.dumps(
        {"report": compact_report, "reward": public_reward}, sort_keys=True
    )
    compact_profile = compact_report["benchmark"]["profiles"][secret_profile]
    compact_leg = compact_profile["legs"][0]

    verifier_source = VERIFIER_PATH.read_text()
    test_source = TEST_SH_PATH.read_text()
    overlay_source = LOCAL_OVERLAY_PATH.read_text()
    base_sources = TASK_CONFIG_PATH.read_text() + BASE_COMPOSE_PATH.read_text()
    stack_source = STACK_PATH.read_text()
    entrypoint_source = ENTRYPOINT_PATH.read_text()
    status_block = stack_source.partition("  verify-local-status)")[2].partition(
        "    ;;"
    )[0]
    checks = {
        "canonical_report_preserves_hidden_aggregate_benchmark": all(
            marker in rendered
            for marker in (
                secret_profile,
                secret_detail,
                "730073",
                str(secret_tier_counter),
                "candidate_post_leg_health",
                "deep_request_offers",
                "profile_config",
                "reference_speedup",
                "performance_score",
                "tail_score",
                secret_host_path,
                secret_uds_path,
                secret_controller_image_id,
                secret_gpu_uuid,
                secret_request_id,
                secret_cache_namespace,
            )
        )
        and compact_profile["baseline_geomean"] == 80.919
        and compact_profile["candidate_geomean"] == 80.622
        and compact_profile["speedup"] == 1.234
        and compact_profile["reference_speedup"] == 1.2,
        "canonical_report_omits_only_bulky_leg_series": (
            "workflows" not in compact_leg
            and compact_leg["omitted_detail_counts"]["workflows"] == 1
            and "live_samples" not in compact_leg["vllm_metrics"]
            and compact_leg["vllm_metrics"]["omitted_detail_counts"][
                "live_samples"
            ]
            == 1
            and compact_report["report_detail_policy"]
            == "aggregate-no-raw-workflow-series-v1"
        ),
        "reward_file_keeps_scalar_dimensions_and_gate": (
            public_reward
            == {
                "reward": 0.75,
                "correctness": 1.0,
                "backend_audit": 1.0,
                "infra_valid": 1.0,
                "hard_gates_passed": True,
                "baseline_valid_steps_per_min": 80.919,
                "candidate_valid_steps_per_min": 80.622,
                "speedup": 1.234,
                "reference_speedup": 1.2,
            }
        ),
        "canonical_report_writes_compact_internal_report": (
            "canonical_report = compact_verifier_report(report)" in verifier_source
            and 'args.report.write_text(json.dumps(canonical_report, indent=2, sort_keys=True)'
            in verifier_source
            and "public_report = public_verifier_report(report)" not in verifier_source
            and 'parser.add_argument("--private-report"' not in verifier_source
            and "KV_PRIVATE_VERIFIER_REPORT" not in test_source
            and "reward = public_reward(report)" in verifier_source
        ),
        "hidden_candidate_stdout_is_discarded_not_artifacted": (
            "log_name=None" in verifier_source
            and "gateway-final-leg-" not in verifier_source
        ),
        "detached_status_exports_canonical_full_report": (
            "docker exec --interactive --user 0:0" in status_block
            and all(
                name in status_block
                for name in (
                    "exit-code.txt",
                    "report.json",
                    "reward.json",
                    "reward.txt",
                    "test-stdout.txt",
                )
            )
            and "private-report" not in status_block
            and 'find "$LOCAL_VERIFIER_LOGS"' not in status_block
            and '< "$LOCAL_VERIFIER_LOGS' not in status_block
            and "listdir" not in status_block
            and "iterdir" not in status_block
            and ".glob(" not in status_block
            and "os.O_NOFOLLOW" in status_block
            and "os.O_NONBLOCK" in status_block
            and "stat.S_ISREG" in status_block
        ),
        "verifier_stdout_bind_is_protected_before_agent_exec": (
            "verifier_log_root=/logs/verifier" in entrypoint_source
            and 'chmod 0700 "$verifier_log_root"' in entrypoint_source
            and entrypoint_source.index('chmod 0700 "$verifier_log_root"')
            < entrypoint_source.index('exec "$@"')
        ),
    }
    output = {
        "schema_version": 1,
        "kind": "verifier-full-output-unit",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
