#!/usr/bin/env python3
"""Streaming adapter mutations for usage/[DONE]/error completeness."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.ledger import Ledger  # noqa: E402
from runner.model import BenchmarkVllmModel, ModelConfig, classify_tool_arguments  # noqa: E402


VALID_EVENTS = [
    b'data: {"choices":[{"delta":{"content":"adapter-ok"}}]}\n\n',
    b'data: {"choices":[],"usage":{"prompt_tokens":7,"completion_tokens":2,"total_tokens":9}}\n\n',
    b"data: [DONE]\n\n",
]


def sse_event(payload: dict[str, Any]) -> bytes:
    return f"data: {json.dumps(payload, separators=(',', ':'))}\n\n".encode()


UNEXPECTED_TOOL_EVENTS = [
    sse_event({"choices": [{"delta": {"reasoning_content": "inspect first"}}]}),
    sse_event(
        {
            "choices": [
                {
                    "finish_reason": "tool_calls",
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_",
                                "type": "function",
                                "function": {"name": "execute_", "arguments": "{\"cmd\":\""},
                            }
                        ]
                    }
                }
            ]
        }
    ),
    sse_event(
        {
            "choices": [
                {
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "unit",
                                "function": {"name": "bash", "arguments": "ls -R\"}"},
                            }
                        ]
                    }
                }
            ]
        }
    ),
    sse_event(
        {
            "choices": [],
            "usage": {"prompt_tokens": 11, "completion_tokens": 5, "total_tokens": 16},
        }
    ),
    b"data: [DONE]\n\n",
]


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 32
    mode: str
    request_bodies: list[dict[str, Any]]


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        raw_request = self.rfile.read(length)
        self.server.request_bodies.append(json.loads(raw_request))  # type: ignore[attr-defined]
        mode = self.server.mode  # type: ignore[attr-defined]
        if mode == "http_500":
            body = b'{"error":"mutated"}'
            self.send_response(500)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)
            return
        events = list(UNEXPECTED_TOOL_EVENTS if mode == "unexpected_tool" else VALID_EVENTS)
        if mode == "missing_done":
            events = events[:-1]
        elif mode == "missing_usage":
            events = [events[0], events[2]]
        elif mode == "stream_error":
            events = [
                sse_event(
                    {
                        "error": {
                            "type": "InternalServerError",
                            "code": 500,
                            "message": "backend decoder error",
                        }
                    }
                ),
                b"data: [DONE]\n\n",
            ]
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Connection", "close")
        self.end_headers()
        for event in events:
            self.wfile.write(event)
            self.wfile.flush()


def run_case(mode: str) -> dict[str, Any]:
    server = Server(("127.0.0.1", 0), Handler)
    server.mode = mode
    server.request_bodies = []
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    ledger = Ledger()
    model = BenchmarkVllmModel(
        endpoint=f"http://127.0.0.1:{server.server_port}/v1",
        run_id="opaque-run",
        profile="opaque-profile",
        leg_id="opaque-leg",
        cache_namespace="opaque-cache",
        seed=1,
        admin_token="unit-token",
        audit_epoch=7,
        ledger=ledger,
        config=ModelConfig(max_tokens=8),
        request_timeout_sec=5,
    )
    error: str | None = None
    response: dict[str, Any] | None = None
    try:
        response = model.query([{"role": "user", "content": f"mode:{mode}"}])
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    record = ledger.snapshot()[0]
    request_body = server.request_bodies[0]
    expected_success = mode in {"valid", "unexpected_tool"}
    expected_response = (
        {
            "content": "",
            "reasoning_content": "inspect first",
            "tool_calls": [
                {
                    "id": "call_unit",
                    "type": "function",
                    "function": {"name": "execute_bash", "arguments": "{\"cmd\":\"ls -R\"}"},
                }
            ],
        }
        if mode == "unexpected_tool"
        else {"content": "adapter-ok"}
    )
    payload_passed = (
        "reasoning_effort" not in request_body
        and "tools" not in request_body
        and "tool_choice" not in request_body
        and "parallel_tool_calls" not in request_body
    )
    payload_passed = payload_passed and request_body.get("cache_salt") == "opaque-cache"
    payload_passed = payload_passed and request_body.get("chat_template_kwargs") == {
        "enable_thinking": False
    }
    passed = (
        error is None
        and response == expected_response
        and payload_passed
        and record["sse_done"] is True
        and record["total_tokens"] == (16 if mode == "unexpected_tool" else 9)
        and (
            mode != "unexpected_tool"
            or (
                record["finish_reason"] == "tool_calls"
                and record["tool_call_count"] == 1
                and record["reasoning_content_chars"] == len("inspect first")
            )
        )
    ) if expected_success else (
        error is not None
        and record["error"] is not None
        and (
            (mode == "missing_done" and record["sse_done"] is False)
            or (mode == "missing_usage" and record["sse_done"] is True and record["total_tokens"] is None)
            or (
                mode == "stream_error"
                and record["sse_done"] is True
                and record["total_tokens"] is None
                and "model stream error" in error
                and "decoder error" in record["sse_error"]
            )
            or (mode == "http_500" and record["status"] == 500)
        )
    )
    return {
        "name": mode,
        "passed": passed,
        "error": error,
        "payload_passed": payload_passed,
        "ledger": {
            key: record.get(key)
            for key in (
                "status",
                "sse_done",
                "prompt_tokens",
                "completion_tokens",
                "total_tokens",
                "finish_reason",
                "tool_call_count",
                "tool_call_names",
                "tool_argument_shapes",
                "internal_reasoning_chars",
                "sse_error",
                "error",
            )
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    cases = [
        run_case(mode)
        for mode in (
            "valid",
            "unexpected_tool",
            "missing_done",
            "missing_usage",
            "stream_error",
            "http_500",
        )
    ]
    source = CONTROLLER_ROOT / "runner" / "model.py"
    report = {
        "schema_version": 1,
        "kind": "benchmark-stream-adapter-mutations",
        "adapter_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
        "tool_argument_classification": {
            "valid_cmd_only": classify_tool_arguments('{"cmd":"pwd"}'),
            "trailing_bracket": classify_tool_arguments('{"cmd":"pwd"]}'),
            "other_invalid": classify_tool_arguments('{"cmd":'),
            "bad_schema": classify_tool_arguments('{"cmd":"pwd","extra":true}'),
        },
    }
    report["passed"] = report["passed"] and report["tool_argument_classification"] == {
        "valid_cmd_only": "valid_cmd_only",
        "trailing_bracket": "invalid_trailing_bracket",
        "other_invalid": "invalid_cmd_json_other",
        "bad_schema": "valid_json_bad_schema",
    }
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered, end="")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
