#!/usr/bin/env python3
"""Check deterministic repo-stratified public/hidden corpus partitioning."""

from __future__ import annotations

import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
STAGER = TASK_ROOT / "scripts" / "stage-swebench-lite.py"


def load_stager():
    spec = importlib.util.spec_from_file_location("kvbench_swebench_stager", STAGER)
    if spec is None or spec.loader is None:
        raise RuntimeError("unable to load corpus stager")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    stager = load_stager()
    repo_sizes = [6, 114, 23, 4, 3, 6, 5, 6, 17, 23, 16, 77]
    instances = [
        {"repo": f"org/repo-{repo_index}", "instance_id": f"repo-{repo_index}__issue-{issue}"}
        for repo_index, size in enumerate(repo_sizes)
        for issue in range(size)
    ]
    forward = stager.partition_map(instances)
    reversed_result = stager.partition_map(list(reversed(instances)))
    counts = Counter(forward.values())
    strata = defaultdict(Counter)
    for instance in instances:
        strata[instance["repo"]][forward[instance["instance_id"]]] += 1
    report = {
        "schema_version": 1,
        "kind": "corpus-partition-unit",
        "passed": (
            len(instances) == 300
            and counts == {"public": 150, "hidden": 150}
            and forward == reversed_result
            and max(abs(values["public"] - values["hidden"]) for values in strata.values()) <= 1
        ),
        "partition_counts": dict(counts),
        "maximum_repo_delta": max(
            abs(values["public"] - values["hidden"]) for values in strata.values()
        ),
        "input_order_independent": forward == reversed_result,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
