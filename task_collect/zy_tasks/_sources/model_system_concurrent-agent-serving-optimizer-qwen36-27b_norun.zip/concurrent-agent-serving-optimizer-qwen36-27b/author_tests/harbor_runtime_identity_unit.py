#!/usr/bin/env python3
"""CPU-only mutation tests for the frozen Harbor uv runtime identity."""

from __future__ import annotations

import importlib.util
import tempfile
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
FREEZER_PATH = TASK_ROOT / "scripts" / "freeze-release-manifest.py"
SPEC = importlib.util.spec_from_file_location("harbor_runtime_identity_unit_freezer", FREEZER_PATH)
assert SPEC and SPEC.loader
FREEZER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(FREEZER)


def write(path: Path, payload: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    path.chmod(mode)


with tempfile.TemporaryDirectory(prefix="harbor-runtime-identity-unit-") as raw:
    root = Path(raw) / "harbor-tool"
    entrypoint = root / "bin/harbor"
    interpreter = root / "bin/python"
    interpreter_target = root / "bin/python3.14"
    site = root / "lib/python3.14/site-packages"
    write(entrypoint, b"#!/bin/sh\nexit 0\n", 0o755)
    write(interpreter_target, b"unit-python-binary\n", 0o755)
    interpreter.symlink_to(interpreter_target.name)
    write(
        root / "pyvenv.cfg",
        (
            f"home = {root / 'bin'}\n"
            "implementation = CPython\nversion_info = 3.14.6\n"
            "include-system-site-packages = false\n"
        ).encode(),
    )
    write(root / "uv-receipt.toml", b"[tool]\nname = 'harbor'\n")
    write(site / "harbor/__init__.py", b"__version__ = '0.18.0'\n")
    write(site / "_virtualenv.pth", b"import _virtualenv\n")
    write(site / "_virtualenv.py", b"# frozen local pth target\n")
    write(
        site / "harbor-0.18.0.dist-info/METADATA",
        b"Metadata-Version: 2.4\nName: harbor\nVersion: 0.18.0\n",
    )
    dependency = site / "pydantic/__init__.py"
    write(dependency, b"unit dependency\n")
    stdlib_file = root / "lib/python3.14/os.py"
    write(stdlib_file, b"# unit standard library\n")

    original = FREEZER.harbor_runtime_identity(entrypoint)
    assert original["harbor_version"] == "0.18.0"
    assert original["site_packages_file_count"] == 5
    assert original["tree_policy"] == "all-regular-files-except-__pycache__-v1"
    assert original["stdlib_file_count"] == 1

    write(site / "harbor/__pycache__/ignored.pyc", b"dynamic cache\n")
    cache_only = FREEZER.harbor_runtime_identity(entrypoint)
    assert cache_only == original

    dependency.write_bytes(b"same-version dependency mutation\n")
    dependency_drift = FREEZER.harbor_runtime_identity(entrypoint)
    assert dependency_drift["site_packages_tree_sha256"] != original[
        "site_packages_tree_sha256"
    ]
    dependency.write_bytes(b"unit dependency\n")

    stdlib_file.write_bytes(b"# same interpreter, changed standard library\n")
    stdlib_drift = FREEZER.harbor_runtime_identity(entrypoint)
    assert stdlib_drift["stdlib_tree_sha256"] != original["stdlib_tree_sha256"]
    stdlib_file.write_bytes(b"# unit standard library\n")

    write(site / "injected.pth", b"/tmp/untrusted\n")
    try:
        FREEZER.harbor_runtime_identity(entrypoint)
    except OSError:
        pass
    else:
        raise AssertionError("path-injecting .pth was accepted")
    (site / "injected.pth").unlink()

    write(site / "sitecustomize.py", b"raise RuntimeError('injected')\n")
    try:
        FREEZER.harbor_runtime_identity(entrypoint)
    except OSError:
        pass
    else:
        raise AssertionError("sitecustomize.py was accepted")
    (site / "sitecustomize.py").unlink()

    symlink = site / "untrusted-link"
    symlink.symlink_to(dependency)
    try:
        FREEZER.harbor_runtime_identity(entrypoint)
    except OSError:
        pass
    else:
        raise AssertionError("Harbor site-packages symlink was accepted")

print("harbor runtime identity unit: passed")
