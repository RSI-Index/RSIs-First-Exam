#!/usr/bin/env python3
"""CPU-only contracts for the one-way agent-to-hidden egress seal."""

from __future__ import annotations

import ast
import copy
import hashlib
import hmac
import importlib.util
import json
import re
import socket
import sys
import time
import types
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
WORKER_PATH = TASK_ROOT / "environment" / "sandbox-worker" / "worker.py"
SERVER_PATH = TASK_ROOT / "environment" / "bench-controller" / "server.py"
COMPOSE_PATH = TASK_ROOT / "environment" / "docker-compose.yaml"
REPO_ROOT = TASK_ROOT.parents[1]
RUNNER_PATH = (
    REPO_ROOT
    / "harbor_run_scripts"
    / "concurrent-agent-serving-optimizer-qwen36-27b"
    / "run-codex-round-loop-common.sh"
)
EGRESS_OVERLAY_PATH = RUNNER_PATH.parent / "codex-egress.compose.yaml"
CONTAINER_INTEGRATION_PATH = TASK_ROOT / "scripts" / "test-main-egress-seal-container.sh"


def load_worker() -> Any:
    class APIError(Exception):
        pass

    class ImageNotFound(APIError):
        pass

    class NotFound(APIError):
        pass

    fake_docker = types.ModuleType("docker")
    fake_errors = types.ModuleType("docker.errors")
    fake_models = types.ModuleType("docker.models")
    fake_containers = types.ModuleType("docker.models.containers")
    fake_types = types.ModuleType("docker.types")
    fake_errors.APIError = APIError
    fake_errors.ImageNotFound = ImageNotFound
    fake_errors.NotFound = NotFound
    fake_containers.Container = object
    fake_types.Ulimit = lambda **_kwargs: object()
    fake_docker.from_env = lambda **_kwargs: None
    modules = {
        "docker": fake_docker,
        "docker.errors": fake_errors,
        "docker.models": fake_models,
        "docker.models.containers": fake_containers,
        "docker.types": fake_types,
    }
    previous = {name: sys.modules.get(name) for name in modules}
    sys.modules.update(modules)
    try:
        spec = importlib.util.spec_from_file_location("main_egress_worker", WORKER_PATH)
        if spec is None or spec.loader is None:
            raise RuntimeError("could not load sandbox worker")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        for name, value in previous.items():
            if value is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value


def load_server_validator() -> tuple[Any, bytes]:
    parsed = ast.parse(SERVER_PATH.read_text(), filename=str(SERVER_PATH))
    names = {
        "_hex_text",
        "_exact_object",
        "_network_seal_record",
        "validate_main_egress_seal_attestation",
    }
    constants = {
        "MAIN_EGRESS_SEAL_CONTEXT",
        "MAIN_EGRESS_SEAL_ACTION",
    }
    selected: list[ast.stmt] = []
    for node in parsed.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id in constants
            for target in node.targets
        ):
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in names:
            selected.append(node)
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict[str, Any] = {
        "Any": Any,
        "hashlib": hashlib,
        "hmac": hmac,
        "json": json,
        "re": re,
        "secrets": __import__("secrets"),
        "time": time,
    }
    exec(compile(module, str(SERVER_PATH), "exec"), namespace)  # noqa: S102
    return (
        namespace["validate_main_egress_seal_attestation"],
        namespace["MAIN_EGRESS_SEAL_CONTEXT"],
    )


class FakeContainer:
    def __init__(self, container_id: str, attrs: dict[str, Any]) -> None:
        self.id = container_id
        self.attrs = attrs

    def reload(self) -> None:
        return None


class FakeNetwork:
    def __init__(
        self,
        network_id: str,
        *,
        internal: bool,
        project: str | None,
        compose_network: str | None,
        main: FakeContainer,
    ) -> None:
        labels: dict[str, str] = {}
        if project is not None:
            labels["com.docker.compose.project"] = project
        if compose_network is not None:
            labels["com.docker.compose.network"] = compose_network
        self.id = network_id
        self.main = main
        self.attrs: dict[str, Any] = {
            "Id": network_id,
            "Internal": internal,
            "Labels": labels,
            "Containers": {main.id: {"Name": "unit-main"}},
        }
        self.disconnect_calls: list[tuple[str, bool]] = []

    def disconnect(self, container_id: str, *, force: bool) -> None:
        if container_id != self.main.id or force is not True:
            raise AssertionError("seal disconnected the wrong target")
        self.disconnect_calls.append((container_id, force))
        attachments = self.main.attrs["NetworkSettings"]["Networks"]
        for name, attachment in list(attachments.items()):
            if attachment["NetworkID"] == self.id:
                del attachments[name]
        self.attrs["Containers"].pop(container_id, None)


class FakeContainers:
    def __init__(
        self,
        worker: FakeContainer,
        mains: list[FakeContainer],
        controllers: list[FakeContainer],
        hostname: str,
    ) -> None:
        self.worker = worker
        self.mains = mains
        self.controllers = controllers
        self.hostname = hostname

    def get(self, value: str) -> FakeContainer:
        if value != self.hostname:
            raise AssertionError(f"unexpected worker lookup: {value}")
        return self.worker

    def list(self, *, all: bool, filters: dict[str, Any]) -> list[FakeContainer]:
        if all is not True or "label" not in filters:
            raise AssertionError("service lookup must be an all-container label query")
        labels = filters["label"]
        if "com.docker.compose.service=main" in labels:
            return list(self.mains)
        if "com.docker.compose.service=bench-controller" in labels:
            return list(self.controllers)
        raise AssertionError(f"unexpected Compose service lookup: {labels!r}")


class FakeNetworks:
    def __init__(self, networks: dict[str, FakeNetwork]) -> None:
        self.networks = networks

    def get(self, network_id: str) -> FakeNetwork:
        return self.networks[network_id]


class FakeDockerClient:
    def __init__(
        self,
        worker: FakeContainer,
        mains: list[FakeContainer],
        controllers: list[FakeContainer],
        networks: dict[str, FakeNetwork],
        hostname: str,
    ) -> None:
        self.containers = FakeContainers(worker, mains, controllers, hostname)
        self.networks = FakeNetworks(networks)


def compose_labels(project: str, service: str) -> dict[str, str]:
    return {
        "com.docker.compose.project": project,
        "com.docker.compose.service": service,
        "com.docker.compose.oneoff": "False",
    }


def topology(worker_module: Any, *, with_external: bool = True) -> tuple[Any, dict[str, Any]]:
    project = "kvbench-egress-unit"
    hostname = "worker-unit"
    worker_id = "1" * 64
    main_id = "2" * 64
    controller_id = "5" * 64
    worker_image_id = "sha256:" + "a" * 64
    main_image_id = "sha256:" + "b" * 64
    controller_image_id = "sha256:" + "c" * 64
    front_id = "3" * 64
    external_id = "4" * 64
    worker = FakeContainer(
        worker_id,
        {
            "Image": worker_image_id,
            "Config": {"Labels": compose_labels(project, "sandbox-worker")},
        },
    )
    attachments = {"front": {"NetworkID": front_id}}
    if with_external:
        attachments["agent-egress"] = {"NetworkID": external_id}
    main = FakeContainer(
        main_id,
        {
            "Image": main_image_id,
            "Config": {"Labels": compose_labels(project, "main")},
            "State": {"Running": True},
            "HostConfig": {"NetworkMode": "kvbench-egress-unit_front"},
            "NetworkSettings": {"Networks": attachments},
        },
    )
    controller = FakeContainer(
        controller_id,
        {
            "Image": controller_image_id,
            "Config": {"Labels": compose_labels(project, "bench-controller")},
        },
    )
    networks = {
        front_id: FakeNetwork(
            front_id,
            internal=True,
            project=project,
            compose_network="front",
            main=main,
        )
    }
    if with_external:
        networks[external_id] = FakeNetwork(
            external_id,
            internal=False,
            project=project,
            compose_network="codex-egress",
            main=main,
        )
    client = FakeDockerClient(worker, [main], [controller], networks, hostname)
    worker_module.docker_client = client
    worker_module.socket.gethostname = lambda: hostname
    token = b"a" * 64
    worker_module._admin_token = lambda: token
    return client, {
        "project": project,
        "worker": worker,
        "main": main,
        "controller": controller,
        "controller_image_id": controller_image_id,
        "front_id": front_id,
        "external_id": external_id,
        "token": token.decode(),
    }


def rejected(callable_: Any) -> bool:
    try:
        callable_()
    except (KeyError, RuntimeError, TypeError, ValueError):
        return True
    return False


def main() -> int:
    worker = load_worker()
    validate, _context = load_server_validator()
    cases: list[dict[str, Any]] = []

    client, state = topology(worker, with_external=True)
    challenge = "b" * 64
    evidence = worker.seal_main_egress(
        {"action": "seal_main_egress", "schema_version": 2, "challenge": challenge}
    )
    seen: set[str] = set()
    summary = validate(
        evidence,
        expected_challenge=challenge,
        admin_token=state["token"],
        seen_nonces=seen,
    )
    cases.append(
        {
            "name": "same_project_external_network_is_detached_and_front_is_preserved",
            "passed": summary["sealed"] is True
            and summary["controller_image_id"] == state["controller_image_id"]
            and summary["external_network_count_before"] == 1
            and summary["external_network_count_after"] == 0
            and set(state["main"].attrs["NetworkSettings"]["Networks"]) == {"front"}
            and client.networks.get(state["external_id"]).disconnect_calls
            == [(state["main"].id, True)],
        }
    )

    second_challenge = "c" * 64
    second = worker.seal_main_egress(
        {
            "action": "seal_main_egress",
            "schema_version": 2,
            "challenge": second_challenge,
        }
    )
    second_summary = validate(
        second,
        expected_challenge=second_challenge,
        admin_token=state["token"],
        seen_nonces=seen,
    )
    cases.append(
        {
            "name": "seal_is_idempotent_with_fresh_one_time_evidence",
            "passed": second_summary["already_sealed"] is True
            and second_summary["detached_network_count"] == 0
            and len(seen) == 2,
        }
    )

    tampered = copy.deepcopy(evidence)
    tampered["topology"]["non_internal_after"] = 1
    cases.append(
        {
            "name": "controller_rejects_tampered_worker_evidence",
            "passed": rejected(
                lambda: validate(
                    tampered,
                    expected_challenge=challenge,
                    admin_token=state["token"],
                    seen_nonces=set(),
                )
            ),
        }
    )
    invalid_image = copy.deepcopy(evidence)
    invalid_image["controller"]["image_id"] = "not-an-image-id"
    unsigned = {key: value for key, value in invalid_image.items() if key != "signature"}
    canonical = json.dumps(
        unsigned, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode()
    invalid_image["signature"] = hmac.new(
        state["token"].encode(), _context + canonical, hashlib.sha256
    ).hexdigest()
    cases.append(
        {
            "name": "controller_rejects_signed_malformed_controller_image_identity",
            "passed": rejected(
                lambda: validate(
                    invalid_image,
                    expected_challenge=challenge,
                    admin_token=state["token"],
                    seen_nonces=set(),
                )
            ),
        }
    )
    cases.append(
        {
            "name": "controller_rejects_stale_challenge_and_replayed_nonce",
            "passed": rejected(
                lambda: validate(
                    evidence,
                    expected_challenge="d" * 64,
                    admin_token=state["token"],
                    seen_nonces=set(),
                )
            )
            and rejected(
                lambda: validate(
                    evidence,
                    expected_challenge=challenge,
                    admin_token=state["token"],
                    seen_nonces={evidence["attestation_nonce"]},
                )
            ),
        }
    )
    cases.append(
        {
            "name": "rpc_cannot_choose_a_cross_project_target",
            "passed": rejected(
                lambda: worker.seal_main_egress(
                    {
                        "action": "seal_main_egress",
                        "schema_version": 2,
                        "challenge": "e" * 64,
                        "container_id": "9" * 64,
                    }
                )
            ),
        }
    )

    _client, ambiguous = topology(worker, with_external=False)
    worker.docker_client.containers.mains.append(ambiguous["main"])
    cases.append(
        {
            "name": "multiple_same_project_main_containers_fail_closed",
            "passed": rejected(
                lambda: worker.seal_main_egress(
                    {
                        "action": "seal_main_egress",
                        "schema_version": 2,
                        "challenge": "f" * 64,
                    }
                )
            ),
        }
    )

    _client, ambiguous_controller = topology(worker, with_external=False)
    worker.docker_client.containers.controllers.append(
        ambiguous_controller["controller"]
    )
    cases.append(
        {
            "name": "multiple_same_project_controller_containers_fail_closed",
            "passed": rejected(
                lambda: worker.seal_main_egress(
                    {
                        "action": "seal_main_egress",
                        "schema_version": 2,
                        "challenge": "0" * 64,
                    }
                )
            ),
        }
    )

    _client, missing_front = topology(worker, with_external=False)
    front_network = worker.docker_client.networks.get(missing_front["front_id"])
    front_network.attrs["Internal"] = False
    cases.append(
        {
            "name": "missing_internal_front_fails_closed",
            "passed": rejected(
                lambda: worker.seal_main_egress(
                    {
                        "action": "seal_main_egress",
                        "schema_version": 2,
                        "challenge": "1" * 64,
                    }
                )
            ),
        }
    )

    compose = COMPOSE_PATH.read_text()
    runner = RUNNER_PATH.read_text()
    overlay = EGRESS_OVERLAY_PATH.read_text()
    container_integration = CONTAINER_INTEGRATION_PATH.read_text()
    server = SERVER_PATH.read_text()
    cases.append(
        {
            "name": "compose_and_runner_keep_docker_authority_out_of_main",
            "passed": "- sandbox-control:/run/kvbench-sandbox:ro" in compose
            and "- verifier-control:/run/kvbench-admin:ro" in compose
            and "- /var/run/docker.sock:/var/run/docker.sock" in compose
            and 'index("NET_ADMIN") == null' in runner
            and 'target != "/var/run/docker.sock"' in runner
            and "agent-only-egress" in overlay,
        }
    )
    cases.append(
        {
            "name": "disposable_egress_test_explicitly_disables_release_anchor",
            "passed": 'RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED: "0"'
            in container_integration
            and container_integration.index(
                'RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED: "0"'
            )
            < container_integration.index('"${compose[@]}" up'),
        }
    )
    begin_source = server[server.index("async def final_session_begin") :]
    cases.append(
        {
            "name": "hidden_session_is_created_only_after_seal_validation",
            "passed": "/admin/final/network-seal/challenge" in server
            and 'payload.get("network_egress_attestation")' in begin_source
            and begin_source.index("validate_main_egress_seal_attestation")
            < begin_source.index('request.app["final_session"] = session'),
        }
    )

    passed = all(case["passed"] for case in cases)
    print(
        json.dumps(
            {
                "schema_version": 1,
                "kind": "main-egress-seal-unit",
                "passed": passed,
                "cases": cases,
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
