#!/usr/bin/env python3
"""Deterministic CPU checks for the Oracle v5 protected/deep cutover."""

from __future__ import annotations

import asyncio
import importlib.util
import json
import sys
import time
from pathlib import Path
from typing import Any, Callable


TASK_ROOT = Path(__file__).resolve().parents[1]
SCHEDULER_PATH = TASK_ROOT / "solution" / "reference_gateway" / "scheduler.py"


def load_scheduler() -> Any:
    spec = importlib.util.spec_from_file_location(
        "reference_gateway_v5_tier_scheduler", SCHEDULER_PATH
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load reference scheduler")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


async def spin_until(predicate: Callable[[], bool]) -> None:
    for _ in range(100):
        if predicate():
            return
        await asyncio.sleep(0)
    raise AssertionError("condition did not become true")


async def add_waiter(
    scheduler: Any,
    module: Any,
    name: str,
    *,
    tokens: int,
    step: int,
    pending: bool = True,
    age_sec: float | None = None,
) -> Any:
    program = await scheduler.get_or_create_program(name)
    program.total_tokens = tokens
    program.step_count = step
    program.status = (
        module.ProgramStatus.REASONING
        if pending
        else module.ProgramStatus.ACTING
    )
    program.request_pending = pending
    if not pending:
        program.acting_since = time.time()
    scheduler._pause_locked(program, reason="v5_tier_test_setup")
    if age_sec is not None:
        program.request_wait_started_monotonic = time.monotonic() - age_sec
    return program


async def admission_boundary_cases(module: Any) -> list[dict[str, Any]]:
    Scheduler = module.ThunderScheduler
    Status = module.ProgramStatus
    Lifecycle = module.ProgramLifecycle
    results: list[dict[str, Any]] = []

    protected_scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    protected_waiter = await add_waiter(
        protected_scheduler,
        module,
        "protected-boundary-waiter",
        tokens=100,
        step=1,
    )
    protected_leader = await protected_scheduler.get_or_create_program(
        "protected-boundary-leader"
    )
    protected_leader.total_tokens = 100
    protected_leader.step_count = 11
    protected_leader.status = Status.ACTING
    protected_leader.acting_since = time.time()
    protected_task = asyncio.create_task(
        protected_scheduler.begin_request(protected_leader, 500)
    )
    await spin_until(
        lambda: protected_leader.lifecycle == Lifecycle.PAUSED
    )
    protected_snapshot = await protected_scheduler.snapshot()
    protected_task.cancel()
    try:
        await protected_task
    except asyncio.CancelledError:
        pass
    await protected_scheduler.cancel_waiting_request(protected_leader)
    await protected_scheduler.release_program(protected_leader.program_id)
    await protected_scheduler.release_program(protected_waiter.program_id)
    results.append(
        {
            "name": "request_twelve_retains_exact_v4_service_lag",
            "passed": (
                protected_leader.step_count == 12
                and protected_snapshot["service_lag_blocked"] == 1
                and protected_snapshot["counters"][
                    "pause_admission_service_lag"
                ]
                == 1
                and protected_snapshot["counters"][
                    "protected_request_offers"
                ]
                == 1
                and protected_snapshot["counters"]["deep_request_offers"]
                == 0
            ),
        }
    )

    deep_scheduler = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    deep_waiter = await add_waiter(
        deep_scheduler,
        module,
        "deep-boundary-waiter",
        tokens=100,
        step=1,
    )
    deep_leader = await deep_scheduler.get_or_create_program(
        "deep-boundary-leader"
    )
    deep_leader.total_tokens = 100
    deep_leader.step_count = 12
    deep_leader.status = Status.ACTING
    deep_leader.acting_since = time.time()
    await deep_scheduler.begin_request(deep_leader, 500)
    deep_snapshot = await deep_scheduler.snapshot()
    await deep_scheduler.finish_request(
        deep_leader, total_tokens=100, prompt_tokens=100
    )
    await deep_scheduler.release_program(deep_leader.program_id)
    await deep_scheduler.release_program(deep_waiter.program_id)
    results.append(
        {
            "name": "request_thirteen_bypasses_only_service_lag",
            "passed": (
                deep_leader.step_count == 13
                and deep_snapshot["active"] == 1
                and deep_snapshot["service_lag_blocked"] == 0
                and deep_snapshot["counters"]["deep_request_offers"] == 1
                and deep_snapshot["counters"][
                    "deep_service_lag_bypass_decisions"
                ]
                == 1
                and deep_snapshot["counters"]["pause_admission"] == 0
            ),
        }
    )
    return results


async def restore_order_cases(module: Any) -> list[dict[str, Any]]:
    Scheduler = module.ThunderScheduler
    Status = module.ProgramStatus
    Lifecycle = module.ProgramLifecycle
    results: list[dict[str, Any]] = []

    tiered = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    anchor = await tiered.get_or_create_program("tier-order-anchor")
    anchor.total_tokens = 650
    anchor.status = Status.REASONING
    protected = await add_waiter(
        tiered, module, "tier-order-protected", tokens=300, step=12
    )
    deep_short = await add_waiter(
        tiered, module, "tier-order-deep-short", tokens=100, step=13
    )
    idle = await add_waiter(
        tiered,
        module,
        "tier-order-idle",
        tokens=10,
        step=13,
        pending=False,
    )
    await tiered.schedule_once()
    tiered_snapshot = await tiered.snapshot()
    results.append(
        {
            "name": "protected_ordinal_precedes_shorter_deep_then_acting",
            "passed": (
                protected.lifecycle == Lifecycle.ACTIVE
                and deep_short.lifecycle == Lifecycle.PAUSED
                and idle.lifecycle == Lifecycle.ACTIVE
                and tiered_snapshot["tracked_tokens_full"] == 960.0
                and tiered_snapshot["capacity_overflow_pages"] is None
                and tiered_snapshot["counters"]["mixed_request_tier_ticks"]
                == 1
                and tiered_snapshot["counters"][
                    "resume_protected_request"
                ]
                == 1
                and tiered_snapshot["counters"]["resume_deep_request"] == 0
            ),
        }
    )

    deep_sjf = Scheduler(capacity_tokens=1000, buffer_per_program=0)
    sjf_anchor = await deep_sjf.get_or_create_program("deep-sjf-anchor")
    sjf_anchor.total_tokens = 700
    sjf_anchor.status = Status.REASONING
    deep_long = await add_waiter(
        deep_sjf, module, "deep-sjf-long-first", tokens=250, step=13
    )
    deep_shorter = await add_waiter(
        deep_sjf, module, "deep-sjf-short-second", tokens=100, step=14
    )
    await deep_sjf.schedule_once()
    deep_sjf_snapshot = await deep_sjf.snapshot()
    results.append(
        {
            "name": "deep_queue_selects_total_tokens_sjf_not_insertion_or_ordinal",
            "passed": (
                deep_long.lifecycle == Lifecycle.PAUSED
                and deep_shorter.lifecycle == Lifecycle.ACTIVE
                and deep_sjf_snapshot["tracked_tokens_full"] == 800.0
                and deep_sjf_snapshot["counters"]["deep_sjf_priority_ticks"]
                == 1
                and deep_sjf_snapshot["counters"]["resume_deep_request"]
                == 1
            ),
        }
    )

    aged_first = Scheduler(
        capacity_tokens=1000,
        buffer_per_program=0,
        fair_wait_threshold_sec=220.0,
    )
    aged_anchor = await aged_first.get_or_create_program("aged-tier-anchor")
    aged_anchor.total_tokens = 600
    aged_anchor.status = Status.REASONING
    aged_deep = await add_waiter(
        aged_first,
        module,
        "aged-deep-owner",
        tokens=400,
        step=13,
        age_sec=220.0,
    )
    young_protected = await add_waiter(
        aged_first,
        module,
        "young-protected",
        tokens=100,
        step=12,
    )
    await aged_first.schedule_once()
    aged_snapshot = await aged_first.snapshot()
    results.append(
        {
            "name": "aged_reservation_precedes_protected_and_deep_tiers",
            "passed": (
                aged_deep.lifecycle == Lifecycle.ACTIVE
                and young_protected.lifecycle == Lifecycle.PAUSED
                and aged_snapshot["tracked_tokens_full"] == 1000.0
                and aged_snapshot["counters"][
                    "aged_reservation_satisfied"
                ]
                == 1
                and aged_snapshot["counters"]["resume_deep_request"] == 1
                and aged_snapshot["aged_rescue_post_commit_overflow_peak"] == 0
            ),
        }
    )
    return results


async def cancel_and_public_compatibility_cases(
    module: Any,
) -> list[dict[str, Any]]:
    Scheduler = module.ThunderScheduler
    Status = module.ProgramStatus
    Lifecycle = module.ProgramLifecycle
    results: list[dict[str, Any]] = []

    cancel_scheduler = Scheduler(capacity_tokens=1, buffer_per_program=0)
    anchor = await cancel_scheduler.get_or_create_program("deep-cancel-anchor")
    anchor.total_tokens = 1
    anchor.status = Status.REASONING
    cancelled = await cancel_scheduler.get_or_create_program(
        "deep-cancel-waiter"
    )
    cancelled.step_count = 12
    cancelled.status = Status.ACTING
    cancelled.acting_since = time.time()
    cancel_task = asyncio.create_task(
        cancel_scheduler.begin_request(cancelled, 5)
    )
    await spin_until(lambda: cancelled.lifecycle == Lifecycle.PAUSED)
    waiting_snapshot = await cancel_scheduler.snapshot()
    cancel_task.cancel()
    try:
        await cancel_task
    except asyncio.CancelledError:
        pass
    await cancel_scheduler.cancel_waiting_request(cancelled)
    cancelled_snapshot = await cancel_scheduler.snapshot()
    await cancel_scheduler.release_program(cancelled.program_id)
    await cancel_scheduler.release_program(anchor.program_id)
    results.append(
        {
            "name": "deep_cancel_clears_request_state_and_partitions_wait_latency",
            "passed": (
                waiting_snapshot["deep_pending_request_waiters"] == 1
                and waiting_snapshot["deep_pending_request_waiters_peak"] == 1
                and cancelled_snapshot["deep_pending_request_waiters"] == 0
                and cancelled_snapshot["pending_request_waiters"] == 0
                and cancelled_snapshot["service_lag_blocked"] == 0
                and cancelled_snapshot["deep_pause_wait_count"] == 1
                and cancelled_snapshot["protected_pause_wait_count"] == 0
                and cancelled_snapshot["pause_wait_count"] == 1
                and cancelled_snapshot["tracked_tokens_full"] == 1.0
            ),
        }
    )

    async def protected_trace(cutoff: int) -> dict[str, Any]:
        scheduler = Scheduler(
            capacity_tokens=1000,
            buffer_per_program=0,
            fair_service_until_step=cutoff,
        )
        trace_anchor = await scheduler.get_or_create_program(
            f"public-trace-anchor-{cutoff}"
        )
        trace_anchor.total_tokens = 600
        trace_anchor.status = Status.REASONING
        pending = await add_waiter(
            scheduler,
            module,
            f"public-trace-pending-{cutoff}",
            tokens=400,
            step=2,
        )
        new = await add_waiter(
            scheduler,
            module,
            f"public-trace-new-{cutoff}",
            tokens=300,
            step=1,
        )
        idle = await add_waiter(
            scheduler,
            module,
            f"public-trace-idle-{cutoff}",
            tokens=200,
            step=3,
            pending=False,
        )
        await scheduler.schedule_once()
        snapshot = await scheduler.snapshot()
        return {
            "pending": pending.lifecycle.value,
            "new": new.lifecycle.value,
            "idle": idle.lifecycle.value,
            "tracked": snapshot["tracked_tokens_full"],
            "resume_pending": snapshot["counters"]["resume_pending"],
            "resume_new": snapshot["counters"]["resume_new"],
            "resume_acting": snapshot["counters"]["resume_acting"],
            "least_ticks": snapshot["counters"][
                "least_service_priority_ticks"
            ],
            "deep_offers": snapshot["counters"]["deep_request_offers"],
            "deep_waiters_peak": snapshot[
                "deep_pending_request_waiters_peak"
            ],
        }

    cutoff_trace = await protected_trace(12)
    v4_emulator_trace = await protected_trace(1_000_000)
    results.append(
        {
            "name": "steps_one_through_twelve_match_v4_protected_trace",
            "passed": (
                cutoff_trace == v4_emulator_trace
                and cutoff_trace["deep_offers"] == 0
                and cutoff_trace["deep_waiters_peak"] == 0
            ),
        }
    )
    return results


async def run_cases() -> list[dict[str, Any]]:
    module = load_scheduler()
    Scheduler = module.ThunderScheduler
    results: list[dict[str, Any]] = []

    snapshot = await Scheduler(capacity_tokens=1000).snapshot()
    rejected: list[Any] = []
    invalid_values: list[Any] = [0, -1, True, 12.0]
    for value in invalid_values:
        try:
            Scheduler(
                capacity_tokens=1000,
                fair_service_until_step=value,
            )
        except ValueError:
            rejected.append(value)
    results.append(
        {
            "name": "v5_policy_schema_and_cutover_are_explicit",
            "passed": (
                snapshot["scheduler_policy_schema_version"] == 4
                and snapshot["queue_policy"]
                == "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"
                and snapshot["fair_service_until_step"] == 12
                and snapshot["deep_request_first_step"] == 13
                and snapshot["deep_reentry_bypasses_service_lag"] is True
                and rejected == invalid_values
            ),
        }
    )
    results.extend(await admission_boundary_cases(module))
    results.extend(await restore_order_cases(module))
    results.extend(await cancel_and_public_compatibility_cases(module))
    return results


def main() -> int:
    cases = asyncio.run(run_cases())
    report = {
        "schema_version": 1,
        "kind": "reference-gateway-v5-tiers-unit",
        "passed": all(case["passed"] for case in cases),
        "cases": cases,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
