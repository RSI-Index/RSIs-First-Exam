#!/usr/bin/env python3
"""End-to-end checks for the credentialed UID-900 loopback bridge."""

from __future__ import annotations

import asyncio
import importlib.util
import json
import os
import stat
import sys
import tempfile
from pathlib import Path

from aiohttp import ClientSession, web


TASK_ROOT = Path(__file__).resolve().parents[1]
BRIDGE_PATH = TASK_ROOT / "environment" / "loopback_bridge.py"
CONTROLLER_ROOT = TASK_ROOT / "environment" / "bench-controller"
sys.path.insert(0, str(CONTROLLER_ROOT))

from runner.model import (  # noqa: E402
    TRANSPORT_AUTH_HEADER,
    derive_transport_credential as controller_credential,
    transport_headers_for_endpoint,
)

spec = importlib.util.spec_from_file_location("kvbench_loopback_bridge", BRIDGE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError("could not load loopback bridge module")
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


async def exercise() -> dict[str, bool]:
    admin_token = b"integration-admin-token"
    expected_credential = controller_credential(admin_token.decode())
    observed: dict[str, object] = {"calls": 0}
    response_chunks = [b"data: first\n\n", b"data: second\x00tail\n\n", b"data: [DONE]\n\n"]

    async def upstream_handler(request: web.Request) -> web.StreamResponse:
        observed["calls"] = int(observed["calls"]) + 1
        observed["credential"] = request.headers.get(TRANSPORT_AUTH_HEADER)
        observed["candidate_header"] = request.headers.get("X-Candidate-Probe")
        observed["query"] = request.query_string
        observed["body"] = await request.read()
        response = web.StreamResponse(
            status=200,
            headers={"Content-Type": "text/event-stream", "X-Upstream-Probe": "preserved"},
        )
        await response.prepare(request)
        for chunk in response_chunks:
            await response.write(chunk)
            await asyncio.sleep(0)
        await response.write_eof()
        return response

    upstream = web.Application()
    upstream.router.add_post("/v1/chat/completions", upstream_handler)
    upstream_runner = web.AppRunner(upstream)
    await upstream_runner.setup()
    upstream_site = web.TCPSite(upstream_runner, "127.0.0.1", 0)
    await upstream_site.start()
    upstream_port = upstream_site._server.sockets[0].getsockname()[1]

    bridge_app = bridge.make_app(
        upstream_origin=f"http://127.0.0.1:{upstream_port}",
        transport_credential=expected_credential,
    )
    bridge_runner = web.AppRunner(bridge_app)
    await bridge_runner.setup()
    bridge_site = web.TCPSite(bridge_runner, "127.0.0.1", 0)
    await bridge_site.start()
    bridge_port = bridge_site._server.sockets[0].getsockname()[1]

    checks: dict[str, bool] = {}
    try:
        async with ClientSession(auto_decompress=False) as client:
            async with client.post(
                f"http://127.0.0.1:{bridge_port}/v1/chat/completions?probe=1",
                data=b"request-body",
                headers={
                    TRANSPORT_AUTH_HEADER: "candidate-chosen-value",
                    "X-Candidate-Probe": "preserved",
                },
            ) as response:
                body = await response.read()
                checks["response_entity_bytes_preserved"] = body == b"".join(response_chunks)
                checks["response_headers_preserved"] = (
                    response.headers.get("X-Upstream-Probe") == "preserved"
                )
        checks["candidate_credential_is_overwritten"] = (
            observed.get("credential") == expected_credential
            and observed.get("credential") != "candidate-chosen-value"
        )
        checks["request_body_and_metadata_preserved"] = (
            observed.get("body") == b"request-body"
            and observed.get("candidate_header") == "preserved"
            and observed.get("query") == "probe=1"
        )
        checks["one_client_request_is_one_upstream_request"] = observed["calls"] == 1
        connector = bridge_app["data_client"].connector
        checks["bridge_connector_preserves_192_concurrency"] = (
            connector is not None
            and connector.limit == 192
            and connector.limit_per_host == 0
            and connector.force_close is True
        )
        control_connector = bridge_app["control_client"].connector
        checks["bridge_control_pool_is_independent"] = (
            control_connector is not None
            and control_connector.limit == 8
            and control_connector.limit_per_host == 0
            and control_connector.force_close is True
        )
    finally:
        await bridge_runner.cleanup()
        await upstream_runner.cleanup()

    previous = os.environ.get("TRUSTED_MODEL_API_DATA_URL")
    os.environ["TRUSTED_MODEL_API_DATA_URL"] = "http://model-api:8100/v1"
    try:
        direct = transport_headers_for_endpoint(
            "http://model-api:8100/v1",
            admin_token.decode(),
        )
        candidate = transport_headers_for_endpoint(
            "http://main:9000/v1",
            admin_token.decode(),
        )
    finally:
        if previous is None:
            os.environ.pop("TRUSTED_MODEL_API_DATA_URL", None)
        else:
            os.environ["TRUSTED_MODEL_API_DATA_URL"] = previous
    checks["controller_direct_leg_gets_matching_credential"] = direct == {
        TRANSPORT_AUTH_HEADER: expected_credential
    }
    checks["controller_candidate_leg_gets_no_transport_credential"] = candidate == {}

    with tempfile.TemporaryDirectory(prefix="kvbench-bridge-credential-") as raw_root:
        root = Path(raw_root)
        token_path = root / "admin.token"
        credential_path = root / "bridge" / "transport.credential"
        token_path.write_bytes(admin_token + b"\n")
        bridge.provision_credential(
            token_path,
            credential_path,
            owner_uid=os.getuid(),
            owner_gid=os.getgid(),
        )
        info = credential_path.stat(follow_symlinks=False)
        checks["provisioned_credential_is_narrow_and_matching"] = (
            stat.S_IMODE(info.st_mode) == 0o440
            and bridge.load_credential(credential_path) == expected_credential
            and bridge.derive_transport_credential(admin_token) == expected_credential
        )

    return checks


async def main() -> int:
    checks = await exercise()
    report = {
        "schema_version": 1,
        "kind": "loopback-bridge-integration",
        "passed": all(checks.values()),
        "checks": checks,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
