"""Trusted closed-loop benchmark implementation."""
