#!/usr/bin/env bash
set -euo pipefail

: "${UPSTREAM_UNIX_SOCKET:?UPSTREAM_UNIX_SOCKET must point to the host vLLM Unix socket}"
if [[ "$UPSTREAM_UNIX_SOCKET" != /* || ! -S "$UPSTREAM_UNIX_SOCKET" ]]; then
  echo "model-api: UPSTREAM_UNIX_SOCKET is not an available absolute Unix socket" >&2
  exit 64
fi

: "${ADMIN_TOKEN_FILE:=/run/kvbench-admin/token}"
install -d -m 0700 "$(dirname "$ADMIN_TOKEN_FILE")"
if [[ ! -f "$ADMIN_TOKEN_FILE" ]]; then
  umask 077
  python3 - <<'PY' > "$ADMIN_TOKEN_FILE"
import secrets
print(secrets.token_hex(32))
PY
fi
chown root:root "$ADMIN_TOKEN_FILE"
chmod 0400 "$ADMIN_TOKEN_FILE"

exec python3 /opt/model-api/server.py
