#!/usr/bin/env python3
"""Fail-closed transport configuration for the trusted model proxy."""

from __future__ import annotations

import os
import stat
from pathlib import Path


UPSTREAM_ORIGIN = "http://localhost"


class UpstreamConfigurationError(RuntimeError):
    """The trusted proxy was not given a usable Unix socket."""


def configured_socket_path(value: str | None = None) -> Path:
    """Return a normalized absolute socket path without permitting TCP fallback."""
    raw = os.environ.get("UPSTREAM_UNIX_SOCKET") if value is None else value
    if not raw:
        raise UpstreamConfigurationError("UPSTREAM_UNIX_SOCKET must be configured")
    if "\x00" in raw:
        raise UpstreamConfigurationError("UPSTREAM_UNIX_SOCKET contains a NUL byte")

    path = Path(raw)
    if not path.is_absolute():
        raise UpstreamConfigurationError("UPSTREAM_UNIX_SOCKET must be an absolute path")
    if path != Path(os.path.normpath(raw)):
        raise UpstreamConfigurationError("UPSTREAM_UNIX_SOCKET must be normalized")
    if path.name in {"", ".", ".."}:
        raise UpstreamConfigurationError("UPSTREAM_UNIX_SOCKET must name a socket")
    return path


def require_live_socket(path: Path) -> None:
    """Reject missing paths, symlinks, and non-socket filesystem objects."""
    try:
        mode = path.lstat().st_mode
    except OSError as exc:
        raise UpstreamConfigurationError(
            f"configured upstream Unix socket is unavailable: {path}"
        ) from exc
    if not stat.S_ISSOCK(mode):
        raise UpstreamConfigurationError(
            f"configured upstream path is not a Unix socket: {path}"
        )
