# Qwen3.6 concurrent-agent workload plan

This is the active workload-selection record for the Qwen/Qwen3.6-27B TP2
task. Retired model experiments and earlier Qwen cache profiles are historical
only; none may set the active model identity, KV budget, pressure threshold,
reference speedup, or release evidence.

## Evaluation question

The task starts an agent from a protocol-correct Direct/FIFO gateway and asks it
to improve concurrent coding-agent action throughput by scheduling admissions
to one fixed vLLM backend. It must preserve one-to-one request transparency,
quality, starvation prevention, backend work, cancellation, and lifecycle
cleanup. The
comparison is Direct versus the submitted scheduler on identical workloads,
not Qwen versus another model.

The reported throughput is successfully parsed and executed mini-SWE-agent
actions per minute. It includes the model reasoning/action loop and real shell
execution. It is not a SWE-bench solve-rate claim.

## Active shape

- Model: Qwen/Qwen3.6-27B revision
  `6a9e13bd6fc8f0983b9b99948120bc37f49c13e9`, TP2 on physical GPUs 6 and 7.
- Runtime: vLLM 0.24.0, FP8 KV, prefix caching, 192-sequence ceiling, and an
  explicit 30 GiB KV allocation per GPU.
- Workload: one live wave of 192 independent mini-SWE-agent rollouts at
  concurrency 192, no synthetic padding, at most 24 model/action steps, and a
  2,048-token completion cap.
- Corpus: six pinned public SWE-bench Lite issues and six disjoint hidden
  issues. Issues repeat to fill the wave, but every rollout receives a fresh
  sandbox and independent trajectory.
- Public: one exact 1800-second measured interval per leg.
- Hidden formal scoring: one complete finite Direct leg and one complete
  finite Candidate leg. A commitment to the private workload nonce selects AB
  or BA, with a fresh candidate process and clean state before both legs.

The 192x24 choice is measured rather than inherited from the paper. On this
smaller Qwen model/cache combination, lower concurrency and shallow runs did
not reliably fill KV. Extending depth can increase working set, but it also
makes a public feedback iteration prohibitively long. The selected shape
reaches sustained real-trajectory pressure while preserving a bounded public
edit-test loop.

## Why the public leg is thirty minutes

The active Direct trace had KV p95 around 0.870 at 300 seconds and 0.868 at 360
seconds; it crossed to about 0.971 at 420 seconds and stayed near saturation.
Consequently, a short result is dominated by workload ramp-up and transient
queue position. Eighteen hundred seconds provides a materially longer
post-knee interval and enough samples for pressure, cancellation,
and sustained-throughput gates.

One author-only release calibration runs Direct plus Oracle, approximately 60
minutes plus warmup and teardown, and atomically creates the immutable private
Direct anchor. Actual Harbor public rounds never repeat Direct: each gateway
edit runs only a new candidate leg, normally 30--35 minutes, under a 2100-second
outer ceiling. A baseline-preflight rejection creates no attempt. Once
preflight passes and execution begins, the controller creates a new pair
directory linked to the anchor; even a runtime-failed execution remains an
append-only attempt. Completed leg payloads are immutable. Repeating compare
may idempotently refresh comparison metadata and `compare.json` for the current
attempt without changing an earlier leg or attempt.

## Public versus hidden semantics

Public deliberately censors in-flight work at the 1800-second boundary. Only
actions whose tool execution ends within the interval count. Pressure,
one-to-one audit, request success, zero-progress fraction, and model /
controller / corpus identities must all pass before a speedup is displayed.

Hidden has no fixed-window censoring. Its finite throughput interval begins at
one global monotonic timestamp immediately before the complete measured cohort
is dispatched and ends when the last measured `agent.run` terminates. This
includes dispatch skew and every agent loop, while repository verification and
sandbox cleanup remain hard quality/lifecycle gates outside the scheduling-rate
denominator. A workflow that
reaches the configured 24-step limit is healthy even if mini-SWE-agent reports
`LimitsExceeded`, so the score requires minimum progress 24 and a calibrated
repository-test count while permitting zero natural-completion markers.

Public and hidden intentionally use different timing protocols but the same
192x24 pressure family, model contract, completion cap, and scheduler API. The
hidden corpus, raw legs, thresholds not already documented, and reward remain
controller-private.

## Evidence status

The fixed-window public v4 pair measured 1.1579x Oracle speedup and exploratory
hidden v4 A/B/B/A measured 1.0360x with stable Direct legs. The finite timing
and hidden-isolation defects discovered from that diagnostic have been fixed.
The v5 development public rerun then measured 1.1503x, reduced KV occupancy,
passed every then-active gate, and showed zero deep/mixed-tier activation. The
v5 exploratory hidden A/B/B/A completed at 1.223906x geometric-mean speedup
with stable Direct/Oracle legs and all deep witnesses. It supplied the
conservative frozen 1.195 reference; it is not the formal release protocol.

Release qualification subsequently completed on the unchanged r2 build. The
author-only public calibration created the immutable Direct anchor and measured
Oracle at 1.125936x Direct. A release-topology Candidate-only Oracle check
measured 1.153165x while reusing that anchor. The nonce-committed formal hidden
run used exactly one Direct and one Oracle leg and measured 1.244720x, with all
quality, lifecycle, audit, and verifier gates passing. The first multi-session
Codex trial then found continuation infrastructure bugs after Round 1; those
runner-only fixes require manifest refreeze but do not change the workload,
policy, images, anchor, or Oracle evidence.
