#!/usr/bin/env python3
"""Retire a full SWE-bench Lite manifest into the pinned compact corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CORPUS_ROOT = Path("~/.cache/harbor-kv-scheduler-v2/swebench-lite").expanduser()
DEFAULT_SELECTION = TASK_ROOT / "scripts" / "swebench-compact-selection.json"
DATASET = "princeton-nlp/SWE-Bench_Lite"
DATASET_REVISION = "6ec7bb89b9342f664a54a6e0a6ea6501d3437cc2"
FULL_INSTANCE_COUNT = 300
COMPACT_INSTANCE_COUNT = 12


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def atomic_write_read_only(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=f".{path.name}-", dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.chmod(0o444)
    temporary.replace(path)


def load_selection(path: Path) -> tuple[dict[str, Any], dict[str, str]]:
    selection = json.loads(path.read_text())
    if (
        selection.get("schema_version") != 1
        or selection.get("dataset") != DATASET
        or selection.get("dataset_revision") != DATASET_REVISION
        or selection.get("source_instance_count") != FULL_INSTANCE_COUNT
    ):
        raise RuntimeError("compact selection lock does not match the pinned dataset")
    partitions = selection.get("partitions")
    if not isinstance(partitions, dict) or set(partitions) != {"public", "hidden"}:
        raise RuntimeError("compact selection lock must contain public and hidden partitions")
    mapping: dict[str, str] = {}
    for partition in ("public", "hidden"):
        instance_ids = partitions.get(partition)
        if not isinstance(instance_ids, list) or len(instance_ids) != COMPACT_INSTANCE_COUNT // 2:
            raise RuntimeError(f"compact {partition} partition must contain six instances")
        for instance_id in instance_ids:
            if not isinstance(instance_id, str) or not instance_id or instance_id in mapping:
                raise RuntimeError(f"invalid or duplicated compact instance: {instance_id!r}")
            mapping[instance_id] = partition
    return selection, mapping


def validate_source(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    if (
        manifest.get("schema_version") != 1
        or manifest.get("dataset") != DATASET
        or manifest.get("dataset_revision") != DATASET_REVISION
    ):
        raise RuntimeError("source manifest does not match the pinned SWE-bench Lite dataset")
    entries = manifest.get("instances")
    if not isinstance(entries, list) or len(entries) != FULL_INSTANCE_COUNT:
        raise RuntimeError("source/archive manifest must contain all 300 instances")
    instance_ids = [entry.get("instance_id") for entry in entries]
    if len(set(instance_ids)) != FULL_INSTANCE_COUNT:
        raise RuntimeError("source manifest instance IDs are duplicated")
    return entries


def inspect_selected(entries: list[dict[str, Any]]) -> None:
    references = [str(entry["image_name"]) for entry in entries]
    inspected = subprocess.run(
        ["docker", "image", "inspect", *references],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=120,
        check=False,
    )
    if inspected.returncode != 0:
        raise RuntimeError(f"one or more compact images are unavailable:\n{inspected.stdout[-4000:]}")
    payload = json.loads(inspected.stdout)
    if not isinstance(payload, list) or len(payload) != len(entries):
        raise RuntimeError("Docker returned an invalid compact image inspection payload")
    for entry, image in zip(entries, payload, strict=True):
        if str(image.get("Id") or "").lower() != str(entry.get("image_digest") or "").lower():
            raise RuntimeError(f"compact image ID changed: {entry.get('instance_id')}")
        official = str(entry.get("official_manifest_digest") or "").lower()
        repo_digests = [str(value).lower() for value in image.get("RepoDigests") or []]
        if not official.startswith("sha256:") or not any(
            value.endswith(f"@{official}") for value in repo_digests
        ):
            raise RuntimeError(f"compact OCI digest is absent locally: {entry.get('instance_id')}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus-root", type=Path, default=DEFAULT_CORPUS_ROOT)
    parser.add_argument("--selection", type=Path, default=DEFAULT_SELECTION)
    parser.add_argument(
        "--skip-docker-validation",
        action="store_true",
        help="metadata-only operation; normally the 12 retained image IDs are verified before writing",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    corpus_root = args.corpus_root.expanduser().resolve(strict=True)
    manifest_path = corpus_root / "manifest.json"
    archive_path = corpus_root / "manifest-full-300-retired.json"
    selection_path = args.selection.expanduser().resolve(strict=True)
    selection_bytes = selection_path.read_bytes()
    selection, partitions = load_selection(selection_path)

    live_bytes = manifest_path.read_bytes()
    live = json.loads(live_bytes)
    if live.get("corpus_mode") == "compact-repeated-rollouts":
        if not archive_path.is_file():
            raise RuntimeError("compact manifest exists without its full-corpus audit archive")
        source_bytes = archive_path.read_bytes()
    else:
        source_bytes = live_bytes
        if archive_path.exists():
            if archive_path.read_bytes() != source_bytes:
                raise RuntimeError("existing full-corpus archive differs from the live source manifest")
        else:
            atomic_write_read_only(archive_path, source_bytes)

    source = json.loads(source_bytes)
    source_entries = validate_source(source)
    by_id = {str(entry["instance_id"]): entry for entry in source_entries}
    missing = sorted(set(partitions) - set(by_id))
    if missing:
        raise RuntimeError(f"compact selection is absent from the source manifest: {missing}")
    entries: list[dict[str, Any]] = []
    for instance_id, partition in partitions.items():
        entry = deepcopy(by_id[instance_id])
        entry["partition"] = partition
        entries.append(entry)
    entries.sort(key=lambda entry: str(entry["instance_id"]))
    repositories = {str(entry.get("repo")) for entry in entries}
    if len(entries) != COMPACT_INSTANCE_COUNT or len(repositories) != COMPACT_INSTANCE_COUNT:
        raise RuntimeError("compact selection must contain exactly one instance from each repository")
    if not args.skip_docker_validation:
        inspect_selected(entries)

    compact = deepcopy(source)
    compact["corpus_mode"] = "compact-repeated-rollouts"
    compact["source_instance_count"] = FULL_INSTANCE_COUNT
    compact["selected_instance_count"] = COMPACT_INSTANCE_COUNT
    compact["source_manifest_sha256"] = sha256_bytes(source_bytes)
    compact["selection_lock_sha256"] = sha256_bytes(selection_bytes)
    compact["selection_policy"] = selection["selection_policy"]
    compact["partition_policy"] = {
        "algorithm": "compact-six-repositories-per-partition",
        "public_instances": COMPACT_INSTANCE_COUNT // 2,
        "hidden_instances": COMPACT_INSTANCE_COUNT // 2,
        "calibration_partition": "public",
        "rollout_reuse": True,
        "fresh_sibling_container_per_rollout": True,
    }
    compact["instances"] = entries
    encoded = (json.dumps(compact, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    atomic_write_read_only(manifest_path, encoded)
    report = {
        "status": "already-compact" if live.get("corpus_mode") == "compact-repeated-rollouts" else "compacted",
        "manifest": str(manifest_path),
        "manifest_sha256": sha256_bytes(encoded),
        "archive": str(archive_path),
        "archive_sha256": sha256_bytes(source_bytes),
        "instances": len(entries),
        "repositories": len(repositories),
        "partition_counts": {
            partition: sum(entry["partition"] == partition for entry in entries)
            for partition in ("public", "hidden")
        },
        "docker_validated": not args.skip_docker_validation,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
