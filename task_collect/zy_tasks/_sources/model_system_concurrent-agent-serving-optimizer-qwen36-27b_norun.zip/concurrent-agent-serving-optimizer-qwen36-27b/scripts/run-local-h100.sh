#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
ORIGINAL_ARGUMENTS=("$@")

HARBOR_BIN="$(command -v harbor || true)"
[[ -n "$HARBOR_BIN" ]] || { echo "Harbor is unavailable" >&2; exit 2; }
HARBOR_BIN="$(readlink -f -- "$HARBOR_BIN")"
[[ -x "$HARBOR_BIN" ]] || { echo "Harbor is not executable: $HARBOR_BIN" >&2; exit 2; }

AGENT="oracle"
AGENT_MODEL=""
JOB_NAME=""
JOBS_DIR="$TASK_DIR/jobs"
PREFLIGHT_ONLY=0
DETACH=0
AGENT_KWARGS=()
RUNTIME_DIR="${HARBOR_VLLM_RUNTIME_DIR:-/tmp/harbor-kv-qwen36-27b-${UID}}"

usage() {
  cat <<'EOF'
Usage: scripts/run-local-h100.sh [options]

The fixed Qwen3.6-27B TP2 vLLM on physical GPUs 6 and 7 must already be ready.
Start it separately with:

  scripts/host-vllm-qwen36-27b.sh start

Options:
  --runtime-dir PATH        External vLLM UDS/attestation directory
  --agent NAME              Harbor agent (default: oracle)
  --agent-model MODEL       Model passed to the Harbor agent
  --agent-kwarg KEY=VALUE   Repeatable Harbor agent kwarg
  --job-name NAME           Explicit Harbor job name
  --jobs-dir PATH           Job output directory
  --preflight-only          Validate external model/corpus/Compose only
  --detach                  Run as a user-systemd service
  -h, --help                Show this help
EOF
}

while (($#)); do
  case "$1" in
    --runtime-dir)
      RUNTIME_DIR="${2:?--runtime-dir requires a value}"
      shift 2
      ;;
    --agent)
      AGENT="${2:?--agent requires a value}"
      shift 2
      ;;
    --agent-model|--model)
      AGENT_MODEL="${2:?--agent-model requires a value}"
      shift 2
      ;;
    --agent-kwarg)
      AGENT_KWARGS+=("${2:?--agent-kwarg requires KEY=VALUE}")
      shift 2
      ;;
    --job-name)
      JOB_NAME="${2:?--job-name requires a value}"
      shift 2
      ;;
    --jobs-dir)
      JOBS_DIR="${2:?--jobs-dir requires a value}"
      shift 2
      ;;
    --preflight-only)
      PREFLIGHT_ONLY=1
      shift
      ;;
    --detach)
      DETACH=1
      shift
      ;;
    # Removed model-sidecar options fail explicitly instead of being ignored.
    --model-path|--model-profile|--compose-overlay|--gpu-indices|--allow-busy-gpus)
      echo "$1 belongs to the retired task-owned vLLM path; use scripts/host-vllm-qwen36-27b.sh" >&2
      exit 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

[[ "$RUNTIME_DIR" == /* ]] || { echo "--runtime-dir must be absolute" >&2; exit 2; }
export HARBOR_VLLM_RUNTIME_DIR="$RUNTIME_DIR"

real_agent_requested=0
if [[ "$AGENT" != oracle && "$AGENT" != nop ]]; then
  real_agent_requested=1
fi
if ((real_agent_requested)); then
  echo "run-local-h100.sh is author-only and permits only oracle/nop agents" >&2
  echo "use the frozen canonical GPT-5.6 Luna runner for any real agent" >&2
  exit 4
fi

if ((DETACH)) && [[ "${KV_TASK_DETACHED_CHILD:-0}" != 1 ]]; then
  command -v systemd-run >/dev/null 2>&1 || { echo "--detach requires systemd-run" >&2; exit 2; }
  unit_suffix="${JOB_NAME:-$(date -u +%Y%m%dT%H%M%SZ)}"
  unit_suffix="$(printf '%s' "$unit_suffix" | tr -c 'A-Za-z0-9_.-' '-')"
  unit_name="harbor-kv-${unit_suffix:0:120}"
  detached_command=("$0" --runtime-dir "$RUNTIME_DIR" --agent "$AGENT" --jobs-dir "$JOBS_DIR")
  [[ -n "$AGENT_MODEL" ]] && detached_command+=(--agent-model "$AGENT_MODEL")
  [[ -n "$JOB_NAME" ]] && detached_command+=(--job-name "$JOB_NAME")
  ((PREFLIGHT_ONLY)) && detached_command+=(--preflight-only)
  for value in "${AGENT_KWARGS[@]}"; do detached_command+=(--agent-kwarg "$value"); done
  systemd-run --user --unit "$unit_name" \
    --property "WorkingDirectory=$TASK_DIR" --property TimeoutStopSec=30 \
    --setenv KV_TASK_DETACHED_CHILD=1 --setenv "PATH=$PATH" \
    --setenv "HARBOR_VLLM_RUNTIME_DIR=$RUNTIME_DIR" \
    "${detached_command[@]}"
  echo "Detached Harbor service started: $unit_name"
  echo "Monitor with: systemctl --user status $unit_name"
  exit 0
fi

if ! docker info >/dev/null 2>&1; then
  [[ "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" != 1 ]] \
    || { echo "Docker remains unavailable after entering the docker group" >&2; exit 2; }
  user_name="$(id -un)"
  getent group docker | awk -F: -v user="$user_name" '
    BEGIN { found=1 }
    { n=split($4,a,","); for(i=1;i<=n;i++) if(a[i]==user) found=0 }
    END { exit found }
  ' || { echo "Docker is unavailable and $user_name is not listed in the docker group" >&2; exit 2; }
  command=(env KV_TASK_DOCKER_GROUP_REEXEC=1 "HARBOR_VLLM_RUNTIME_DIR=$RUNTIME_DIR" "$0" "${ORIGINAL_ARGUMENTS[@]}")
  command_string=""
  for argument in "${command[@]}"; do
    printf -v quoted '%q' "$argument"
    command_string+="${command_string:+ }$quoted"
  done
  exec sg docker -c "$command_string"
fi

# This is the only model gate in the Harbor wrapper. It validates the exact
# ready attestation, live tmux/container identity, image, process and UDS; it
# deliberately does not launch, restart, or inspect task-owned GPU services.
"$SCRIPT_DIR/host-vllm-qwen36-27b.sh" status >/dev/null || {
  echo "external Qwen3.6-27B TP2 on GPUs 6 and 7 is not ready; run scripts/host-vllm-qwen36-27b.sh start" >&2
  exit 4
}

export HARBOR_KVBENCH_STATE_ROOT="${HARBOR_KVBENCH_STATE_ROOT:-$HOME/.cache/harbor-kv-qwen36-public30}"
export HARBOR_SWEBENCH_CORPUS_SOURCE="${HARBOR_SWEBENCH_CORPUS_SOURCE:-$HOME/.cache/harbor-kv-scheduler-v2/swebench-lite}"
install -d -m 0755 "$HARBOR_KVBENCH_STATE_ROOT/workspaces"
if [[ ! -f "$HARBOR_SWEBENCH_CORPUS_SOURCE/manifest.json" ]]; then
  echo "pinned SWE-bench Lite corpus is not staged: $HARBOR_SWEBENCH_CORPUS_SOURCE/manifest.json" >&2
  echo "run scripts/stage-swebench-lite.sh first" >&2
  exit 4
fi
python3 "$SCRIPT_DIR/validate-staged-corpus.py" "$HARBOR_SWEBENCH_CORPUS_SOURCE/manifest.json" >/dev/null

docker compose --project-directory "$TASK_DIR/environment" \
  -f "$TASK_DIR/scripts/compose-main-base.yaml" \
  -f "$TASK_DIR/environment/docker-compose.yaml" config --quiet

if ((PREFLIGHT_ONLY)); then
  echo "External Qwen TP2 attestation, corpus, and Harbor Compose preflight passed."
  exit 0
fi

mkdir -p "$JOBS_DIR"
command=("$HARBOR_BIN" run --path "$TASK_DIR" --env docker --agent "$AGENT" --n-concurrent 1 --jobs-dir "$JOBS_DIR" --yes)
[[ -n "$AGENT_MODEL" ]] && command+=(--model "$AGENT_MODEL")
[[ -n "$JOB_NAME" ]] && command+=(--job-name "$JOB_NAME")
for value in "${AGENT_KWARGS[@]}"; do command+=(--agent-kwarg "$value"); done

echo "Starting Harbor against the already-attested external Qwen3.6-27B TP2 UDS."
env -u LD_AUDIT -u LD_PRELOAD -u LD_LIBRARY_PATH -u PYTHONHOME -u PYTHONPATH \
  -u PYTHONUSERBASE -u PYTHONSTARTUP -u PYTHONINSPECT -u PYTHONPLATLIBDIR \
  PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 exec "${command[@]}"
