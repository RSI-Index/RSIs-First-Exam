#!/usr/bin/env python3
"""Run one isolated direct-A / fresh-ThunderAgent-B author qualification pair."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import math
import os
import re
import secrets
import stat
import subprocess
import tempfile
import sys
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


sys.path.insert(0, str(Path(__file__).resolve().parent))
from evidence_contract import validate_finite_agent_execution_interval  # noqa: E402


TASK_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_ROOT = TASK_ROOT / "solution" / "reference_gateway"
STACK = TASK_ROOT / "scripts" / "calibration-stack.sh"
SCORING_POLICY = (
    TASK_ROOT
    / "environment"
    / "bench-controller"
    / "profiles"
    / "scoring-policy.json"
)
RELEASE_PUBLIC_SUITE = "public"
RELEASE_PUBLIC_PROFILE = "public-pressure-192"
RELEASE_ID = "qwen36-27b-tp2-public30-v7-r1"
PUBLIC_DIRECT_ANCHOR_KIND = "kvbench-release-public-direct-anchor"
REFERENCE_QUALIFICATION_ROLE = (
    "author public pair creates the reusable release Direct anchor; "
    "exploratory hidden ABBA is reference derivation only"
)
EXPECTED_ORACLE_SCHEDULER = {
    "algorithm": "thunderagent-program-aware-single-backend",
    # ``capacity_tokens`` is retained only to bind the gateway to the frozen
    # vLLM profile.  Qwen3.6's hybrid cache is not token-linear: all admission
    # and pause decisions below are made in physical KV allocation pages.
    "capacity_tokens": 1_887_738,
    "scheduler_interval_sec": 5.0,
    "acting_decay_base": 2.0,
    # Preserve ThunderAgent's generic decode headroom.  1,568 is the number of
    # attention tokens represented by one page, not a per-program buffer.
    "buffer_per_program": 100,
    "high_watermark": 1.0,
    "low_watermark": 1.0,
    # Schema v3 keeps resident state distinct from transient headroom and
    # reserves the two-page/group request-lifetime peak only while a program is
    # REASONING/request-pending.  Agent step_count is not vLLM allocator state:
    # even an initial request can reach the peak across engine iterations.
    "accounting_schema_version": 3,
    "accounting_mode": "qwen36-vllm024-hybrid-state-aware-pages",
    "decision_unit": "kv_pages",
    "decision_capacity": 1_252,
    "raw_gpu_blocks": 1_253,
    "reserved_null_blocks": 1,
    "capacity_pages": 1_252,
    "attention_page_tokens": 1_568,
    "mamba_group_count": 3,
    "mamba_peak_pages_per_group": 2,
    "mamba_resident_pages_per_group": 1,
    "fixed_mamba_pages_per_program": 3,
    "transient_mamba_pages_per_program": 3,
    "peak_mamba_pages_per_reasoning_program": 6,
    "mamba_initial_uncached_pages_per_program": 3,
    "mamba_reservation_scope": "request_lifetime_peak",
    "mamba_reservation_phase": "reasoning_or_request_pending",
    "mamba_reservation_uses_agent_step_count": False,
    "decision_pages_are_reservations": True,
    "acting_attention_decay_scope": "restore_only",
    "decode_headroom_tokens": 100,
    "reported_logical_capacity_tokens": 1_887_738,
    "reported_logical_capacity_is_informational": True,
}
EXPECTED_ORACLE_SCHEDULER_POLICY = {
    # The page-accounting schema remains v3.  This separate schema binds the
    # Harbor finite-cohort adapter and its deep upstream-style SJF tier without
    # misrepresenting either as vLLM allocator state.
    "scheduler_policy_schema_version": 4,
    "queue_policy": (
        "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5"
    ),
    "fair_service_lag_steps": 1,
    "fair_service_until_step": 12,
    "deep_request_first_step": 13,
    "protected_request_policy": "v4-exact-through-step-12",
    "deep_request_policy": (
        "total_tokens-sjf-with-service-lag-bypass-from-step-13"
    ),
    "service_lag_scope": (
        "protected-reentry-vs-feasible-blocked-request-ordinal"
    ),
    "service_lag_comparison": (
        "protected_reentry_ordinal>least_waiting_ordinal+lag"
    ),
    "normal_restore_order": (
        "aged-then-protected-request-ordinal-then-deep-total-tokens-"
        "then-idle-acting"
    ),
    "deep_restore_order": "total_tokens-then-request-wait-age-then-program-id",
    "deep_reentry_bypasses_service_lag": True,
    "fair_wait_threshold_sec": 220.0,
    "aged_resume_quota_per_tick": 4,
    "request_age_scope": "blocked_gateway_request_only",
    "aged_priority_scope": (
        "single-oldest-reservation-then-aged-quota-then-tiered-sjf"
    ),
    "aged_reservation_precedes_service_lag_order": True,
    "aged_reservation_owner_limit": 1,
    "aged_reservation_capacity_basis": "full_phase_aware_decision_units",
    "aged_reservation_victim_policy": (
        "active-idle-acting-shortest-context-first"
    ),
    "aged_reservation_blocks_younger_restore": True,
    "aged_reservation_blocks_conflicting_reentry": True,
    "aged_reservation_inflight_reasoning_policy": "never_pause",
}
EVIDENCE_ENVIRONMENT_KEYS = {
    "BACKEND_URL",
    "BASELINE_URL",
    "CANDIDATE_URL",
    "MODEL_API_URL",
    "PORT",
    "TRUSTED_MODEL_API_DATA_URL",
    "UPSTREAM_UNIX_SOCKET",
}
EXPECTED_CONTROLLER_ENDPOINTS = {
    "BASELINE_URL": "http://model-api:8100/v1",
    "TRUSTED_MODEL_API_DATA_URL": "http://model-api:8100/v1",
    "CANDIDATE_URL": "http://main:9000/v1",
    "MODEL_API_URL": "http://model-api:8100",
}
REMOTE_REQUEST = r"""
import json
import pathlib
import sys
import urllib.error
import urllib.request

method, path, raw_payload, timeout = sys.argv[1:]
token = pathlib.Path('/run/kvbench-admin/token').read_text().strip()
body = raw_payload.encode() if raw_payload else None
request = urllib.request.Request(
    'http://127.0.0.1:7000' + path,
    data=body,
    method=method,
    headers={
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
    },
)
try:
    with urllib.request.urlopen(request, timeout=int(timeout)) as response:
        sys.stdout.buffer.write(response.read())
except urllib.error.HTTPError as exc:
    sys.stderr.buffer.write(exc.read())
    raise
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _hex_text(value: Any, length: int) -> bool:
    return (
        isinstance(value, str)
        and re.fullmatch(rf"[0-9a-f]{{{length}}}", value) is not None
    )


def load_scoring_policy(path: Path = SCORING_POLICY) -> dict[str, Any]:
    payload = json.loads(path.read_text())
    if not isinstance(payload, dict):
        raise ValueError("scoring policy must be an object")
    return payload


def run(
    command: list[str],
    *,
    timeout: int = 300,
    extra_environment: dict[str, str] | None = None,
) -> str:
    environment = None
    if extra_environment is not None:
        environment = {**os.environ, **extra_environment}
    completed = subprocess.run(
        command,
        cwd=TASK_ROOT,
        env=environment,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        timeout=timeout,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"command failed ({completed.returncode}): {' '.join(command)}\n"
            + completed.stdout[-8000:]
        )
    return completed.stdout


def measurement_lock_path() -> Path:
    runtime = Path(
        os.environ.get(
            "HARBOR_VLLM_RUNTIME_DIR",
            f"/tmp/harbor-kv-qwen36-27b-{os.getuid()}",
        )
    )
    if not runtime.is_absolute():
        raise RuntimeError("HARBOR_VLLM_RUNTIME_DIR must be absolute")
    return runtime / "benchmark-measurement.lock"


@contextmanager
def host_measurement_lock(*, enabled: bool = True) -> Iterator[Path | None]:
    """Serialize measurements that share one attested host model runtime."""

    if not enabled:
        yield None
        return
    path = measurement_lock_path()
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    flags = os.O_CREAT | os.O_RDWR | os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags, 0o600)
    try:
        os.fchmod(descriptor, 0o600)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(
                f"host model measurement lock is already held: {path}"
            ) from exc
        yield path
    finally:
        os.close(descriptor)


def service_containers(project: str, service: str, *, running: bool) -> list[str]:
    command = [
        "docker",
        "ps",
        *( [] if running else ["--all"] ),
        "--filter",
        f"label=com.docker.compose.project={project}",
        "--filter",
        f"label=com.docker.compose.service={service}",
        "--format",
        "{{.ID}}",
    ]
    return [line for line in run(command, timeout=30).splitlines() if line]


def exactly_one_service(project: str, service: str, *, running: bool = True) -> str:
    containers = service_containers(project, service, running=running)
    if len(containers) != 1:
        state = "running" if running else "created"
        raise RuntimeError(
            f"expected exactly one {state} {project}/{service} container, got {containers}"
        )
    return containers[0]


def inspect_container(container: str) -> dict[str, Any]:
    raw = run(["docker", "inspect", container], timeout=30)
    payload = json.loads(raw)
    if not isinstance(payload, list) or len(payload) != 1:
        raise RuntimeError(f"invalid docker inspect result for {container}")
    item = payload[0]
    state = item.get("State") or {}
    config = item.get("Config") or {}
    environment: dict[str, str] = {}
    for entry in config.get("Env") or []:
        if not isinstance(entry, str) or "=" not in entry:
            continue
        name, value = entry.split("=", 1)
        if name in EVIDENCE_ENVIRONMENT_KEYS:
            environment[name] = value
    return {
        "id": item.get("Id"),
        "image_id": item.get("Image"),
        "created": item.get("Created"),
        "started_at": state.get("StartedAt"),
        "running": state.get("Running"),
        "pid": state.get("Pid"),
        "command": [config.get("Entrypoint"), config.get("Cmd")],
        "selected_environment": environment,
    }


def controller_request(
    container: str,
    method: str,
    path: str,
    payload: dict[str, Any] | None,
    *,
    timeout_sec: int,
) -> dict[str, Any]:
    encoded = "" if payload is None else json.dumps(payload, separators=(",", ":"))
    completed = subprocess.run(
        [
            "docker",
            "exec",
            container,
            "python3",
            "-c",
            REMOTE_REQUEST,
            method,
            path,
            encoded,
            str(timeout_sec),
        ],
        cwd=TASK_ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=timeout_sec + 60,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"controller {method} {path} failed: "
            + (completed.stderr or completed.stdout)[-8000:]
        )
    result = json.loads(completed.stdout)
    if not isinstance(result, dict):
        raise RuntimeError("controller response was not an object")
    return result


def gateway_health(container: str) -> dict[str, Any]:
    source = r"""
import sys
import urllib.request
with urllib.request.urlopen('http://127.0.0.1:9000/health', timeout=10) as response:
    sys.stdout.buffer.write(response.read())
"""
    payload = json.loads(
        run(["docker", "exec", container, "python3", "-c", source], timeout=30)
    )
    if not isinstance(payload, dict):
        raise RuntimeError("reference gateway health response was not an object")
    return payload


def controller_gateway_probe(controller: str) -> dict[str, Any]:
    source = r"""
import json
import urllib.error
import urllib.request
try:
    with urllib.request.urlopen('http://main:9000/health', timeout=3) as response:
        raw = response.read(1024 * 1024)
        print(json.dumps({
            'reachable': True,
            'status': response.status,
            'body': json.loads(raw),
            'error': None,
        }, separators=(',', ':'), sort_keys=True))
except Exception as exc:
    print(json.dumps({
        'reachable': False,
        'status': getattr(exc, 'code', None),
        'body': None,
        'error': type(exc).__name__ + ': ' + str(exc),
    }, separators=(',', ':'), sort_keys=True))
"""
    payload = json.loads(
        run(["docker", "exec", controller, "python3", "-c", source], timeout=30)
    )
    if not isinstance(payload, dict) or not isinstance(payload.get("reachable"), bool):
        raise RuntimeError("controller gateway probe returned an invalid result")
    return payload


def reference_gateway_tree_sha256(root: Path = REFERENCE_ROOT) -> str:
    records: list[bytes] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink() or (not path.is_dir() and not path.is_file()):
            raise RuntimeError(f"invalid Oracle tree entry: {relative.as_posix()}")
        if path.is_dir():
            continue
        payload = path.read_bytes()
        records.append(
            json.dumps(
                {
                    "path": relative.as_posix(),
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "size": len(payload),
                },
                separators=(",", ":"),
                sort_keys=True,
            ).encode()
        )
    if not records:
        raise RuntimeError("Oracle reference tree is empty")
    digest = hashlib.sha256(b"reference-gateway-tree-v1\n")
    for record in records:
        digest.update(record)
        digest.update(b"\n")
    return digest.hexdigest()


def atomic_write(path: Path, report: dict[str, Any], *, initial: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if initial and (path.exists() or path.is_symlink()):
        raise RuntimeError(f"refusing to overwrite pair evidence: {path}")
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w") as stream:
            json.dump(report, stream, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_object_sha256(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def public_anchor_output_path(
    value: Path | None,
    *,
    suite: str,
    profile: str,
    pair_output: Path,
) -> Path | None:
    """Validate the optional author-only release anchor destination.

    The artifact contains the raw workload nonce, so it must never be written
    below the Harbor task tree where an agent workspace or release bundle could
    pick it up accidentally.
    """

    if value is None:
        return None
    if suite != RELEASE_PUBLIC_SUITE or profile != RELEASE_PUBLIC_PROFILE:
        raise ValueError(
            "--public-anchor-output is valid only for "
            f"{RELEASE_PUBLIC_SUITE}/{RELEASE_PUBLIC_PROFILE}"
        )
    path = value.expanduser().resolve()
    task_root = TASK_ROOT.resolve()
    if path == task_root or path.is_relative_to(task_root):
        raise ValueError("--public-anchor-output must be outside the task tree")
    if path == pair_output:
        raise ValueError("pair evidence and public anchor outputs must be distinct")
    if path.exists() or path.is_symlink():
        raise ValueError(f"refusing to overwrite public Direct anchor: {path}")
    return path


def build_public_direct_anchor(
    *,
    report: dict[str, Any],
    workload_nonce: str,
    source_report_sha256: str,
    scoring_policy: dict[str, Any],
    scoring_policy_sha256: str,
) -> dict[str, Any]:
    """Project a successful public A/B report into the private Direct anchor."""

    if (
        report.get("status") != "complete"
        or report.get("passed") is not True
        or report.get("suite") != RELEASE_PUBLIC_SUITE
        or report.get("profile") != RELEASE_PUBLIC_PROFILE
        or (report.get("evaluation") or {}).get("passed") is not True
    ):
        raise ValueError("public Direct anchor requires a successful complete A/B report")
    if not isinstance(workload_nonce, str) or not workload_nonce:
        raise ValueError("public Direct anchor workload nonce is invalid")
    workload_nonce_sha256 = hashlib.sha256(workload_nonce.encode()).hexdigest()
    if report.get("workload_nonce_sha256") != workload_nonce_sha256:
        raise ValueError("public Direct anchor workload nonce commitment changed")
    if not _hex_text(source_report_sha256, 64):
        raise ValueError("public Direct anchor source report digest is invalid")
    if not _hex_text(scoring_policy_sha256, 64):
        raise ValueError("public Direct anchor scoring policy digest is invalid")
    if scoring_policy.get("release_id") != RELEASE_ID:
        raise ValueError("public Direct anchor scoring policy release ID is invalid")

    legs = report.get("legs") or {}
    baseline = legs.get("baseline")
    candidate = legs.get("candidate")
    if not isinstance(baseline, dict) or not isinstance(candidate, dict):
        raise ValueError("public Direct anchor source report is missing an A/B leg")
    baseline_run_id = baseline.get("run_id")
    controller_config_sha256 = baseline.get("controller_config_sha256")
    corpus_fingerprint = baseline.get("corpus_fingerprint")
    model_provenance = baseline.get("model_provenance")
    controller = report.get("controller") or {}
    controller_image_id = controller.get("image_id")
    if (
        baseline.get("mode") != "baseline"
        or candidate.get("mode") != "candidate"
        or not isinstance(baseline_run_id, str)
        or not baseline_run_id
        or baseline.get("release_id") != RELEASE_ID
        or candidate.get("release_id") != RELEASE_ID
        or baseline.get("profile") != RELEASE_PUBLIC_PROFILE
        or baseline.get("corpus_namespace")
        != f"{RELEASE_PUBLIC_SUITE}-{RELEASE_PUBLIC_PROFILE}"
        or baseline.get("workload_nonce_sha256") != workload_nonce_sha256
        or candidate.get("workload_nonce_sha256") != workload_nonce_sha256
        or not _hex_text(controller_config_sha256, 64)
        or candidate.get("controller_config_sha256") != controller_config_sha256
        or not _hex_text(corpus_fingerprint, 64)
        or candidate.get("corpus_fingerprint") != corpus_fingerprint
        or not isinstance(model_provenance, dict)
        or not model_provenance
        or candidate.get("model_provenance") != model_provenance
        or not isinstance(controller_image_id, str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", controller_image_id) is None
    ):
        raise ValueError("public Direct anchor source bindings are invalid")

    return {
        "schema_version": 1,
        "kind": PUBLIC_DIRECT_ANCHOR_KIND,
        "created_at_utc": utc_now(),
        "release_id": RELEASE_ID,
        "policy_release_id": RELEASE_ID,
        "suite": RELEASE_PUBLIC_SUITE,
        "profile": RELEASE_PUBLIC_PROFILE,
        "workload_nonce": workload_nonce,
        "workload_nonce_sha256": workload_nonce_sha256,
        "baseline_run_id": baseline_run_id,
        "baseline": baseline,
        "source_report_sha256": source_report_sha256,
        "scoring_policy_sha256": scoring_policy_sha256,
        "controller_config_sha256": controller_config_sha256,
        "controller_image_id": controller_image_id,
        "corpus_namespace": baseline["corpus_namespace"],
        "corpus_fingerprint": corpus_fingerprint,
        "model_provenance": model_provenance,
        "model_provenance_sha256": canonical_object_sha256(model_provenance),
    }


def atomic_create_private_json(path: Path, payload: dict[str, Any]) -> None:
    """Atomically create, but never replace, a mode-0600 JSON artifact."""

    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        try:
            # link(2) is an atomic create-if-absent operation.  Unlike
            # os.replace(), it cannot overwrite a pre-existing file or symlink
            # that appears between validation and publication.
            os.link(temporary, path, follow_symlinks=False)
        except FileExistsError as exc:
            raise RuntimeError(f"refusing to overwrite public Direct anchor: {path}") from exc
        published = path.lstat()
        if not stat.S_ISREG(published.st_mode) or stat.S_IMODE(published.st_mode) != 0o600:
            raise RuntimeError("published public Direct anchor is not a private regular file")
        directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)


def immutable_pair_checks(
    baseline: dict[str, Any],
    candidate: dict[str, Any],
    nonce_sha256: str,
    *,
    expected_profile: str,
    expected_corpus_namespace: str,
) -> dict[str, bool]:
    checks = {
        "leg_modes_are_direct_then_candidate": (
            baseline.get("mode") == "baseline" and candidate.get("mode") == "candidate"
        ),
        "workload_nonce_matches": (
            baseline.get("workload_nonce_sha256")
            == candidate.get("workload_nonce_sha256")
            == nonce_sha256
        ),
        "expected_profile": (
            baseline.get("profile")
            == candidate.get("profile")
            == expected_profile
        ),
        "expected_corpus_namespace": (
            baseline.get("corpus_namespace")
            == candidate.get("corpus_namespace")
            == expected_corpus_namespace
        ),
        "distinct_run_ids": (
            isinstance(baseline.get("run_id"), str)
            and isinstance(candidate.get("run_id"), str)
            and bool(baseline["run_id"])
            and bool(candidate["run_id"])
            and baseline["run_id"] != candidate["run_id"]
        ),
    }
    for key in (
        "profile",
        "profile_config",
        "corpus_namespace",
        "corpus_fingerprint",
        "model_adapter",
        "model_provenance",
        "release_id",
        "controller_config_sha256",
    ):
        checks[f"same_{key}"] = baseline.get(key) == candidate.get(key)
    return checks


def is_number(value: Any, *, minimum: float | None = None, maximum: float | None = None) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    number = float(value)
    if not math.isfinite(number):
        return False
    return not (
        (minimum is not None and number < minimum)
        or (maximum is not None and number > maximum)
    )


def is_nonnegative_integer(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def qwen_hybrid_page_contract(scheduler: dict[str, Any]) -> bool:
    """Bind evidence to the frozen physical-page accounting implementation."""

    if not all(
        scheduler.get(key) == expected
        for key, expected in EXPECTED_ORACLE_SCHEDULER.items()
    ):
        return False
    groups = scheduler["mamba_group_count"]
    peak_per_group = scheduler["mamba_peak_pages_per_group"]
    resident_per_group = scheduler["mamba_resident_pages_per_group"]
    steady = scheduler["fixed_mamba_pages_per_program"]
    transient = scheduler["transient_mamba_pages_per_program"]
    reasoning_peak = scheduler["peak_mamba_pages_per_reasoning_program"]
    return (
        0 < resident_per_group <= peak_per_group
        and steady == groups * resident_per_group
        and transient == groups * (peak_per_group - resident_per_group)
        and reasoning_peak == steady + transient == groups * peak_per_group
        and scheduler["mamba_initial_uncached_pages_per_program"] == steady
        and scheduler["mamba_reservation_uses_agent_step_count"] is False
        and scheduler["decision_pages_are_reservations"] is True
    )


def bounded_request_age_contract(scheduler: dict[str, Any]) -> bool:
    """Bind evidence to finite-cohort service-lag and tail adapters."""

    return all(
        scheduler.get(key) == expected
        for key, expected in EXPECTED_ORACLE_SCHEDULER_POLICY.items()
    )


def bounded_request_age_telemetry_sane(scheduler: dict[str, Any]) -> bool:
    """Validate service-lag/age gauges and exact counter partitions."""

    counters = scheduler.get("counters") or {}
    integer_fields = (
        "pending_request_waiters",
        "protected_pending_request_waiters",
        "deep_pending_request_waiters",
        "aged_request_waiters",
        "pending_request_waiters_peak",
        "protected_pending_request_waiters_peak",
        "deep_pending_request_waiters_peak",
        "aged_request_waiters_peak",
        "service_lag_blocked",
        "service_lag_blocked_peak",
        "aged_reservation_active",
        "aged_reservation_required_capacity",
        "aged_reservation_gap_capacity",
        "aged_reservation_active_peak",
        "aged_reservation_required_capacity_peak",
        "aged_reservation_gap_capacity_peak",
        "aged_rescue_post_commit_overflow_peak",
    )
    counter_fields = (
        "pause_admission",
        "pause_admission_new",
        "pause_admission_reentry",
        "pause_admission_aged_reservation",
        "pause_admission_service_lag",
        "protected_request_offers",
        "deep_request_offers",
        "deep_service_lag_bypass_decisions",
        "pause_acting",
        "pause_acting_pressure",
        "pause_acting_aged_reservation",
        "resume_pending",
        "resume_new",
        "resume_aged_pending",
        "resume_aged_new",
        "resume_aged_reservation_pending",
        "resume_aged_reservation_new",
        "resume_least_service_request",
        "resume_protected_request",
        "resume_deep_request",
        "least_service_priority_ticks",
        "deep_sjf_priority_ticks",
        "mixed_request_tier_ticks",
        "aged_priority_ticks",
        "aged_capacity_skip_count",
        "aged_no_fit_ticks",
        "aged_quota_exhausted_ticks",
        "aged_reservation_started",
        "aged_reservation_satisfied",
        "aged_reservation_cancelled",
        "aged_reservation_oversize",
        "aged_reservation_oversize_owner",
        "aged_reservation_partial_ticks",
        "aged_reservation_no_safe_victim_ticks",
        "aged_reservation_blocked_reentry",
        "aged_reservation_victims_paused",
        "aged_reservation_capacity_freed",
        "aged_reservation_post_commit_capacity_violations",
        "blocked_capacity_timeout",
    )
    if not all(
        is_nonnegative_integer(scheduler.get(key)) for key in integer_fields
    ) or not all(is_nonnegative_integer(counters.get(key)) for key in counter_fields):
        return False
    current_oldest = scheduler.get("oldest_pending_request_wait_sec")
    peak_oldest = scheduler.get("oldest_pending_request_wait_sec_peak")
    reservation_age = scheduler.get("aged_reservation_age_sec")
    reservation_age_peak = scheduler.get("aged_reservation_age_sec_peak")
    wait_latency_fields = (
        "pause_wait_total_sec",
        "pause_wait_max_sec",
        "protected_pause_wait_total_sec",
        "protected_pause_wait_max_sec",
        "deep_pause_wait_total_sec",
        "deep_pause_wait_max_sec",
    )
    if not (
        is_number(current_oldest, minimum=0.0)
        and is_number(peak_oldest, minimum=0.0)
        and is_number(reservation_age, minimum=0.0)
        and is_number(reservation_age_peak, minimum=0.0)
        and all(
            is_number(scheduler.get(key), minimum=0.0)
            for key in wait_latency_fields
        )
    ):
        return False

    pending = scheduler["pending_request_waiters"]
    protected_pending = scheduler["protected_pending_request_waiters"]
    deep_pending = scheduler["deep_pending_request_waiters"]
    aged = scheduler["aged_request_waiters"]
    pending_peak = scheduler["pending_request_waiters_peak"]
    protected_pending_peak = scheduler[
        "protected_pending_request_waiters_peak"
    ]
    deep_pending_peak = scheduler["deep_pending_request_waiters_peak"]
    aged_peak = scheduler["aged_request_waiters_peak"]
    paused = scheduler.get("paused")
    paused_peak = scheduler.get("paused_peak")
    service_lag_blocked = scheduler["service_lag_blocked"]
    service_lag_blocked_peak = scheduler["service_lag_blocked_peak"]
    pause_wait_count = scheduler.get("pause_wait_count")
    protected_pause_wait_count = scheduler.get(
        "protected_pause_wait_count"
    )
    deep_pause_wait_count = scheduler.get("deep_pause_wait_count")
    pause_wait_total = float(scheduler["pause_wait_total_sec"])
    protected_pause_wait_total = float(
        scheduler["protected_pause_wait_total_sec"]
    )
    deep_pause_wait_total = float(scheduler["deep_pause_wait_total_sec"])
    pause_wait_max = float(scheduler["pause_wait_max_sec"])
    protected_pause_wait_max = float(
        scheduler["protected_pause_wait_max_sec"]
    )
    deep_pause_wait_max = float(scheduler["deep_pause_wait_max_sec"])
    threshold = EXPECTED_ORACLE_SCHEDULER_POLICY["fair_wait_threshold_sec"]
    quota = EXPECTED_ORACLE_SCHEDULER_POLICY["aged_resume_quota_per_tick"]
    aged_resumes = counters["resume_aged_pending"] + counters["resume_aged_new"]
    reservation_resumes = (
        counters["resume_aged_reservation_pending"]
        + counters["resume_aged_reservation_new"]
    )
    reservation_active = scheduler["aged_reservation_active"]
    reservation_active_peak = scheduler["aged_reservation_active_peak"]
    reservation_required = scheduler["aged_reservation_required_capacity"]
    reservation_required_peak = scheduler[
        "aged_reservation_required_capacity_peak"
    ]
    reservation_gap = scheduler["aged_reservation_gap_capacity"]
    reservation_gap_peak = scheduler["aged_reservation_gap_capacity_peak"]
    return (
        is_nonnegative_integer(paused)
        and is_nonnegative_integer(paused_peak)
        and is_nonnegative_integer(pause_wait_count)
        and is_nonnegative_integer(protected_pause_wait_count)
        and is_nonnegative_integer(deep_pause_wait_count)
        and protected_pending + deep_pending == pending
        and protected_pending <= protected_pending_peak <= pending_peak
        and deep_pending <= deep_pending_peak <= pending_peak
        and pending_peak <= protected_pending_peak + deep_pending_peak
        and protected_pending_peak <= counters["protected_request_offers"]
        and deep_pending_peak <= counters["deep_request_offers"]
        and aged <= pending <= paused
        and aged_peak <= pending_peak <= paused_peak
        and service_lag_blocked <= protected_pending
        and service_lag_blocked <= service_lag_blocked_peak
        <= protected_pending_peak
        and pending <= pending_peak
        and aged <= aged_peak
        and float(peak_oldest) >= float(current_oldest)
        and (aged == 0 or float(current_oldest) >= threshold)
        and (aged_peak == 0 or float(peak_oldest) >= threshold)
        and counters["resume_aged_pending"] <= counters["resume_pending"]
        and counters["resume_aged_new"] <= counters["resume_new"]
        and counters["aged_no_fit_ticks"] <= counters["aged_priority_ticks"]
        and counters["aged_quota_exhausted_ticks"]
        <= counters["aged_priority_ticks"]
        and counters["aged_capacity_skip_count"]
        >= counters["aged_no_fit_ticks"]
        and aged_resumes <= counters["aged_priority_ticks"] * quota
        and reservation_active in {0, 1}
        and reservation_active <= reservation_active_peak <= 1
        and reservation_required <= reservation_required_peak
        and reservation_gap <= reservation_gap_peak
        and float(reservation_age_peak) >= float(reservation_age)
        and (
            reservation_active == 0
            or (
                reservation_required > 0
                and float(reservation_age) >= threshold
            )
        )
        and (
            reservation_active_peak == 0
            or (
                reservation_required_peak > 0
                and float(reservation_age_peak) >= threshold
            )
        )
        and counters["pause_admission"]
        == counters["pause_admission_new"]
        + counters["pause_admission_reentry"]
        and counters["pause_admission_aged_reservation"]
        == counters["aged_reservation_blocked_reentry"]
        and counters["pause_admission_aged_reservation"]
        <= counters["pause_admission_reentry"]
        and counters["pause_admission_service_lag"]
        <= counters["pause_admission_reentry"]
        and counters["deep_service_lag_bypass_decisions"]
        <= counters["deep_request_offers"]
        and (
            counters["pause_admission_service_lag"] == 0
            or service_lag_blocked_peak > 0
        )
        and counters["resume_least_service_request"]
        <= counters["resume_protected_request"]
        and counters["resume_protected_request"]
        + counters["resume_deep_request"]
        == counters["resume_pending"] + counters["resume_new"]
        and counters["resume_deep_request"] <= counters["resume_pending"]
        and counters["resume_new"] <= counters["resume_protected_request"]
        and counters["resume_protected_request"]
        <= counters["protected_request_offers"]
        and counters["resume_deep_request"] <= counters["deep_request_offers"]
        and counters["least_service_priority_ticks"]
        <= scheduler["scheduler_ticks"]
        and counters["deep_sjf_priority_ticks"] <= scheduler["scheduler_ticks"]
        and counters["mixed_request_tier_ticks"] <= scheduler["scheduler_ticks"]
        and (
            counters["resume_least_service_request"] == 0
            or counters["least_service_priority_ticks"] > 0
        )
        and counters["pause_acting"]
        == counters["pause_acting_pressure"]
        + counters["pause_acting_aged_reservation"]
        and counters["pause_acting_aged_reservation"]
        == counters["aged_reservation_victims_paused"]
        and counters["aged_reservation_capacity_freed"]
        >= counters["aged_reservation_victims_paused"]
        and counters["aged_reservation_started"]
        == counters["aged_reservation_satisfied"]
        + counters["aged_reservation_cancelled"]
        + counters["aged_reservation_oversize_owner"]
        + reservation_active
        and counters["aged_reservation_satisfied"] == reservation_resumes
        and counters["resume_aged_reservation_pending"]
        <= counters["resume_aged_pending"]
        and counters["resume_aged_reservation_new"]
        <= counters["resume_aged_new"]
        and counters["aged_reservation_partial_ticks"]
        <= counters["aged_no_fit_ticks"]
        and counters["aged_reservation_no_safe_victim_ticks"]
        <= counters["aged_no_fit_ticks"]
        and counters["aged_reservation_post_commit_capacity_violations"] == 0
        and scheduler["aged_rescue_post_commit_overflow_peak"] == 0
        and (
            counters["aged_reservation_started"] == 0
            or reservation_active_peak == 1
        )
        and (
            counters["aged_priority_ticks"] == 0
            or counters["aged_reservation_started"] > 0
            or counters["aged_reservation_oversize"] > 0
        )
        and (
            counters["aged_priority_ticks"] == 0
            or (aged_peak > 0 and float(peak_oldest) >= threshold)
        )
        and (pause_wait_count == 0 or pending_peak > 0)
        and pause_wait_count
        == protected_pause_wait_count + deep_pause_wait_count
        and protected_pause_wait_count
        <= counters["protected_request_offers"]
        and deep_pause_wait_count <= counters["deep_request_offers"]
        and abs(
            pause_wait_total
            - protected_pause_wait_total
            - deep_pause_wait_total
        )
        <= 0.000002
        and abs(
            pause_wait_max
            - max(protected_pause_wait_max, deep_pause_wait_max)
        )
        <= 0.000001
        and (
            counters["deep_request_offers"] > 0
            or (
                deep_pending_peak == 0
                and deep_pause_wait_count == 0
                and counters["deep_service_lag_bypass_decisions"] == 0
                and counters["resume_deep_request"] == 0
                and counters["deep_sjf_priority_ticks"] == 0
                and counters["mixed_request_tier_ticks"] == 0
            )
        )
        and (
            aged_resumes == 0
            or (
                counters["aged_priority_ticks"] > 0
                and aged_peak > 0
                and float(peak_oldest) >= threshold
            )
        )
    )


def deep_tier_activation_contract(
    scheduler: dict[str, Any], *, windowed: bool
) -> bool:
    """Require tier telemetry to match the frozen 24-step workload."""

    counters = scheduler.get("counters") or {}
    deep_signals = {
        "offers": counters.get("deep_request_offers"),
        "waiters_peak": scheduler.get("deep_pending_request_waiters_peak"),
        "wait_count": scheduler.get("deep_pause_wait_count"),
        "lag_bypass": counters.get("deep_service_lag_bypass_decisions"),
        "resumes": counters.get("resume_deep_request"),
        "sjf_ticks": counters.get("deep_sjf_priority_ticks"),
        "mixed_ticks": counters.get("mixed_request_tier_ticks"),
    }
    if not all(is_nonnegative_integer(value) for value in deep_signals.values()):
        return False
    if windowed:
        # The 30-minute window lets real trajectories cross step 13. Require
        # both sides of the protected/deep cutover instead of preserving the
        # obsolete 10-minute assumption that every deep signal stays zero.
        return all(value > 0 for value in deep_signals.values())
    return (
        deep_signals["offers"] > 0
        and deep_signals["waiters_peak"] > 0
        and deep_signals["wait_count"] > 0
        and deep_signals["lag_bypass"] > 0
        and deep_signals["resumes"] > 0
        and deep_signals["sjf_ticks"] > 0
    )


def qwen_page_telemetry_sane(scheduler: dict[str, Any]) -> bool:
    """Validate persistent page telemetry without trusting token-linear aliases."""

    page_fields = (
        "tracked_pages_full",
        "tracked_pages_with_decay",
        "tracked_attention_pages_full",
        "tracked_attention_pages_with_decay",
        "tracked_fixed_mamba_pages",
        "tracked_reserved_transient_mamba_pages",
        "reasoning_peak_reserved_programs",
        "capacity_overflow_pages",
        "first_pause_tracked_pages_full",
        "first_pause_overflow_pages",
        "first_pause_attention_pages_full",
        "first_pause_fixed_mamba_pages",
        "first_pause_reserved_transient_mamba_pages",
        "first_pause_reasoning_peak_reserved_programs",
        "tracked_pages_full_peak",
        "tracked_pages_with_decay_peak",
        "tracked_attention_pages_full_peak",
        "tracked_attention_pages_with_decay_peak",
        "tracked_fixed_mamba_pages_peak",
        "tracked_reserved_transient_mamba_pages_peak",
        "reasoning_peak_reserved_programs_peak",
    )
    if not all(is_nonnegative_integer(scheduler.get(key)) for key in page_fields):
        return False
    active = scheduler.get("active")
    reasoning = scheduler.get("reasoning")
    active_peak = scheduler.get("active_peak")
    first_pause_active = scheduler.get("first_pause_active")
    if not all(
        is_nonnegative_integer(value)
        for value in (active, reasoning, active_peak, first_pause_active)
    ):
        return False

    capacity = EXPECTED_ORACLE_SCHEDULER["capacity_pages"]
    fixed_per_program = EXPECTED_ORACLE_SCHEDULER[
        "fixed_mamba_pages_per_program"
    ]
    transient_per_program = EXPECTED_ORACLE_SCHEDULER[
        "transient_mamba_pages_per_program"
    ]
    full = scheduler["tracked_pages_full"]
    decayed = scheduler["tracked_pages_with_decay"]
    attention_full = scheduler["tracked_attention_pages_full"]
    attention_decayed = scheduler["tracked_attention_pages_with_decay"]
    fixed = scheduler["tracked_fixed_mamba_pages"]
    transient = scheduler["tracked_reserved_transient_mamba_pages"]
    reserved_programs = scheduler["reasoning_peak_reserved_programs"]
    overflow = scheduler["capacity_overflow_pages"]
    first_full = scheduler["first_pause_tracked_pages_full"]
    first_overflow = scheduler["first_pause_overflow_pages"]
    first_attention = scheduler["first_pause_attention_pages_full"]
    first_fixed = scheduler["first_pause_fixed_mamba_pages"]
    first_transient = scheduler[
        "first_pause_reserved_transient_mamba_pages"
    ]
    first_reserved_programs = scheduler[
        "first_pause_reasoning_peak_reserved_programs"
    ]
    full_peak = scheduler["tracked_pages_full_peak"]
    decayed_peak = scheduler["tracked_pages_with_decay_peak"]
    attention_full_peak = scheduler["tracked_attention_pages_full_peak"]
    attention_decayed_peak = scheduler[
        "tracked_attention_pages_with_decay_peak"
    ]
    fixed_peak = scheduler["tracked_fixed_mamba_pages_peak"]
    transient_peak = scheduler[
        "tracked_reserved_transient_mamba_pages_peak"
    ]
    reserved_programs_peak = scheduler[
        "reasoning_peak_reserved_programs_peak"
    ]

    return (
        # Current gauges describe one self-consistent reservation.  Resident
        # Mamba state is charged to every active program; request-lifetime
        # transient headroom is charged to every active REASONING/pending one.
        full == attention_full + fixed + transient
        and decayed == attention_decayed + fixed + transient
        and decayed <= full
        and fixed == active * fixed_per_program
        and reserved_programs == reasoning
        and transient == reserved_programs * transient_per_program
        and overflow == max(0, full - capacity)
        # The first persisted pause must be attributable to real page overflow.
        and first_pause_active > 0
        and first_reserved_programs > 0
        and first_reserved_programs <= first_pause_active
        and first_full == first_attention + first_fixed + first_transient
        and first_fixed == first_pause_active * fixed_per_program
        and first_transient
        == first_reserved_programs * transient_per_program
        and first_full > capacity
        and first_overflow == first_full - capacity
        # Peaks are persistent witnesses: separate component maxima need not
        # occur on the same observation, hence the bounding (not equality)
        # checks for their sums.
        and full_peak >= first_full
        and decayed_peak <= full_peak
        and attention_full_peak >= first_attention
        and attention_decayed_peak <= attention_full_peak
        and fixed_peak == active_peak * fixed_per_program
        and fixed_peak >= first_fixed
        and reserved_programs_peak >= first_reserved_programs
        and reserved_programs_peak <= active_peak
        and transient_peak
        == reserved_programs_peak * transient_per_program
        and transient_peak >= first_transient
        and max(attention_full_peak, fixed_peak, transient_peak) <= full_peak
        and full_peak
        <= attention_full_peak + fixed_peak + transient_peak
        and max(attention_decayed_peak, fixed_peak, transient_peak)
        <= decayed_peak
        and decayed_peak
        <= attention_decayed_peak + fixed_peak + transient_peak
    )


def leg_schema_checks(leg: dict[str, Any], label: str) -> dict[str, bool]:
    profile = leg.get("profile_config")
    live = ((leg.get("vllm_metrics") or {}).get("live_series") or {})
    string_fields = (
        "run_id",
        "profile",
        "corpus_namespace",
        "corpus_fingerprint",
        "release_id",
        "controller_config_sha256",
        "workload_nonce_sha256",
    )
    checks = {
        f"{label}_schema_version": is_number(leg.get("schema_version"), minimum=1),
        f"{label}_identity_strings_present": all(
            isinstance(leg.get(key), str) and bool(leg[key]) for key in string_fields
        ),
        f"{label}_identity_digests_well_formed": all(
            isinstance(leg.get(key), str)
            and re.fullmatch(r"[0-9a-f]{64}", leg[key]) is not None
            for key in (
                "corpus_fingerprint",
                "controller_config_sha256",
                "workload_nonce_sha256",
            )
        ),
        f"{label}_profile_config_present": (
            isinstance(profile, dict)
            and isinstance(profile.get("workflows"), int)
            and not isinstance(profile.get("workflows"), bool)
            and profile["workflows"] > 0
            and isinstance(profile.get("warmup_requests"), int)
            and not isinstance(profile.get("warmup_requests"), bool)
            and profile["warmup_requests"] >= 0
        ),
        f"{label}_model_adapter_present": (
            isinstance(leg.get("model_adapter"), dict) and bool(leg["model_adapter"])
        ),
        f"{label}_model_provenance_present": (
            isinstance(leg.get("model_provenance"), dict)
            and bool(leg["model_provenance"])
        ),
        f"{label}_audits_present": (
            isinstance(leg.get("backend_audit"), dict)
            and isinstance(leg.get("warmup_audit"), dict)
        ),
        f"{label}_request_count_positive": (
            isinstance(leg.get("request_count"), int)
            and not isinstance(leg.get("request_count"), bool)
            and leg["request_count"] > 0
        ),
        f"{label}_rates_and_ratios_present": (
            is_number(leg.get("valid_steps_per_min"), minimum=0.0)
            and is_number(leg.get("valid_step_ratio"), minimum=0.0, maximum=1.0)
            and is_number(leg.get("backend_tokens_per_valid_step"), minimum=0.0)
            and is_number(leg.get("request_success_rate"), minimum=0.0, maximum=1.0)
        ),
        f"{label}_quality_counts_present": all(
            is_nonnegative_integer(leg.get(key))
            for key in (
                "valid_steps",
                "minimum_workflow_progress",
                "tests_passed_workflows",
                "completed_workflows",
            )
        ),
        f"{label}_pressure_present": isinstance(leg.get("pressure_validation"), dict),
        f"{label}_metrics_sampler_present": (
            isinstance(live.get("sampler_error_count"), int)
            and not isinstance(live.get("sampler_error_count"), bool)
        ),
    }
    return checks


def audit_checks(leg: dict[str, Any], label: str) -> dict[str, bool]:
    backend_audit = leg.get("backend_audit") or {}
    return {
        f"{label}_no_infrastructure_failure": leg.get("infrastructure_failure") is None,
        f"{label}_no_candidate_failure": leg.get("candidate_failure") is None,
        f"{label}_backend_audit": backend_audit.get("passed") is True,
        f"{label}_gateway_wait_metrics_present": all(
            is_number(backend_audit.get(key), minimum=0.0)
            for key in (
                "p95_gateway_wait_sec",
                "p99_gateway_wait_sec",
                "max_gateway_wait_sec",
            )
        ),
        f"{label}_warmup_audit": (leg.get("warmup_audit") or {}).get("passed") is True,
        f"{label}_request_success": leg.get("request_success_rate") == 1.0,
        f"{label}_metrics_sampler": (
            ((leg.get("vllm_metrics") or {}).get("live_series") or {}).get(
                "sampler_error_count"
            )
            == 0
        ),
    }


def agent_execution_interval_contract(
    leg: dict[str, Any], *, windowed: bool
) -> bool:
    """Bind finite throughput to agent execution, excluding verify/cleanup."""

    measurement_window = leg.get("measurement_window") or {}
    if windowed:
        return (
            "agent_execution_interval" not in leg
            and measurement_window.get("configured") is True
        )
    try:
        validate_finite_agent_execution_interval(
            leg,
            "reference pair finite agent execution interval",
            require_live_samples=True,
        )
    except ValueError:
        return False
    return True


def evaluate_pair(
    baseline: dict[str, Any],
    candidate: dict[str, Any],
    *,
    nonce_sha256: str,
    minimum_speedup: float,
    gateway_after: dict[str, Any],
    expected_profile: str,
    expected_corpus_namespace: str,
    expected_tree_sha256: str,
    scoring_policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    policy = scoring_policy if scoring_policy is not None else load_scoring_policy()
    maximum_gateway_wait = policy.get("max_p99_gateway_wait_sec")
    if not is_number(maximum_gateway_wait, minimum=0.0):
        raise ValueError("scoring policy max_p99_gateway_wait_sec is invalid")
    maximum_p99_step_ratio = policy.get("max_p99_step_latency_ratio")
    if (
        not is_number(maximum_p99_step_ratio)
        or float(maximum_p99_step_ratio) <= 1.0
    ):
        raise ValueError("scoring policy max_p99_step_latency_ratio is invalid")
    base_rate = float(baseline.get("valid_steps_per_min") or 0.0)
    candidate_rate = float(candidate.get("valid_steps_per_min") or 0.0)
    speedup = candidate_rate / base_rate if base_rate > 0 else 0.0
    lifecycle = candidate.get("program_lifecycle") or {}
    warmup_lifecycle = lifecycle.get("warmup") or {}
    profile = candidate.get("profile_config") or {}
    windowed = isinstance(profile.get("measurement_window_sec"), int)
    finite_progress_floor = int(profile.get("max_steps") or 0)
    measured_expected = int(profile.get("workflows") or 0)
    warmup_expected = int(profile.get("warmup_requests") or 0)
    scheduler_after = gateway_after.get("scheduler") or {}
    counters = scheduler_after.get("counters") or {}
    expected_releases = measured_expected + warmup_expected
    expected_concurrency = int(profile.get("concurrency") or 0)
    baseline_request_count = int(baseline.get("request_count") or 0)
    candidate_request_count = int(candidate.get("request_count") or 0)
    request_count_ratio = (
        candidate_request_count / baseline_request_count
        if baseline_request_count > 0
        else 0.0
    )
    pause_decisions = sum(
        int(counters.get(key) or 0)
        for key in ("pause_admission", "pause_acting", "mark_reasoning")
    )
    split_admission_decisions = sum(
        int(counters.get(key) or 0)
        for key in ("pause_admission_new", "pause_admission_reentry")
    )
    resume_decisions = sum(
        int(counters.get(key) or 0)
        for key in ("resume_pending", "resume_new", "resume_acting")
    )
    first_pause_elapsed = scheduler_after.get("first_pause_elapsed_sec")
    first_resume_elapsed = scheduler_after.get("first_resume_elapsed_sec")
    first_pause_active = scheduler_after.get("first_pause_active")
    first_pause_reason = scheduler_after.get("first_pause_reason")
    programs_peak = scheduler_after.get("programs_peak")
    active_peak = scheduler_after.get("active_peak")
    paused_peak = scheduler_after.get("paused_peak")
    marked_for_pause_peak = scheduler_after.get("marked_for_pause_peak")
    pause_wait_count = scheduler_after.get("pause_wait_count")
    pause_wait_total = scheduler_after.get("pause_wait_total_sec")
    pause_wait_max = scheduler_after.get("pause_wait_max_sec")
    scheduler_ticks = scheduler_after.get("scheduler_ticks")
    timing_telemetry_sane = (
        is_number(first_pause_elapsed, minimum=0.0)
        and isinstance(first_pause_reason, str)
        and first_pause_reason
        in {"admission_capacity", "acting_pressure", "marked_reasoning_pressure"}
        and is_nonnegative_integer(first_pause_active)
        and first_pause_active > 0
        and is_number(first_resume_elapsed, minimum=float(first_pause_elapsed))
        and is_nonnegative_integer(active_peak)
        and active_peak >= first_pause_active
        and is_nonnegative_integer(programs_peak)
        and programs_peak >= active_peak
        and is_nonnegative_integer(paused_peak)
        and paused_peak > 0
        and paused_peak <= programs_peak
        and is_nonnegative_integer(marked_for_pause_peak)
        and is_nonnegative_integer(pause_wait_count)
        and pause_wait_count > 0
        and is_number(pause_wait_total, minimum=0.0)
        and is_number(pause_wait_max, minimum=0.0)
        and float(pause_wait_total) >= float(pause_wait_max)
        and is_nonnegative_integer(scheduler_ticks)
        and scheduler_ticks > 0
    )
    page_telemetry_sane = qwen_page_telemetry_sane(scheduler_after)
    age_telemetry_sane = bounded_request_age_telemetry_sane(scheduler_after)
    deep_tier_matches_shape = deep_tier_activation_contract(
        scheduler_after, windowed=windowed
    )
    telemetry_complete_and_sane = (
        timing_telemetry_sane
        and page_telemetry_sane
        and age_telemetry_sane
    )

    contracts = {
        **leg_schema_checks(baseline, "baseline"),
        **leg_schema_checks(candidate, "candidate"),
        **immutable_pair_checks(
            baseline,
            candidate,
            nonce_sha256,
            expected_profile=expected_profile,
            expected_corpus_namespace=expected_corpus_namespace,
        ),
        **audit_checks(baseline, "baseline"),
        **audit_checks(candidate, "candidate"),
        "baseline_pressure_qualified": (
            (baseline.get("pressure_validation") or {}).get("valid") is True
        ),
        "candidate_lifecycle_enabled": lifecycle.get("enabled") is True,
        "candidate_measured_release_complete": (
            lifecycle.get("measured_attempted") == measured_expected
            and lifecycle.get("measured_acknowledged") == measured_expected
            and lifecycle.get("measured_unsupported") == 0
            and lifecycle.get("measured_failed") == 0
        ),
        "candidate_warmup_release_complete": (
            warmup_lifecycle.get("program_release_attempted") == warmup_expected
            and warmup_lifecycle.get("program_release_acknowledged") == warmup_expected
            and warmup_lifecycle.get("program_release_failed") == 0
        ),
        "gateway_working_set_released": (
            scheduler_after.get("programs") == 0
            and scheduler_after.get("active") == 0
            and scheduler_after.get("reasoning") == 0
            and scheduler_after.get("acting") == 0
            and scheduler_after.get("paused") == 0
            and scheduler_after.get("marked_for_pause") == 0
            and scheduler_after.get("terminating") == 0
            and scheduler_after.get("tracked_tokens_full") == 0.0
            and scheduler_after.get("tracked_tokens_with_decay") == 0.0
            and scheduler_after.get("tracked_pages_full") == 0
            and scheduler_after.get("tracked_pages_with_decay") == 0
            and scheduler_after.get("tracked_attention_pages_full") == 0
            and scheduler_after.get("tracked_attention_pages_with_decay") == 0
            and scheduler_after.get("tracked_fixed_mamba_pages") == 0
            and scheduler_after.get("tracked_reserved_transient_mamba_pages")
            == 0
            and scheduler_after.get("reasoning_peak_reserved_programs") == 0
            and scheduler_after.get("capacity_overflow_pages") == 0
            and scheduler_after.get("pending_request_waiters") == 0
            and scheduler_after.get("protected_pending_request_waiters") == 0
            and scheduler_after.get("deep_pending_request_waiters") == 0
            and scheduler_after.get("aged_request_waiters") == 0
            and scheduler_after.get("oldest_pending_request_wait_sec") == 0.0
            and scheduler_after.get("aged_reservation_active") == 0
            and scheduler_after.get("aged_reservation_required_capacity") == 0
            and scheduler_after.get("aged_reservation_gap_capacity") == 0
            and scheduler_after.get("aged_reservation_age_sec") == 0.0
            and scheduler_after.get("service_lag_blocked") == 0
        ),
        "gateway_tree_matches_pair_evidence": (
            gateway_after.get("reference_gateway_tree_sha256_at_start")
            == expected_tree_sha256
        ),
        "oracle_release_counter_binds_all_programs": (
            counters.get("release") == expected_releases
            and counters.get("release_deferred") == 0
        ),
        "oracle_registered_full_agent_concurrency": (
            expected_concurrency > 0
            and isinstance(scheduler_after.get("programs_peak"), int)
            and not isinstance(scheduler_after.get("programs_peak"), bool)
            and scheduler_after["programs_peak"] >= expected_concurrency
        ),
        "oracle_scheduler_task_alive": (
            scheduler_after.get("scheduler_task_alive") is True
        ),
        "oracle_scheduler_error_free": (
            counters.get("scheduler_errors") == 0
            and scheduler_after.get("last_scheduler_error") is None
        ),
        "oracle_qwen_hybrid_page_accounting_contract": (
            qwen_hybrid_page_contract(scheduler_after)
        ),
        "oracle_bounded_request_age_policy_contract": (
            bounded_request_age_contract(scheduler_after)
        ),
        "oracle_page_telemetry_complete_and_sane": page_telemetry_sane,
        "oracle_bounded_request_age_telemetry_complete_and_sane": (
            age_telemetry_sane
        ),
        "oracle_deep_tier_matches_measurement_shape": deep_tier_matches_shape,
        "oracle_scheduler_telemetry_complete_and_sane": (
            telemetry_complete_and_sane
        ),
        # Warmup and measured programs share one intentionally persistent
        # scheduler.  The first pause must therefore observe more active
        # programs than the entire warmup could register; otherwise counters
        # alone could misattribute a warmup-only decision to the measured leg.
        "oracle_first_pause_belongs_to_measured_workload": (
            telemetry_complete_and_sane
            and first_pause_active > warmup_expected
        ),
        "request_count_within_five_percent": (
            windowed or 0.95 <= request_count_ratio <= 1.05
        ),
        "fixed_window_contract_complete": (
            not windowed
            or all(
                isinstance(leg.get("measurement_window"), dict)
                and leg["measurement_window"].get("duration_sec")
                == profile["measurement_window_sec"]
                and leg["measurement_window"].get("deadline_reached") is True
                and leg["measurement_window"].get("passed") is True
                for leg in (baseline, candidate)
            )
        ),
        "baseline_agent_execution_interval_contract": (
            agent_execution_interval_contract(baseline, windowed=windowed)
        ),
        "candidate_agent_execution_interval_contract": (
            agent_execution_interval_contract(candidate, windowed=windowed)
        ),
        "finite_pair_p99_step_latency_metrics_present": (
            windowed
            or (
                is_number(baseline.get("p99_step_latency_sec"), minimum=0.0)
                and float(baseline["p99_step_latency_sec"]) > 0.0
                and is_number(candidate.get("p99_step_latency_sec"), minimum=0.0)
                and float(candidate["p99_step_latency_sec"]) > 0.0
            )
        ),
        "oracle_scheduling_was_triggered": pause_decisions > 0,
        "oracle_admission_counter_partition_is_exact": (
            counters.get("pause_admission") == split_admission_decisions
        ),
        "oracle_reentry_capacity_check_was_triggered": (
            int(counters.get("pause_admission_reentry") or 0) > 0
        ),
        "oracle_service_lag_was_triggered": (
            int(counters.get("pause_admission_service_lag") or 0) > 0
            and int(counters.get("least_service_priority_ticks") or 0) > 0
            and int(counters.get("resume_least_service_request") or 0) > 0
            and int(scheduler_after.get("service_lag_blocked_peak") or 0) > 0
        ),
        "oracle_restore_was_triggered": resume_decisions > 0,
        "oracle_did_not_force_resume": counters.get("force_resume") == 0,
        "oracle_had_no_blocked_capacity_timeout": (
            counters.get("blocked_capacity_timeout") == 0
        ),
    }

    base_valid_ratio = float(baseline.get("valid_step_ratio") or 0.0)
    candidate_valid_ratio = float(candidate.get("valid_step_ratio") or 0.0)
    base_tokens_per_step = float(baseline.get("backend_tokens_per_valid_step") or 0.0)
    candidate_tokens_per_step = float(candidate.get("backend_tokens_per_valid_step") or 0.0)
    backend_work_ratio = (
        candidate_tokens_per_step / base_tokens_per_step
        if base_tokens_per_step > 0
        else 0.0
    )
    candidate_p99_gateway_wait = float(
        ((candidate.get("backend_audit") or {}).get("p99_gateway_wait_sec"))
        or 0.0
    )
    p99_step_values_valid = (
        is_number(baseline.get("p99_step_latency_sec"), minimum=0.0)
        and float(baseline["p99_step_latency_sec"]) > 0.0
        and is_number(candidate.get("p99_step_latency_sec"), minimum=0.0)
        and float(candidate["p99_step_latency_sec"]) > 0.0
    )
    baseline_p99_step = (
        float(baseline["p99_step_latency_sec"]) if p99_step_values_valid else None
    )
    candidate_p99_step = (
        float(candidate["p99_step_latency_sec"]) if p99_step_values_valid else None
    )
    position_paired_p99_step_ratio = (
        candidate_p99_step / baseline_p99_step
        if baseline_p99_step is not None and candidate_p99_step is not None
        else None
    )
    finite_tail_evaluated = not windowed
    finite_tail_passed = (
        p99_step_values_valid
        and position_paired_p99_step_ratio is not None
        and position_paired_p99_step_ratio <= float(maximum_p99_step_ratio)
    )
    tail_anti_gaming = {
        "schema_version": 1,
        "metric": "p99_step_latency_sec",
        "pairing": "candidate_over_baseline:B/A",
        "evaluated": finite_tail_evaluated,
        "skip_reason": None if finite_tail_evaluated else "fixed-window-censored",
        "baseline_p99_step_latency_sec": (
            [baseline_p99_step] if finite_tail_evaluated else None
        ),
        "candidate_p99_step_latency_sec": (
            [candidate_p99_step] if finite_tail_evaluated else None
        ),
        "position_paired_ratios": (
            [position_paired_p99_step_ratio] if finite_tail_evaluated else None
        ),
        "max_position_paired_ratio": (
            position_paired_p99_step_ratio if finite_tail_evaluated else None
        ),
        "maximum_allowed_ratio": (
            float(maximum_p99_step_ratio) if finite_tail_evaluated else None
        ),
        "diagnostic_max_candidate_over_max_baseline_ratio": (
            position_paired_p99_step_ratio if finite_tail_evaluated else None
        ),
        "passed": finite_tail_passed if finite_tail_evaluated else True,
    }
    quality = {
        "baseline_absolute_quality": (
            base_valid_ratio >= 0.90
            and (
                (
                    float(
                        (baseline.get("measurement_window") or {}).get(
                            "zero_progress_fraction", 1.0
                        )
                    )
                    <= 0.05
                )
                if windowed
                else (
                    finite_progress_floor > 0
                    and int(baseline.get("minimum_workflow_progress") or 0)
                    >= finite_progress_floor
                    and int(baseline.get("tests_passed_workflows") or 0) >= 1
                    # A healthy max-step mini-SWE run ends LimitsExceeded, not
                    # Submitted.  Completion is therefore allowed to be zero.
                    and int(baseline.get("completed_workflows") or 0) >= 0
                )
            )
        ),
        "candidate_absolute_quality": (
            candidate_valid_ratio >= 0.90
            and (
                float(
                    (candidate.get("measurement_window") or {}).get(
                        "zero_progress_fraction", 1.0
                    )
                )
                <= 0.05
                if windowed
                else (
                    finite_progress_floor > 0
                    and int(candidate.get("minimum_workflow_progress") or 0)
                    >= finite_progress_floor
                )
            )
        ),
        "valid_step_ratio_no_material_regression": (
            candidate_valid_ratio + 0.002 >= base_valid_ratio
        ),
        "minimum_progress_preserved": (
            windowed
            or int(candidate.get("minimum_workflow_progress") or 0)
            >= int(baseline.get("minimum_workflow_progress") or 0)
        ),
        "tests_passed_preserved": (
            windowed
            or int(candidate.get("tests_passed_workflows") or 0)
            >= int(baseline.get("tests_passed_workflows") or 0)
        ),
        "completed_workflows_preserved": (
            windowed
            or int(candidate.get("completed_workflows") or 0)
            >= int(baseline.get("completed_workflows") or 0)
        ),
        "backend_work_per_step_not_inflated": (
            windowed or (base_tokens_per_step > 0 and backend_work_ratio <= 1.02)
        ),
        "backend_work_per_step_not_deflated": windowed or backend_work_ratio >= 0.85,
        "candidate_p99_gateway_wait_bounded": (
            0.0 <= candidate_p99_gateway_wait <= float(maximum_gateway_wait)
        ),
        "finite_position_paired_p99_step_latency_bounded": (
            tail_anti_gaming["passed"]
        ),
    }
    effect = {
        "baseline_valid_steps_per_min": base_rate,
        "candidate_valid_steps_per_min": candidate_rate,
        "speedup": speedup,
        "minimum_speedup": minimum_speedup,
        "passed": speedup > minimum_speedup,
    }
    return {
        "passed": all(contracts.values()) and all(quality.values()) and effect["passed"],
        "contracts_passed": all(contracts.values()),
        "quality_passed": all(quality.values()),
        "contracts": contracts,
        "quality": quality,
        "tail_anti_gaming": tail_anti_gaming,
        "effect": effect,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--suite", choices=("public", "calibration", "hidden"), default="calibration"
    )
    parser.add_argument("--profile", required=True)
    parser.add_argument(
        "--project",
        choices=("kvbench-qwen36-public30",),
        default="kvbench-qwen36-public30",
        help="fixed author calibration project",
    )
    parser.add_argument("--request-timeout-sec", type=int, default=14400)
    parser.add_argument("--minimum-speedup", type=float, default=1.0)
    parser.add_argument("--workload-nonce")
    parser.add_argument(
        "--no-lock",
        action="store_true",
        help=(
            "skip the host measurement flock only when an enclosing author "
            "runner already holds the same runtime-bound lock"
        ),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--public-anchor-output",
        type=Path,
        help=(
            "atomically create the private release Direct anchor after a "
            "successful public/public-pressure-192 A/B run"
        ),
    )
    return parser.parse_args()


def validate_workload_nonce(value: str) -> str:
    """Reject malformed custom nonces before any controller/GPU operation."""

    if re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError("--workload-nonce must be exactly 64 lowercase hex characters")
    return value


def run_pair(args: argparse.Namespace) -> int:
    if not 300 <= args.request_timeout_sec <= 21600:
        raise ValueError("--request-timeout-sec must be in 300..21600")
    if args.minimum_speedup < 1.0:
        raise ValueError("--minimum-speedup must be at least 1.0")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.profile):
        raise ValueError("--profile contains unsafe characters")

    output = args.output.expanduser().resolve()
    anchor_output = public_anchor_output_path(
        args.public_anchor_output,
        suite=args.suite,
        profile=args.profile,
        pair_output=output,
    )
    nonce = validate_workload_nonce(args.workload_nonce or secrets.token_hex(32))
    nonce_sha256 = hashlib.sha256(nonce.encode()).hexdigest()
    scoring_policy_bytes = SCORING_POLICY.read_bytes()
    scoring_policy = json.loads(scoring_policy_bytes)
    if not isinstance(scoring_policy, dict):
        raise ValueError("scoring policy must be an object")
    scoring_policy_sha256 = hashlib.sha256(scoring_policy_bytes).hexdigest()
    controller = exactly_one_service(args.project, "bench-controller")
    controller_identity = inspect_container(controller)
    controller_environment = controller_identity["selected_environment"]
    if any(
        controller_environment.get(key) != value
        for key, value in EXPECTED_CONTROLLER_ENDPOINTS.items()
    ):
        raise RuntimeError(
            f"controller data-plane endpoints are not frozen: {controller_environment}"
        )
    model_api = exactly_one_service(args.project, "model-api")
    model_api_identity = inspect_container(model_api)
    if (
        model_api_identity["selected_environment"].get("UPSTREAM_UNIX_SOCKET")
        != "/run/kvbench-vllm/vllm.sock"
    ):
        raise RuntimeError("model-api is not bound to the frozen UDS path")
    readiness = controller_request(
        controller, "GET", "/admin/readiness", None, timeout_sec=60
    )
    required = ("model_api", "infrastructure_attested", "real_swebench_workload")
    missing = [key for key in required if readiness.get(key) is not True]
    if missing:
        raise RuntimeError(f"controller readiness missing {missing}: {readiness}")

    initial_tree_sha256 = reference_gateway_tree_sha256()
    report: dict[str, Any] = {
        "schema_version": 1,
        "kind": "isolated-reference-thunderagent-pair",
        "qualification_role": REFERENCE_QUALIFICATION_ROLE,
        "status": "running",
        "passed": False,
        "started_at_utc": utc_now(),
        "completed_at_utc": None,
        "suite": args.suite,
        "profile": args.profile,
        "order": ["direct_baseline", "fresh_thunderagent_oracle"],
        "workload_nonce_sha256": nonce_sha256,
        "reference_gateway_tree_sha256": initial_tree_sha256,
        "thunderagent_source_commit": "7ddc8610270e56d3b109eed8796b3a4360fc67c9",
        "controller": controller_identity,
        "model_api": model_api_identity,
        "controller_readiness": readiness,
        "lifecycle": {},
        "legs": {},
        "evaluation": None,
        "errors": [],
    }
    atomic_write(output, report, initial=True)
    print(f"pair evidence: {output}", flush=True)

    try:
        main_before = exactly_one_service(args.project, "main", running=False)
        report["lifecycle"]["main_before_stop"] = inspect_container(main_before)
        run([str(STACK), "stop-oracle"], timeout=180)
        if service_containers(args.project, "main", running=True):
            raise RuntimeError("author gateway remained running during direct baseline leg")
        closed_probe_before = controller_gateway_probe(controller)
        if closed_probe_before["reachable"] is not False:
            raise RuntimeError(
                f"main:9000 remained reachable before direct leg: {closed_probe_before}"
            )
        report["lifecycle"]["direct_leg_gateway_running"] = False
        report["lifecycle"]["direct_leg_gateway_probe_before"] = closed_probe_before
        atomic_write(output, report)

        print(f"START A/direct {args.profile} {utc_now()}", flush=True)
        response = controller_request(
            controller,
            "POST",
            "/admin/run",
            {
                "suite": args.suite,
                "profile": args.profile,
                "mode": "baseline",
                "workload_nonce": nonce,
            },
            timeout_sec=args.request_timeout_sec,
        )
        baseline = response.get("result")
        if not isinstance(baseline, dict):
            raise RuntimeError(f"baseline response has no result: {response}")
        report["legs"]["baseline"] = baseline
        closed_probe_after = controller_gateway_probe(controller)
        if closed_probe_after["reachable"] is not False:
            raise RuntimeError(
                f"main:9000 became reachable during direct leg: {closed_probe_after}"
            )
        if inspect_container(controller)["id"] != controller_identity["id"]:
            raise RuntimeError("controller identity changed during direct leg")
        if inspect_container(model_api)["id"] != model_api_identity["id"]:
            raise RuntimeError("model-api identity changed during direct leg")
        report["lifecycle"]["direct_leg_gateway_probe_after"] = closed_probe_after
        report["lifecycle"]["controller_after_baseline"] = inspect_container(controller)
        report["lifecycle"]["model_api_after_baseline"] = inspect_container(model_api)
        atomic_write(output, report)

        print(f"START B/ThunderAgent {args.profile} {utc_now()}", flush=True)
        tree_before_candidate = reference_gateway_tree_sha256()
        if tree_before_candidate != initial_tree_sha256:
            raise RuntimeError("Oracle reference tree changed before candidate leg")
        run([str(STACK), "restart-oracle"], timeout=300)
        fresh_main = exactly_one_service(args.project, "main")
        main_before_candidate = inspect_container(fresh_main)
        if main_before_candidate["id"] == report["lifecycle"]["main_before_stop"]["id"]:
            raise RuntimeError("candidate leg did not receive a fresh-recreated main container")
        main_environment = main_before_candidate["selected_environment"]
        if (
            main_environment.get("BACKEND_URL") != "http://127.0.0.1:8100/v1"
            or main_environment.get("PORT") != "9000"
        ):
            raise RuntimeError(f"fresh Oracle endpoints are not frozen: {main_environment}")
        health_before = gateway_health(fresh_main)
        scheduler_before = health_before.get("scheduler") or {}
        transport_before = health_before.get("transport") or {}
        scheduler_contract = {
            key: scheduler_before.get(key) == expected
            for key, expected in {
                **EXPECTED_ORACLE_SCHEDULER,
                **EXPECTED_ORACLE_SCHEDULER_POLICY,
            }.items()
        }
        fresh_page_gauges_zero = all(
            scheduler_before.get(key) == 0
            for key in (
                "tracked_pages_full",
                "tracked_pages_with_decay",
                "tracked_attention_pages_full",
                "tracked_attention_pages_with_decay",
                "tracked_fixed_mamba_pages",
                "tracked_reserved_transient_mamba_pages",
                "reasoning_peak_reserved_programs",
                "capacity_overflow_pages",
                "tracked_pages_full_peak",
                "tracked_pages_with_decay_peak",
                "tracked_attention_pages_full_peak",
                "tracked_attention_pages_with_decay_peak",
                "tracked_fixed_mamba_pages_peak",
                "tracked_reserved_transient_mamba_pages_peak",
                "reasoning_peak_reserved_programs_peak",
                "pending_request_waiters",
                "protected_pending_request_waiters",
                "deep_pending_request_waiters",
                "aged_request_waiters",
                "oldest_pending_request_wait_sec",
                "pending_request_waiters_peak",
                "protected_pending_request_waiters_peak",
                "deep_pending_request_waiters_peak",
                "aged_request_waiters_peak",
                "oldest_pending_request_wait_sec_peak",
                "service_lag_blocked",
                "service_lag_blocked_peak",
                "pause_wait_count",
                "pause_wait_total_sec",
                "pause_wait_max_sec",
                "protected_pause_wait_count",
                "protected_pause_wait_total_sec",
                "protected_pause_wait_max_sec",
                "deep_pause_wait_count",
                "deep_pause_wait_total_sec",
                "deep_pause_wait_max_sec",
            )
        )
        if (
            health_before.get("oracle") != "thunderagent-extracted"
            or health_before.get("thunderagent_source_commit")
            != report["thunderagent_source_commit"]
            or scheduler_before.get("programs") != 0
            or scheduler_before.get("programs_peak") != 0
            or scheduler_before.get("scheduler_task_alive") is not True
            or any((scheduler_before.get("counters") or {}).values())
            or health_before.get("reference_gateway_tree_sha256_at_start")
            != initial_tree_sha256
            or transport_before.get("max_inflight") != 192
            or transport_before.get("inbound_auto_decompress") is not False
            or transport_before.get("handler_cancellation") is not True
            or not all(scheduler_contract.values())
            or not fresh_page_gauges_zero
        ):
            raise RuntimeError(f"fresh Oracle preflight failed: {health_before}")
        report["lifecycle"]["main_before_candidate"] = main_before_candidate
        reachable_probe = controller_gateway_probe(controller)
        if (
            reachable_probe.get("reachable") is not True
            or (reachable_probe.get("body") or {}).get("oracle")
            != "thunderagent-extracted"
            or (reachable_probe.get("body") or {}).get(
                "reference_gateway_tree_sha256_at_start"
            )
            != initial_tree_sha256
        ):
            raise RuntimeError(
                f"controller cannot reach the fresh Oracle identity: {reachable_probe}"
            )
        report["lifecycle"]["controller_gateway_probe_before_candidate"] = (
            reachable_probe
        )
        report["lifecycle"]["gateway_health_before_candidate"] = health_before
        report["lifecycle"]["scheduler_contract"] = scheduler_contract
        report["lifecycle"]["fresh_page_gauges_zero"] = fresh_page_gauges_zero
        atomic_write(output, report)

        response = controller_request(
            controller,
            "POST",
            "/admin/run",
            {
                "suite": args.suite,
                "profile": args.profile,
                "mode": "candidate",
                "workload_nonce": nonce,
            },
            timeout_sec=args.request_timeout_sec,
        )
        candidate = response.get("result")
        if not isinstance(candidate, dict):
            raise RuntimeError(f"candidate response has no result: {response}")
        report["legs"]["candidate"] = candidate
        current_main = exactly_one_service(args.project, "main")
        main_after_candidate = inspect_container(current_main)
        if main_after_candidate["id"] != main_before_candidate["id"]:
            raise RuntimeError("Oracle container identity changed during candidate leg")
        health_after = gateway_health(current_main)
        tree_after_candidate = reference_gateway_tree_sha256()
        if tree_after_candidate != initial_tree_sha256:
            raise RuntimeError("Oracle reference tree changed during candidate leg")
        if inspect_container(controller)["id"] != controller_identity["id"]:
            raise RuntimeError("controller identity changed during candidate leg")
        if inspect_container(model_api)["id"] != model_api_identity["id"]:
            raise RuntimeError("model-api identity changed during candidate leg")
        report["lifecycle"]["main_after_candidate"] = main_after_candidate
        report["lifecycle"]["gateway_health_after_candidate"] = health_after
        report["lifecycle"]["reference_gateway_tree_sha256_before_candidate"] = (
            tree_before_candidate
        )
        report["lifecycle"]["reference_gateway_tree_sha256_after_candidate"] = (
            tree_after_candidate
        )
        report["lifecycle"]["controller_after_candidate"] = inspect_container(controller)
        report["lifecycle"]["model_api_after_candidate"] = inspect_container(model_api)
        report["evaluation"] = evaluate_pair(
            baseline,
            candidate,
            nonce_sha256=nonce_sha256,
            minimum_speedup=args.minimum_speedup,
            gateway_after=health_after,
            expected_profile=args.profile,
            expected_corpus_namespace=f"{args.suite}-{args.profile}",
            expected_tree_sha256=initial_tree_sha256,
            scoring_policy=scoring_policy,
        )
        report["passed"] = report["evaluation"]["passed"]
        report["status"] = "complete"
        report["completed_at_utc"] = utc_now()
        atomic_write(output, report)
        if anchor_output is not None:
            if report["passed"] is not True:
                raise RuntimeError(
                    "refusing to create public Direct anchor from a failed A/B pair"
                )
            if SCORING_POLICY.read_bytes() != scoring_policy_bytes:
                raise RuntimeError("scoring policy changed during the public A/B pair")
            source_report_sha256 = sha256_file(output)
            anchor = build_public_direct_anchor(
                report=report,
                workload_nonce=nonce,
                source_report_sha256=source_report_sha256,
                scoring_policy=scoring_policy,
                scoring_policy_sha256=scoring_policy_sha256,
            )
            atomic_create_private_json(anchor_output, anchor)
        print(
            json.dumps(report["evaluation"]["effect"], separators=(",", ":")),
            flush=True,
        )
        print(f"COMPLETE {output} passed={report['passed']}", flush=True)
        return 0 if report["passed"] else 1
    except Exception as exc:
        report["status"] = "failed"
        report["completed_at_utc"] = utc_now()
        report["errors"].append(f"{type(exc).__name__}: {exc}")
        atomic_write(output, report)
        raise


def main() -> int:
    args = parse_args()
    with host_measurement_lock(enabled=not args.no_lock):
        return run_pair(args)


if __name__ == "__main__":
    raise SystemExit(main())
