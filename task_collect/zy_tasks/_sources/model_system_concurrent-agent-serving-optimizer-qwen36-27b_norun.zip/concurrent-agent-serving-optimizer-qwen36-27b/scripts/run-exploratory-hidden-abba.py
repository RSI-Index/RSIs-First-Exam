#!/usr/bin/env python3
"""Run author-only pre-freeze hidden Direct/Oracle/Oracle/Direct evidence.

This runner is intentionally separate from the release verifier.  It is usable
only while ``release_ready`` is false and its private output is never eligible
as final release evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import secrets
import shutil
import statistics
import sys
import tempfile
import time
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
PAIR_RUNNER_PATH = TASK_ROOT / "scripts" / "run-reference-pair.py"
STACK = TASK_ROOT / "scripts" / "calibration-stack.sh"
REFERENCE_ROOT = TASK_ROOT / "solution" / "reference_gateway"
HIDDEN_PROFILES = TASK_ROOT / "environment" / "bench-controller" / "profiles" / "hidden.json"
SCORING_POLICY = (
    TASK_ROOT / "environment" / "bench-controller" / "profiles" / "scoring-policy.json"
)
PROJECT = "kvbench-qwen36-public30"
LEG_PLAN = (
    ("A1", "baseline", "direct"),
    ("B1", "candidate", "oracle"),
    ("B2", "candidate", "oracle"),
    ("A2", "baseline", "direct"),
)
IDENTITY_FIELDS = (
    "profile",
    "profile_config",
    "corpus_namespace",
    "corpus_fingerprint",
    "model_adapter",
    "model_provenance",
    "release_id",
    "controller_config_sha256",
    "workload_nonce_sha256",
)
MODEL_API_ADMIN_REQUEST = r"""
import json
import pathlib
import sys
import urllib.error
import urllib.request

method, path, raw_payload, timeout = sys.argv[1:]
token = pathlib.Path('/run/kvbench-admin/token').read_text().strip()
body = raw_payload.encode() if raw_payload else None
request = urllib.request.Request(
    'http://model-api:8100' + path,
    data=body,
    method=method,
    headers={
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
    },
)
try:
    with urllib.request.urlopen(request, timeout=int(timeout)) as response:
        status = response.status
        raw = response.read()
except urllib.error.HTTPError as exc:
    status = exc.code
    raw = exc.read()
try:
    payload = json.loads(raw) if raw else {}
except json.JSONDecodeError:
    payload = {'raw_body': raw.decode(errors='replace')}
print(json.dumps({'status': status, 'payload': payload}, separators=(',', ':'), sort_keys=True))
"""


def load_pair_runner() -> Any:
    spec = importlib.util.spec_from_file_location("kvbench_reference_pair", PAIR_RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("could not load run-reference-pair.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


PAIR = load_pair_runner()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometric_mean(values: list[float]) -> float:
    if not values or any(value <= 0 for value in values):
        return 0.0
    return math.exp(sum(math.log(value) for value in values) / len(values))


def coefficient_of_variation(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = statistics.fmean(values)
    return statistics.pstdev(values) / mean if mean else math.inf


def canonical_digest(value: Any) -> str:
    encoded = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def load_closed_hidden_contract(profile_name: str) -> tuple[dict[str, Any], dict[str, Any]]:
    policy = json.loads(SCORING_POLICY.read_text())
    profiles_payload = json.loads(HIDDEN_PROFILES.read_text())
    profiles = profiles_payload.get("profiles")
    if not isinstance(profiles, dict):
        raise RuntimeError("hidden profile file is malformed")
    enabled = [
        name
        for name, profile in profiles.items()
        if isinstance(profile, dict) and profile.get("enabled") is True
    ]
    if enabled != [profile_name]:
        raise RuntimeError(
            f"exploratory ABBA requires the sole enabled hidden profile {profile_name!r}; "
            f"observed {enabled}"
        )
    policy_profiles = policy.get("hidden_profiles")
    if not isinstance(policy_profiles, list) or [
        item.get("name") for item in policy_profiles if isinstance(item, dict)
    ] != [profile_name]:
        raise RuntimeError("scoring policy does not bind exactly the selected hidden profile")
    if policy.get("release_ready") is not False:
        raise RuntimeError(
            "exploratory hidden ABBA is pre-freeze only and refuses release_ready=true"
        )
    return policy, profiles[profile_name]


def validate_output_path(raw: Path) -> Path:
    output = raw.expanduser().resolve()
    if output == TASK_ROOT or TASK_ROOT in output.parents:
        raise ValueError(
            "private hidden ABBA output must be outside the task tree; use a private /tmp "
            "or author evidence directory"
        )
    if output.exists() or output.is_symlink():
        raise RuntimeError(f"refusing to overwrite hidden ABBA evidence: {output}")
    return output


def copy_immutable_snapshot(source: Path, destination: Path) -> dict[str, Any]:
    if destination.exists() or destination.is_symlink():
        raise RuntimeError(f"snapshot destination already exists: {destination}")
    source_before = PAIR.reference_gateway_tree_sha256(source)
    shutil.copytree(
        source,
        destination,
        copy_function=shutil.copy2,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
    )
    source_after = PAIR.reference_gateway_tree_sha256(source)
    snapshot_digest = PAIR.reference_gateway_tree_sha256(destination)
    if not source_before == source_after == snapshot_digest:
        raise RuntimeError("Oracle source changed while the immutable snapshot was copied")

    entries = list(destination.rglob("*"))
    if any(
        "__pycache__" in path.relative_to(destination).parts
        or path.suffix in {".pyc", ".pyo"}
        for path in entries
    ):
        raise RuntimeError("Oracle snapshot copied runtime bytecode caches")
    for path in entries:
        if path.is_symlink():
            raise RuntimeError(f"Oracle snapshot contains a symlink: {path}")
        if path.is_file():
            executable = bool(path.stat().st_mode & 0o111)
            path.chmod(0o555 if executable else 0o444)
    for path in sorted(
        (entry for entry in entries if entry.is_dir()),
        key=lambda item: len(item.parts),
        reverse=True,
    ):
        path.chmod(0o555)
    destination.chmod(0o555)

    immutable = all(
        path.stat().st_mode & 0o222 == 0
        for path in [destination, *destination.rglob("*")]
    )
    if not immutable:
        raise RuntimeError("Oracle snapshot retained writable entries")
    return {
        "schema_version": 1,
        "source_tree_sha256_before_copy": source_before,
        "source_tree_sha256_after_copy": source_after,
        "snapshot_tree_sha256": snapshot_digest,
        "file_count": sum(path.is_file() for path in entries),
        "directory_count": 1 + sum(path.is_dir() for path in entries),
        "all_entries_nonwritable": immutable,
        "runtime_bytecode_caches_excluded": True,
        "docker_mount_read_only_required": True,
    }


def stack_action(action: str, snapshot: Path, *, timeout: int) -> str:
    return PAIR.run(
        [str(STACK), action],
        timeout=timeout,
        extra_environment={"KV_AUTHOR_REFERENCE_GATEWAY_DIR": str(snapshot)},
    )


def model_api_admin_request(
    controller: str,
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    *,
    timeout_sec: int = 60,
) -> dict[str, Any]:
    encoded = "" if payload is None else json.dumps(payload, separators=(",", ":"))
    raw = PAIR.run(
        [
            "docker",
            "exec",
            controller,
            "python3",
            "-c",
            MODEL_API_ADMIN_REQUEST,
            method,
            path,
            encoded,
            str(timeout_sec),
        ],
        timeout=timeout_sec + 30,
    )
    response = json.loads(raw)
    if (
        not isinstance(response, dict)
        or not isinstance(response.get("status"), int)
        or not isinstance(response.get("payload"), dict)
    ):
        raise RuntimeError(f"invalid model-api admin response: {response}")
    return response


def reset_model_boundary(
    controller: str,
    label: str,
    *,
    timeout_sec: int = 180,
) -> dict[str, Any]:
    started = time.monotonic()
    deadline = started + timeout_sec
    attempts = 0
    before: dict[str, Any] | None = None
    while time.monotonic() < deadline:
        attempts += 1
        response = model_api_admin_request(
            controller, "GET", "/admin/quiescent", timeout_sec=30
        )
        before = response
        if response["status"] == 200 and response["payload"].get("quiescent") is True:
            break
        time.sleep(1.0)
    else:
        raise RuntimeError(f"model-api did not quiesce at {label}: {before}")

    reset = model_api_admin_request(
        controller, "POST", "/admin/measurement/reset", timeout_sec=60
    )
    after = model_api_admin_request(
        controller, "GET", "/admin/quiescent", timeout_sec=30
    )
    audit = model_api_admin_request(
        controller, "GET", "/admin/audit/snapshot", timeout_sec=30
    )
    reset_payload = reset["payload"]
    audit_epoch = reset_payload.get("audit_epoch")
    checks = {
        "quiescent_before_reset": (
            before is not None
            and before["status"] == 200
            and before["payload"].get("quiescent") is True
        ),
        "atomic_reset_succeeded": (
            reset["status"] == 200 and reset_payload.get("reset") is True
        ),
        "prefix_cache_cleared": reset_payload.get("kv_cache_usage") == 0.0,
        "audit_epoch_valid": (
            isinstance(audit_epoch, int)
            and not isinstance(audit_epoch, bool)
            and audit_epoch >= 0
        ),
        "quiescent_after_reset": (
            after["status"] == 200 and after["payload"].get("quiescent") is True
        ),
        "audit_epoch_matches_reset": (
            audit["status"] == 200
            and audit["payload"].get("audit_epoch") == audit_epoch
        ),
        "audit_is_empty": (
            audit["status"] == 200
            and audit["payload"].get("count") == 0
            and audit["payload"].get("records") == []
        ),
    }
    record = {
        "schema_version": 1,
        "label": label,
        "completed_at_utc": PAIR.utc_now(),
        "wait_attempts": attempts,
        "elapsed_sec": time.monotonic() - started,
        "quiescent_before": before,
        "measurement_reset": reset,
        "quiescent_after": after,
        "audit_after": audit,
        "checks": checks,
        "passed": all(checks.values()),
    }
    if not record["passed"]:
        raise RuntimeError(f"model-api reset boundary failed at {label}: {checks}")
    return record


def reference_mount(container: str, snapshot: Path) -> dict[str, Any]:
    payload = json.loads(PAIR.run(["docker", "inspect", container], timeout=30))
    if not isinstance(payload, list) or len(payload) != 1:
        raise RuntimeError(f"invalid docker inspect response for {container}")
    mounts = [
        mount
        for mount in payload[0].get("Mounts") or []
        if isinstance(mount, dict) and mount.get("Destination") == "/opt/reference-gateway"
    ]
    if len(mounts) != 1:
        raise RuntimeError(f"Oracle container has invalid reference mounts: {mounts}")
    mount = mounts[0]
    source = Path(str(mount.get("Source", ""))).resolve()
    record = {
        "type": mount.get("Type"),
        "source_matches_snapshot": source == snapshot.resolve(),
        "destination": mount.get("Destination"),
        "read_only": mount.get("RW") is False,
        "propagation": mount.get("Propagation"),
    }
    if not (
        record["type"] == "bind"
        and record["source_matches_snapshot"]
        and record["destination"] == "/opt/reference-gateway"
        and record["read_only"]
    ):
        raise RuntimeError(f"Oracle snapshot mount is not immutable: {record}")
    return record


def gateway_absent(project: str, controller: str, label: str) -> dict[str, Any]:
    running = PAIR.service_containers(project, "main", running=True)
    probe = PAIR.controller_gateway_probe(controller)
    record = {
        "label": label,
        "running_main_containers": running,
        "controller_gateway_probe": probe,
        "passed": not running and probe.get("reachable") is False,
    }
    if not record["passed"]:
        raise RuntimeError(f"Direct leg gateway was not absent at {label}: {record}")
    return record


def start_fresh_oracle(
    *,
    project: str,
    controller: str,
    snapshot: Path,
    snapshot_digest: str,
    label: str,
    previous_identity_digest: str | None,
) -> dict[str, Any]:
    if PAIR.reference_gateway_tree_sha256(snapshot) != snapshot_digest:
        raise RuntimeError(f"Oracle snapshot changed before {label}")
    stack_action("restart-oracle", snapshot, timeout=300)
    container = PAIR.exactly_one_service(project, "main")
    identity = PAIR.inspect_container(container)
    environment = identity["selected_environment"]
    mount = reference_mount(container, snapshot)
    health = PAIR.gateway_health(container)
    probe = PAIR.controller_gateway_probe(controller)
    process_identity_digest = canonical_digest(
        {
            "container_id": identity.get("id"),
            "pid": identity.get("pid"),
            "started_at": identity.get("started_at"),
        }
    )
    checks = {
        "container_running": identity.get("running") is True,
        "fresh_process_identity": (
            previous_identity_digest is None
            or process_identity_digest != previous_identity_digest
        ),
        "frozen_backend_endpoint": (
            environment.get("BACKEND_URL") == "http://127.0.0.1:8100/v1"
            and environment.get("PORT") == "9000"
        ),
        "immutable_snapshot_mount": (
            mount["source_matches_snapshot"] and mount["read_only"]
        ),
        "snapshot_digest_at_gateway_start": (
            health.get("reference_gateway_tree_sha256_at_start") == snapshot_digest
        ),
        "gateway_reachable_from_controller": (
            probe.get("reachable") is True and probe.get("status") == 200
        ),
        "snapshot_still_immutable": (
            PAIR.reference_gateway_tree_sha256(snapshot) == snapshot_digest
        ),
    }
    record = {
        "label": label,
        "container": identity,
        "process_identity_sha256": process_identity_digest,
        "mount": mount,
        "gateway_health_before": health,
        "controller_gateway_probe": probe,
        "checks": checks,
        "passed": all(checks.values()),
    }
    if not record["passed"]:
        raise RuntimeError(f"fresh Oracle lifecycle failed for {label}: {checks}")
    return record


def run_leg(
    controller: str,
    *,
    profile: str,
    mode: str,
    nonce: str,
    timeout_sec: int,
) -> dict[str, Any]:
    response = PAIR.controller_request(
        controller,
        "POST",
        "/admin/run",
        {
            "suite": "hidden",
            "profile": profile,
            "mode": mode,
            "workload_nonce": nonce,
        },
        timeout_sec=timeout_sec,
    )
    result = response.get("result")
    if not isinstance(result, dict):
        raise RuntimeError(f"hidden {mode} response has no result: {response}")
    if result.get("mode") != mode:
        raise RuntimeError(f"hidden leg returned the wrong mode: {result.get('mode')}")
    return result


def summarize_audits(legs: list[dict[str, Any]]) -> dict[str, Any]:
    per_leg: dict[str, Any] = {}
    for (label, _, _), leg in zip(LEG_PLAN, legs):
        backend = leg.get("backend_audit") or {}
        warmup = leg.get("warmup_audit") or {}
        per_leg[label] = {
            "backend_passed": backend.get("passed") is True,
            "warmup_passed": warmup.get("passed") is True,
            "request_success_rate": leg.get("request_success_rate"),
            "infrastructure_failure": leg.get("infrastructure_failure"),
            "candidate_failure": leg.get("candidate_failure"),
        }
    return {
        "per_leg": per_leg,
        "all_passed": all(
            item["backend_passed"]
            and item["warmup_passed"]
            and item["request_success_rate"] == 1.0
            and item["infrastructure_failure"] is None
            and item["candidate_failure"] is None
            for item in per_leg.values()
        ),
    }


def summarize_pressure(legs: list[dict[str, Any]]) -> dict[str, Any]:
    per_leg = {
        label: leg.get("pressure_validation")
        for (label, _, _), leg in zip(LEG_PLAN, legs)
    }
    return {
        "per_leg": per_leg,
        "direct_legs_passed": all(
            isinstance(per_leg[label], dict) and per_leg[label].get("valid") is True
            for label in ("A1", "A2")
        ),
        "all_legs_passed": all(
            isinstance(value, dict) and value.get("valid") is True
            for value in per_leg.values()
        ),
    }


def summarize_quality(legs: list[dict[str, Any]], policy: dict[str, Any]) -> dict[str, Any]:
    baseline = [legs[0], legs[3]]
    candidate = [legs[1], legs[2]]
    failures: list[str] = []

    baseline_success = min(float(leg.get("request_success_rate") or 0.0) for leg in baseline)
    candidate_success = min(float(leg.get("request_success_rate") or 0.0) for leg in candidate)
    success_floor = max(
        float(policy["min_request_success_rate"]),
        baseline_success - float(policy["request_success_tolerance"]),
    )
    if baseline_success < float(policy["min_request_success_rate"]):
        failures.append("baseline_request_success")
    if candidate_success < success_floor:
        failures.append("candidate_request_success")

    baseline_valid = min(float(leg.get("valid_step_ratio") or 0.0) for leg in baseline)
    candidate_valid = min(float(leg.get("valid_step_ratio") or 0.0) for leg in candidate)
    valid_floor = max(
        float(policy["min_valid_step_ratio"]),
        baseline_valid - float(policy["valid_step_ratio_tolerance"]),
    )
    if baseline_valid < float(policy["min_valid_step_ratio"]):
        failures.append("baseline_valid_step_ratio")
    if candidate_valid < valid_floor:
        failures.append("candidate_valid_step_ratio")

    semantic: dict[str, Any] = {}
    for metric, minimum_key, tolerance_key in (
        (
            "tests_passed_workflows",
            "min_tests_passed_workflows",
            "tests_passed_workflows_tolerance",
        ),
        (
            "completed_workflows",
            "min_completed_workflows",
            "completed_workflows_tolerance",
        ),
    ):
        absolute_floor = int(policy[minimum_key])
        tolerance = int(policy[tolerance_key])
        baseline_counts = [int(leg.get(metric) or 0) for leg in baseline]
        candidate_counts = [int(leg.get(metric) or 0) for leg in candidate]
        candidate_floors = [
            max(absolute_floor, value - tolerance) for value in baseline_counts
        ]
        if any(value < absolute_floor for value in baseline_counts):
            failures.append(f"baseline_{metric}")
        if any(
            value < floor for value, floor in zip(candidate_counts, candidate_floors)
        ):
            failures.append(f"candidate_{metric}")
        semantic[metric] = {
            "baseline": baseline_counts,
            "candidate": candidate_counts,
            "absolute_floor": absolute_floor,
            "tolerance": tolerance,
            "paired_candidate_floors": candidate_floors,
        }

    baseline_progress = min(
        int(leg.get("minimum_workflow_progress") or 0) for leg in baseline
    )
    candidate_progress = min(
        int(leg.get("minimum_workflow_progress") or 0) for leg in candidate
    )
    if baseline_progress < int(policy["minimum_workflow_progress"]):
        failures.append("baseline_minimum_progress")
    if candidate_progress < int(policy["minimum_workflow_progress"]):
        failures.append("candidate_minimum_progress")

    candidate_wait = max(
        float((leg.get("backend_audit") or {}).get("p99_gateway_wait_sec") or 0.0)
        for leg in candidate
    )
    if candidate_wait > float(policy["max_p99_gateway_wait_sec"]):
        failures.append("candidate_p99_gateway_wait")

    baseline_p99_steps = [
        float(leg.get("p99_step_latency_sec") or 0.0) for leg in baseline
    ]
    candidate_p99_steps = [
        float(leg.get("p99_step_latency_sec") or 0.0) for leg in candidate
    ]
    p99_steps_valid = all(
        math.isfinite(value) and value > 0.0
        for value in baseline_p99_steps + candidate_p99_steps
    )
    if not p99_steps_valid:
        failures.append("invalid_p99_step_latency")
        paired_p99_step_ratios = [None, None]
        diagnostic_max_p99_step_ratio = None
    else:
        paired_p99_step_ratios = [
            candidate_value / baseline_value
            for baseline_value, candidate_value in zip(
                baseline_p99_steps, candidate_p99_steps
            )
        ]
        diagnostic_max_p99_step_ratio = max(candidate_p99_steps) / max(
            baseline_p99_steps
        )
    maximum_paired_p99_step_ratio = (
        max(float(value) for value in paired_p99_step_ratios)
        if p99_steps_valid
        else None
    )
    maximum_allowed_p99_step_ratio = float(policy["max_p99_step_latency_ratio"])
    if (
        maximum_paired_p99_step_ratio is not None
        and maximum_paired_p99_step_ratio > maximum_allowed_p99_step_ratio
    ):
        failures.append("candidate_position_paired_p99_step_latency_ratio")
    tail_anti_gaming = {
        "schema_version": 1,
        "metric": "p99_step_latency_sec",
        "pairing": "candidate_over_baseline:B1/A1,B2/A2",
        "baseline_p99_step_latency_sec": baseline_p99_steps,
        "candidate_p99_step_latency_sec": candidate_p99_steps,
        "position_paired_ratios": paired_p99_step_ratios,
        "max_position_paired_ratio": maximum_paired_p99_step_ratio,
        "maximum_allowed_ratio": maximum_allowed_p99_step_ratio,
        "diagnostic_max_candidate_over_max_baseline_ratio": (
            diagnostic_max_p99_step_ratio
        ),
        "passed": p99_steps_valid
        and maximum_paired_p99_step_ratio is not None
        and maximum_paired_p99_step_ratio <= maximum_allowed_p99_step_ratio,
    }
    baseline_work = geometric_mean(
        [float(leg.get("backend_tokens_per_valid_step") or 0.0) for leg in baseline]
    )
    candidate_work = geometric_mean(
        [float(leg.get("backend_tokens_per_valid_step") or 0.0) for leg in candidate]
    )
    work_ratio = candidate_work / baseline_work if baseline_work else 0.0
    if baseline_work <= 0:
        failures.append("baseline_backend_work")
    if not float(policy["backend_work_ratio_min"]) <= work_ratio <= float(
        policy["backend_work_ratio_max"]
    ):
        failures.append("candidate_backend_work_ratio")

    return {
        "passed": not failures,
        "failures": failures,
        "baseline_request_success": baseline_success,
        "candidate_request_success": candidate_success,
        "candidate_request_success_floor": success_floor,
        "baseline_valid_step_ratio": baseline_valid,
        "candidate_valid_step_ratio": candidate_valid,
        "candidate_valid_step_ratio_floor": valid_floor,
        "semantic_quality": semantic,
        "baseline_minimum_workflow_progress": baseline_progress,
        "candidate_minimum_workflow_progress": candidate_progress,
        "candidate_p99_gateway_wait_sec": candidate_wait,
        "tail_anti_gaming": tail_anti_gaming,
        "baseline_backend_tokens_per_valid_step_geomean": baseline_work,
        "candidate_backend_tokens_per_valid_step_geomean": candidate_work,
        "backend_work_ratio": work_ratio,
    }


def evaluate_exploratory_abba(
    legs: list[dict[str, Any]],
    *,
    pair_diagnostics: list[dict[str, Any]],
    policy: dict[str, Any],
    profile: str,
    nonce_sha256: str,
    minimum_speedup: float,
) -> dict[str, Any]:
    if len(legs) != 4 or len(pair_diagnostics) != 2:
        raise ValueError("ABBA evaluation requires exactly four legs and two Oracle pairs")
    labels = [item[0] for item in LEG_PLAN]
    expected_modes = [item[1] for item in LEG_PLAN]
    schema_checks: dict[str, bool] = {}
    for label, leg in zip(labels, legs):
        schema_checks.update(PAIR.leg_schema_checks(leg, label))
    identity_checks = {
        "exact_abba_modes": [leg.get("mode") for leg in legs] == expected_modes,
        "same_hidden_profile": all(leg.get("profile") == profile for leg in legs),
        "same_hidden_corpus_namespace": all(
            leg.get("corpus_namespace") == f"hidden-{profile}" for leg in legs
        ),
        "same_workload_nonce": all(
            leg.get("workload_nonce_sha256") == nonce_sha256 for leg in legs
        ),
        "distinct_run_ids": (
            all(isinstance(leg.get("run_id"), str) and leg["run_id"] for leg in legs)
            and len({leg["run_id"] for leg in legs}) == 4
        ),
        **{
            f"same_{field}": all(leg.get(field) == legs[0].get(field) for leg in legs)
            for field in IDENTITY_FIELDS
            if field not in {"workload_nonce_sha256", "profile", "corpus_namespace"}
        },
    }
    baseline_rates = [float(legs[index].get("valid_steps_per_min") or 0.0) for index in (0, 3)]
    candidate_rates = [float(legs[index].get("valid_steps_per_min") or 0.0) for index in (1, 2)]
    baseline_geomean = geometric_mean(baseline_rates)
    candidate_geomean = geometric_mean(candidate_rates)
    speedup = candidate_geomean / baseline_geomean if baseline_geomean else 0.0
    baseline_cv = coefficient_of_variation(baseline_rates)
    candidate_cv = coefficient_of_variation(candidate_rates)
    audits = summarize_audits(legs)
    pressure = summarize_pressure(legs)
    quality = summarize_quality(legs, policy)
    contracts_passed = all(
        diagnostic.get("contracts_passed") is True for diagnostic in pair_diagnostics
    )
    pair_quality_passed = all(
        diagnostic.get("quality_passed") is True for diagnostic in pair_diagnostics
    )
    effect = {
        "baseline_rates": baseline_rates,
        "candidate_rates": candidate_rates,
        "baseline_geomean": baseline_geomean,
        "candidate_geomean": candidate_geomean,
        "baseline_cv": baseline_cv,
        "candidate_cv": candidate_cv,
        "maximum_baseline_cv": float(policy["max_baseline_cv"]),
        "speedup": speedup,
        "minimum_speedup": minimum_speedup,
        "speedup_passed": speedup > minimum_speedup,
        "baseline_cv_passed": baseline_cv <= float(policy["max_baseline_cv"]),
    }
    checks = {
        **schema_checks,
        **identity_checks,
        "reference_pair_contracts_passed": contracts_passed,
        "reference_pair_quality_passed": pair_quality_passed,
        "all_audits_passed": audits["all_passed"],
        "both_direct_legs_pressurized": pressure["direct_legs_passed"],
        "aggregate_quality_passed": quality["passed"],
        "position_paired_p99_step_tail_passed": quality["tail_anti_gaming"][
            "passed"
        ],
        "baseline_cv_passed": effect["baseline_cv_passed"],
        "aggregate_speedup_passed": effect["speedup_passed"],
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "audit": audits,
        "pressure": pressure,
        "quality": quality,
        "effect": effect,
        "pair_diagnostics": pair_diagnostics,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="author-only release_ready=false hidden Direct/Oracle/Oracle/Direct"
    )
    parser.add_argument("--profile", default="hidden-pressure-192")
    parser.add_argument("--project", choices=(PROJECT,), default=PROJECT)
    parser.add_argument("--request-timeout-sec", type=int, default=14400)
    parser.add_argument("--quiescence-timeout-sec", type=int, default=180)
    parser.add_argument("--minimum-speedup", type=float, default=1.0)
    parser.add_argument("--workload-nonce")
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def run_exploratory_abba(args: argparse.Namespace, lock_path: Path) -> int:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.profile):
        raise ValueError("--profile contains unsafe characters")
    if not 300 <= args.request_timeout_sec <= 21600:
        raise ValueError("--request-timeout-sec must be in 300..21600")
    if not 30 <= args.quiescence_timeout_sec <= 600:
        raise ValueError("--quiescence-timeout-sec must be in 30..600")
    if args.minimum_speedup < 1.0:
        raise ValueError("--minimum-speedup must be at least 1.0")
    if args.workload_nonce is not None and not 1 <= len(args.workload_nonce) <= 512:
        raise ValueError("--workload-nonce must contain 1..512 characters")

    output = validate_output_path(args.output)
    policy, hidden_profile = load_closed_hidden_contract(args.profile)
    nonce = args.workload_nonce or secrets.token_hex(32)
    nonce_sha256 = hashlib.sha256(nonce.encode()).hexdigest()

    controller = PAIR.exactly_one_service(args.project, "bench-controller")
    controller_identity = PAIR.inspect_container(controller)
    controller_environment = controller_identity["selected_environment"]
    if any(
        controller_environment.get(key) != value
        for key, value in PAIR.EXPECTED_CONTROLLER_ENDPOINTS.items()
    ):
        raise RuntimeError(
            f"controller data-plane endpoints are not frozen: {controller_environment}"
        )
    model_api = PAIR.exactly_one_service(args.project, "model-api")
    model_api_identity = PAIR.inspect_container(model_api)
    if (
        model_api_identity["selected_environment"].get("UPSTREAM_UNIX_SOCKET")
        != "/run/kvbench-vllm/vllm.sock"
    ):
        raise RuntimeError("model-api is not bound to the frozen UDS path")
    readiness = PAIR.controller_request(
        controller, "GET", "/admin/readiness", None, timeout_sec=60
    )
    required_readiness = (
        "model_api",
        "infrastructure_attested",
        "real_swebench_workload",
        "hidden_profiles",
    )
    missing = [key for key in required_readiness if readiness.get(key) is not True]
    if missing:
        raise RuntimeError(f"controller readiness missing {missing}: {readiness}")
    if (
        readiness.get("oracle_calibrated") is not False
        or readiness.get("real_agent_test_allowed") is not False
        or readiness.get("release_id") != policy.get("release_id")
    ):
        raise RuntimeError(
            "controller is not the closed pre-freeze policy required by exploratory ABBA"
        )

    with tempfile.TemporaryDirectory(prefix="kvbench-hidden-abba-snapshot-") as raw:
        snapshot = Path(raw) / "reference_gateway"
        snapshot_record = copy_immutable_snapshot(REFERENCE_ROOT, snapshot)
        snapshot_digest = snapshot_record["snapshot_tree_sha256"]
        report: dict[str, Any] = {
            "schema_version": 1,
            "kind": "author-only-exploratory-hidden-reference-abba",
            "author_only": True,
            "private_hidden_evidence": True,
            "release_evidence_eligible": False,
            "qualification_role": (
                "pre-freeze reference-selection diagnostic only; never final release evidence"
            ),
            "status": "running",
            "passed": False,
            "started_at_utc": PAIR.utc_now(),
            "completed_at_utc": None,
            "release_ready_at_run": False,
            "suite": "hidden",
            "profile": args.profile,
            "profile_config": hidden_profile,
            "project": args.project,
            "order": [label for label, _, _ in LEG_PLAN],
            "mode_order": [mode for _, mode, _ in LEG_PLAN],
            "role_order": [role for _, _, role in LEG_PLAN],
            "workload_nonce_sha256": nonce_sha256,
            "host_measurement_lock": str(lock_path),
            "reference_snapshot": snapshot_record,
            "thunderagent_source_commit": "7ddc8610270e56d3b109eed8796b3a4360fc67c9",
            "controller": controller_identity,
            "model_api": model_api_identity,
            "controller_readiness": readiness,
            "policy": {
                "release_id": policy.get("release_id"),
                "release_ready": policy.get("release_ready"),
                "policy_file_sha256": sha256_file(SCORING_POLICY),
                "policy_contract_sha256": readiness.get("policy_contract_sha256"),
                "max_baseline_cv": policy.get("max_baseline_cv"),
                "noise_floor": policy.get("noise_floor"),
            },
            "lifecycle": {
                "boundaries": {},
                "direct": {},
                "oracle": {},
                "service_identities": {},
                "cleanup": {},
            },
            "legs": [],
            "evaluation": None,
            "errors": [],
        }
        PAIR.atomic_write(output, report, initial=True)
        print(f"private exploratory hidden ABBA: {output}", flush=True)
        failure: Exception | None = None
        cleanup_failure: Exception | None = None
        try:
            initial_main = PAIR.exactly_one_service(args.project, "main", running=False)
            report["lifecycle"]["service_identities"]["main_before_A1"] = (
                PAIR.inspect_container(initial_main)
            )
            stack_action("stop-oracle", snapshot, timeout=180)
            report["lifecycle"]["direct"]["A1_before"] = gateway_absent(
                args.project, controller, "A1_before"
            )
            report["lifecycle"]["boundaries"]["before_A1"] = reset_model_boundary(
                controller,
                "before_A1",
                timeout_sec=args.quiescence_timeout_sec,
            )
            PAIR.atomic_write(output, report)

            print(f"START A1/Direct {args.profile} {PAIR.utc_now()}", flush=True)
            a1 = run_leg(
                controller,
                profile=args.profile,
                mode="baseline",
                nonce=nonce,
                timeout_sec=args.request_timeout_sec,
            )
            report["legs"].append({"label": "A1", "role": "direct", "result": a1})
            report["lifecycle"]["direct"]["A1_after"] = gateway_absent(
                args.project, controller, "A1_after"
            )
            report["lifecycle"]["boundaries"]["between_A1_B1"] = reset_model_boundary(
                controller,
                "between_A1_B1",
                timeout_sec=args.quiescence_timeout_sec,
            )
            PAIR.atomic_write(output, report)

            print(f"START B1/fresh-Oracle {args.profile} {PAIR.utc_now()}", flush=True)
            b1_lifecycle = start_fresh_oracle(
                project=args.project,
                controller=controller,
                snapshot=snapshot,
                snapshot_digest=snapshot_digest,
                label="B1",
                previous_identity_digest=None,
            )
            report["lifecycle"]["oracle"]["B1"] = b1_lifecycle
            b1 = run_leg(
                controller,
                profile=args.profile,
                mode="candidate",
                nonce=nonce,
                timeout_sec=args.request_timeout_sec,
            )
            b1_container = PAIR.exactly_one_service(args.project, "main")
            b1_after_identity = PAIR.inspect_container(b1_container)
            if b1_after_identity["id"] != b1_lifecycle["container"]["id"]:
                raise RuntimeError("B1 Oracle container changed during the leg")
            b1_health_after = PAIR.gateway_health(b1_container)
            b1_lifecycle["container_after"] = b1_after_identity
            b1_lifecycle["gateway_health_after"] = b1_health_after
            b1_lifecycle["snapshot_tree_sha256_after"] = (
                PAIR.reference_gateway_tree_sha256(snapshot)
            )
            report["legs"].append({"label": "B1", "role": "oracle", "result": b1})
            stack_action("stop-oracle", snapshot, timeout=180)
            report["lifecycle"]["oracle"]["B1_after_stop"] = gateway_absent(
                args.project, controller, "B1_after_stop"
            )
            report["lifecycle"]["boundaries"]["between_B1_B2"] = reset_model_boundary(
                controller,
                "between_B1_B2",
                timeout_sec=args.quiescence_timeout_sec,
            )
            PAIR.atomic_write(output, report)

            print(f"START B2/fresh-Oracle {args.profile} {PAIR.utc_now()}", flush=True)
            b2_lifecycle = start_fresh_oracle(
                project=args.project,
                controller=controller,
                snapshot=snapshot,
                snapshot_digest=snapshot_digest,
                label="B2",
                previous_identity_digest=b1_lifecycle["process_identity_sha256"],
            )
            if b2_lifecycle["container"]["id"] == b1_lifecycle["container"]["id"]:
                raise RuntimeError("B2 did not receive a fresh-recreated Oracle container")
            report["lifecycle"]["oracle"]["B2"] = b2_lifecycle
            b2 = run_leg(
                controller,
                profile=args.profile,
                mode="candidate",
                nonce=nonce,
                timeout_sec=args.request_timeout_sec,
            )
            b2_container = PAIR.exactly_one_service(args.project, "main")
            b2_after_identity = PAIR.inspect_container(b2_container)
            if b2_after_identity["id"] != b2_lifecycle["container"]["id"]:
                raise RuntimeError("B2 Oracle container changed during the leg")
            b2_health_after = PAIR.gateway_health(b2_container)
            b2_lifecycle["container_after"] = b2_after_identity
            b2_lifecycle["gateway_health_after"] = b2_health_after
            b2_lifecycle["snapshot_tree_sha256_after"] = (
                PAIR.reference_gateway_tree_sha256(snapshot)
            )
            report["legs"].append({"label": "B2", "role": "oracle", "result": b2})
            stack_action("stop-oracle", snapshot, timeout=180)
            report["lifecycle"]["oracle"]["B2_after_stop"] = gateway_absent(
                args.project, controller, "B2_after_stop"
            )
            report["lifecycle"]["boundaries"]["between_B2_A2"] = reset_model_boundary(
                controller,
                "between_B2_A2",
                timeout_sec=args.quiescence_timeout_sec,
            )
            report["lifecycle"]["direct"]["A2_before"] = gateway_absent(
                args.project, controller, "A2_before"
            )
            PAIR.atomic_write(output, report)

            print(f"START A2/Direct {args.profile} {PAIR.utc_now()}", flush=True)
            a2 = run_leg(
                controller,
                profile=args.profile,
                mode="baseline",
                nonce=nonce,
                timeout_sec=args.request_timeout_sec,
            )
            report["legs"].append({"label": "A2", "role": "direct", "result": a2})
            report["lifecycle"]["direct"]["A2_after"] = gateway_absent(
                args.project, controller, "A2_after"
            )
            report["lifecycle"]["boundaries"]["after_A2"] = reset_model_boundary(
                controller,
                "after_A2",
                timeout_sec=args.quiescence_timeout_sec,
            )

            current_controller = PAIR.inspect_container(controller)
            current_model_api = PAIR.inspect_container(model_api)
            report["lifecycle"]["service_identities"]["controller_after_A2"] = (
                current_controller
            )
            report["lifecycle"]["service_identities"]["model_api_after_A2"] = (
                current_model_api
            )
            raw_legs = [item["result"] for item in report["legs"]]
            pair_diagnostics = [
                PAIR.evaluate_pair(
                    a1,
                    b1,
                    nonce_sha256=nonce_sha256,
                    minimum_speedup=0.0,
                    gateway_after=b1_health_after,
                    expected_profile=args.profile,
                    expected_corpus_namespace=f"hidden-{args.profile}",
                    expected_tree_sha256=snapshot_digest,
                ),
                PAIR.evaluate_pair(
                    a2,
                    b2,
                    nonce_sha256=nonce_sha256,
                    minimum_speedup=0.0,
                    gateway_after=b2_health_after,
                    expected_profile=args.profile,
                    expected_corpus_namespace=f"hidden-{args.profile}",
                    expected_tree_sha256=snapshot_digest,
                ),
            ]
            evaluation = evaluate_exploratory_abba(
                raw_legs,
                pair_diagnostics=pair_diagnostics,
                policy=policy,
                profile=args.profile,
                nonce_sha256=nonce_sha256,
                minimum_speedup=args.minimum_speedup,
            )
            lifecycle_checks = {
                "all_model_boundaries_reset": all(
                    boundary.get("passed") is True
                    for boundary in report["lifecycle"]["boundaries"].values()
                )
                and set(report["lifecycle"]["boundaries"])
                == {
                    "before_A1",
                    "between_A1_B1",
                    "between_B1_B2",
                    "between_B2_A2",
                    "after_A2",
                },
                "direct_legs_had_no_gateway": all(
                    record.get("passed") is True
                    for record in report["lifecycle"]["direct"].values()
                ),
                "oracle_legs_fresh": (
                    b1_lifecycle["process_identity_sha256"]
                    != b2_lifecycle["process_identity_sha256"]
                    and b1_lifecycle["container"]["id"]
                    != b2_lifecycle["container"]["id"]
                ),
                "oracle_snapshot_immutable": (
                    PAIR.reference_gateway_tree_sha256(snapshot) == snapshot_digest
                    and b1_lifecycle["snapshot_tree_sha256_after"] == snapshot_digest
                    and b2_lifecycle["snapshot_tree_sha256_after"] == snapshot_digest
                ),
                "oracle_source_unchanged": (
                    PAIR.reference_gateway_tree_sha256(REFERENCE_ROOT)
                    == snapshot_record["source_tree_sha256_before_copy"]
                ),
                "controller_identity_stable": (
                    current_controller["id"] == controller_identity["id"]
                ),
                "model_api_identity_stable": (
                    current_model_api["id"] == model_api_identity["id"]
                ),
            }
            evaluation["lifecycle_checks"] = lifecycle_checks
            evaluation["passed"] = evaluation["passed"] and all(
                lifecycle_checks.values()
            )
            report["evaluation"] = evaluation
            report["passed"] = evaluation["passed"]
            report["status"] = "complete"
            report["completed_at_utc"] = PAIR.utc_now()
        except Exception as exc:
            failure = exc
            report["status"] = "failed"
            report["passed"] = False
            report["completed_at_utc"] = PAIR.utc_now()
            report["errors"].append(f"{type(exc).__name__}: {exc}")
        finally:
            try:
                stack_action("stop-oracle", snapshot, timeout=180)
                report["lifecycle"]["cleanup"]["gateway_after_runner"] = gateway_absent(
                    args.project, controller, "runner_cleanup"
                )
            except Exception as exc:
                cleanup_failure = exc
                report["status"] = "failed"
                report["passed"] = False
                report["errors"].append(f"cleanup {type(exc).__name__}: {exc}")
            report["lifecycle"]["cleanup"]["snapshot_tree_sha256_final"] = (
                PAIR.reference_gateway_tree_sha256(snapshot)
            )
            report["lifecycle"]["cleanup"]["source_tree_sha256_final"] = (
                PAIR.reference_gateway_tree_sha256(REFERENCE_ROOT)
            )
            PAIR.atomic_write(output, report)

        if failure is not None:
            raise failure
        if cleanup_failure is not None:
            raise cleanup_failure
        print(json.dumps(report["evaluation"]["effect"], separators=(",", ":")), flush=True)
        print(
            f"COMPLETE {output} passed={report['passed']} release_evidence_eligible=false",
            flush=True,
        )
        return 0 if report["passed"] else 1


def main() -> int:
    args = parse_args()
    with PAIR.host_measurement_lock() as lock_path:
        if lock_path is None:
            raise RuntimeError("exploratory hidden ABBA requires the host measurement lock")
        return run_exploratory_abba(args, lock_path)


if __name__ == "__main__":
    raise SystemExit(main())
