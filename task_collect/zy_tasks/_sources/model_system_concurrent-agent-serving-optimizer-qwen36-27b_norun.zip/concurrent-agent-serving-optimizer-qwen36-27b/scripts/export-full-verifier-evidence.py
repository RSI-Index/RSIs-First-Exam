#!/usr/bin/env python3
"""Remove private workflow material from a full-verifier report."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import stat
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


sys.path.insert(0, str(Path(__file__).resolve().parent))
from evidence_contract import (  # noqa: E402
    PRESSURE_QUALIFICATION_PATHS,
    PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS,
    publishable_model_runtime_identity,
    reject_private_runtime_identity,
    runtime_boot_identity_sha256,
    validate_audited_oversubscribed_working_set,
    validate_finite_agent_execution_interval,
)


SELECTED_COUNTERS = {
    "vllm:generation_tokens_total",
    "vllm:num_preemptions_total",
    "vllm:prefix_cache_hits_total",
    "vllm:prefix_cache_queries_total",
    "vllm:prompt_tokens_total",
}
QWEN_PROFILE_ID = "qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2"
QWEN_REVISION = "6a9e13bd6fc8f0983b9b99948120bc37f49c13e9"
QWEN_CONFIG_SHA256 = "69db4eb7196bc8190813231b3018ca05d8c2e3abc7b1af19d55c157af44a9d9c"
QWEN_WEIGHT_INDEX_SHA256 = "a8ad2c26fb707ff8c245806315b03e3b4b74595528492423af5dae0ce39b4d9b"
QWEN_VLLM_PACKAGE_VERSION = "0.24.0"
TASK_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_GATEWAY_TREE = TASK_ROOT / "solution" / "reference_gateway"
REFERENCE_SOLVE_SH = TASK_ROOT / "solution" / "solve.sh"
SCORING_POLICY = (
    TASK_ROOT / "environment" / "bench-controller" / "profiles" / "scoring-policy.json"
)
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
DOCKER_IMAGE_ID_PATTERN = re.compile(r"sha256:[0-9a-f]{64}")
THUNDERAGENT_SOURCE_COMMIT = "7ddc8610270e56d3b109eed8796b3a4360fc67c9"
PUBLIC_ORACLE_PROFILE = "public-pressure-192"
HIDDEN_ORACLE_PROFILE = "hidden-pressure-192"
PUBLIC_MEASUREMENT_WINDOW_SEC = 1800
PUBLIC_MIN_VALID_STEP_RATIO = 0.90
PUBLIC_MAX_ZERO_PROGRESS_FRACTION = 0.05
PUBLIC_MIN_REQUEST_SUCCESS_RATE = 0.98
NETWORK_EGRESS_SEAL_SCHEMA_VERSION = 2
NETWORK_EGRESS_SEAL_PROTOCOL = "same-compose-main-egress-hmac-v2"
MAX_PUBLIC_PAIR_BYTES = 16 * 1024 * 1024
PUBLIC_DIRECT_ANCHOR_KIND = "kvbench-release-public-direct-anchor"
FINAL_LEG_ORDER_CONTEXT = b"kvbench-final-leg-order-v1\n"
FINAL_LEG_ORDER_PROTOCOL = "sha256-domain-separated-first-byte-lsb-v1"
FINAL_FORMAL_LEG_COUNT = 2
EXPECTED_V5_TIER_POLICY = {
    "algorithm": "thunderagent-program-aware-single-backend",
    "scheduler_policy_schema_version": 4,
    "queue_policy": "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5",
    "fair_service_until_step": 12,
    "deep_request_first_step": 13,
    "protected_request_policy": "v4-exact-through-step-12",
    "deep_request_policy": "total_tokens-sjf-with-service-lag-bypass-from-step-13",
    "normal_restore_order": (
        "aged-then-protected-request-ordinal-then-deep-total-tokens-then-idle-acting"
    ),
    "deep_restore_order": "total_tokens-then-request-wait-age-then-program-id",
    "deep_reentry_bypasses_service_lag": True,
}
DEEP_SIGNAL_PATHS = {
    "offers": ("counters", "deep_request_offers"),
    "waiters_peak": (None, "deep_pending_request_waiters_peak"),
    "wait_count": (None, "deep_pause_wait_count"),
    "lag_bypass": ("counters", "deep_service_lag_bypass_decisions"),
    "resumes": ("counters", "resume_deep_request"),
    "sjf_ticks": ("counters", "deep_sjf_priority_ticks"),
}
REFERENCE_SUBMISSION_FILES = {
    "THIRD_PARTY_LICENSE.md": 0o644,
    "gateway.py": 0o644,
    "launch.sh": 0o755,
    "scheduler.py": 0o644,
}
REFERENCE_SOLVE_SH_BYTES = b"""#!/usr/bin/env bash
set -euo pipefail

rm -rf /app/submission
install -d -m 0755 /app/submission
install -m 0644 \\
  /solution/reference_gateway/gateway.py \\
  /solution/reference_gateway/scheduler.py \\
  /solution/reference_gateway/THIRD_PARTY_LICENSE.md \\
  /app/submission/
install -m 0755 /solution/reference_gateway/launch.sh /app/submission/launch.sh
"""


def _submission_record(
    *, path: str, kind: str, executable: bool, size: int, payload_sha256: str
) -> bytes:
    """Render the exact record framing used by tests/verify.py."""

    return json.dumps(
        {
            "kind": kind,
            "path": path,
            "executable": executable,
            "size": size,
            "sha256": payload_sha256,
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode()


def frozen_submission_sha256(submission: Path) -> str:
    """Reproduce tests/verify.py:frozen_submission_sha256 byte-for-byte."""

    if submission.is_symlink() or not submission.is_dir():
        raise OSError(f"frozen submission is not a real directory: {submission}")
    result = hashlib.sha256()
    for entry in [submission, *sorted(submission.rglob("*"))]:
        relative = "." if entry == submission else entry.relative_to(submission).as_posix()
        metadata = entry.lstat()
        if stat.S_ISDIR(metadata.st_mode):
            kind = "directory"
            payload_digest = ""
            size = 0
        elif stat.S_ISREG(metadata.st_mode):
            kind = "file"
            payload_digest = hashlib.sha256(entry.read_bytes()).hexdigest()
            size = metadata.st_size
        else:
            raise OSError(f"frozen submission contains unsupported entry: {relative}")
        result.update(
            _submission_record(
                path=relative,
                kind=kind,
                executable=bool(metadata.st_mode & 0o111),
                size=size,
                payload_sha256=payload_digest,
            )
        )
        result.update(b"\n")
    return result.hexdigest()


def reference_submission_sha256(
    root: Path = REFERENCE_GATEWAY_TREE,
    solve_sh: Path = REFERENCE_SOLVE_SH,
) -> str:
    """Hash the exact four-file tree installed by the frozen solve.sh.

    Source modes are intentionally irrelevant because solve.sh normalizes the
    destination modes.  The solve script itself is checked byte-for-byte so a
    changed installed mode or file set cannot retain the old identity.
    """

    if solve_sh.is_symlink() or not solve_sh.is_file():
        raise OSError(f"Oracle solve script is not a regular file: {solve_sh}")
    if solve_sh.read_bytes() != REFERENCE_SOLVE_SH_BYTES:
        raise OSError("Oracle solve.sh no longer installs the frozen four-file contract")
    if root.is_symlink() or not root.is_dir():
        raise OSError(f"Oracle reference tree is not a real directory: {root}")

    result = hashlib.sha256()
    result.update(
        _submission_record(
            path=".", kind="directory", executable=True, size=0, payload_sha256=""
        )
    )
    result.update(b"\n")
    for name in sorted(REFERENCE_SUBMISSION_FILES):
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise OSError(f"Oracle submission source is not a regular file: {name}")
        payload = path.read_bytes()
        result.update(
            _submission_record(
                path=name,
                kind="file",
                executable=bool(REFERENCE_SUBMISSION_FILES[name] & 0o111),
                size=len(payload),
                payload_sha256=hashlib.sha256(payload).hexdigest(),
            )
        )
        result.update(b"\n")
    return result.hexdigest()


def policy_contract_sha256(policy: dict[str, Any]) -> str:
    immutable = {
        key: value
        for key, value in policy.items()
        if key not in {"release_ready", "not_ready_reasons"}
    }
    encoded = json.dumps(immutable, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def load_scoring_policy(path: Path = SCORING_POLICY) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"cannot read frozen scoring policy {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit("frozen scoring policy must be a JSON object")
    return value


def load_bounded_regular_json(path: Path, label: str) -> tuple[dict[str, Any], bytes]:
    """Read one bounded, non-symlink regular JSON object exactly once."""

    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise SystemExit(f"cannot open {label} {path}: {exc}") from exc
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise SystemExit(f"{label} is not a regular file: {path}")
        if metadata.st_size > MAX_PUBLIC_PAIR_BYTES:
            raise SystemExit(f"{label} exceeds the {MAX_PUBLIC_PAIR_BYTES}-byte limit")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            raw = stream.read(MAX_PUBLIC_PAIR_BYTES + 1)
    finally:
        os.close(descriptor)
    if len(raw) > MAX_PUBLIC_PAIR_BYTES:
        raise SystemExit(f"{label} exceeds the {MAX_PUBLIC_PAIR_BYTES}-byte limit")
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise SystemExit(f"cannot parse {label} {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit(f"{label} must be a JSON object")
    return payload, raw


def reference_gateway_tree_sha256(root: Path = REFERENCE_GATEWAY_TREE) -> str:
    """Hash every authored Oracle file with stable path/content framing.

    Runtime bytecode caches are excluded.  Everything else below the reference
    root is part of the Oracle identity; symlinks and special files are rejected
    so the digest cannot depend on an external target or device semantics.
    """

    if root.is_symlink() or not root.is_dir():
        raise OSError(f"Oracle reference tree is not a real directory: {root}")
    records: list[bytes] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink():
            raise OSError(f"Oracle reference tree contains a symlink: {relative.as_posix()}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise OSError(f"Oracle reference tree contains a special file: {relative.as_posix()}")
        payload = path.read_bytes()
        record = {
            "path": relative.as_posix(),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "size": len(payload),
        }
        records.append(json.dumps(record, separators=(",", ":"), sort_keys=True).encode())
    if not records:
        raise OSError(f"Oracle reference tree has no authored files: {root}")
    digest = hashlib.sha256(b"reference-gateway-tree-v1\n")
    for record in records:
        digest.update(record)
        digest.update(b"\n")
    return digest.hexdigest()


def atomic_write_new(path: Path, rendered: str) -> None:
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink() or path.exists():
        raise SystemExit(f"refusing to overwrite evidence output: {path}")
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w") as stream:
            stream.write(rendered)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        try:
            os.link(temporary, path)
        except FileExistsError as exc:
            raise SystemExit(f"refusing to overwrite evidence output: {path}") from exc
    finally:
        temporary.unlink(missing_ok=True)


def require_sha256(value: Any, field: str, *, docker_image_id: bool = False) -> str:
    pattern = DOCKER_IMAGE_ID_PATTERN if docker_image_id else SHA256_PATTERN
    if not isinstance(value, str) or pattern.fullmatch(value) is None:
        expected = "Docker SHA-256 image ID" if docker_image_id else "lowercase SHA-256 digest"
        raise SystemExit(f"raw verifier {field} must be a {expected}")
    return value


def canonical_object_sha256(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def formal_leg_order(workload_nonce_sha256: str) -> tuple[str, str]:
    require_sha256(workload_nonce_sha256, "formal workload_nonce_sha256")
    digest = hashlib.sha256(
        FINAL_LEG_ORDER_CONTEXT + workload_nonce_sha256.encode("ascii")
    ).digest()
    return (
        ("candidate", "baseline")
        if digest[0] & 1
        else ("baseline", "candidate")
    )


def validate_formal_profile_pair(
    profile: Any,
    profile_name: str,
) -> tuple[list[dict[str, Any]], tuple[str, str], int]:
    """Validate the schema-2 nonce-committed formal AB/BA pair."""

    if not isinstance(profile, dict):
        raise SystemExit(f"raw verifier hidden profile is malformed: {profile_name}")
    legs = profile.get("legs")
    commitment = profile.get("leg_order_commitment")
    expected_commitment_keys = {
        "schema_version",
        "protocol",
        "context",
        "workload_nonce_sha256",
        "order",
    }
    if (
        not isinstance(legs, list)
        or len(legs) != FINAL_FORMAL_LEG_COUNT
        or any(not isinstance(leg, dict) for leg in legs)
        or not isinstance(commitment, dict)
        or set(commitment) != expected_commitment_keys
        or commitment.get("schema_version") != 1
        or commitment.get("protocol") != FINAL_LEG_ORDER_PROTOCOL
        or commitment.get("context")
        != FINAL_LEG_ORDER_CONTEXT.decode("ascii").rstrip("\n")
    ):
        raise SystemExit(
            f"raw verifier hidden profile is not a committed two-leg pair: {profile_name}"
        )
    nonce_sha256 = require_sha256(
        commitment.get("workload_nonce_sha256"),
        f"{profile_name} leg-order workload_nonce_sha256",
    )
    expected_order = formal_leg_order(nonce_sha256)
    modes = tuple(leg.get("mode") for leg in legs)
    if (
        tuple(commitment.get("order") or ()) != expected_order
        or modes != expected_order
        or sorted(modes) != ["baseline", "candidate"]
        or any(leg.get("workload_nonce_sha256") != nonce_sha256 for leg in legs)
    ):
        raise SystemExit(
            f"raw verifier hidden pair order disagrees with its nonce commitment: {profile_name}"
        )
    return legs, expected_order, expected_order.index("candidate") + 1


def validate_qwen_provenance(
    report: dict[str, Any], release_id: str, profile_sha256: str
) -> dict[str, Any]:
    """Validate the current full-verifier provenance contract.

    Older full-verifier reports did not carry the policy, corpus, model, and
    controller provenance emitted by the current trusted controller.  Merely
    replacing their attestation or release ID must not make them releasable.
    """

    if type(report.get("schema_version")) is not int or report["schema_version"] != 1:
        raise SystemExit("raw verifier report has the wrong schema_version")
    if report.get("phase") != "final":
        raise SystemExit("raw verifier report is not a final verifier report")
    detail_policy = report.get("report_detail_policy")
    if detail_policy not in (None, "aggregate-no-raw-workflow-series-v1"):
        raise SystemExit("verifier report has an unknown detail policy")
    compact_aggregate_report = detail_policy == "aggregate-no-raw-workflow-series-v1"
    checks = report.get("checks")
    benchmark = report.get("benchmark")
    if not isinstance(checks, dict) or not isinstance(benchmark, dict):
        raise SystemExit("raw verifier report is missing checks or benchmark")
    if type(benchmark.get("schema_version")) is not int or benchmark["schema_version"] != 2:
        raise SystemExit("raw verifier benchmark has the wrong schema_version")
    if benchmark.get("release_id") != release_id:
        raise SystemExit("raw verifier benchmark release_id does not match --release-id")

    require_sha256(benchmark.get("policy_contract_sha256"), "benchmark policy_contract_sha256")
    require_sha256(benchmark.get("controller_config_sha256"), "benchmark controller_config_sha256")
    require_sha256(benchmark.get("corpus_manifest_sha256"), "benchmark corpus_manifest_sha256")
    if benchmark.get("model_profile_sha256") != profile_sha256:
        raise SystemExit(
            "raw verifier benchmark model_profile_sha256 does not match --model-profile-sha256"
        )

    attestation = checks.get("attestation")
    if not isinstance(attestation, dict):
        raise SystemExit("raw verifier report is missing model attestation")
    model = attestation.get("model")
    runtime = attestation.get("runtime")
    if not isinstance(model, dict) or not isinstance(runtime, dict):
        raise SystemExit("raw verifier model attestation is incomplete")
    file_hashes = model.get("file_hashes")
    runtime_image_id = require_sha256(
        runtime.get("runtime_image_id"),
        "attestation runtime.runtime_image_id",
        docker_image_id=True,
    )
    if (
        type(attestation.get("schema_version")) is not int
        or attestation["schema_version"] != 1
        or attestation.get("state") != "ready"
        or attestation.get("profile_sha256") != profile_sha256
        or attestation.get("profile_id") != QWEN_PROFILE_ID
        or model.get("profile_id") != QWEN_PROFILE_ID
        or model.get("revision") != QWEN_REVISION
        or not isinstance(file_hashes, dict)
        or file_hashes.get("config.json") != QWEN_CONFIG_SHA256
        or file_hashes.get("model.safetensors.index.json")
        != QWEN_WEIGHT_INDEX_SHA256
        or attestation.get("model_mount_read_only") is not True
        or attestation.get("observed_vllm_package_version")
        != QWEN_VLLM_PACKAGE_VERSION
        or runtime.get("vllm_package_version") != QWEN_VLLM_PACKAGE_VERSION
        or runtime.get("tensor_parallel_size") != 2
        or runtime.get("kv_cache_dtype") != "fp8"
        or runtime.get("tool_call_parser") is not None
        or runtime.get("reasoning_parser") != "qwen3"
    ):
        raise SystemExit("raw verifier report is not bound to the frozen Qwen runtime")

    expected_model_provenance = {
        "profile_id": QWEN_PROFILE_ID,
        "profile_sha256": profile_sha256,
        "model_revision": QWEN_REVISION,
        "runtime_image_id": runtime_image_id,
        "tensor_parallel_size": 2,
        "kv_cache_dtype": "fp8",
        "runtime_boot_identity_sha256": runtime_boot_identity_sha256(
            attestation
        ),
    }
    if benchmark.get("model_provenance") != expected_model_provenance:
        raise SystemExit("raw verifier benchmark model_provenance disagrees with attestation")

    profiles = benchmark.get("profiles")
    if not isinstance(profiles, dict) or len(profiles) != 1:
        raise SystemExit("raw verifier benchmark must contain one hidden profile")
    formal_order: tuple[str, str] | None = None
    for profile_name, profile in profiles.items():
        if not isinstance(profile_name, str) or not isinstance(profile, dict):
            raise SystemExit("raw verifier benchmark profile structure is invalid")
        legs, formal_order, _candidate_ordinal = validate_formal_profile_pair(
            profile, profile_name
        )
        if any(
            not isinstance(leg, dict) or leg.get("model_provenance") != expected_model_provenance
            for leg in legs
        ):
            raise SystemExit(
                f"raw verifier benchmark leg model_provenance disagrees with attestation: {profile_name}"
            )
        for leg in legs:
            validate_pressure_qualification(leg, profile_name)
            if compact_aggregate_report:
                metrics = leg.get("vllm_metrics")
                omitted = (
                    metrics.get("omitted_detail_counts")
                    if isinstance(metrics, dict)
                    else None
                )
                if (
                    not isinstance(metrics, dict)
                    or "live_samples" in metrics
                    or "live_series" in metrics
                    or not isinstance(omitted, dict)
                    or not isinstance(omitted.get("live_samples"), int)
                    or isinstance(omitted.get("live_samples"), bool)
                    or omitted["live_samples"] <= 0
                    or not isinstance(omitted.get("live_series"), int)
                    or isinstance(omitted.get("live_series"), bool)
                    or omitted["live_series"] <= 0
                ):
                    raise SystemExit(
                        f"compact verifier {profile_name}:{leg.get('run_id')} "
                        "does not carry trusted raw-series omission counts"
                    )
            try:
                validate_finite_agent_execution_interval(
                    leg,
                    f"raw verifier {profile_name}:{leg.get('run_id')}",
                    require_live_samples=not compact_aggregate_report,
                )
            except ValueError as exc:
                raise SystemExit(str(exc)) from exc
    lifecycle = benchmark.get("candidate_lifecycle")
    epochs = lifecycle.get("epochs") if isinstance(lifecycle, dict) else None
    assert formal_order is not None
    if (
        not isinstance(lifecycle, dict)
        or lifecycle.get("schema_version") != 1
        or lifecycle.get("epoch_count") != 2
        or lifecycle.get("candidate_process_epoch_count") != 1
        or not isinstance(epochs, list)
        or len(epochs) != 2
        or any(not isinstance(epoch, dict) for epoch in epochs)
        or [epoch.get("leg_ordinal") for epoch in epochs] != [1, 2]
        or tuple(epoch.get("mode") for epoch in epochs) != formal_order
    ):
        raise SystemExit("raw verifier candidate lifecycle is not one committed pair")
    candidate_epoch = epochs[formal_order.index("candidate")]
    require_sha256(
        candidate_epoch.get("gateway_process_identity_sha256"),
        "candidate lifecycle gateway_process_identity_sha256",
    )
    return benchmark


def validate_pressure_qualification(leg: dict[str, Any], profile_name: str) -> None:
    """Reject legacy occupancy-only verifier legs before sanitization."""

    config = leg.get("profile_config")
    pressure = leg.get("pressure_validation")
    if not isinstance(config, dict) or not isinstance(pressure, dict):
        raise SystemExit(f"raw verifier leg is missing pressure contract: {profile_name}")
    expected_required = bool(
        config.get("pressure_required") is True and leg.get("mode") == "baseline"
    )
    contention = pressure.get("contention_evidence")
    if (
        pressure.get("qualification_schema_version") != 1
        or pressure.get("required") is not expected_required
        or pressure.get("valid") is not True
        or not isinstance(contention, dict)
        or contention.get("required") is not expected_required
        or contention.get("valid") is not True
    ):
        raise SystemExit(
            f"raw verifier leg lacks current KV contention evidence: {profile_name}"
        )
    if not expected_required:
        return
    paths = contention.get("qualification_paths")
    if not isinstance(paths, list) or not paths:
        raise SystemExit(f"raw verifier baseline has no KV qualification path: {profile_name}")
    if not all(
        isinstance(path, str) and path in PRESSURE_QUALIFICATION_PATHS
        for path in paths
    ):
        raise SystemExit(f"raw verifier baseline has an unsafe KV qualification path: {profile_name}")
    if (
        "audited_active_working_set" in paths
        and (contention.get("active_working_set") or {}).get("valid") is not True
    ):
        raise SystemExit(f"raw verifier active-working-set evidence is invalid: {profile_name}")
    if "audited_oversubscribed_working_set" in paths:
        try:
            validate_audited_oversubscribed_working_set(
                contention,
                f"raw verifier baseline {profile_name}",
            )
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    preemption = contention.get("preemption") or {}
    preemption_delta = preemption.get("preemptions_delta")
    if (
        "vllm_preemption" in paths
        and not (
            preemption.get("valid") is True
            and isinstance(preemption_delta, (int, float))
            and not isinstance(preemption_delta, bool)
            and float(preemption_delta) > 0
        )
    ):
        raise SystemExit(f"raw verifier preemption evidence is invalid: {profile_name}")


def validate_cli_bindings(
    report: dict[str, Any],
    *,
    run_kind: str,
    gateway_tree_sha256: str,
    controller_image_id: str,
) -> None:
    """Cross-check author labels against trusted raw-verifier provenance."""

    if "run_kind" in report and report.get("run_kind") != run_kind:
        raise SystemExit("raw verifier run_kind does not match --run-kind")
    benchmark = report.get("benchmark")
    lifecycle = benchmark.get("candidate_lifecycle") if isinstance(benchmark, dict) else None
    seal = lifecycle.get("network_egress_seal") if isinstance(lifecycle, dict) else None
    if (
        not isinstance(seal, dict)
        or seal.get("schema_version") != NETWORK_EGRESS_SEAL_SCHEMA_VERSION
        or seal.get("protocol") != NETWORK_EGRESS_SEAL_PROTOCOL
        or seal.get("sealed") is not True
    ):
        raise SystemExit("raw verifier report lacks the trusted controller-image seal")
    attested_controller_image_id = require_sha256(
        seal.get("controller_image_id"),
        "benchmark candidate_lifecycle.network_egress_seal.controller_image_id",
        docker_image_id=True,
    )
    if attested_controller_image_id != controller_image_id:
        raise SystemExit(
            "raw verifier attested controller image ID does not match --controller-image-id"
        )

    artifacts = report.get("artifacts")
    if not isinstance(artifacts, dict):
        raise SystemExit("raw verifier artifacts must be an object")
    if artifacts.get("bench_controller_image_id") != attested_controller_image_id:
        raise SystemExit("raw verifier controller image artifact disagrees with its trusted seal")
    raw_tree_sha256 = artifacts.get("reference_gateway_tree_sha256")
    if raw_tree_sha256 is not None and raw_tree_sha256 != gateway_tree_sha256:
        raise SystemExit(
            "raw verifier reference tree digest does not match --gateway-tree-sha256"
        )
    if run_kind == "oracle":
        try:
            expected_gateway_tree_sha256 = reference_gateway_tree_sha256()
        except OSError as exc:
            raise SystemExit(f"cannot hash frozen Oracle reference tree: {exc}") from exc
        if gateway_tree_sha256 != expected_gateway_tree_sha256:
            raise SystemExit(
                "--gateway-tree-sha256 does not identify the frozen Oracle reference tree"
            )


def _finite_number(value: Any, field: str) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
    ):
        raise SystemExit(f"raw verifier {field} must be a finite number")
    return float(value)


def validate_public_fixed_window_quality(leg: dict[str, Any], name: str) -> None:
    """Recompute the documented public quality floors from raw leg fields."""

    window = leg.get("measurement_window")
    if not isinstance(window, dict):
        raise SystemExit(f"raw public Oracle {name} leg has no measurement window")
    valid_step_ratio = _finite_number(
        leg.get("valid_step_ratio"), f"public {name} valid_step_ratio"
    )
    zero_progress = _finite_number(
        window.get("zero_progress_fraction"),
        f"public {name} zero_progress_fraction",
    )
    request_success = _finite_number(
        leg.get("request_success_rate"), f"public {name} request_success_rate"
    )
    if not (
        PUBLIC_MIN_VALID_STEP_RATIO <= valid_step_ratio <= 1.0
        and 0.0 <= zero_progress <= PUBLIC_MAX_ZERO_PROGRESS_FRACTION
        and PUBLIC_MIN_REQUEST_SUCCESS_RATE <= request_success <= 1.0
    ):
        raise SystemExit(
            f"raw public Oracle {name} leg failed an exact fixed-window quality floor"
        )


def validate_oracle_identity_and_performance(
    benchmark: dict[str, Any],
    *,
    run_kind: str,
    release_id: str,
    reference_submission_sha256_value: str,
    scoring_policy: dict[str, Any],
) -> None:
    """Bind an Oracle label to both reference bytes and reference performance.

    The exporter CLI is author-controlled metadata, while candidate_lifecycle
    is produced by the trusted verifier from the frozen submission directory.
    Requiring their digest equality prevents a normal passing candidate report
    from being re-exported as an Oracle report by changing only --run-kind.
    """

    if run_kind != "oracle":
        return
    if scoring_policy.get("release_id") != release_id:
        raise SystemExit("frozen scoring policy release_id does not match --release-id")
    if benchmark.get("policy_contract_sha256") != policy_contract_sha256(scoring_policy):
        raise SystemExit("raw verifier policy contract does not match frozen scoring policy")

    lifecycle = benchmark.get("candidate_lifecycle")
    if (
        not isinstance(lifecycle, dict)
        or lifecycle.get("schema_version") != 1
        or lifecycle.get("frozen_submission_sha256")
        != reference_submission_sha256_value
    ):
        raise SystemExit(
            "raw Oracle candidate lifecycle does not identify the frozen reference submission"
        )

    configured = scoring_policy.get("hidden_profiles")
    if not isinstance(configured, list) or not configured:
        raise SystemExit("frozen scoring policy has no hidden profiles")
    expected: dict[str, float] = {}
    for entry in configured:
        if not isinstance(entry, dict) or not isinstance(entry.get("name"), str):
            raise SystemExit("frozen scoring policy hidden profile structure is invalid")
        name = entry["name"]
        if not name or name in expected:
            raise SystemExit("frozen scoring policy hidden profile names are invalid")
        reference = _finite_number(
            entry.get("reference_speedup"),
            f"scoring policy reference_speedup for {name}",
        )
        if reference <= 0:
            raise SystemExit(f"frozen scoring policy reference_speedup is invalid: {name}")
        expected[name] = reference

    profiles = benchmark.get("profiles")
    if not isinstance(profiles, dict) or set(profiles) != set(expected):
        raise SystemExit("raw Oracle hidden profile set does not match frozen scoring policy")
    for name, expected_reference in expected.items():
        profile = profiles[name]
        if not isinstance(profile, dict):
            raise SystemExit(f"raw Oracle profile is malformed: {name}")
        speedup = _finite_number(profile.get("speedup"), f"speedup for {name}")
        observed_reference = _finite_number(
            profile.get("reference_speedup"), f"reference_speedup for {name}"
        )
        performance = _finite_number(
            profile.get("performance_score"), f"performance_score for {name}"
        )
        if observed_reference != expected_reference:
            raise SystemExit(f"raw Oracle reference_speedup drift: {name}")
        if speedup <= 1.0 or speedup < expected_reference:
            raise SystemExit(
                f"raw Oracle did not beat baseline and frozen reference: {name}"
            )
        if performance != 1.0:
            raise SystemExit(f"raw Oracle performance_score is not one: {name}")
    if _finite_number(
        benchmark.get("performance_score"), "benchmark performance_score"
    ) != 1.0:
        raise SystemExit("raw Oracle aggregate performance_score is not one")


def _nonnegative_integer(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise SystemExit(f"{field} must be a non-negative integer")
    return value


def validate_v5_tier_health(
    health: Any,
    *,
    expected_tree_sha256: str,
    label: str,
) -> dict[str, Any]:
    """Validate and select the exact v5 identity, cutover, and tier counters."""

    if not isinstance(health, dict):
        raise SystemExit(f"{label} health observation is not an object")
    if (
        health.get("status") != "ok"
        or health.get("oracle") != "thunderagent-extracted"
        or health.get("thunderagent_source_commit") != THUNDERAGENT_SOURCE_COMMIT
        or health.get("reference_gateway_tree_sha256_at_start")
        != expected_tree_sha256
    ):
        raise SystemExit(f"{label} does not identify the frozen Oracle tree")
    scheduler = health.get("scheduler")
    if not isinstance(scheduler, dict):
        raise SystemExit(f"{label} has no scheduler observation")
    policy = {key: scheduler.get(key) for key in EXPECTED_V5_TIER_POLICY}
    if policy != EXPECTED_V5_TIER_POLICY:
        raise SystemExit(f"{label} does not identify the exact v5 tier policy")
    counters = scheduler.get("counters")
    if not isinstance(counters, dict):
        raise SystemExit(f"{label} has no scheduler counters")
    signals: dict[str, int] = {}
    for selected_name, (container, source_name) in DEEP_SIGNAL_PATHS.items():
        source = counters if container == "counters" else scheduler
        signals[selected_name] = _nonnegative_integer(
            source.get(source_name), f"{label} {source_name}"
        )
    mixed_ticks = _nonnegative_integer(
        counters.get("mixed_request_tier_ticks"),
        f"{label} mixed_request_tier_ticks",
    )
    return {
        "policy": policy,
        "deep_signals": signals,
        "mixed_request_tier_ticks": mixed_ticks,
    }


def validate_hidden_oracle_tier_qualification(
    report: dict[str, Any],
    benchmark: dict[str, Any],
    *,
    expected_tree_sha256: str,
) -> dict[str, Any]:
    """Require the sole fresh candidate epoch to exhibit every deep-tier signal."""

    profiles = benchmark.get("profiles")
    if not isinstance(profiles, dict) or set(profiles) != {HIDDEN_ORACLE_PROFILE}:
        raise SystemExit("raw Oracle tier evidence must use the one frozen hidden profile")
    profile = profiles[HIDDEN_ORACLE_PROFILE]
    _legs, order, candidate_ordinal = validate_formal_profile_pair(
        profile, HIDDEN_ORACLE_PROFILE
    )

    lifecycle = benchmark.get("candidate_lifecycle")
    epochs = lifecycle.get("epochs") if isinstance(lifecycle, dict) else None
    if (
        not isinstance(lifecycle, dict)
        or lifecycle.get("schema_version") != 1
        or lifecycle.get("epoch_count") != 2
        or lifecycle.get("candidate_process_epoch_count") != 1
        or not isinstance(epochs, list)
        or len(epochs) != 2
        or [epoch.get("mode") for epoch in epochs if isinstance(epoch, dict)]
        != list(order)
        or [epoch.get("leg_ordinal") for epoch in epochs if isinstance(epoch, dict)]
        != [1, 2]
    ):
        raise SystemExit("raw Oracle candidate lifecycle is not one fresh committed pair")
    candidate_identity = epochs[candidate_ordinal - 1].get(
        "gateway_process_identity_sha256"
    )
    if (
        not isinstance(candidate_identity, str)
        or SHA256_PATTERN.fullmatch(candidate_identity) is None
    ):
        raise SystemExit("raw Oracle hidden candidate leg lacks a fresh gateway epoch")

    checks = report.get("checks")
    post_leg = checks.get("candidate_post_leg_health") if isinstance(checks, dict) else None
    observations = post_leg.get("observations") if isinstance(post_leg, dict) else None
    if (
        not isinstance(post_leg, dict)
        or post_leg.get("schema_version") != 1
        or not isinstance(observations, dict)
        or set(observations) != {str(candidate_ordinal)}
    ):
        raise SystemExit("raw Oracle report lacks its sole hidden candidate health observation")

    observation = observations[str(candidate_ordinal)]
    if (
        not isinstance(observation, dict)
        or observation.get("schema_version") != 1
        or observation.get("leg_ordinal") != candidate_ordinal
        or observation.get("capture_status") != "ok"
        or observation.get("http_status") != 200
        or isinstance(observation.get("response_bytes"), bool)
        or not isinstance(observation.get("response_bytes"), int)
        or not 0 < observation["response_bytes"] <= 64 * 1024
    ):
        raise SystemExit("raw Oracle hidden candidate health capture is invalid")
    qualified = validate_v5_tier_health(
        observation.get("selected"),
        expected_tree_sha256=expected_tree_sha256,
        label="raw Oracle hidden candidate",
    )
    if any(value <= 0 for value in qualified["deep_signals"].values()):
        raise SystemExit(
            "raw Oracle hidden candidate did not activate every deep-tier signal"
        )
    return {
        "profile": HIDDEN_ORACLE_PROFILE,
        "leg_order_protocol": FINAL_LEG_ORDER_PROTOCOL,
        "leg_order": list(order),
        "candidate_leg_ordinal": candidate_ordinal,
        "candidate_process_epoch_count": 1,
        "observation": {
            "leg_ordinal": candidate_ordinal,
            **qualified,
        },
    }


def validate_public_oracle_pair(
    public_pair: dict[str, Any],
    benchmark: dict[str, Any],
    *,
    expected_tree_sha256: str,
    expected_controller_image_id: str,
    expected_release_id: str,
) -> dict[str, Any]:
    """Bind a passed raw 1800-second public pair to the formal hidden run."""

    if (
        public_pair.get("schema_version") != 1
        or public_pair.get("kind") != "isolated-reference-thunderagent-pair"
        or public_pair.get("status") != "complete"
        or public_pair.get("passed") is not True
        or public_pair.get("errors") != []
        or public_pair.get("suite") != "public"
        or public_pair.get("profile") != PUBLIC_ORACLE_PROFILE
        or public_pair.get("order")
        != ["direct_baseline", "fresh_thunderagent_oracle"]
        or public_pair.get("reference_gateway_tree_sha256") != expected_tree_sha256
        or public_pair.get("thunderagent_source_commit") != THUNDERAGENT_SOURCE_COMMIT
    ):
        raise SystemExit("raw public Oracle pair is not the frozen passed public run")
    controller = public_pair.get("controller")
    readiness = public_pair.get("controller_readiness")
    if (
        not isinstance(controller, dict)
        or controller.get("image_id") != expected_controller_image_id
        or not isinstance(readiness, dict)
        or readiness.get("release_id") != expected_release_id
        or readiness.get("controller_config_sha256")
        != benchmark.get("controller_config_sha256")
        or readiness.get("policy_contract_sha256")
        != benchmark.get("policy_contract_sha256")
        or readiness.get("corpus_manifest_sha256")
        != benchmark.get("corpus_manifest_sha256")
    ):
        raise SystemExit("raw public Oracle pair controller/release provenance drifted")

    legs = public_pair.get("legs")
    if not isinstance(legs, dict) or set(legs) != {"baseline", "candidate"}:
        raise SystemExit("raw public Oracle pair must contain exact direct/candidate legs")
    nonce_sha256 = public_pair.get("workload_nonce_sha256")
    if not isinstance(nonce_sha256, str) or SHA256_PATTERN.fullmatch(nonce_sha256) is None:
        raise SystemExit("raw public Oracle pair workload nonce digest is invalid")
    for name, expected_mode in (("baseline", "baseline"), ("candidate", "candidate")):
        leg = legs[name]
        config = leg.get("profile_config") if isinstance(leg, dict) else None
        window = leg.get("measurement_window") if isinstance(leg, dict) else None
        if (
            not isinstance(leg, dict)
            or leg.get("mode") != expected_mode
            or leg.get("profile") != PUBLIC_ORACLE_PROFILE
            or leg.get("release_id") != expected_release_id
            or leg.get("controller_config_sha256")
            != benchmark.get("controller_config_sha256")
            or leg.get("model_provenance") != benchmark.get("model_provenance")
            or leg.get("workload_nonce_sha256") != nonce_sha256
            or not isinstance(config, dict)
            or config.get("name") != PUBLIC_ORACLE_PROFILE
            or config.get("measurement_window_sec") != PUBLIC_MEASUREMENT_WINDOW_SEC
            or config.get("workflows") != 192
            or config.get("concurrency") != 192
            or config.get("max_steps") != 24
            or config.get("corpus_partition") != "public"
            or not isinstance(window, dict)
            or window.get("schema_version") != 1
            or window.get("configured") is not True
            or window.get("duration_sec") != PUBLIC_MEASUREMENT_WINDOW_SEC
            or window.get("deadline_reached") is not True
            or window.get("termination") != "trusted_fixed_window"
            or window.get("control_passed") is not True
            or window.get("passed") is not True
            or "agent_execution_interval" in leg
        ):
            raise SystemExit(f"raw public Oracle {name} leg is not exact fixed-1800")
        if (
            _finite_number(
                window.get("measurement_elapsed_sec"),
                f"public {name} measurement_elapsed_sec",
            )
            != float(PUBLIC_MEASUREMENT_WINDOW_SEC)
            or _finite_number(leg.get("elapsed_sec"), f"public {name} elapsed_sec")
            != float(PUBLIC_MEASUREMENT_WINDOW_SEC)
        ):
            raise SystemExit(f"raw public Oracle {name} timing is not exact fixed-1800")
        validate_public_fixed_window_quality(leg, name)

    evaluation = public_pair.get("evaluation")
    contracts = evaluation.get("contracts") if isinstance(evaluation, dict) else None
    effect = evaluation.get("effect") if isinstance(evaluation, dict) else None
    if (
        not isinstance(evaluation, dict)
        or evaluation.get("passed") is not True
        or evaluation.get("contracts_passed") is not True
        or evaluation.get("quality_passed") is not True
        or not isinstance(contracts, dict)
        or not contracts
        or any(value is not True for value in contracts.values())
        or contracts.get("oracle_deep_tier_matches_measurement_shape") is not True
        or not isinstance(effect, dict)
        or effect.get("passed") is not True
        or _finite_number(effect.get("minimum_speedup"), "public minimum_speedup") < 1.0
        or _finite_number(effect.get("speedup"), "public speedup") <= 1.0
    ):
        raise SystemExit("raw public Oracle pair did not pass every pair contract")

    lifecycle = public_pair.get("lifecycle")
    health = lifecycle.get("gateway_health_after_candidate") if isinstance(lifecycle, dict) else None
    qualified = validate_v5_tier_health(
        health,
        expected_tree_sha256=expected_tree_sha256,
        label="raw public Oracle candidate",
    )
    if (
        any(value <= 0 for value in qualified["deep_signals"].values())
        or qualified["mixed_request_tier_ticks"] <= 0
    ):
        raise SystemExit("raw public Oracle candidate did not exercise both scheduling tiers")
    return {
        "profile": PUBLIC_ORACLE_PROFILE,
        "measurement_window_sec": PUBLIC_MEASUREMENT_WINDOW_SEC,
        "passed": True,
        "policy": qualified["policy"],
        "deep_signals": qualified["deep_signals"],
        "mixed_request_tier_ticks": qualified["mixed_request_tier_ticks"],
        "release_id": expected_release_id,
        "controller_config_sha256": benchmark["controller_config_sha256"],
        "model_provenance": benchmark["model_provenance"],
        "reference_gateway_tree_sha256": expected_tree_sha256,
        "bench_controller_image_id": expected_controller_image_id,
    }


def validate_public_direct_anchor(
    anchor: dict[str, Any],
    *,
    anchor_raw: bytes,
    public_pair: dict[str, Any],
    public_pair_raw: bytes,
    benchmark: dict[str, Any],
    scoring_policy: dict[str, Any],
    expected_controller_image_id: str,
    expected_release_id: str,
) -> dict[str, Any]:
    """Validate the private reusable Direct anchor and emit only safe bindings."""

    expected_keys = {
        "schema_version",
        "kind",
        "created_at_utc",
        "release_id",
        "policy_release_id",
        "suite",
        "profile",
        "workload_nonce",
        "workload_nonce_sha256",
        "baseline_run_id",
        "baseline",
        "source_report_sha256",
        "scoring_policy_sha256",
        "controller_config_sha256",
        "controller_image_id",
        "corpus_namespace",
        "corpus_fingerprint",
        "model_provenance",
        "model_provenance_sha256",
    }
    if set(anchor) != expected_keys:
        raise SystemExit("private public Direct anchor fields drifted")
    pair_baseline = (public_pair.get("legs") or {}).get("baseline")
    pair_candidate = (public_pair.get("legs") or {}).get("candidate")
    workload_nonce = anchor.get("workload_nonce")
    workload_nonce_sha256 = anchor.get("workload_nonce_sha256")
    source_report_sha256 = hashlib.sha256(public_pair_raw).hexdigest()
    scoring_policy_sha256 = hashlib.sha256(SCORING_POLICY.read_bytes()).hexdigest()
    model_provenance = benchmark.get("model_provenance")
    if (
        anchor.get("schema_version") != 1
        or anchor.get("kind") != PUBLIC_DIRECT_ANCHOR_KIND
        or anchor.get("release_id") != expected_release_id
        or anchor.get("policy_release_id") != expected_release_id
        or scoring_policy.get("release_id") != expected_release_id
        or anchor.get("suite") != "public"
        or anchor.get("profile") != PUBLIC_ORACLE_PROFILE
        or not isinstance(workload_nonce, str)
        or not workload_nonce
        or hashlib.sha256(workload_nonce.encode()).hexdigest()
        != workload_nonce_sha256
        or public_pair.get("workload_nonce_sha256") != workload_nonce_sha256
        or anchor.get("source_report_sha256") != source_report_sha256
        or anchor.get("scoring_policy_sha256") != scoring_policy_sha256
        or not isinstance(pair_baseline, dict)
        or not isinstance(pair_candidate, dict)
        or anchor.get("baseline") != pair_baseline
        or anchor.get("baseline_run_id") != pair_baseline.get("run_id")
        or anchor.get("controller_config_sha256")
        != benchmark.get("controller_config_sha256")
        or pair_baseline.get("controller_config_sha256")
        != anchor.get("controller_config_sha256")
        or pair_candidate.get("controller_config_sha256")
        != anchor.get("controller_config_sha256")
        or anchor.get("controller_image_id") != expected_controller_image_id
        or (public_pair.get("controller") or {}).get("image_id")
        != expected_controller_image_id
        or anchor.get("corpus_namespace") != pair_baseline.get("corpus_namespace")
        or pair_candidate.get("corpus_namespace") != anchor.get("corpus_namespace")
        or anchor.get("corpus_fingerprint") != pair_baseline.get("corpus_fingerprint")
        or pair_candidate.get("corpus_fingerprint")
        != anchor.get("corpus_fingerprint")
        or anchor.get("model_provenance") != model_provenance
        or pair_baseline.get("model_provenance") != model_provenance
        or pair_candidate.get("model_provenance") != model_provenance
        or anchor.get("model_provenance_sha256")
        != canonical_object_sha256(model_provenance)
    ):
        raise SystemExit("private public Direct anchor bindings are invalid")
    baseline_sha256 = canonical_object_sha256(pair_baseline)
    return {
        "schema_version": 1,
        "kind": PUBLIC_DIRECT_ANCHOR_KIND,
        "sha256": hashlib.sha256(anchor_raw).hexdigest(),
        "bytes": len(anchor_raw),
        "release_id": expected_release_id,
        "profile": PUBLIC_ORACLE_PROFILE,
        "source_report_sha256": source_report_sha256,
        "scoring_policy_sha256": scoring_policy_sha256,
        "baseline_sha256": baseline_sha256,
        "controller_config_sha256": benchmark["controller_config_sha256"],
        "controller_image_id": expected_controller_image_id,
        "corpus_fingerprint": anchor["corpus_fingerprint"],
        "model_provenance_sha256": canonical_object_sha256(model_provenance),
    }


def selected_counters(leg: dict[str, Any]) -> dict[str, float]:
    return {
        sample["name"]: float(sample["delta"])
        for sample in leg.get("vllm_metrics", {}).get("counter_deltas", [])
        if sample.get("name") in SELECTED_COUNTERS
        and sample.get("labels", "") in ("", 'engine="0",model_name="target-model"')
    }


def clean_audit(audit: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in audit.items() if key != "mismatches"}


def clean_isolation(isolation: object) -> dict[str, bool]:
    value = isolation if isinstance(isolation, dict) else {}
    capabilities = value.get("candidate_capabilities")
    return {
        "passed": bool(
            value.get("forbidden_paths_present") == []
            and value.get("gpu_devices") == []
            and value.get("candidate_can_read_admin_token") is False
            and capabilities
            == {
                "permitted": "0000000000000000",
                "effective": "0000000000000000",
                "no_new_privs": "1",
            }
        )
    }


def clean_protocol(protocol: object) -> dict[str, Any]:
    value = protocol if isinstance(protocol, dict) else {}
    projected: dict[str, Any] = {
        "passed": value.get("passed") is True,
        "cancelled_backend_request_observed": (
            value.get("cancelled_backend_request_observed") is True
        ),
    }
    for key in ("expected_backend_requests", "observed_backend_requests"):
        count = value.get(key)
        if isinstance(count, int) and not isinstance(count, bool) and 0 <= count <= 1_000_000:
            projected[key] = count
    return projected


def recompute_hidden_tail_anti_gaming(
    benchmark: dict[str, Any], scoring_policy: dict[str, Any]
) -> dict[str, Any]:
    """Recompute the scalar p99-step gate from each committed formal pair."""

    maximum_allowed_ratio = _finite_number(
        scoring_policy.get("max_p99_step_latency_ratio"),
        "scoring policy max_p99_step_latency_ratio",
    )
    if maximum_allowed_ratio <= 1.0:
        raise SystemExit(
            "scoring policy max_p99_step_latency_ratio must be greater than one"
        )
    if benchmark.get("policy_contract_sha256") != policy_contract_sha256(
        scoring_policy
    ):
        raise SystemExit("raw verifier policy contract does not match frozen scoring policy")
    configured = scoring_policy.get("hidden_profiles")
    if not isinstance(configured, list) or not configured:
        raise SystemExit("frozen scoring policy has no hidden profiles")
    expected_names = [
        entry.get("name") if isinstance(entry, dict) else None for entry in configured
    ]
    if (
        any(not isinstance(name, str) or not name for name in expected_names)
        or len(set(expected_names)) != len(expected_names)
    ):
        raise SystemExit("frozen scoring policy hidden profile names are invalid")
    profiles = benchmark.get("profiles")
    if not isinstance(profiles, dict) or set(profiles) != set(expected_names):
        raise SystemExit("raw verifier hidden profile set does not match scoring policy")

    reports: dict[str, Any] = {}
    for name in expected_names:
        profile = profiles[name]
        legs, order, _candidate_ordinal = validate_formal_profile_pair(profile, name)
        baseline_value = _finite_number(
            legs[order.index("baseline")].get("p99_step_latency_sec"),
            f"{name} baseline p99_step_latency_sec",
        )
        candidate_value = _finite_number(
            legs[order.index("candidate")].get("p99_step_latency_sec"),
            f"{name} candidate p99_step_latency_sec",
        )
        if baseline_value <= 0.0 or candidate_value <= 0.0:
            raise SystemExit(f"raw verifier p99 step latency is not positive: {name}")
        ratio = candidate_value / baseline_value
        recomputed = {
            "schema_version": 2,
            "metric": "p99_step_latency_sec",
            "pairing": "candidate_over_baseline:single_committed_pair",
            "baseline_p99_step_latency_sec": baseline_value,
            "candidate_p99_step_latency_sec": candidate_value,
            "ratio": ratio,
            "maximum_allowed_ratio": maximum_allowed_ratio,
            "passed": ratio <= maximum_allowed_ratio,
        }
        if profile.get("tail_anti_gaming") != recomputed:
            raise SystemExit(
                f"raw verifier declared p99 step tail report disagrees with legs: {name}"
            )
        if not recomputed["passed"]:
            raise SystemExit(
                f"raw verifier single-pair p99 step tail exceeded policy: {name}"
            )
        reports[name] = recomputed
    return {
        "schema_version": 2,
        "metric": "p99_step_latency_sec",
        "pairing": "candidate_over_baseline:single_committed_pair",
        "maximum_allowed_ratio": maximum_allowed_ratio,
        "all_profiles_passed": True,
        "profiles": reports,
    }


def clean_leg(leg: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "mode",
        "run_id",
        "started_unix",
        "ended_unix",
        "elapsed_sec",
        "wall_elapsed_sec",
        "valid_steps",
        "valid_step_ratio",
        "valid_steps_per_min",
        "request_count",
        "request_success_rate",
        "minimum_workflow_progress",
        "backend_tokens_per_valid_step",
        "p95_query_latency_sec",
        "p99_query_latency_sec",
        "p95_tool_latency_sec",
        "p99_tool_latency_sec",
        "p95_step_latency_sec",
        "p99_step_latency_sec",
        "model_query_time_fraction",
        "p95_ttft_sec",
        "p99_ttft_sec",
        "corpus_fingerprint",
    )
    return {
        **{key: leg.get(key) for key in keys},
        "agent_execution_interval": leg.get("agent_execution_interval"),
        "measurement_window": leg.get("measurement_window"),
        "profile_config": leg.get("profile_config"),
        "backend_audit": clean_audit(leg.get("backend_audit", {})),
        "warmup_audit": clean_audit(leg.get("warmup_audit", {})),
        "pressure_validation": leg.get("pressure_validation"),
        "selected_vllm_counter_deltas": selected_counters(leg),
    }


def clean_attestation(attestation: dict[str, Any]) -> dict[str, Any]:
    return publishable_model_runtime_identity(attestation)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument(
        "--public-pair-input",
        type=Path,
        help=(
            "raw formal public run-reference-pair report; required only for "
            "--run-kind oracle"
        ),
    )
    parser.add_argument(
        "--public-direct-anchor-input",
        type=Path,
        help=(
            "private public Direct anchor emitted beside the formal public pair; "
            "required only for --run-kind oracle"
        ),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-kind", required=True, choices=("oracle", "frozen-candidate"))
    parser.add_argument("--gateway-tree-sha256", required=True)
    parser.add_argument("--controller-image-id", required=True)
    parser.add_argument("--release-id", required=True)
    parser.add_argument("--model-profile-sha256", required=True)
    args = parser.parse_args()
    if not args.release_id or args.release_id.startswith("development"):
        raise SystemExit("--release-id must be a non-development release ID")
    if not SHA256_PATTERN.fullmatch(args.model_profile_sha256):
        raise SystemExit("--model-profile-sha256 must be a lowercase SHA-256 digest")
    if not SHA256_PATTERN.fullmatch(args.gateway_tree_sha256):
        raise SystemExit("--gateway-tree-sha256 must be a lowercase SHA-256 digest")
    if not DOCKER_IMAGE_ID_PATTERN.fullmatch(args.controller_image_id):
        raise SystemExit("--controller-image-id must be a Docker SHA-256 image ID")
    if args.run_kind == "oracle" and args.public_pair_input is None:
        raise SystemExit("--public-pair-input is required for Oracle evidence")
    if args.run_kind == "oracle" and args.public_direct_anchor_input is None:
        raise SystemExit("--public-direct-anchor-input is required for Oracle evidence")
    if args.run_kind != "oracle" and args.public_pair_input is not None:
        raise SystemExit("--public-pair-input is only valid for Oracle evidence")
    if args.run_kind != "oracle" and args.public_direct_anchor_input is not None:
        raise SystemExit("--public-direct-anchor-input is only valid for Oracle evidence")

    raw = args.input.read_bytes()
    report = json.loads(raw)
    if not isinstance(report, dict):
        raise SystemExit("full-verifier input must be a JSON object")
    benchmark = validate_qwen_provenance(report, args.release_id, args.model_profile_sha256)
    validate_cli_bindings(
        report,
        run_kind=args.run_kind,
        gateway_tree_sha256=args.gateway_tree_sha256,
        controller_image_id=args.controller_image_id,
    )
    try:
        reference_submission_digest = reference_submission_sha256()
    except OSError as exc:
        raise SystemExit(f"cannot hash frozen Oracle submission: {exc}") from exc
    scoring_policy = load_scoring_policy()
    tail_anti_gaming = recompute_hidden_tail_anti_gaming(
        benchmark, scoring_policy
    )
    validate_oracle_identity_and_performance(
        benchmark,
        run_kind=args.run_kind,
        release_id=args.release_id,
        reference_submission_sha256_value=reference_submission_digest,
        scoring_policy=scoring_policy,
    )
    tier_qualification: dict[str, Any] | None = None
    public_pair_raw: bytes | None = None
    public_direct_anchor_binding: dict[str, Any] | None = None
    if args.run_kind == "oracle":
        assert args.public_pair_input is not None
        assert args.public_direct_anchor_input is not None
        public_pair, public_pair_raw = load_bounded_regular_json(
            args.public_pair_input,
            "raw public Oracle pair",
        )
        public_direct_anchor, public_direct_anchor_raw = load_bounded_regular_json(
            args.public_direct_anchor_input,
            "private public Direct anchor",
        )
        public_direct_anchor_binding = validate_public_direct_anchor(
            public_direct_anchor,
            anchor_raw=public_direct_anchor_raw,
            public_pair=public_pair,
            public_pair_raw=public_pair_raw,
            benchmark=benchmark,
            scoring_policy=scoring_policy,
            expected_controller_image_id=args.controller_image_id,
            expected_release_id=args.release_id,
        )
        tier_qualification = {
            "schema_version": 2,
            "reference_gateway_tree_sha256": args.gateway_tree_sha256,
            "policy": dict(EXPECTED_V5_TIER_POLICY),
            "public": validate_public_oracle_pair(
                public_pair,
                benchmark,
                expected_tree_sha256=args.gateway_tree_sha256,
                expected_controller_image_id=args.controller_image_id,
                expected_release_id=args.release_id,
            ),
            "hidden": validate_hidden_oracle_tier_qualification(
                report,
                benchmark,
                expected_tree_sha256=args.gateway_tree_sha256,
            ),
        }
    profiles: dict[str, Any] = {}
    for name, profile in (benchmark.get("profiles") or {}).items():
        profiles[name] = {
            **{key: value for key, value in profile.items() if key != "legs"},
            "legs": [clean_leg(leg) for leg in profile.get("legs", [])],
        }

    checks = report.get("checks") or {}
    protocol = checks.get("protocol") or {}
    real_protocol = checks.get("real_protocol_audit") or {}
    output = {
        "schema_version": 2,
        "kind": "sanitized-full-verifier-evidence",
        "release_id": args.release_id,
        "model_profile_sha256": args.model_profile_sha256,
        "corpus_manifest_sha256": benchmark["corpus_manifest_sha256"],
        "status": "complete",
        "errors": [],
        "run_kind": args.run_kind,
        "observed_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "raw_private_report": {
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
        },
        **(
            {
                "raw_public_pair": {
                    "sha256": hashlib.sha256(public_pair_raw).hexdigest(),
                    "bytes": len(public_pair_raw),
                },
                "public_direct_anchor": public_direct_anchor_binding,
                "tier_qualification": tier_qualification,
            }
            if args.run_kind == "oracle"
            else {}
        ),
        "artifacts": {
            "reference_gateway_tree_sha256": args.gateway_tree_sha256,
            "reference_submission_sha256": reference_submission_digest,
            "bench_controller_image_id": args.controller_image_id,
        },
        "verifier": {
            key: report.get(key)
            for key in ("reward", "correctness", "backend_audit", "infra_valid", "error")
        },
        "checks": {
            "isolation": clean_isolation(checks.get("isolation")),
            "attestation": clean_attestation(checks.get("attestation") or {}),
            "protocol": clean_protocol(protocol),
            "real_protocol_audit": {
                "passed": real_protocol.get("passed"),
                "request_count": len(real_protocol.get("requests", [])),
                "methods": [item.get("method") for item in real_protocol.get("requests", [])],
                "statuses": [item.get("status") for item in real_protocol.get("requests", [])],
            },
        },
        "tail_anti_gaming": tail_anti_gaming,
        "benchmark": {
            **{
                key: value
                for key, value in benchmark.items()
                if key not in {"profiles", "suite_nonce_sha256"}
            },
            "profiles": profiles,
        },
    }
    output["passed"] = bool(
        report.get("correctness") == 1.0
        and report.get("backend_audit") == 1.0
        and report.get("infra_valid") == 1.0
        and benchmark.get("hard_gates_passed") is True
        and benchmark.get("status") == "ok"
        and float(report.get("reward", 0.0)) > 0
    )
    try:
        reject_private_runtime_identity(output, "sanitized full-verifier evidence")
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    rendered = json.dumps(output, indent=2, sort_keys=True) + "\n"
    atomic_write_new(args.output, rendered)
    print(rendered, end="")
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
