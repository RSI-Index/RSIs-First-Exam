#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_dir="$(cd -- "$script_dir/.." && pwd)"

if ! docker info >/dev/null 2>&1; then
  if [[ "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" == 1 ]]; then
    echo "Docker remains unavailable after entering the docker group" >&2
    exit 2
  fi
  printf -v reexec 'KV_TASK_DOCKER_GROUP_REEXEC=1 exec %q' "$0"
  exec sg docker -c "$reexec"
fi

main_image="harbor-kv/main:qwen36-27b-tp2-public30-r2"
model_api_image="harbor-kv/model-api:qwen36-27b-tp2-public30-r2"
docker image inspect "$main_image" "$model_api_image" >/dev/null

docker run --rm --network none \
  --volume "$task_dir:/workspace:ro" \
  --workdir /workspace \
  --entrypoint python3 \
  "$main_image" \
  author_tests/loopback_bridge_integration.py

docker run --rm --network none \
  --volume "$task_dir:/workspace:ro" \
  --volume "$task_dir/environment/model-api:/opt/model-api:ro" \
  --workdir /workspace \
  --entrypoint python3 \
  "$model_api_image" \
  author_tests/model_api_uds_integration.py
