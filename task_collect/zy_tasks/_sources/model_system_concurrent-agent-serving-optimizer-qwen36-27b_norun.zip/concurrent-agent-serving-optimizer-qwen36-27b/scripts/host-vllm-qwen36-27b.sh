#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
RUNTIME_ASSETS="$TASK_DIR/environment/vllm-runtime"
PROFILE="$RUNTIME_ASSETS/model-profile-qwen3.6-27b.json"
ATTESTATION_HELPER="$SCRIPT_DIR/host-vllm-attestation.py"
PREFLIGHT_HELPER="$SCRIPT_DIR/preflight-host.py"

DEFAULT_MODEL_PATH="/home/yuetaili/.cache/huggingface/hub/models--Qwen--Qwen3.6-27B/snapshots/6a9e13bd6fc8f0983b9b99948120bc37f49c13e9"
MODEL_PATH="${HARBOR_VLLM_MODEL_PATH:-$DEFAULT_MODEL_PATH}"
RUNTIME_DIR="${HARBOR_VLLM_RUNTIME_DIR:-/tmp/harbor-kv-qwen36-27b-${UID}}"
IMAGE_REF="harbor-kv/vllm-qwen36-27b-h100:host-r1"
HEALTH_TIMEOUT_SECONDS="${HARBOR_VLLM_HEALTH_TIMEOUT_SECONDS:-3600}"

# These names are part of the release contract. Keeping them non-configurable
# prevents status/stop from ever selecting an unrelated tmux session/container.
TMUX_SOCKET="harbor-kv-qwen36-27b"
TMUX_SESSION="harbor-kv-qwen36-27b"
CONTAINER_NAME="harbor-kv-qwen36-27b-host"
# The pinned image was originally produced by Compose and carries inherited
# com.docker.compose.* labels. Override the two ownership labels at container
# creation so the calibration project's `down --remove-orphans` can never
# select this standalone model server.
STANDALONE_COMPOSE_PROJECT="harbor-kv-external-qwen36"
STANDALONE_COMPOSE_SERVICE="external-vllm"
LOCK_PATH="/tmp/harbor-kv-qwen36-27b-gpu6-7.lock"
SOCKET_PATH="$RUNTIME_DIR/vllm.sock"
ATTESTATION_PATH="$RUNTIME_DIR/attestation.json"
LOG_PATH="$RUNTIME_DIR/vllm.log"
CONTAINER_PASSWD_PATH="$RUNTIME_DIR/container.passwd"
CONTAINER_GROUP_PATH="$RUNTIME_DIR/container.group"
ORIGINAL_ARGUMENTS=("$@")

usage() {
  cat <<'EOF'
Usage: scripts/host-vllm-qwen36-27b.sh ACTION

Actions:
  preflight   Validate the pinned snapshot, image, host, and idle GPUs only
  start       Start the external Docker vLLM in a private tmux server and wait
  status      Verify attested process/container ownership and UDS health
  stop        Stop only the exact attested container and tmux pane
  logs        Print the persistent vLLM log path and recent log lines

Environment:
  HARBOR_VLLM_RUNTIME_DIR            Host directory exported to Harbor Compose
  HARBOR_VLLM_MODEL_PATH             Pinned Qwen3.6-27B snapshot path
  HARBOR_VLLM_HEALTH_TIMEOUT_SECONDS Startup timeout (default: 3600)

The runtime image reference is frozen by the model profile. Setting
HARBOR_VLLM_IMAGE is rejected even when an alternate tag resolves to the same
image ID, because the attestation binds both the reference and content ID.
EOF
}

die() {
  echo "host-vllm-qwen36-27b: $*" >&2
  exit 2
}

require_commands() {
  local name
  for name in docker flock jq python3 tmux curl sha256sum; do
    command -v "$name" >/dev/null 2>&1 || die "missing required command: $name"
  done
}

reexec_in_docker_group() {
  local argument command_part command_string
  local command=(
    env
    KV_HOST_VLLM_DOCKER_GROUP_REEXEC=1
    "HARBOR_VLLM_MODEL_PATH=$MODEL_PATH"
    "HARBOR_VLLM_RUNTIME_DIR=$RUNTIME_DIR"
    "HARBOR_VLLM_HEALTH_TIMEOUT_SECONDS=$HEALTH_TIMEOUT_SECONDS"
    "$0"
    "${ORIGINAL_ARGUMENTS[@]}"
  )
  command_string=""
  for argument in "${command[@]}"; do
    printf -v command_part '%q' "$argument"
    command_string+="${command_string:+ }$command_part"
  done
  exec sg docker -c "$command_string"
}

ensure_docker_access() {
  if docker info >/dev/null 2>&1; then
    return
  fi
  [[ "${KV_HOST_VLLM_DOCKER_GROUP_REEXEC:-0}" != 1 ]] \
    || die "Docker remains unavailable after entering the docker group"
  local user_name
  user_name="$(id -un)"
  getent group docker | awk -F: -v user="$user_name" '
    BEGIN { found=1 }
    { count=split($4,members,","); for(i=1;i<=count;i++) if(members[i]==user) found=0 }
    END { exit found }
  ' || die "Docker is unavailable and $user_name is not listed in the docker group"
  reexec_in_docker_group
}

validate_inputs() {
  [[ -z "${HARBOR_VLLM_IMAGE+x}" ]] \
    || die "HARBOR_VLLM_IMAGE overrides are forbidden; use the exact image reference frozen in the Qwen profile"
  [[ "$MODEL_PATH" == /* ]] || die "HARBOR_VLLM_MODEL_PATH must be absolute"
  [[ "$RUNTIME_DIR" == /* ]] || die "HARBOR_VLLM_RUNTIME_DIR must be absolute"
  [[ "$HEALTH_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]] \
    || die "HARBOR_VLLM_HEALTH_TIMEOUT_SECONDS must be a positive integer"
  [[ -f "$PROFILE" ]] || die "missing Qwen runtime profile: $PROFILE"
  [[ "$IMAGE_REF" == "$(profile_value '.runtime.runtime_image_ref')" ]] \
    || die "launcher image reference differs from the frozen Qwen profile"
  [[ -x "$ATTESTATION_HELPER" ]] || die "attestation helper is not executable: $ATTESTATION_HELPER"
  [[ -f "$PREFLIGHT_HELPER" ]] || die "missing host preflight helper: $PREFLIGHT_HELPER"
  if [[ -e "$RUNTIME_DIR" && -L "$RUNTIME_DIR" ]]; then
    die "runtime directory must not be a symlink: $RUNTIME_DIR"
  fi
}

prepare_runtime_dir() {
  if [[ ! -e "$RUNTIME_DIR" ]]; then
    install -d -m 0755 "$RUNTIME_DIR"
  fi
  [[ -d "$RUNTIME_DIR" && ! -L "$RUNTIME_DIR" ]] \
    || die "runtime path is not a real directory: $RUNTIME_DIR"
  [[ "$(stat -c '%u' "$RUNTIME_DIR")" == "$UID" ]] \
    || die "runtime directory is not owned by uid $UID: $RUNTIME_DIR"
  # model-api runs in a separate user namespace and receives this directory
  # read-only. World traversal is required; candidate containers never mount it.
  chmod 0755 "$RUNTIME_DIR"
  install -d -m 0750 "$RUNTIME_DIR/home" "$RUNTIME_DIR/cache"
  local runtime_gid temporary expected
  runtime_gid="$(stat -c '%g' "$RUNTIME_DIR")"
  expected="kvvllm:x:$UID:$runtime_gid:Harbor Qwen vLLM:/run/kvbench-vllm/home:/usr/sbin/nologin"
  temporary="$(mktemp "$RUNTIME_DIR/.container-passwd.XXXXXX")"
  printf '%s\n' "$expected" >"$temporary"
  chmod 0444 "$temporary"
  mv -f -- "$temporary" "$CONTAINER_PASSWD_PATH"
  expected="kvvllm:x:$runtime_gid:"
  temporary="$(mktemp "$RUNTIME_DIR/.container-group.XXXXXX")"
  printf '%s\n' "$expected" >"$temporary"
  chmod 0444 "$temporary"
  mv -f -- "$temporary" "$CONTAINER_GROUP_PATH"
}

profile_value() {
  jq -er "$1" "$PROFILE"
}

validate_image() {
  local expected_id observed_id observed_version expected_version
  expected_id="$(profile_value '.runtime.runtime_image_id')"
  observed_id="$(docker image inspect --format '{{.Id}}' "$IMAGE_REF" 2>/dev/null)" \
    || die "pinned vLLM image tag is missing: $IMAGE_REF"
  [[ "$observed_id" == "$expected_id" ]] \
    || die "vLLM image ID drift: $observed_id != $expected_id"
  observed_version="$(docker run --rm --network none \
    --entrypoint /usr/local/bin/vllm "$IMAGE_REF" --version 2>/dev/null)" \
    || die "cannot query vLLM version from $IMAGE_REF"
  expected_version="$(profile_value '.runtime.vllm_package_version')"
  [[ "$observed_version" == "$expected_version" ]] \
    || die "vLLM version drift: $observed_version != $expected_version"
  printf '%s\n' "$observed_version"
}

validate_runtime_user() {
  local runtime_gid observed_version expected_version
  runtime_gid="$(stat -c '%g' "$RUNTIME_DIR")"
  observed_version="$(docker run --rm --network none \
    --user "$UID:$runtime_gid" \
    --security-opt no-new-privileges:true \
    --cap-drop ALL \
    --env HOME=/run/kvbench-vllm/home \
    --env XDG_CACHE_HOME=/run/kvbench-vllm/cache \
    --env USER=kvvllm \
    --env LOGNAME=kvvllm \
    --env VLLM_SERVER_DEV_MODE=1 \
    --mount "type=bind,source=$RUNTIME_DIR,target=/run/kvbench-vllm" \
    --mount "type=bind,source=$CONTAINER_PASSWD_PATH,target=/etc/passwd,readonly" \
    --mount "type=bind,source=$CONTAINER_GROUP_PATH,target=/etc/group,readonly" \
    --entrypoint /usr/local/bin/vllm "$IMAGE_REF" --version 2>/dev/null)" \
    || die "pinned vLLM cannot run as the host-owned runtime UID"
  expected_version="$(profile_value '.runtime.vllm_package_version')"
  [[ "$observed_version" == "$expected_version" ]] \
    || die "non-root vLLM version drift: $observed_version != $expected_version"
}

assert_lock_available() {
  local lock_fd
  exec {lock_fd}>"$LOCK_PATH"
  flock -n "$lock_fd" || die "another Qwen/vLLM process owns GPU devices 6 and 7"
  flock -u "$lock_fd"
  exec {lock_fd}>&-
}

run_preflight() {
  local output="$1"
  validate_image >/dev/null
  if docker container inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
    die "reserved container name already exists: $CONTAINER_NAME"
  fi
  python3 "$PREFLIGHT_HELPER" \
    --model-path "$MODEL_PATH" \
    --profile "$PROFILE" \
    --gpu-indices 6,7 \
    --output "$output" >/dev/null
}

do_preflight() {
  local report
  report="$(mktemp --tmpdir host-vllm-qwen36-preflight.XXXXXX.json)"
  assert_lock_available
  run_preflight "$report"
  jq '{status,model_profile_sha256,model,gpus,docker,host_memory_bytes}' "$report"
  rm -f -- "$report"
  echo "Preflight passed. No GPU process or model server was started."
}

attestation_identity_args() {
  local wrapper_pid="$1" container_id="$2" token_sha="$3"
  printf '%s\0' \
    --session "$TMUX_SESSION" \
    --wrapper-pid "$wrapper_pid" \
    --container-name "$CONTAINER_NAME" \
    --container-id "$container_id" \
    --launch-token-sha256 "$token_sha"
}

cleanup_owned_container() {
  local container_id="${1:-}" token_sha="${2:-}" logger_pid="${3:-}"
  set +e
  if [[ -n "$logger_pid" ]]; then
    kill "$logger_pid" >/dev/null 2>&1
    wait "$logger_pid" >/dev/null 2>&1
  fi
  if [[ -n "$container_id" ]]; then
    local observed_id observed_token
    observed_id="$(docker container inspect --format '{{.Id}}' "$CONTAINER_NAME" 2>/dev/null)"
    observed_token="$(docker container inspect --format '{{index .Config.Labels "ai.openai.harbor-kv.launch-token-sha256"}}' "$CONTAINER_NAME" 2>/dev/null)"
    if [[ "$observed_id" == "$container_id" && "$observed_token" == "$token_sha" ]]; then
      docker container rm --force "$container_id" >/dev/null 2>&1
    fi
  fi
  [[ ! -S "$SOCKET_PATH" ]] || rm -f -- "$SOCKET_PATH"
}

serve_inside_tmux() {
  local token_sha="${KV_HOST_VLLM_LAUNCH_TOKEN_SHA256:-}"
  [[ "$token_sha" =~ ^[0-9a-f]{64}$ ]] || die "missing internal launch token hash"
  # The private tmux server is created by a docker-group process. Do not spawn
  # another group wrapper here: pane_pid must remain the attested Bash PID.
  docker info >/dev/null 2>&1 || die "private tmux server lacks Docker access"

  prepare_runtime_dir
  validate_runtime_user
  local lock_fd
  exec {lock_fd}>"$LOCK_PATH"
  flock -n "$lock_fd" || die "another Qwen/vLLM process owns GPU devices 6 and 7"

  [[ ! -e "$ATTESTATION_PATH" ]] || die "attestation already exists: $ATTESTATION_PATH"
  [[ ! -e "$SOCKET_PATH" ]] || die "socket path already exists: $SOCKET_PATH"

  local preflight_report observed_version image_id mount_source model_relative model_in_container
  preflight_report="$(mktemp --tmpdir host-vllm-qwen36-preflight.XXXXXX.json)"
  run_preflight "$preflight_report"
  observed_version="$(validate_image)"
  image_id="$(profile_value '.runtime.runtime_image_id')"
  mount_source="$(jq -er '.model_mount_source' "$preflight_report")"
  model_relative="$(jq -er '.model_relative_path' "$preflight_report")"
  if [[ "$model_relative" == . ]]; then
    model_in_container="/opt/model-repo"
  else
    model_in_container="/opt/model-repo/$model_relative"
  fi

  local served_name tp_size dtype kv_dtype block_size max_model_len max_num_seqs
  local max_num_batched_tokens kv_cache_memory_bytes gpu_util socket_in_container reasoning_parser
  local mamba_cache_mode mamba_ssm_cache_dtype gdn_prefill_backend
  served_name="$(profile_value '.runtime.served_model_name')"
  tp_size="$(profile_value '.runtime.tensor_parallel_size')"
  dtype="$(profile_value '.runtime.dtype')"
  kv_dtype="$(profile_value '.runtime.kv_cache_dtype')"
  block_size="$(profile_value '.runtime.block_size')"
  max_model_len="$(profile_value '.runtime.max_model_len')"
  max_num_seqs="$(profile_value '.runtime.max_num_seqs')"
  max_num_batched_tokens="$(profile_value '.runtime.max_num_batched_tokens')"
  kv_cache_memory_bytes="$(profile_value '.runtime.kv_cache_memory_bytes')"
  gpu_util="$(profile_value '.runtime.gpu_memory_utilization')"
  socket_in_container="$(profile_value '.runtime.container_socket_path')"
  reasoning_parser="$(profile_value '.runtime.reasoning_parser')"
  mamba_cache_mode="$(profile_value '.runtime.mamba_cache_mode')"
  mamba_ssm_cache_dtype="$(profile_value '.runtime.mamba_ssm_cache_dtype')"
  gdn_prefill_backend="$(profile_value '.runtime.gdn_prefill_backend')"

  local -a vllm_args vllm_command create_command
  local runtime_gid
  runtime_gid="$(stat -c '%g' "$RUNTIME_DIR")"
  vllm_args=(
    serve "$model_in_container"
    --served-model-name "$served_name"
    --uds "$socket_in_container"
    --tensor-parallel-size "$tp_size"
    --model-impl vllm
    --runner generate
    --language-model-only
    --mm-processor-cache-gb 0
    --dtype "$dtype"
    --kv-cache-dtype "$kv_dtype"
    --enable-prefix-caching
    --mamba-cache-mode "$mamba_cache_mode"
    --mamba-ssm-cache-dtype "$mamba_ssm_cache_dtype"
    --gdn-prefill-backend "$gdn_prefill_backend"
    --block-size "$block_size"
    --max-model-len "$max_model_len"
    --max-num-seqs "$max_num_seqs"
    --max-num-batched-tokens "$max_num_batched_tokens"
    --kv-cache-memory-bytes "$kv_cache_memory_bytes"
    --gpu-memory-utilization "$gpu_util"
    --enable-chunked-prefill
    --load-format safetensors
    --safetensors-load-strategy lazy
    --reasoning-parser "$reasoning_parser"
    --generation-config vllm
    --no-enable-log-requests
    --disable-uvicorn-access-log
    --no-fail-on-environ-validation
  )
  vllm_command=(/usr/local/bin/vllm "${vllm_args[@]}")
  create_command=(
    docker container create
    --name "$CONTAINER_NAME"
    --network none
    --ipc host
    --gpus '"device=6,7"'
    --user "$UID:$runtime_gid"
    --ulimit memlock=-1
    --security-opt no-new-privileges:true
    --cap-drop ALL
    --label ai.openai.harbor-kv.role=external-model-server
    --label "ai.openai.harbor-kv.profile=$(profile_value '.profile_id')"
    --label "ai.openai.harbor-kv.launch-token-sha256=$token_sha"
    --label "com.docker.compose.project=$STANDALONE_COMPOSE_PROJECT"
    --label "com.docker.compose.service=$STANDALONE_COMPOSE_SERVICE"
    --env HF_HUB_OFFLINE=1
    --env TRANSFORMERS_OFFLINE=1
    --env HF_DATASETS_OFFLINE=1
    --env VLLM_NO_USAGE_STATS=1
    --env TOKENIZERS_PARALLELISM=false
    --env VLLM_BATCH_INVARIANT=0
    --env VLLM_USE_FLASHINFER_SAMPLER=0
    --env HOME=/run/kvbench-vllm/home
    --env XDG_CACHE_HOME=/run/kvbench-vllm/cache
    --env USER=kvvllm
    --env LOGNAME=kvvllm
    --env VLLM_SERVER_DEV_MODE=1
    --mount "type=bind,source=$mount_source,target=/opt/model-repo,readonly"
    --mount "type=bind,source=$RUNTIME_DIR,target=/run/kvbench-vllm"
    --mount "type=bind,source=$CONTAINER_PASSWD_PATH,target=/etc/passwd,readonly"
    --mount "type=bind,source=$CONTAINER_GROUP_PATH,target=/etc/group,readonly"
    --entrypoint /usr/local/bin/vllm
    "$IMAGE_REF"
    "${vllm_args[@]}"
  )

  local container_id logger_pid="" command_json wrapper_pid
  container_id="$("${create_command[@]}")"
  wrapper_pid="$$"
  trap 'python3 "$ATTESTATION_HELPER" exited --attestation "$ATTESTATION_PATH" --session "$TMUX_SESSION" --wrapper-pid "$wrapper_pid" --container-name "$CONTAINER_NAME" --container-id "$container_id" --launch-token-sha256 "$token_sha" >/dev/null 2>&1 || true; cleanup_owned_container "$container_id" "$token_sha" "$logger_pid"; rm -f -- "$preflight_report"' EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
  trap 'exit 129' HUP
  command_json="$(printf '%s\n' "${vllm_command[@]}" | jq -Rsc 'split("\n")[:-1]')"
  python3 "$ATTESTATION_HELPER" write-starting \
    --profile "$PROFILE" \
    --preflight "$preflight_report" \
    --runtime-dir "$RUNTIME_DIR" \
    --socket "$SOCKET_PATH" \
    --output "$ATTESTATION_PATH" \
    --image-ref "$IMAGE_REF" \
    --image-id "$image_id" \
    --observed-vllm-package-version "$observed_version" \
    --command-json "$command_json" \
    --session "$TMUX_SESSION" \
    --wrapper-pid "$wrapper_pid" \
    --container-name "$CONTAINER_NAME" \
    --container-id "$container_id" \
    --launch-token-sha256 "$token_sha"

  docker container start "$container_id" >/dev/null
  docker container logs --follow "$container_id" >>"$LOG_PATH" 2>&1 &
  logger_pid="$!"

  local started now model_response
  started="$(date +%s)"
  while true; do
    if [[ "$(docker container inspect --format '{{.State.Running}}' "$container_id" 2>/dev/null)" != true ]]; then
      echo "vLLM container exited before becoming healthy; inspect $LOG_PATH" >&2
      exit 5
    fi
    if [[ -S "$SOCKET_PATH" ]]; then
      # vLLM creates the socket under the host UID. model-api is a different
      # remapped UID, so grant connect permission before Harbor can mount it.
      chmod 0666 "$SOCKET_PATH"
    fi
    if [[ -S "$SOCKET_PATH" ]] \
      && curl --silent --show-error --fail --max-time 3 --unix-socket "$SOCKET_PATH" http://localhost/health >/dev/null 2>&1; then
      model_response="$(curl --silent --show-error --fail --max-time 5 \
        --unix-socket "$SOCKET_PATH" http://localhost/v1/models 2>/dev/null || true)"
      if jq -e --arg name "$served_name" '.data | any(.id == $name)' \
        <<<"$model_response" >/dev/null 2>&1; then
        break
      fi
    fi
    now="$(date +%s)"
    if ((now - started >= HEALTH_TIMEOUT_SECONDS)); then
      echo "vLLM did not become healthy within ${HEALTH_TIMEOUT_SECONDS}s; inspect $LOG_PATH" >&2
      exit 5
    fi
    sleep 2
  done

  python3 "$ATTESTATION_HELPER" ready \
    --attestation "$ATTESTATION_PATH" \
    --socket "$SOCKET_PATH" \
    --session "$TMUX_SESSION" \
    --wrapper-pid "$wrapper_pid" \
    --container-name "$CONTAINER_NAME" \
    --container-id "$container_id" \
    --launch-token-sha256 "$token_sha"

  echo "Qwen3.6-27B vLLM is ready on Unix socket $SOCKET_PATH"
  docker container wait "$container_id" >/dev/null
}

read_attested_identity() {
  [[ -f "$ATTESTATION_PATH" && ! -L "$ATTESTATION_PATH" ]] \
    || die "attestation is unavailable: $ATTESTATION_PATH"
  ATTESTED_STATE="$(jq -er '.state' "$ATTESTATION_PATH")"
  ATTESTED_SESSION="$(jq -er '.process.tmux_session' "$ATTESTATION_PATH")"
  ATTESTED_PID="$(jq -er '.process.wrapper_pid' "$ATTESTATION_PATH")"
  ATTESTED_CONTAINER_NAME="$(jq -er '.container.name' "$ATTESTATION_PATH")"
  ATTESTED_CONTAINER_ID="$(jq -er '.container.id' "$ATTESTATION_PATH")"
  ATTESTED_TOKEN_SHA="$(jq -er '.container.launch_token_sha256' "$ATTESTATION_PATH")"
  [[ "$(jq -er '.schema_version' "$ATTESTATION_PATH")" == 1 ]] || die "unsupported attestation schema"
  [[ "$(jq -er '.preflight_status' "$ATTESTATION_PATH")" == ok ]] || die "attested preflight was not successful"
  [[ "$(jq -er '.model_mount_read_only' "$ATTESTATION_PATH")" == true ]] || die "attested model mount is not read-only"
  [[ "$ATTESTED_SESSION" == "$TMUX_SESSION" ]] || die "attested tmux session drift"
  [[ "$ATTESTED_CONTAINER_NAME" == "$CONTAINER_NAME" ]] || die "attested container name drift"
  [[ "$ATTESTED_CONTAINER_ID" =~ ^[0-9a-f]{64}$ ]] || die "invalid attested container ID"
  [[ "$ATTESTED_TOKEN_SHA" =~ ^[0-9a-f]{64}$ ]] || die "invalid attested launch token hash"
  [[ "$(jq -er '.profile_id' "$ATTESTATION_PATH")" == "$(profile_value '.profile_id')" ]] \
    || die "attested profile ID drift"
  [[ "$(jq -er '.profile_sha256' "$ATTESTATION_PATH")" == "$(sha256sum "$PROFILE" | awk '{print $1}')" ]] \
    || die "attested profile hash drift"
  [[ "$(jq -er '.container.image_id' "$ATTESTATION_PATH")" == "$(profile_value '.runtime.runtime_image_id')" ]] \
    || die "attested image ID drift"
  [[ "$(jq -er '.container.image_ref' "$ATTESTATION_PATH")" == "$(profile_value '.runtime.runtime_image_ref')" ]] \
    || die "attested image reference drift"
  [[ "$(jq -er '.container.environment.VLLM_SERVER_DEV_MODE' "$ATTESTATION_PATH")" == 1 ]] \
    || die "attested vLLM server dev mode drift"
  [[ "$(jq -er '.observed_vllm_package_version' "$ATTESTATION_PATH")" == "$(profile_value '.runtime.vllm_package_version')" ]] \
    || die "attested vLLM package version drift"
  [[ "$(jq -er '.model.revision' "$ATTESTATION_PATH")" == "$(profile_value '.source.revision')" ]] \
    || die "attested model revision drift"
  [[ "$(jq -er '.transport.socket_path' "$ATTESTATION_PATH")" == "$SOCKET_PATH" ]] \
    || die "attested host socket path drift"
}

verify_live_identity() {
  read_attested_identity
  python3 "$ATTESTATION_HELPER" check \
    --attestation "$ATTESTATION_PATH" \
    --session "$ATTESTED_SESSION" \
    --wrapper-pid "$ATTESTED_PID" \
    --container-name "$ATTESTED_CONTAINER_NAME" \
    --container-id "$ATTESTED_CONTAINER_ID" \
    --launch-token-sha256 "$ATTESTED_TOKEN_SHA" >/dev/null

  tmux -L "$TMUX_SOCKET" has-session -t "=$ATTESTED_SESSION" 2>/dev/null \
    || die "attested tmux session is not live"
  local pane_pid
  pane_pid="$(tmux -L "$TMUX_SOCKET" list-panes -t "=$ATTESTED_SESSION" -F '#{pane_pid}')"
  [[ "$pane_pid" == "$ATTESTED_PID" ]] \
    || die "attested tmux pane PID changed: $pane_pid != $ATTESTED_PID"

  local observed_id observed_image observed_token observed_environment
  local observed_compose_project observed_compose_service
  observed_id="$(docker container inspect --format '{{.Id}}' "$ATTESTED_CONTAINER_NAME" 2>/dev/null)" \
    || die "attested container is unavailable"
  observed_image="$(docker container inspect --format '{{.Image}}' "$ATTESTED_CONTAINER_NAME")"
  observed_token="$(docker container inspect --format '{{index .Config.Labels "ai.openai.harbor-kv.launch-token-sha256"}}' "$ATTESTED_CONTAINER_NAME")"
  observed_environment="$(docker container inspect --format '{{json .Config.Env}}' "$ATTESTED_CONTAINER_NAME")"
  observed_compose_project="$(docker container inspect --format '{{index .Config.Labels "com.docker.compose.project"}}' "$ATTESTED_CONTAINER_NAME")"
  observed_compose_service="$(docker container inspect --format '{{index .Config.Labels "com.docker.compose.service"}}' "$ATTESTED_CONTAINER_NAME")"
  [[ "$observed_id" == "$ATTESTED_CONTAINER_ID" ]] || die "attested container ID changed"
  [[ "$observed_image" == "$(profile_value '.runtime.runtime_image_id')" ]] || die "live container image ID drift"
  [[ "$observed_token" == "$ATTESTED_TOKEN_SHA" ]] || die "live container ownership label drift"
  [[ "$observed_compose_project" == "$STANDALONE_COMPOSE_PROJECT" ]] \
    || die "live container inherited the calibration Compose project label"
  [[ "$observed_compose_service" == "$STANDALONE_COMPOSE_SERVICE" ]] \
    || die "live container inherited the calibration Compose service label"
  jq -e 'index("VLLM_SERVER_DEV_MODE=1") != null' <<<"$observed_environment" >/dev/null \
    || die "live container is missing VLLM_SERVER_DEV_MODE=1"
}

status_ready() {
  verify_live_identity
  [[ "$ATTESTED_STATE" == ready ]] || return 1
  [[ -S "$SOCKET_PATH" && ! -L "$SOCKET_PATH" ]] || die "attested UDS is unavailable"
  curl --silent --show-error --fail --max-time 3 \
    --unix-socket "$SOCKET_PATH" http://localhost/health >/dev/null \
    || die "attested vLLM health check failed"
  local served_name
  served_name="$(profile_value '.runtime.served_model_name')"
  curl --silent --show-error --fail --max-time 5 \
    --unix-socket "$SOCKET_PATH" http://localhost/v1/models \
    | jq -e --arg name "$served_name" '.data | any(.id == $name)' >/dev/null \
    || die "attested vLLM does not expose $served_name"
}

do_status() {
  if [[ ! -f "$ATTESTATION_PATH" ]]; then
    if tmux -L "$TMUX_SOCKET" has-session -t "=$TMUX_SESSION" 2>/dev/null; then
      echo '{"status":"starting","attested":false}'
      return 1
    fi
    echo '{"status":"stopped","attested":false}'
    return 3
  fi
  read_attested_identity
  if ! kill -0 "$ATTESTED_PID" 2>/dev/null \
    && ! tmux -L "$TMUX_SOCKET" has-session -t "=$ATTESTED_SESSION" 2>/dev/null \
    && ! docker container inspect "$ATTESTED_CONTAINER_NAME" >/dev/null 2>&1; then
    jq '{status:"stale",profile_id,state,container_id:.container.id}' "$ATTESTATION_PATH"
    return 3
  fi
  if [[ "$ATTESTED_STATE" == ready ]] && status_ready; then
    jq '{status:"ready",profile_id,state,ready_unix,model_revision:.model.revision,container_id:.container.id,socket:.transport.socket_path}' "$ATTESTATION_PATH"
    return 0
  fi
  if [[ "$ATTESTED_STATE" == starting ]] && verify_live_identity; then
    jq '{status:"starting",profile_id,state,created_unix,container_id:.container.id}' "$ATTESTATION_PATH"
    return 1
  fi
  jq '{status:"not-ready",profile_id,state,container_id:.container.id}' "$ATTESTATION_PATH"
  return 3
}

do_start() {
  prepare_runtime_dir
  validate_runtime_user
  assert_lock_available
  tmux -L "$TMUX_SOCKET" has-session -t "=$TMUX_SESSION" 2>/dev/null \
    && die "reserved tmux session already exists: $TMUX_SESSION"
  [[ ! -e "$ATTESTATION_PATH" ]] || die "attestation already exists; run status/stop first"
  [[ ! -e "$SOCKET_PATH" ]] || die "socket path already exists; run status/stop first"
  docker container inspect "$CONTAINER_NAME" >/dev/null 2>&1 \
    && die "reserved container already exists: $CONTAINER_NAME"

  # Fail before detaching so obvious model/image/GPU errors remain visible.
  local report
  report="$(mktemp --tmpdir host-vllm-qwen36-start.XXXXXX.json)"
  run_preflight "$report"
  rm -f -- "$report"

  local token_sha command_part command_string argument
  token_sha="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  local command=(
    exec env
    "KV_HOST_VLLM_LAUNCH_TOKEN_SHA256=$token_sha"
    "HARBOR_VLLM_MODEL_PATH=$MODEL_PATH"
    "HARBOR_VLLM_RUNTIME_DIR=$RUNTIME_DIR"
    "HARBOR_VLLM_HEALTH_TIMEOUT_SECONDS=$HEALTH_TIMEOUT_SECONDS"
    "$0" _serve
  )
  command_string=""
  for argument in "${command[@]}"; do
    printf -v command_part '%q' "$argument"
    command_string+="${command_string:+ }$command_part"
  done
  tmux -L "$TMUX_SOCKET" new-session -d -s "$TMUX_SESSION" "$command_string"

  local started now last_notice
  started="$(date +%s)"
  last_notice="$started"
  while true; do
    if [[ -f "$ATTESTATION_PATH" ]] && [[ "$(jq -r '.state // ""' "$ATTESTATION_PATH" 2>/dev/null)" == ready ]]; then
      status_ready
      echo "External Qwen3.6-27B vLLM is ready."
      echo "export HARBOR_VLLM_RUNTIME_DIR=$(printf '%q' "$RUNTIME_DIR")"
      return 0
    fi
    if ! tmux -L "$TMUX_SOCKET" has-session -t "=$TMUX_SESSION" 2>/dev/null; then
      echo "vLLM tmux session exited during startup; recent log follows:" >&2
      [[ ! -f "$LOG_PATH" ]] || tail -n 80 "$LOG_PATH" >&2
      return 5
    fi
    now="$(date +%s)"
    if ((now - started >= HEALTH_TIMEOUT_SECONDS)); then
      echo "startup wait exceeded ${HEALTH_TIMEOUT_SECONDS}s; run status/logs" >&2
      return 5
    fi
    if ((now - last_notice >= 30)); then
      echo "Waiting for Qwen3.6-27B vLLM startup ($((now - started))s elapsed)..."
      last_notice="$now"
    fi
    sleep 2
  done
}

do_stop() {
  if [[ ! -f "$ATTESTATION_PATH" ]]; then
    if tmux -L "$TMUX_SOCKET" has-session -t "=$TMUX_SESSION" 2>/dev/null; then
      die "tmux startup is live but not yet attested; wait for start/status before stopping"
    fi
    echo "External Qwen vLLM is already stopped; no attested target exists."
    return 0
  fi
  read_attested_identity

  if [[ "$ATTESTED_STATE" == starting || "$ATTESTED_STATE" == ready || "$ATTESTED_STATE" == stopping ]]; then
    local process_live=0 session_live=0 container_live=0
    kill -0 "$ATTESTED_PID" 2>/dev/null && process_live=1
    tmux -L "$TMUX_SOCKET" has-session -t "=$ATTESTED_SESSION" 2>/dev/null && session_live=1
    docker container inspect "$ATTESTED_CONTAINER_NAME" >/dev/null 2>&1 && container_live=1
    if ((process_live || session_live || container_live)); then
      # A partially matching lifecycle is unsafe too: verify all three exact
      # identities before sending any signal or Docker mutation.
      verify_live_identity
      python3 "$ATTESTATION_HELPER" stopping \
        --attestation "$ATTESTATION_PATH" \
        --session "$ATTESTED_SESSION" \
        --wrapper-pid "$ATTESTED_PID" \
        --container-name "$ATTESTED_CONTAINER_NAME" \
        --container-id "$ATTESTED_CONTAINER_ID" \
        --launch-token-sha256 "$ATTESTED_TOKEN_SHA"
      docker container stop --time 30 "$ATTESTED_CONTAINER_ID" >/dev/null

      local deadline pane_pid
      deadline=$((SECONDS + 45))
      while tmux -L "$TMUX_SOCKET" has-session -t "=$ATTESTED_SESSION" 2>/dev/null && ((SECONDS < deadline)); do
        sleep 1
      done
      if tmux -L "$TMUX_SOCKET" has-session -t "=$ATTESTED_SESSION" 2>/dev/null; then
        pane_pid="$(tmux -L "$TMUX_SOCKET" list-panes -t "=$ATTESTED_SESSION" -F '#{pane_pid}')"
        [[ "$pane_pid" == "$ATTESTED_PID" ]] || die "refusing to kill a changed tmux pane"
        tmux -L "$TMUX_SOCKET" kill-session -t "=$ATTESTED_SESSION"
      fi
    else
      echo "Cleaning an attested stale launch; its exact PID, tmux session, and container ID are all absent."
    fi
  elif [[ "$ATTESTED_STATE" != exited && "$ATTESTED_STATE" != not-ready ]]; then
    die "refusing to stop unknown attestation state: $ATTESTED_STATE"
  fi

  if docker container inspect "$ATTESTED_CONTAINER_NAME" >/dev/null 2>&1; then
    local observed_id observed_token
    observed_id="$(docker container inspect --format '{{.Id}}' "$ATTESTED_CONTAINER_NAME")"
    observed_token="$(docker container inspect --format '{{index .Config.Labels "ai.openai.harbor-kv.launch-token-sha256"}}' "$ATTESTED_CONTAINER_NAME")"
    [[ "$observed_id" == "$ATTESTED_CONTAINER_ID" && "$observed_token" == "$ATTESTED_TOKEN_SHA" ]] \
      || die "refusing to remove a container that no longer matches attestation"
    docker container rm --force "$ATTESTED_CONTAINER_ID" >/dev/null
  fi
  [[ ! -S "$SOCKET_PATH" ]] || rm -f -- "$SOCKET_PATH"
  rm -f -- "$ATTESTATION_PATH"
  echo "Stopped the exact attested Qwen vLLM instance. Log retained at $LOG_PATH"
}

do_logs() {
  echo "$LOG_PATH"
  [[ ! -f "$LOG_PATH" ]] || tail -n 120 "$LOG_PATH"
}

main() {
  [[ $# == 1 ]] || { usage >&2; exit 2; }
  local action="$1"
  case "$action" in
    preflight|start|status|stop|logs|_serve) ;;
    -h|--help|help) usage; return 0 ;;
    *) usage >&2; die "unknown action: $action" ;;
  esac

  require_commands
  validate_inputs
  if [[ "$action" != logs ]]; then
    ensure_docker_access
  fi
  case "$action" in
    preflight) do_preflight ;;
    start) do_start ;;
    status) do_status ;;
    stop) do_stop ;;
    logs) do_logs ;;
    _serve) serve_inside_tmux ;;
  esac
}

main "$@"
