#!/usr/bin/env python3
"""Run and checkpoint trusted real-SWE baseline calibration profiles."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


TASK_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PROFILES = (
    "qwen36-adapter-8",
    "qwen36-trajectory-24-deep48",
    "qwen36-low-control-48-deep64",
    "qwen36-pressure-192-deep24",
    "qwen36-pressure-192-deep32",
    "qwen36-pressure-192-deep48",
    "qwen36-pressure-192-deep64",
    "qwen36-pressure-192-deep96",
    "qwen36-paper-control-96-deep135",
)
DEFAULT_CALIBRATION_PROFILES = (
    TASK_ROOT / "environment" / "bench-controller" / "profiles" / "calibration.json"
)
RELEASE_QUALIFICATION_KEY = "release_qualification_profiles"
PROFILE_DEFAULTS: dict[str, Any] = {
    "warmup_requests": 2,
    "warmup_context_bytes": 2048,
    "warmup_steps": 1,
    "workload_family": "synthetic-fixture",
    "metrics_sample_interval_sec": 1.0,
    "metrics_request_timeout_sec": 15,
    "pressure_required": False,
    "pressure_kv_threshold": 0.85,
    "pressure_kv_p95_min": 0.85,
    "pressure_time_fraction_min": 0.10,
    "pressure_min_samples": 5,
    "corpus_partition": "fixture",
    "corpus_unique_instances_min": 1,
    "tool_timeout_sec": 60,
    "sandbox_prepare_concurrency": 16,
    "backend_stall_timeout_sec": 30,
    "candidate_admission_stall_timeout_sec": 60,
}
REMOTE_REQUEST = r"""
import json
import pathlib
import sys
import urllib.error
import urllib.request

method, path, raw_payload, timeout = sys.argv[1:]
token = pathlib.Path('/run/kvbench-admin/token').read_text().strip()
body = raw_payload.encode() if raw_payload else None
request = urllib.request.Request(
    'http://127.0.0.1:7000' + path,
    data=body,
    method=method,
    headers={
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
    },
)
try:
    with urllib.request.urlopen(request, timeout=int(timeout)) as response:
        sys.stdout.buffer.write(response.read())
except urllib.error.HTTPError as exc:
    sys.stderr.buffer.write(exc.read())
    raise
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def policy_contract_sha256(policy: dict[str, Any]) -> str:
    immutable = {
        key: value
        for key, value in policy.items()
        if key not in {"release_ready", "not_ready_reasons"}
    }
    encoded = json.dumps(immutable, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def canonical_json(value: Any) -> str:
    """Render JSON so booleans cannot compare equal to integer contract fields."""

    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def canonical_profile_config(name: str, configured: dict[str, Any]) -> dict[str, Any]:
    expected = {**PROFILE_DEFAULTS, **configured, "name": name}
    return expected


def release_qualification_profiles(payload: dict[str, Any]) -> tuple[str, ...]:
    """Return the explicit, ordered release list or fail closed.

    Enabled author diagnostics are deliberately not inferred into this list.
    An empty list is valid in the development config, but cannot be selected
    for a qualification run.
    """

    configured = payload.get("profiles")
    if not isinstance(configured, dict) or any(
        not isinstance(config, dict) for config in configured.values()
    ):
        raise ValueError("calibration profile file has no valid profiles object")
    selected = payload.get(RELEASE_QUALIFICATION_KEY)
    if not isinstance(selected, list):
        raise ValueError(f"{RELEASE_QUALIFICATION_KEY} must be a JSON list")
    if not selected:
        raise ValueError(
            f"{RELEASE_QUALIFICATION_KEY} is empty; select empirically qualified profiles first"
        )
    if any(not isinstance(name, str) or not name for name in selected):
        raise ValueError(
            f"{RELEASE_QUALIFICATION_KEY} entries must be non-empty strings"
        )
    if len(selected) != len(set(selected)):
        raise ValueError(f"{RELEASE_QUALIFICATION_KEY} contains duplicate entries")
    missing = [name for name in selected if name not in configured]
    if missing:
        raise ValueError(
            f"{RELEASE_QUALIFICATION_KEY} references missing profiles: {missing}"
        )
    disabled = [name for name in selected if configured[name].get("enabled") is not True]
    if disabled:
        raise ValueError(
            f"{RELEASE_QUALIFICATION_KEY} references disabled profiles: {disabled}"
        )
    return tuple(selected)


def select_profiles(
    payload: dict[str, Any],
    explicit_profiles: list[str] | None,
    use_release_qualification_profiles: bool,
) -> tuple[tuple[str, ...], str]:
    """Select diagnostics normally, or exactly the frozen release allowlist."""

    if explicit_profiles and use_release_qualification_profiles:
        raise ValueError(
            "--profile and --release-qualification-profiles are mutually exclusive"
        )
    if use_release_qualification_profiles:
        return release_qualification_profiles(payload), "release_qualification_allowlist"
    if explicit_profiles:
        return tuple(explicit_profiles), "explicit_diagnostics"
    return DEFAULT_PROFILES, "default_diagnostics"


def validate_selection_policy(
    scoring_policy: dict[str, Any], selection_mode: str
) -> None:
    """Keep exploratory diagnostics separate from final release evidence.

    While ``release_ready`` is false, this runner only accepts an explicit
    ``--profile`` selection.  The default sweep is convenient during early
    development, but is too easy to mistake for frozen evidence.  Conversely,
    the release allowlist is usable only after the final contract has a
    non-development release ID and the readiness bit has been flipped.
    """

    if selection_mode not in {
        "explicit_diagnostics",
        "default_diagnostics",
        "release_qualification_allowlist",
    }:
        raise ValueError(f"unknown profile selection mode: {selection_mode!r}")
    release_ready = scoring_policy.get("release_ready") is True
    release_id = scoring_policy.get("release_id")
    if selection_mode == "release_qualification_allowlist":
        if not release_ready:
            raise ValueError(
                "--release-qualification-profiles requires release_ready=true"
            )
        if (
            not isinstance(release_id, str)
            or not release_id
            or release_id.startswith("development")
        ):
            raise ValueError(
                "--release-qualification-profiles requires a non-development release ID"
            )
    elif not release_ready and selection_mode != "explicit_diagnostics":
        raise ValueError(
            "release_ready=false permits only explicit --profile diagnostics"
        )


def validate_final_controller_readiness(
    scoring_policy: dict[str, Any],
    readiness: dict[str, Any],
    selection_mode: str,
) -> None:
    """Require a rebuilt, final-ready controller for qualification sweeps."""

    if selection_mode != "release_qualification_allowlist":
        return
    if readiness.get("phase") != 1:
        raise RuntimeError("release qualification requires phase-1 controller readiness")
    expected_release_id = scoring_policy.get("release_id")
    if readiness.get("release_id") != expected_release_id:
        raise RuntimeError(
            "release qualification controller release ID differs from scoring policy"
        )
    required = (
        "model_api",
        "infrastructure_attested",
        "public_profiles",
        "real_swebench_workload",
        "hidden_profiles",
        "oracle_calibrated",
        "real_agent_test_allowed",
    )
    missing = [key for key in required if readiness.get(key) is not True]
    if missing:
        raise RuntimeError(
            "release qualification requires final controller readiness: "
            + ",".join(missing)
        )


def validate_selected_profiles(
    payload: dict[str, Any], selected: tuple[str, ...]
) -> dict[str, dict[str, Any]]:
    """Resolve a dynamic diagnostic selection against the trusted profile file."""

    configured = payload.get("profiles")
    if not isinstance(configured, dict) or any(
        not isinstance(config, dict) for config in configured.values()
    ):
        raise ValueError("calibration profile file has no valid profiles object")
    missing = [name for name in selected if name not in configured]
    if missing:
        raise ValueError(f"calibration profiles are missing: {missing}")
    disabled = [name for name in selected if configured[name].get("enabled") is not True]
    if disabled:
        raise ValueError(f"calibration profiles are disabled: {disabled}")
    return configured


def expected_model_provenance(
    model_profile: dict[str, Any], profile_sha256: str
) -> dict[str, Any]:
    source = model_profile.get("source") or {}
    runtime = model_profile.get("runtime") or {}
    return {
        "profile_id": model_profile.get("profile_id"),
        "profile_sha256": profile_sha256,
        "model_revision": source.get("revision"),
        "runtime_image_id": runtime.get("runtime_image_id"),
        "tensor_parallel_size": runtime.get("tensor_parallel_size"),
        "kv_cache_dtype": runtime.get("kv_cache_dtype"),
    }


def calibration_result_failures(
    result: dict[str, Any],
    *,
    profile_name: str,
    expected_profile_config: dict[str, Any],
    expected_release_id: str,
    expected_controller_config_sha256: str,
    expected_provenance: dict[str, Any],
    expected_model_adapter: dict[str, Any],
    quality_gates: dict[str, float | int],
) -> list[str]:
    """Return every fail-closed reason that prevents checkpoint completion."""

    failures: list[str] = []
    if result.get("profile") != profile_name or result.get("mode") != "baseline":
        failures.append("profile_or_mode_mismatch")
    if canonical_json(result.get("profile_config")) != canonical_json(
        expected_profile_config
    ):
        failures.append("profile_config_mismatch")
    if result.get("release_id") != expected_release_id:
        failures.append("release_id_mismatch")
    if result.get("controller_config_sha256") != expected_controller_config_sha256:
        failures.append("controller_config_sha256_mismatch")
    if canonical_json(result.get("model_provenance")) != canonical_json(
        expected_provenance
    ):
        failures.append("model_provenance_mismatch")
    run_adapter = {
        **expected_model_adapter,
        "effective_max_tokens": expected_profile_config.get("max_tokens"),
    }
    if canonical_json(result.get("model_adapter")) != canonical_json(run_adapter):
        failures.append("model_adapter_mismatch")
    if result.get("infrastructure_failure") is not None:
        failures.append(
            "infrastructure_failure="
            + json.dumps(result["infrastructure_failure"], separators=(",", ":"))
        )
    if result.get("backend_audit", {}).get("passed") is not True:
        failures.append("backend_audit_failed")
    if result.get("warmup_audit", {}).get("passed") is not True:
        failures.append("warmup_audit_failed")
    pressure = result.get("pressure_validation", {})
    if pressure.get("valid") is not True:
        reasons = pressure.get("reasons")
        failures.append(
            "pressure_validation_failed="
            + json.dumps(reasons, separators=(",", ":"))
        )
    expected_pressure_required = expected_profile_config.get("pressure_required") is True
    contention = pressure.get("contention_evidence", {})
    if pressure.get("qualification_schema_version") != 1:
        failures.append("pressure_qualification_schema_version")
    if pressure.get("required") is not expected_pressure_required:
        failures.append("pressure_required_mismatch")
    if contention.get("required") is not expected_pressure_required:
        failures.append("contention_evidence_required_mismatch")
    if contention.get("valid") is not True:
        failures.append("contention_evidence_invalid")
    if expected_pressure_required:
        paths = contention.get("qualification_paths")
        allowed_paths = {
            "audited_active_working_set",
            "audited_oversubscribed_working_set",
            "vllm_preemption",
        }
        if (
            not isinstance(paths, list)
            or not paths
            or not all(
                isinstance(path, str) and path in allowed_paths for path in paths
            )
        ):
            failures.append("unsafe_or_missing_pressure_qualification_path")
        else:
            if (
                "audited_active_working_set" in paths
                and (contention.get("active_working_set") or {}).get("valid")
                is not True
            ):
                failures.append("active_working_set_evidence_invalid")
            if "audited_oversubscribed_working_set" in paths:
                oversubscribed = contention.get("oversubscribed_working_set") or {}
                corroboration = oversubscribed.get("corroboration_paths")
                allowed_corroboration = {
                    "synchronized_waiting",
                    "leg_local_cache_churn",
                }
                if (
                    oversubscribed.get("valid") is not True
                    or oversubscribed.get("occupancy_independent") is not True
                    or oversubscribed.get("demand_ratio_threshold") != 1.0
                    or not isinstance(corroboration, list)
                    or not corroboration
                    or not all(
                        isinstance(path, str) and path in allowed_corroboration
                        for path in corroboration
                    )
                ):
                    failures.append("oversubscribed_working_set_evidence_invalid")
                else:
                    if (
                        "synchronized_waiting" in corroboration
                        and (oversubscribed.get("synchronized_waiting") or {}).get(
                            "valid"
                        )
                        is not True
                    ):
                        failures.append(
                            "oversubscribed_synchronized_waiting_evidence_invalid"
                        )
                    if (
                        "leg_local_cache_churn" in corroboration
                        and (oversubscribed.get("leg_local_cache_churn") or {}).get(
                            "valid"
                        )
                        is not True
                    ):
                        failures.append(
                            "oversubscribed_cache_churn_evidence_invalid"
                        )
            preemption = contention.get("preemption") or {}
            preemption_delta = preemption.get("preemptions_delta")
            if "vllm_preemption" in paths and not (
                preemption.get("valid") is True
                and isinstance(preemption_delta, (int, float))
                and not isinstance(preemption_delta, bool)
                and float(preemption_delta) > 0
            ):
                failures.append("preemption_evidence_invalid")

    success = result.get("request_success_rate")
    if (
        isinstance(success, bool)
        or not isinstance(success, (int, float))
        or float(success) < 1.0
    ):
        failures.append(f"request_success_rate={success!r}<1.000000")
    valid_step_ratio = result.get("valid_step_ratio")
    valid_floor = float(quality_gates["minimum_valid_step_ratio"])
    if (
        isinstance(valid_step_ratio, bool)
        or not isinstance(valid_step_ratio, (int, float))
        or float(valid_step_ratio) < valid_floor
    ):
        failures.append(f"valid_step_ratio={valid_step_ratio!r}<{valid_floor:.6f}")
    minimum_progress = result.get("minimum_workflow_progress")
    progress_floor = int(quality_gates["minimum_workflow_progress"])
    if (
        isinstance(minimum_progress, bool)
        or not isinstance(minimum_progress, int)
        or minimum_progress < progress_floor
    ):
        failures.append(
            f"minimum_workflow_progress={minimum_progress!r}<{progress_floor}"
        )
    sampler_errors = result.get("vllm_metrics", {}).get("live_series", {}).get(
        "sampler_error_count"
    )
    if (
        isinstance(sampler_errors, bool)
        or not isinstance(sampler_errors, int)
        or sampler_errors != 0
    ):
        failures.append(f"metrics_sampler_errors={sampler_errors!r}")
    return failures


def controller_container(project: str) -> str:
    inspected = subprocess.run(
        [
            "docker",
            "ps",
            "--filter",
            f"label=com.docker.compose.project={project}",
            "--filter",
            "label=com.docker.compose.service=bench-controller",
            "--format",
            "{{.ID}}",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        timeout=30,
    )
    containers = [line.strip() for line in inspected.stdout.splitlines() if line.strip()]
    if inspected.returncode != 0 or len(containers) != 1:
        raise RuntimeError(f"expected one healthy bench-controller for {project}: {inspected.stdout}")
    return containers[0]


def container_image_id(container: str) -> str:
    inspected = subprocess.run(
        ["docker", "inspect", "--format", "{{.Image}}", container],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        timeout=30,
    )
    image_id = inspected.stdout.strip()
    if inspected.returncode != 0 or not re.fullmatch(r"sha256:[0-9a-f]{64}", image_id):
        raise RuntimeError(
            f"cannot attest bench-controller image for {container}: {inspected.stdout}"
        )
    return image_id


def controller_request(
    container: str,
    method: str,
    path: str,
    payload: dict[str, Any] | None,
    *,
    timeout_sec: int,
) -> dict[str, Any]:
    encoded = "" if payload is None else json.dumps(payload, separators=(",", ":"))
    completed = subprocess.run(
        [
            "docker",
            "exec",
            container,
            "python3",
            "-c",
            REMOTE_REQUEST,
            method,
            path,
            encoded,
            str(timeout_sec),
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=timeout_sec + 60,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"controller {method} {path} failed: {(completed.stderr or completed.stdout)[-4000:]}"
        )
    response = json.loads(completed.stdout)
    if not isinstance(response, dict):
        raise RuntimeError("controller returned a non-object response")
    return response


def summarize(result: dict[str, Any]) -> dict[str, Any]:
    metrics = result.get("vllm_metrics", {})
    samples = metrics.get("live_samples", [])
    return {
        "run_id": result.get("run_id"),
        "profile": result.get("profile"),
        "workload_family": result.get("profile_config", {}).get("workload_family"),
        "corpus_partition": result.get("profile_config", {}).get("corpus_partition"),
        "workflows": result.get("profile_config", {}).get("workflows"),
        "concurrency": result.get("profile_config", {}).get("concurrency"),
        "max_steps": result.get("profile_config", {}).get("max_steps"),
        "effective_max_tokens": result.get("profile_config", {}).get("max_tokens"),
        "model_adapter": result.get("model_adapter"),
        "sandbox_preparation_sec": result.get("sandbox_preparation_sec"),
        "sandbox_preparation": result.get("sandbox_preparation"),
        "elapsed_sec": result.get("elapsed_sec"),
        "valid_steps_per_min": result.get("valid_steps_per_min"),
        "tests_passed_workflows": result.get("tests_passed_workflows"),
        "completed_workflows": result.get("completed_workflows"),
        "request_success_rate": result.get("request_success_rate"),
        "valid_step_ratio": result.get("valid_step_ratio"),
        "minimum_workflow_progress": result.get("minimum_workflow_progress"),
        "p99_ttft_sec": result.get("p99_ttft_sec"),
        "p95_tool_latency_sec": result.get("p95_tool_latency_sec"),
        "model_query_time_fraction": result.get("model_query_time_fraction"),
        "backend_audit_passed": result.get("backend_audit", {}).get("passed"),
        "warmup_audit_passed": result.get("warmup_audit", {}).get("passed"),
        "warmup_protocol": result.get("warmup_protocol"),
        "pressure_validation": result.get("pressure_validation"),
        "live_series": metrics.get("live_series"),
        "derived_metrics": metrics.get("derived"),
        "live_sample_count": len(samples) if isinstance(samples, list) else None,
        "request_token_distribution": result.get("request_token_distribution"),
        "model_response_outcomes": result.get("model_response_outcomes"),
        "model_protocol_diagnostics": result.get("model_protocol_diagnostics"),
        "agent_step_outcomes": result.get("agent_step_outcomes"),
        "format_error_details": result.get("format_error_details"),
        "infrastructure_failure": result.get("infrastructure_failure"),
    }


def atomic_write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    with tempfile.NamedTemporaryFile(prefix=f".{path.name}.", dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", default="kvbench-qwen36-public30")
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument(
        "--profile",
        action="append",
        metavar="NAME",
        help=(
            "run one enabled profile from --calibration-profiles; repeat this "
            "option to run an ordered diagnostic subset"
        ),
    )
    selection.add_argument(
        "--release-qualification-profiles",
        action="store_true",
        help=(
            "run exactly the ordered release_qualification_profiles list from "
            "the calibration profile file; require a non-development, "
            "release-ready policy and final controller readiness"
        ),
    )
    parser.add_argument("--request-timeout-sec", type=int, default=10800)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--model-profile",
        type=Path,
        default=Path(
            os.environ.get(
                "KV_MODEL_PROFILE",
                TASK_ROOT
                / "environment"
                / "vllm-runtime"
                / "model-profile-qwen3.6-27b.json",
            )
        ),
    )
    parser.add_argument(
        "--corpus-manifest",
        type=Path,
        default=Path("~/.cache/harbor-kv-scheduler-v2/swebench-lite/manifest.json").expanduser(),
    )
    parser.add_argument(
        "--scoring-policy",
        type=Path,
        default=TASK_ROOT / "environment" / "bench-controller" / "profiles" / "scoring-policy.json",
    )
    parser.add_argument(
        "--calibration-profiles",
        type=Path,
        default=DEFAULT_CALIBRATION_PROFILES,
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=TASK_ROOT
        / "calibration"
        / f"real-swe-baseline-sweep-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}.json",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 300 <= args.request_timeout_sec <= 21600:
        raise ValueError("--request-timeout-sec must be in 300..21600")
    manifest = args.corpus_manifest.expanduser().resolve(strict=True)
    model_profile = args.model_profile.expanduser().resolve(strict=True)
    scoring_policy_path = args.scoring_policy.expanduser().resolve(strict=True)
    calibration_profiles_path = args.calibration_profiles.expanduser().resolve(strict=True)
    model_profile_payload = json.loads(model_profile.read_text())
    if not isinstance(model_profile_payload, dict):
        raise ValueError("model profile must be a JSON object")
    scoring_policy = json.loads(scoring_policy_path.read_text())
    calibration_profiles_payload = json.loads(calibration_profiles_path.read_text())
    profiles, selection_mode = select_profiles(
        calibration_profiles_payload,
        args.profile,
        args.release_qualification_profiles,
    )
    validate_selection_policy(scoring_policy, selection_mode)
    configured_profiles = validate_selected_profiles(
        calibration_profiles_payload, profiles
    )
    profile_selection = {
        "mode": selection_mode,
        "profiles": list(profiles),
    }
    expected_profile_configs = {
        name: canonical_profile_config(name, configured_profiles[name])
        for name in configured_profiles
    }
    quality_gates = {
        "minimum_valid_step_ratio": float(scoring_policy["min_valid_step_ratio"]),
        "minimum_workflow_progress": int(scoring_policy["minimum_workflow_progress"]),
    }
    container = controller_container(args.project)
    controller_image_sha256 = container_image_id(container)
    readiness = controller_request(container, "GET", "/admin/readiness", None, timeout_sec=60)
    required = ("model_api", "infrastructure_attested", "public_profiles", "real_swebench_workload")
    missing = [key for key in required if readiness.get(key) is not True]
    if missing:
        raise RuntimeError(f"controller readiness is incomplete: {missing}: {readiness}")
    validate_final_controller_readiness(scoring_policy, readiness, selection_mode)
    expected_corpus_sha256 = sha256(manifest)
    expected_policy_contract_sha256 = policy_contract_sha256(scoring_policy)
    expected_controller_config_sha256 = readiness.get("controller_config_sha256")
    expected_release_id = readiness.get("release_id")
    if readiness.get("corpus_manifest_sha256") != expected_corpus_sha256:
        raise RuntimeError("controller corpus manifest differs from calibration input")
    if readiness.get("policy_contract_sha256") != expected_policy_contract_sha256:
        raise RuntimeError("controller scoring-policy contract differs from calibration input")
    if not isinstance(expected_controller_config_sha256, str) or not re.fullmatch(
        r"[0-9a-f]{64}", expected_controller_config_sha256
    ):
        raise RuntimeError("controller readiness has no valid configuration digest")
    if not isinstance(expected_release_id, str) or not expected_release_id:
        raise RuntimeError("controller readiness has no release ID")
    model_profile_sha256 = sha256(model_profile)
    static_provenance = expected_model_provenance(
        model_profile_payload, model_profile_sha256
    )
    provenance = readiness.get("model_provenance")
    if (
        any(value is None for value in static_provenance.values())
        or not isinstance(provenance, dict)
        or {
            key: provenance.get(key)
            for key in static_provenance
        }
        != static_provenance
        or not isinstance(provenance.get("runtime_boot_identity_sha256"), str)
        or re.fullmatch(
            r"[0-9a-f]{64}", provenance["runtime_boot_identity_sha256"]
        )
        is None
    ):
        raise RuntimeError(
            "controller readiness has incomplete or mismatched model runtime provenance"
        )
    readiness_model_adapter = readiness.get("model_adapter")
    if not isinstance(readiness_model_adapter, dict) or not readiness_model_adapter:
        raise RuntimeError("controller readiness has no model-adapter provenance")

    output = args.output.expanduser().resolve()
    if args.resume and output.exists():
        report = json.loads(output.read_text())
        if report.get("kind") != "real-swe-baseline-calibration-sweep":
            raise RuntimeError("resume output has the wrong kind")
        if report.get("release_id") != readiness.get("release_id"):
            raise RuntimeError("resume output release ID changed")
        if report.get("corpus_manifest_sha256") != expected_corpus_sha256:
            raise RuntimeError("resume output corpus digest changed")
        if report.get("model_profile_sha256") != model_profile_sha256:
            raise RuntimeError("resume output model profile digest changed")
        if report.get("controller_image_id") != controller_image_sha256:
            raise RuntimeError("resume output controller image changed")
        if report.get("calibration_profiles_sha256") != sha256(
            calibration_profiles_path
        ):
            raise RuntimeError("resume output calibration profile digest changed")
        if report.get("scoring_policy_sha256") != sha256(scoring_policy_path):
            raise RuntimeError("resume output scoring policy digest changed")
        if (
            report.get("scoring_policy_contract_sha256")
            != expected_policy_contract_sha256
        ):
            raise RuntimeError("resume output scoring policy contract changed")
        if report.get("quality_gates") != quality_gates:
            raise RuntimeError("resume output quality gates changed")
        previous_readiness = report.get("controller_readiness", {})
        if previous_readiness.get("controller_config_sha256") != readiness.get(
            "controller_config_sha256"
        ):
            raise RuntimeError("resume output controller configuration digest changed")
        existing_order = report.get("profile_order")
        if not isinstance(existing_order, list):
            raise RuntimeError("resume output has no valid profile order")
        if args.release_qualification_profiles:
            if existing_order != list(profiles):
                raise RuntimeError(
                    "release-qualification resume profile order differs from the allowlist"
                )
            if report.get("profile_selection") != profile_selection:
                raise RuntimeError(
                    "release-qualification resume selection metadata changed"
                )
        else:
            report["profile_order"] = list(
                dict.fromkeys([*existing_order, *profiles])
            )
            report["profile_selection"] = {
                "mode": "resumed_diagnostics",
                "profiles": report["profile_order"],
            }
        report["status"] = "running"
        report["completed_at_utc"] = None
        report["last_resumed_at_utc"] = utc_now()
        atomic_write(output, report)
    else:
        if output.exists():
            raise RuntimeError(f"refusing to overwrite existing calibration evidence: {output}")
        report = {
            "schema_version": 1,
            "kind": "real-swe-baseline-calibration-sweep",
            "release_id": readiness.get("release_id"),
            "status": "running",
            "started_at_utc": utc_now(),
            "completed_at_utc": None,
            "controller_image_id": controller_image_sha256,
            "controller_readiness": readiness,
            "corpus_manifest_sha256": expected_corpus_sha256,
            "model_profile_sha256": model_profile_sha256,
            "calibration_profiles_sha256": sha256(calibration_profiles_path),
            "scoring_policy_sha256": sha256(scoring_policy_path),
            "scoring_policy_contract_sha256": expected_policy_contract_sha256,
            "quality_gates": quality_gates,
            "profile_selection": profile_selection,
            "profile_order": list(profiles),
            "summaries": {},
            "runs": {},
            "errors": [],
        }
        atomic_write(output, report)

    print(f"calibration evidence: {output}", flush=True)
    try:
        for profile in profiles:
            if profile in report["runs"]:
                failures = calibration_result_failures(
                    report["runs"][profile],
                    profile_name=profile,
                    expected_profile_config=expected_profile_configs[profile],
                    expected_release_id=expected_release_id,
                    expected_controller_config_sha256=expected_controller_config_sha256,
                    expected_provenance=provenance,
                    expected_model_adapter=readiness_model_adapter,
                    quality_gates=quality_gates,
                )
                if failures:
                    raise RuntimeError(
                        f"{profile} checkpoint validation failure: "
                        + ";".join(failures)
                    )
                print(f"SKIP {profile}: checkpoint already present", flush=True)
                continue
            print(f"START {profile} {utc_now()}", flush=True)
            response = controller_request(
                container,
                "POST",
                "/admin/run",
                {"suite": "calibration", "profile": profile, "mode": "baseline"},
                timeout_sec=args.request_timeout_sec,
            )
            result = response.get("result")
            if not isinstance(result, dict):
                raise RuntimeError(f"calibration response has no result: {response}")
            report["runs"][profile] = result
            report["summaries"][profile] = summarize(result)
            atomic_write(output, report)
            quality_failures = calibration_result_failures(
                result,
                profile_name=profile,
                expected_profile_config=expected_profile_configs[profile],
                expected_release_id=expected_release_id,
                expected_controller_config_sha256=expected_controller_config_sha256,
                expected_provenance=provenance,
                expected_model_adapter=readiness_model_adapter,
                quality_gates=quality_gates,
            )
            if quality_failures:
                raise RuntimeError(f"{profile} calibration quality failure: " + ";".join(quality_failures))
            print(
                "DONE "
                + profile
                + " "
                + json.dumps(report["summaries"][profile], separators=(",", ":"), sort_keys=True),
                flush=True,
            )
    except Exception as exc:
        report["status"] = "failed"
        report["completed_at_utc"] = utc_now()
        report["errors"].append(f"{type(exc).__name__}: {exc}")
        atomic_write(output, report)
        raise

    try:
        profile_order = report.get("profile_order")
        runs = report.get("runs")
        if (
            not isinstance(profile_order, list)
            or not isinstance(runs, dict)
            or set(profile_order) != set(runs)
            or len(profile_order) != len(set(profile_order))
        ):
            raise RuntimeError("calibration checkpoint profile/run set is inconsistent")
        for profile in profile_order:
            if profile not in expected_profile_configs or not isinstance(runs.get(profile), dict):
                raise RuntimeError(f"unknown or invalid calibration checkpoint profile: {profile}")
            failures = calibration_result_failures(
                runs[profile],
                profile_name=profile,
                expected_profile_config=expected_profile_configs[profile],
                expected_release_id=expected_release_id,
                expected_controller_config_sha256=expected_controller_config_sha256,
                expected_provenance=provenance,
                expected_model_adapter=readiness_model_adapter,
                quality_gates=quality_gates,
            )
            if failures:
                raise RuntimeError(
                    f"{profile} final checkpoint validation failure: "
                    + ";".join(failures)
                )
    except Exception as exc:
        report["status"] = "failed"
        report["completed_at_utc"] = utc_now()
        report["errors"].append(f"{type(exc).__name__}: {exc}")
        atomic_write(output, report)
        raise

    report["status"] = "complete"
    report["completed_at_utc"] = utc_now()
    atomic_write(output, report)
    print(f"COMPLETE {output}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
