#!/usr/bin/env bash
set -euo pipefail

task_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${task_root}"
export PYTHONPATH="tests:environment/bench-controller:environment/bench-controller/vendor"
pycache_root="$(mktemp -d -t kvbench-pycache.XXXXXX)"
export PYTHONPYCACHEPREFIX="${pycache_root}"
trap 'rm -rf -- "${pycache_root}"' EXIT

find environment tests author_tests scripts solution -name '*.py' -print0 \
  | xargs -0 python3 -m py_compile

python3 author_tests/pressure_metrics_unit.py
python3 author_tests/workload_watchdog_unit.py
python3 author_tests/candidate_admission_watchdog_unit.py
python3 author_tests/workflow_progress_unit.py
python3 author_tests/public_measurement_window_unit.py
python3 author_tests/finite_agent_execution_interval_unit.py
python3 author_tests/public_pair_state_unit.py
python3 author_tests/release_public_anchor_unit.py
python3 author_tests/runtime_boot_provenance_unit.py
python3 author_tests/public_cli_unit.py
python3 author_tests/corpus_isolation_unit.py
python3 author_tests/corpus_partition_unit.py
python3 author_tests/compact_corpus_unit.py
python3 author_tests/sandbox_parallel_unit.py
python3 author_tests/sandbox_pool_unit.py
python3 author_tests/sandbox_control_backpressure_unit.py
python3 author_tests/main_egress_seal_unit.py
python3 author_tests/formal_tier_observation_unit.py
python3 author_tests/retry_policy_unit.py
python3 author_tests/hidden_candidate_isolation_unit.py
python3 author_tests/hidden_suite_deadline_unit.py
python3 author_tests/verifier_bundle_isolation_unit.py
python3 author_tests/verifier_output_privacy_unit.py
python3 author_tests/failure_attribution_unit.py
python3 author_tests/model_profile_unit.py
python3 author_tests/model_api_topology_unit.py
python3 author_tests/oracle_isolation_unit.py
python3 author_tests/starter_gateway_unit.py
python3 author_tests/transport_credential_unit.py
python3 author_tests/qwen36_migration_unit.py
python3 author_tests/calibration_profile_192_unit.py
python3 author_tests/steady_window_calibration_unit.py
python3 author_tests/calibration_stack_unit.py
python3 author_tests/host_vllm_scope_unit.py
python3 author_tests/calibration_runner_contract_unit.py
python3 author_tests/qwen36_attestation_unit.py
python3 author_tests/release_manifest_evidence_unit.py
python3 author_tests/release_exporter_unit.py
python3 author_tests/release_manifest_currentness_unit.py
python3 author_tests/harbor_runtime_identity_unit.py
python3 author_tests/kv_budget_feasibility_unit.py
python3 author_tests/scoring_policy_unit.py
python3 author_tests/scoring_mutations.py
python3 author_tests/model_adapter_unit.py
python3 author_tests/model_adapter_contract_unit.py
python3 author_tests/tool_agent_unit.py
python3 author_tests/warmup_protocol_unit.py
python3 author_tests/program_lifecycle_unit.py
python3 author_tests/protocol_mutations.py
python3 author_tests/reference_gate_unit.py
python3 author_tests/reference_gateway_v5_tiers_unit.py
python3 author_tests/reference_pair_runner_unit.py
python3 author_tests/exploratory_hidden_abba_runner_unit.py
