#!/usr/bin/env python3
"""Exercise compact SWE-bench images as fresh parallel sibling runtimes."""

from __future__ import annotations

import argparse
import concurrent.futures
import errno
import hashlib
import json
import os
import socket
import tempfile
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

import docker


SOCKET_PATH = Path(os.environ.get("SANDBOX_SOCKET", "/run/kvbench-sandbox/control.sock"))
MANAGED_LABEL = "org.harbor-kv-scheduler.swe-sandbox"
IMPORT_CHECKS = {
    "astropy/astropy": "python -c 'import astropy'",
    "django/django": "python -c 'import django'",
    "matplotlib/matplotlib": "python -c 'import matplotlib'",
    "mwaskom/seaborn": "python -c 'import seaborn'",
    "pallets/flask": "python -c 'import flask'",
    "psf/requests": "python -c 'import requests'",
    "pytest-dev/pytest": "python -c 'import pytest'",
    "pydata/xarray": "python -c 'import xarray'",
    "pylint-dev/pylint": "python -c 'import pylint'",
    "scikit-learn/scikit-learn": "python -c 'import sklearn'",
    "sphinx-doc/sphinx": "python -c 'import sphinx'",
    "sympy/sympy": "python -c 'import sympy'",
}
RPC_CONNECT_MAX_ATTEMPTS = 20
RPC_CONNECT_BACKOFF_MAX_SEC = 0.25


def connect_control_socket(timeout: int) -> socket.socket:
    """Connect through a temporarily full UNIX listen queue without data loss."""

    transient_errnos = {errno.EAGAIN, errno.EWOULDBLOCK}
    for attempt in range(RPC_CONNECT_MAX_ATTEMPTS):
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(timeout)
        try:
            client.connect(str(SOCKET_PATH))
            return client
        except BlockingIOError as exc:
            client.close()
            if (
                exc.errno not in transient_errnos
                or attempt + 1 >= RPC_CONNECT_MAX_ATTEMPTS
            ):
                raise
            time.sleep(min(0.01 * (2**attempt), RPC_CONNECT_BACKOFF_MAX_SEC))
        except Exception:
            client.close()
            raise

    raise RuntimeError("unreachable control-socket retry state")


def rpc(payload: dict[str, Any], timeout: int = 190) -> dict[str, Any]:
    client = connect_control_socket(timeout)
    chunks = []
    try:
        client.sendall(json.dumps(payload, separators=(",", ":")).encode() + b"\n")
        client.shutdown(socket.SHUT_WR)
        while chunk := client.recv(65536):
            chunks.append(chunk)
    finally:
        client.close()
    response = json.loads(b"".join(chunks))
    if "protocol_error" in response:
        raise RuntimeError(response["protocol_error"])
    return response


def execute(sandbox_id: str, command: str, timeout: int = 60) -> dict[str, Any]:
    response = rpc(
        {
            "action": "execute",
            "sandbox_id": sandbox_id,
            "command": command,
            "timeout_sec": timeout,
        },
        timeout=timeout + 15,
    )
    if response.get("returncode") != 0:
        raise RuntimeError(f"command failed ({response.get('returncode')}): {response.get('output', '')[-1000:]}")
    return response


def assert_container_policy(client: docker.DockerClient, sandbox_id: str) -> None:
    container = client.containers.get(f"harbor-kv-swe-{sandbox_id}")
    container.reload()
    host = container.attrs["HostConfig"]
    if container.attrs.get("Mounts"):
        raise RuntimeError("SWE sandbox unexpectedly has a host/volume mount")
    if host.get("NetworkMode") != "none":
        raise RuntimeError("SWE sandbox network is not disabled")
    if "ALL" not in (host.get("CapDrop") or []):
        raise RuntimeError("SWE sandbox capabilities were not dropped")
    if "no-new-privileges:true" not in (host.get("SecurityOpt") or []):
        raise RuntimeError("SWE sandbox lacks no-new-privileges")
    if int(host.get("PidsLimit") or 0) != 1024:
        raise RuntimeError("SWE sandbox pids limit changed")
    if int(host.get("Memory") or 0) != 8 * 1024**3:
        raise RuntimeError("SWE sandbox memory limit changed")
    if int(host.get("NanoCpus") or 0) != 2_000_000_000:
        raise RuntimeError("SWE sandbox CPU quota changed")


def writable_layer_size(client: docker.DockerClient, sandbox_id: str) -> int | None:
    container = client.containers.get(f"harbor-kv-swe-{sandbox_id}")
    # docker-py 7.1 removed the public ``size=`` argument even though the
    # Engine API still exposes GET /containers/{id}/json?size=1.  The worker
    # image pins that SDK version, so use its stable low-level request helpers
    # and fail the soak if the daemon does not return SizeRw.
    response = client.api._get(
        client.api._url("/containers/{0}/json", container.id),
        params={"size": 1},
    )
    inspected = client.api._result(response, json=True)
    value = inspected.get("SizeRw")
    return int(value) if isinstance(value, int) and value >= 0 else None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--concurrency", type=int, default=72)
    parser.add_argument("--prepare-concurrency", type=int, default=16)
    parser.add_argument("--duration-sec", type=int, default=1800)
    parser.add_argument("--probe-interval-sec", type=int, default=60)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.concurrency <= 192:
        raise ValueError("--concurrency must be in 1..192")
    if not 1 <= args.prepare_concurrency <= min(args.concurrency, 32):
        raise ValueError("--prepare-concurrency must be in 1..min(concurrency, 32)")
    if args.duration_sec < 10 or not 5 <= args.probe_interval_sec <= 300:
        raise ValueError("soak duration or probe interval is invalid")
    manifest_bytes = args.manifest.read_bytes()
    manifest = json.loads(manifest_bytes)
    entries = sorted(
        (entry for entry in manifest.get("instances", []) if entry.get("partition") == "public"),
        key=lambda entry: str(entry.get("instance_id")),
    )
    if not entries:
        raise RuntimeError("public corpus is empty")
    repos = {str(entry["repo"]) for entry in entries}
    unknown_repos = repos - set(IMPORT_CHECKS)
    if unknown_repos:
        raise RuntimeError(f"missing offline import checks for repositories: {sorted(unknown_repos)}")

    client = docker.from_env(timeout=180)
    client.ping()
    existing = client.containers.list(all=True, filters={"label": f"{MANAGED_LABEL}=true"})
    if existing:
        raise RuntimeError(f"managed SWE containers exist before soak: {[container.name for container in existing]}")

    started_unix = time.time()
    steady_started = 0.0
    steady_deadline = 0.0

    def start_steady_interval() -> None:
        nonlocal steady_started, steady_deadline
        steady_started = time.monotonic()
        steady_deadline = steady_started + args.duration_sec

    barrier = threading.Barrier(args.concurrency, action=start_steady_interval)
    prepare_gate = threading.Semaphore(args.prepare_concurrency)
    lock = threading.Lock()
    # docker-py's UNIX adapter is not safe when one client is used
    # concurrently for many distinct URL paths: its small URL-keyed LRU can
    # close a pool that another thread is still using.  Soak-side inspection
    # is diagnostic and short, so serialize it on the inventory client.
    docker_probe_lock = threading.Lock()
    lifecycle_count = 0
    command_count = 0
    used_instances: set[str] = set()
    errors: list[str] = []
    active_ids: set[str] = set()
    max_active = 0
    steady_holds: dict[int, float] = {}
    writable_samples: dict[int, list[int]] = defaultdict(list)

    def worker(slot: int) -> None:
        nonlocal lifecycle_count, command_count, max_active
        for cycle in range(3):
            entry = entries[(slot + cycle * args.concurrency) % len(entries)]
            sandbox_id = hashlib.sha256(f"soak:{slot}:{cycle}:{started_unix}".encode()).hexdigest()[:32]
            created = False
            try:
                with prepare_gate:
                    response = rpc(
                        {
                            "action": "create",
                            "sandbox_id": sandbox_id,
                            "image": entry["image_name"],
                            "image_digest": entry["image_digest"],
                            "base_commit": entry["base_commit"],
                            "runtime_head_commit": entry["runtime_head_commit"],
                        }
                    )
                    if response.get("created") is not True:
                        raise RuntimeError(f"create returned an invalid response: {response}")
                    created = True
                    with lock:
                        active_ids.add(sandbox_id)
                        max_active = max(max_active, len(active_ids))
                        used_instances.add(str(entry["instance_id"]))
                    with docker_probe_lock:
                        assert_container_policy(client, sandbox_id)
                    marker = f".kvbench-soak-history-{slot}"
                    execute(
                        sandbox_id,
                        f"test ! -e {marker} && test ! -S /var/run/docker.sock && "
                        f"printf '%s\\n' {cycle} > {marker} && git diff --check",
                    )
                    execute(sandbox_id, IMPORT_CHECKS[str(entry["repo"])], timeout=120)
                    with lock:
                        command_count += 2
                if cycle == 0:
                    barrier.wait(timeout=600)
                    with docker_probe_lock:
                        initial_size = writable_layer_size(client, sandbox_id)
                    if initial_size is not None:
                        with lock:
                            writable_samples[slot].append(initial_size)
                    while time.monotonic() < steady_deadline:
                        execute(sandbox_id, f"test -f {marker} && git diff --check")
                        with docker_probe_lock:
                            sampled_size = writable_layer_size(client, sandbox_id)
                        with lock:
                            command_count += 1
                            if sampled_size is not None:
                                writable_samples[slot].append(sampled_size)
                        time.sleep(
                            min(
                                float(args.probe_interval_sec),
                                max(0.0, steady_deadline - time.monotonic()),
                            )
                        )
                    with lock:
                        steady_holds[slot] = time.monotonic() - steady_started
            finally:
                if created:
                    cleanup = rpc(
                        {"action": "cleanup", "sandbox_id": sandbox_id}, timeout=75
                    )
                    if cleanup.get("removed") is not True:
                        raise RuntimeError(
                            f"cleanup returned an invalid response: {cleanup}"
                        )
                    with lock:
                        active_ids.discard(sandbox_id)
            with lock:
                lifecycle_count += 1

    def guarded_worker(slot: int) -> None:
        try:
            worker(slot)
        except Exception as exc:
            with lock:
                errors.append(f"slot={slot}: {type(exc).__name__}: {exc}")
            try:
                barrier.abort()
            except Exception:
                pass

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        list(pool.map(guarded_worker, range(args.concurrency)))

    leftovers = client.containers.list(all=True, filters={"label": f"{MANAGED_LABEL}=true"})
    writable_growth = {
        slot: max(samples) - samples[0]
        for slot, samples in writable_samples.items()
        if len(samples) >= 2
    }
    report = {
        "schema_version": 1,
        "kind": "swebench-sandbox-soak",
        "passed": (
            not errors
            and not leftovers
            and not active_ids
            and max_active == args.concurrency
            and lifecycle_count >= args.concurrency * 3
            and len(steady_holds) == args.concurrency
            and min(steady_holds.values(), default=0) >= args.duration_sec
            and len(writable_growth) == args.concurrency
            and max(writable_growth.values(), default=0) <= 1024**2
        ),
        "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "concurrency": args.concurrency,
        "prepare_concurrency": args.prepare_concurrency,
        "duration_target_sec": args.duration_sec,
        "elapsed_sec": time.time() - started_unix,
        "probe_interval_sec": args.probe_interval_sec,
        "minimum_steady_hold_sec": min(steady_holds.values(), default=0),
        "writable_layer_slots_sampled": len(writable_growth),
        "maximum_writable_layer_peak_growth_bytes": max(writable_growth.values(), default=0),
        "total_writable_layer_peak_growth_bytes": sum(writable_growth.values()),
        "lifecycle_count": lifecycle_count,
        "command_count": command_count,
        "unique_instances_exercised": len(used_instances),
        "rollout_reuse": len(entries) < args.concurrency,
        "fresh_container_per_rollout": True,
        "max_active_containers": max_active,
        "active_runtime_ids_after": sorted(active_ids),
        "leftover_containers": [container.name for container in leftovers],
        "errors": errors[:50],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(report, indent=2, sort_keys=True) + "\n").encode()
    with tempfile.NamedTemporaryFile(prefix="soak-", suffix=".json", dir=args.output.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.chmod(0o644)
    temporary.replace(args.output)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
