#!/usr/bin/env python3
"""Plan or invoke the fail-closed author-only steady-window protocol.

The current Harbor controller does not implement this protocol.  ``plan`` is
fully local, while ``check`` and ``run`` require an exact capability handshake
from a future author controller before any run request is sent.  This prevents
the finite-workflow ``/admin/run`` endpoint from being mislabeled as rolling
steady-state evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable, Mapping


TASK_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PROFILE_PATH = TASK_ROOT / "author_profiles" / "qwen36-steady-window.json"
DEFAULT_PROFILE = "qwen36-paper-window-192-deep135"
PROTOCOL_ID = "kvbench-steady-window-rolling-v1"
PROFILE_SET_KIND = "kvbench-author-steady-window-profile-set"
RESULT_KIND = "kvbench-author-steady-window-leg"
ALLOWED_SLOTS = (96, 144, 168, 192)
EXPECTED_CONTROLLER_PROTOCOL = {
    "id": PROTOCOL_ID,
    "schema_version": 1,
    "capabilities_path": "/admin/calibration/steady-window/capabilities",
    "run_path": "/admin/calibration/steady-window/run",
}
EXPECTED_SEMANTICS = {
    "audit_scope": "ramp-window-drain-all-requests",
    "fairness_unit": "persistent-slot-window-tool-completions",
    "inflight_at_window_end": "drain-without-window-boundary-cancellation",
    "numerator_event": "tool-completed-with-returncode",
    "numerator_interval": "closed-open-window",
    "replacement_policy": "natural-terminal-only-before-window-end",
    "rollout_identity": "unique-run-id-and-cache-namespace",
    "window_end_policy": "stop-before-next-model-query",
}
REQUIRED_CAPABILITIES = (
    "author_only_no_scoring_mutation",
    "fixed_slots",
    "full_ramp_window_drain_audit",
    "inflight_drain_without_window_cancel",
    "natural_terminal_rolling_replacement",
    "persistent_slot_fairness",
    "per_rollout_unique_identity",
    "step_boundary_window_close",
    "tool_completion_window_numerator",
)
PROFILE_KEYS = {
    "enabled",
    "release_evidence_eligible",
    "slots",
    "max_rollout_steps",
    "max_tokens",
    "ramp_sec",
    "window_sec",
    "drain_timeout_sec",
    "rollout_cap_per_slot",
    "workflow_timeout_sec",
    "request_timeout_sec",
    "tool_timeout_sec",
    "seed",
    "workload_sequence_id",
    "workload_family",
    "corpus_partition",
    "corpus_unique_instances_min",
    "warmup_requests",
    "warmup_steps",
    "metrics_sample_interval_sec",
    "backend_stall_timeout_sec",
    "candidate_admission_stall_timeout_sec",
    "minimum_slot_steps",
    "minimum_slot_jain_fairness",
    "pressure_required",
}


class ContractError(ValueError):
    """An author profile, capability, or result violated the frozen schema."""


class CapabilityUnavailable(RuntimeError):
    """The controller cannot safely execute the author-only protocol."""


Requester = Callable[[str, str, Mapping[str, Any] | None, int], dict[str, Any]]


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def integer(value: object, *, minimum: int, maximum: int | None = None) -> bool:
    return (
        isinstance(value, int)
        and not isinstance(value, bool)
        and value >= minimum
        and (maximum is None or value <= maximum)
    )


def finite_number(
    value: object,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    number = float(value)
    return (
        math.isfinite(number)
        and (minimum is None or number >= minimum)
        and (maximum is None or number <= maximum)
    )


def profile_sha256(
    name: str,
    config: Mapping[str, Any],
    semantics_sha256: str,
) -> str:
    return digest(
        {
            "name": name,
            "config": config,
            "protocol": PROTOCOL_ID,
            "semantics_sha256": semantics_sha256,
        }
    )


def _validate_profile(name: str, config: object) -> dict[str, Any]:
    if not isinstance(config, dict):
        raise ContractError(f"profile {name} must be a JSON object")
    missing = sorted(PROFILE_KEYS - set(config))
    extra = sorted(set(config) - PROFILE_KEYS)
    if missing or extra:
        raise ContractError(
            f"profile {name} fields differ: missing={missing}, extra={extra}"
        )
    if config["enabled"] is not True:
        raise ContractError(f"profile {name} must be enabled")
    if config["release_evidence_eligible"] is not False:
        raise ContractError(f"profile {name} must remain author-only evidence")
    slots = config["slots"]
    if slots not in ALLOWED_SLOTS:
        raise ContractError(f"profile {name} has unsupported slots: {slots!r}")
    expected_name = f"qwen36-paper-window-{slots}-deep135"
    if name != expected_name:
        raise ContractError(f"profile {name} does not match slot count {slots}")
    exact = {
        "max_rollout_steps": 135,
        "max_tokens": 2048,
        "workload_family": "swebench-lite",
        "corpus_partition": "public",
        "workload_sequence_id": "qwen36-paper-window-public-v1",
        "warmup_requests": 4,
        "warmup_steps": 3,
        "pressure_required": False,
    }
    for key, expected in exact.items():
        if config[key] != expected:
            raise ContractError(
                f"profile {name} requires {key}={expected!r}, got {config[key]!r}"
            )
    for key, minimum, maximum in (
        ("ramp_sec", 1, 3600),
        ("window_sec", 60, 14_400),
        ("drain_timeout_sec", 60, 3600),
        ("rollout_cap_per_slot", 2, 128),
        ("workflow_timeout_sec", 60, 14_400),
        ("request_timeout_sec", 30, 3600),
        ("tool_timeout_sec", 1, 120),
        ("corpus_unique_instances_min", 6, 300),
        ("backend_stall_timeout_sec", 10, 300),
        ("candidate_admission_stall_timeout_sec", 10, 300),
        ("minimum_slot_steps", 1, 135 * 128),
    ):
        if not integer(config[key], minimum=minimum, maximum=maximum):
            raise ContractError(f"profile {name} has invalid {key}: {config[key]!r}")
    if config["request_timeout_sec"] > config["workflow_timeout_sec"]:
        raise ContractError(f"profile {name} request timeout exceeds workflow timeout")
    if config["workflow_timeout_sec"] < config["ramp_sec"] + config["window_sec"]:
        raise ContractError(f"profile {name} cannot keep an initial rollout for the window")
    if not integer(config["seed"], minimum=0):
        raise ContractError(f"profile {name} has invalid seed")
    if not finite_number(
        config["metrics_sample_interval_sec"], minimum=0.1, maximum=10.0
    ):
        raise ContractError(f"profile {name} has invalid metrics interval")
    if not finite_number(
        config["minimum_slot_jain_fairness"], minimum=0.0, maximum=1.0
    ):
        raise ContractError(f"profile {name} has invalid fairness floor")
    return dict(config)


def validate_profile_set(payload: object) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ContractError("profile set must be a JSON object")
    expected_keys = {
        "schema_version",
        "kind",
        "author_only",
        "release_qualification_profiles",
        "controller_protocol",
        "semantics",
        "profiles",
    }
    if set(payload) != expected_keys:
        raise ContractError(
            "profile-set fields differ: "
            f"missing={sorted(expected_keys - set(payload))}, "
            f"extra={sorted(set(payload) - expected_keys)}"
        )
    if payload["schema_version"] != 1 or payload["kind"] != PROFILE_SET_KIND:
        raise ContractError("unsupported steady-window profile-set identity")
    if payload["author_only"] is not True:
        raise ContractError("steady-window profile set is not author-only")
    if payload["release_qualification_profiles"] != []:
        raise ContractError("steady-window profiles cannot enter release qualification")
    if payload["controller_protocol"] != EXPECTED_CONTROLLER_PROTOCOL:
        raise ContractError("controller protocol paths or identity changed")
    if payload["semantics"] != EXPECTED_SEMANTICS:
        raise ContractError("steady-window measurement semantics changed")
    profiles = payload["profiles"]
    if not isinstance(profiles, dict):
        raise ContractError("steady-window profiles must be an object")
    validated = {
        name: _validate_profile(name, config) for name, config in profiles.items()
    }
    if {config["slots"] for config in validated.values()} != set(ALLOWED_SLOTS):
        raise ContractError("steady-window matrix must contain 96/144/168/192 slots")
    if len(validated) != len(ALLOWED_SLOTS):
        raise ContractError("steady-window matrix contains duplicate slot shapes")
    return {
        **payload,
        "profiles": validated,
        "semantics_sha256": digest(payload["semantics"]),
    }


def load_profile_set(path: Path = DEFAULT_PROFILE_PATH) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise ContractError(f"could not load steady-window profiles: {exc}") from exc
    return validate_profile_set(payload)


def select_profile(profile_set: Mapping[str, Any], name: str) -> dict[str, Any]:
    profiles = profile_set.get("profiles")
    if not isinstance(profiles, dict) or name not in profiles:
        raise ContractError(f"unknown steady-window profile: {name}")
    config = profiles[name]
    if not isinstance(config, dict):
        raise ContractError(f"invalid steady-window profile: {name}")
    return config


def plan(profile_set: Mapping[str, Any], name: str) -> dict[str, Any]:
    config = select_profile(profile_set, name)
    semantics_sha256 = str(profile_set["semantics_sha256"])
    return {
        "schema_version": 1,
        "kind": "kvbench-author-steady-window-plan",
        "author_only": True,
        "release_evidence_eligible": False,
        "execution_status": "requires-exact-controller-capability-handshake",
        "protocol": PROTOCOL_ID,
        "semantics_sha256": semantics_sha256,
        "profile_name": name,
        "profile_sha256": profile_sha256(name, config, semantics_sha256),
        "profile_config": config,
        "planned_rollout_cap": config["slots"] * config["rollout_cap_per_slot"],
        "fixed_slot_count": config["slots"],
        "minimum_leg_wall_sec": config["ramp_sec"] + config["window_sec"],
        "maximum_valid_leg_wall_sec": (
            config["ramp_sec"] + config["window_sec"] + config["drain_timeout_sec"]
        ),
        "primary_metric": {
            "name": "steady_valid_steps_per_min",
            "numerator": EXPECTED_SEMANTICS["numerator_event"],
            "interval": EXPECTED_SEMANTICS["numerator_interval"],
            "denominator_sec": config["window_sec"],
        },
        "fairness": {
            "unit": EXPECTED_SEMANTICS["fairness_unit"],
            "minimum_slot_steps": config["minimum_slot_steps"],
            "minimum_jain": config["minimum_slot_jain_fairness"],
        },
        "audit_scope": EXPECTED_SEMANTICS["audit_scope"],
    }


def validate_capability(
    payload: object,
    *,
    profile: Mapping[str, Any],
    semantics_sha256: str,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise CapabilityUnavailable("capability response is not a JSON object")
    checks = (
        (payload.get("schema_version") == 1, "schema_version"),
        (payload.get("protocol") == PROTOCOL_ID, "protocol"),
        (payload.get("author_only") is True, "author_only"),
        (payload.get("supported") is True, "supported"),
        (
            payload.get("semantics_sha256") == semantics_sha256,
            "semantics_sha256",
        ),
        (payload.get("result_schema_version") == 1, "result_schema_version"),
    )
    failed = [label for passed, label in checks if not passed]
    features = payload.get("features")
    if not isinstance(features, dict):
        failed.append("features")
    else:
        failed.extend(
            f"feature:{name}"
            for name in REQUIRED_CAPABILITIES
            if features.get(name) is not True
        )
    slots = payload.get("supported_slots")
    if (
        not isinstance(slots, list)
        or any(not integer(value, minimum=1) for value in slots)
        or profile["slots"] not in slots
    ):
        failed.append("supported_slots")
    if not integer(
        payload.get("max_rollout_steps"),
        minimum=int(profile["max_rollout_steps"]),
    ):
        failed.append("max_rollout_steps")
    if failed:
        raise CapabilityUnavailable(
            "controller does not implement the frozen author-only steady-window "
            "protocol; no run request was sent; failed=" + ",".join(failed)
        )
    return dict(payload)


def jain(values: list[int]) -> float:
    if not values or not any(values):
        return 0.0
    return sum(values) ** 2 / (len(values) * sum(value * value for value in values))


def validate_leg_result(
    payload: object,
    *,
    profile_name: str,
    profile: Mapping[str, Any],
    semantics_sha256: str,
    mode: str,
    workload_nonce: str,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ContractError("steady-window result is not a JSON object")
    expected_identity = {
        "schema_version": 1,
        "kind": RESULT_KIND,
        "author_only": True,
        "release_evidence_eligible": False,
        "protocol": PROTOCOL_ID,
        "semantics_sha256": semantics_sha256,
        "profile_name": profile_name,
        "profile_sha256": profile_sha256(
            profile_name, profile, semantics_sha256
        ),
        "mode": mode,
        "workload_nonce_sha256": hashlib.sha256(workload_nonce.encode()).hexdigest(),
        "profile_config": dict(profile),
    }
    mismatches = [
        key for key, expected in expected_identity.items() if payload.get(key) != expected
    ]
    if mismatches:
        raise ContractError(
            "steady-window result identity mismatch: " + ",".join(mismatches)
        )
    measurement = payload.get("measurement")
    if not isinstance(measurement, dict):
        raise ContractError("steady-window result has no measurement contract")
    required_measurement = {
        "ramp_sec": profile["ramp_sec"],
        "window_sec": profile["window_sec"],
        "drain_timeout_sec": profile["drain_timeout_sec"],
        "numerator_event": EXPECTED_SEMANTICS["numerator_event"],
        "numerator_interval": EXPECTED_SEMANTICS["numerator_interval"],
        "replacement_policy": EXPECTED_SEMANTICS["replacement_policy"],
        "window_end_policy": EXPECTED_SEMANTICS["window_end_policy"],
        "audit_scope": EXPECTED_SEMANTICS["audit_scope"],
        "post_window_model_query_starts": 0,
        "window_boundary_client_cancellations": 0,
        "drain_completed": True,
    }
    bad_measurement = [
        key
        for key, expected in required_measurement.items()
        if measurement.get(key) != expected
    ]
    if bad_measurement:
        raise ContractError(
            "steady-window boundary contract failed: " + ",".join(bad_measurement)
        )
    timestamps = [
        measurement.get(key)
        for key in (
            "ramp_started_unix",
            "window_started_unix",
            "window_ended_unix",
            "drain_ended_unix",
        )
    ]
    if not all(finite_number(value, minimum=0.0) for value in timestamps):
        raise ContractError("steady-window result has invalid timestamps")
    ramp_started, window_started, window_ended, drain_ended = map(float, timestamps)
    if not (
        ramp_started <= window_started < window_ended <= drain_ended
        and abs((window_started - ramp_started) - profile["ramp_sec"]) <= 2.0
        and abs((window_ended - window_started) - profile["window_sec"]) <= 2.0
        and drain_ended - window_ended <= profile["drain_timeout_sec"] + 2.0
    ):
        raise ContractError("steady-window timestamp boundaries changed")
    steady = payload.get("steady")
    if not isinstance(steady, dict):
        raise ContractError("steady-window result has no steady metrics")
    valid_steps = steady.get("valid_steps")
    slot_steps = steady.get("slot_valid_steps")
    if (
        not integer(valid_steps, minimum=0)
        or not isinstance(slot_steps, list)
        or len(slot_steps) != profile["slots"]
        or any(not integer(value, minimum=0) for value in slot_steps)
        or sum(slot_steps) != valid_steps
    ):
        raise ContractError("steady-window slot step accounting is invalid")
    expected_rate = valid_steps * 60.0 / profile["window_sec"]
    if not finite_number(steady.get("valid_steps_per_min"), minimum=0.0) or not math.isclose(
        float(steady["valid_steps_per_min"]), expected_rate, rel_tol=1e-12, abs_tol=1e-12
    ):
        raise ContractError("steady-window rate does not use the fixed denominator")
    expected_jain = jain(slot_steps)
    if not finite_number(steady.get("slot_jain_fairness"), minimum=0.0, maximum=1.0) or not math.isclose(
        float(steady["slot_jain_fairness"]), expected_jain, rel_tol=1e-12, abs_tol=1e-12
    ):
        raise ContractError("steady-window slot fairness is inconsistent")
    if steady.get("minimum_slot_steps") != min(slot_steps):
        raise ContractError("steady-window minimum slot progress is inconsistent")
    rollouts = payload.get("rollouts")
    if not isinstance(rollouts, dict):
        raise ContractError("steady-window result has no rollout accounting")
    started = rollouts.get("started")
    natural = rollouts.get("natural_terminal")
    replacements = rollouts.get("replacements_started")
    censored = rollouts.get("window_censored")
    if not all(integer(value, minimum=0) for value in (started, natural, replacements, censored)):
        raise ContractError("steady-window rollout counts are invalid")
    if (
        started < profile["slots"]
        or started > profile["slots"] * profile["rollout_cap_per_slot"]
        or replacements != started - profile["slots"]
        or natural < replacements
        or censored > profile["slots"]
        or rollouts.get("rollout_cap_exhausted") is not False
    ):
        raise ContractError("steady-window rolling replacement contract failed")
    audit = payload.get("backend_audit")
    if not isinstance(audit, dict):
        raise ContractError("steady-window result has no backend audit")
    if (
        audit.get("scope") != EXPECTED_SEMANTICS["audit_scope"]
        or audit.get("passed") is not True
        or not integer(audit.get("client_requests"), minimum=1)
        or audit.get("audited_backend_requests") != audit.get("client_requests")
    ):
        raise ContractError("steady-window full-lifecycle audit failed")
    lifecycle = payload.get("program_lifecycle")
    if not isinstance(lifecycle, dict):
        raise ContractError("steady-window result has no lifecycle accounting")
    expected_releases = started if mode == "candidate" else 0
    if (
        lifecycle.get("measured_release_attempted") != expected_releases
        or lifecycle.get("measured_release_acknowledged") != expected_releases
        or lifecycle.get("measured_release_failed") != 0
    ):
        raise ContractError("steady-window program lifecycle release failed")
    return dict(payload)


def _controller_url(base: str, path: str) -> str:
    parsed = urllib.parse.urlsplit(base)
    if (
        parsed.scheme != "http"
        or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ContractError("controller base must be a credential-free loopback HTTP URL")
    base_path = parsed.path.rstrip("/")
    return urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, f"{base_path}{path}", "", "")
    )


def make_requester(controller_base: str, token: str) -> Requester:
    if not token:
        raise ContractError("admin token is empty")

    def request(method: str, path: str, payload: Mapping[str, Any] | None, timeout: int) -> dict[str, Any]:
        body = canonical_json(payload) if payload is not None else None
        raw = urllib.request.Request(
            _controller_url(controller_base, path),
            data=body,
            method=method,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(raw, timeout=timeout) as response:
                parsed = json.loads(response.read())
        except urllib.error.HTTPError as exc:
            detail = exc.read(4096).decode(errors="replace")
            if method == "GET":
                raise CapabilityUnavailable(
                    f"controller capability endpoint returned HTTP {exc.code}; "
                    "no run request was sent; detail=" + detail[:500]
                ) from exc
            raise RuntimeError(
                f"steady-window run endpoint returned HTTP {exc.code}: {detail[:500]}"
            ) from exc
        except (OSError, json.JSONDecodeError) as exc:
            if method == "GET":
                raise CapabilityUnavailable(
                    f"controller capability handshake failed; no run request was sent: {exc}"
                ) from exc
            raise RuntimeError(f"steady-window run request failed: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ContractError("controller response is not a JSON object")
        return parsed

    return request


def execute_author_leg(
    *,
    profile_set: Mapping[str, Any],
    profile_name: str,
    mode: str,
    workload_nonce: str,
    requester: Requester,
) -> dict[str, Any]:
    if mode not in {"baseline", "candidate"}:
        raise ContractError(f"invalid steady-window mode: {mode}")
    if re.fullmatch(r"[A-Za-z0-9_.:-]{16,128}", workload_nonce) is None:
        raise ContractError("workload nonce must be 16-128 safe ASCII characters")
    profile = select_profile(profile_set, profile_name)
    semantics_sha256 = str(profile_set["semantics_sha256"])
    controller = profile_set["controller_protocol"]
    capability = requester(
        "GET",
        str(controller["capabilities_path"]),
        None,
        30,
    )
    validate_capability(
        capability,
        profile=profile,
        semantics_sha256=semantics_sha256,
    )
    request_payload = {
        "schema_version": 1,
        "protocol": PROTOCOL_ID,
        "author_only": True,
        "profile_name": profile_name,
        "profile_sha256": profile_sha256(
            profile_name, profile, semantics_sha256
        ),
        "profile_config": profile,
        "semantics": profile_set["semantics"],
        "semantics_sha256": semantics_sha256,
        "mode": mode,
        "workload_nonce": workload_nonce,
    }
    response = requester(
        "POST",
        str(controller["run_path"]),
        request_payload,
        int(profile["ramp_sec"] + profile["window_sec"] + profile["drain_timeout_sec"] + 300),
    )
    result = response.get("result")
    return validate_leg_result(
        result,
        profile_name=profile_name,
        profile=profile,
        semantics_sha256=semantics_sha256,
        mode=mode,
        workload_nonce=workload_nonce,
    )


def atomic_write(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, raw = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(raw)
    try:
        with os.fdopen(descriptor, "w") as stream:
            json.dump(payload, stream, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--profiles", type=Path, default=DEFAULT_PROFILE_PATH)
    subcommands = result.add_subparsers(dest="command", required=True)
    plan_command = subcommands.add_parser("plan", help="print a local immutable plan")
    plan_command.add_argument("--profile", default=DEFAULT_PROFILE)
    check_command = subcommands.add_parser(
        "check", help="perform only the read-only controller capability handshake"
    )
    check_command.add_argument("--profile", default=DEFAULT_PROFILE)
    check_command.add_argument("--controller-base", default="http://127.0.0.1:7000")
    check_command.add_argument(
        "--admin-token-file", type=Path, default=Path("/run/kvbench-admin/token")
    )
    run_command = subcommands.add_parser(
        "run", help="run one leg only after the exact capability handshake"
    )
    run_command.add_argument("--profile", default=DEFAULT_PROFILE)
    run_command.add_argument("--mode", choices=("baseline", "candidate"), required=True)
    run_command.add_argument("--workload-nonce", required=True)
    run_command.add_argument("--controller-base", default="http://127.0.0.1:7000")
    run_command.add_argument(
        "--admin-token-file", type=Path, default=Path("/run/kvbench-admin/token")
    )
    run_command.add_argument("--output", type=Path, required=True)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        profile_set = load_profile_set(args.profiles)
        if args.command == "plan":
            print(json.dumps(plan(profile_set, args.profile), indent=2, sort_keys=True))
            return 0
        profile = select_profile(profile_set, args.profile)
        token = args.admin_token_file.read_text().strip()
        requester = make_requester(args.controller_base, token)
        if args.command == "check":
            capability = requester(
                "GET",
                str(profile_set["controller_protocol"]["capabilities_path"]),
                None,
                30,
            )
            checked = validate_capability(
                capability,
                profile=profile,
                semantics_sha256=str(profile_set["semantics_sha256"]),
            )
            print(json.dumps(checked, indent=2, sort_keys=True))
            return 0
        result = execute_author_leg(
            profile_set=profile_set,
            profile_name=args.profile,
            mode=args.mode,
            workload_nonce=args.workload_nonce,
            requester=requester,
        )
        atomic_write(args.output, result)
        print(json.dumps({"output": str(args.output), "result": result}, indent=2, sort_keys=True))
        return 0
    except (ContractError, CapabilityUnavailable, OSError, RuntimeError) as exc:
        print(f"steady-window calibration refused: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
