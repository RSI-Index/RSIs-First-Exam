#!/usr/bin/env bash
set -euo pipefail

task_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
container_name="kvbench-isolation-test-$$"
scratch_root=""
host_uid="$(id -u)"
host_gid="$(id -g)"

if ! docker info >/dev/null 2>&1; then
  if [[ "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" == 1 ]]; then
    echo "Docker remains unavailable after entering the docker group" >&2
    exit 2
  fi
  printf -v reexec 'KV_TASK_DOCKER_GROUP_REEXEC=1 exec %q' "$0"
  exec sg docker -c "$reexec"
fi

if docker container inspect "${container_name}" >/dev/null 2>&1; then
  echo "refusing to reuse existing container: ${container_name}" >&2
  exit 2
fi

cleanup() {
  if docker container inspect "${container_name}" >/dev/null 2>&1; then
    # The entrypoint intentionally root-seals the verifier bind. Return this
    # test's exact mktemp roots to the invoking user before removing them.
    docker exec "${container_name}" sh -ceu '
      chown -R 0:0 /logs/agent /logs/artifacts /logs/verifier
      chmod -R u+rwX /logs/agent /logs/artifacts /logs/verifier
      chown -R "$1:$2" /logs/agent /logs/artifacts /logs/verifier
    ' sh "$host_uid" "$host_gid" >/dev/null 2>&1 || true
  fi
  docker stop --time 1 "${container_name}" >/dev/null 2>&1 || true
  if [[ -n "$scratch_root" && "$scratch_root" == /tmp/kvbench-hidden-isolation.* ]]; then
    rm -rf -- "$scratch_root"
  fi
}
trap cleanup EXIT

scratch_root="$(mktemp -d -t kvbench-hidden-isolation.XXXXXX)"
mkdir -p \
  "$scratch_root/agent" \
  "$scratch_root/artifacts" \
  "$scratch_root/verifier" \
  "$scratch_root/admin"
chmod 0777 "$scratch_root/agent" "$scratch_root/artifacts" "$scratch_root/verifier"
printf '%s\n' 'kvbench-hidden-isolation-disposable-admin-token' \
  > "$scratch_root/admin/token"
chmod 0400 "$scratch_root/admin/token"

docker run --rm --detach \
  --name "${container_name}" \
  --init \
  --network none \
  --security-opt no-new-privileges:true \
  --cap-drop ALL \
  --cap-add CHOWN \
  --cap-add DAC_OVERRIDE \
  --cap-add KILL \
  --cap-add SETGID \
  --cap-add SETUID \
  --mount "type=bind,source=${task_root},target=/workspace,readonly" \
  --mount "type=bind,source=${scratch_root}/agent,target=/logs/agent" \
  --mount "type=bind,source=${scratch_root}/artifacts,target=/logs/artifacts" \
  --mount "type=bind,source=${scratch_root}/verifier,target=/logs/verifier" \
  --mount "type=bind,source=${scratch_root}/admin,target=/run/kvbench-admin,readonly" \
  harbor-kv/main:qwen36-27b-tp2-public30-r2 /bin/sleep infinity >/dev/null

for _ in $(seq 1 100); do
  if docker exec "${container_name}" test -f \
    /run/kvbench-log-guard/verifier-root.meta 2>/dev/null; then
    break
  fi
  sleep 0.05
done
docker exec "${container_name}" test -f \
  /run/kvbench-log-guard/verifier-root.meta

# This is the exact pre-agent attack the entrypoint guard must prevent. A test
# performed only after test.sh starts would be too late because Harbor's root
# shell opens test-stdout.txt before invoking that script.
if docker exec "${container_name}" setpriv \
  --reuid candidate --regid candidate --init-groups --no-new-privs \
  ln -s /run/kvbench-admin/token /logs/verifier/test-stdout.txt \
  >/dev/null 2>&1; then
  echo "candidate unexpectedly planted verifier stdout symlink" >&2
  exit 1
fi
if docker exec "${container_name}" setpriv \
  --reuid candidate --regid candidate --init-groups --no-new-privs \
  mkfifo /logs/verifier/test-stdout.txt \
  >/dev/null 2>&1; then
  echo "candidate unexpectedly planted verifier stdout FIFO" >&2
  exit 1
fi
docker exec "${container_name}" test ! -e /logs/verifier/test-stdout.txt

docker exec "${container_name}" bash -ceu '
  cp -r /workspace/solution/reference_gateway /run/kvbench-isolation-frozen
  chown -R 0:0 /run/kvbench-isolation-frozen
  find /run/kvbench-isolation-frozen -type d -exec chmod 0555 {} +
  find /run/kvbench-isolation-frozen -type f -exec chmod 0444 {} +
  chmod 0555 /run/kvbench-isolation-frozen/launch.sh
'
docker exec \
  --env PYTHONPATH=/workspace/tests \
  "${container_name}" \
  python3 /workspace/author_tests/hidden_candidate_reset_integration.py

# Exercise tests/test.sh's EXIT restoration against the real bind root without
# starting the expensive benchmark. The fake python executable replaces only
# verify.py after all shell-side kill/clear/reward/trap logic has run.
docker exec "${container_name}" sh -ceu '
  install -d -o root -g root -m 0700 /run/kvbench-test-fake-bin
  printf "%s\n" "#!/bin/sh" "exit 0" \
    > /run/kvbench-test-fake-bin/python3
  chmod 0555 /run/kvbench-test-fake-bin/python3
'
docker exec \
  --env PATH=/run/kvbench-test-fake-bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  "${container_name}" \
  bash /workspace/tests/test.sh
restored_verifier_metadata="$(
  docker exec "${container_name}" stat -c '%u:%g:%a' /logs/verifier
)"
[[ "$restored_verifier_metadata" == "$host_uid:$host_gid:777" ]] || {
  echo "test.sh did not restore verifier bind metadata: $restored_verifier_metadata" >&2
  exit 1
}
[[ "$(tr -d '[:space:]' < "$scratch_root/verifier/reward.txt")" == 0 ]] || {
  echo "restored verifier bind is not readable by the Harbor host user" >&2
  exit 1
}
