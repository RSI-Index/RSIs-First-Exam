#!/usr/bin/env bash
set -Eeuo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_dir="$(cd -- "$script_dir/.." && pwd)"

main_image="${KV_MAIN_IMAGE:-harbor-kv/main:qwen36-27b-tp2-public30-r2}"
runtime_dir="${HARBOR_VLLM_RUNTIME_DIR:-/tmp/harbor-kv-qwen36-27b-$(id -u)}"
corpus_source="${HARBOR_SWEBENCH_CORPUS_SOURCE:-$HOME/.cache/harbor-kv-scheduler-v2/swebench-lite}"

die() {
  echo "ERROR: $*" >&2
  exit 1
}

if ! docker info >/dev/null 2>&1; then
  if [[ "${KV_EGRESS_SEAL_DOCKER_GROUP_REEXEC:-0}" == 1 ]]; then
    die "Docker remains unavailable after entering the docker group"
  fi
  printf -v reexec \
    'KV_EGRESS_SEAL_DOCKER_GROUP_REEXEC=1 KV_MAIN_IMAGE=%q HARBOR_VLLM_RUNTIME_DIR=%q HARBOR_SWEBENCH_CORPUS_SOURCE=%q exec %q' \
    "$main_image" "$runtime_dir" "$corpus_source" "$0"
  exec sg docker -c "$reexec"
fi

docker image inspect "$main_image" >/dev/null 2>&1 \
  || die "missing locally built main image: $main_image"
[[ -S "$runtime_dir/vllm.sock" ]] || die "external Qwen UDS is unavailable: $runtime_dir/vllm.sock"
[[ -f "$runtime_dir/attestation.json" ]] || die "external Qwen attestation is unavailable"
[[ -f "$corpus_source/manifest.json" ]] || die "staged SWE corpus is unavailable"

temp_root="$(mktemp -d "${TMPDIR:-/tmp}/kvbench-main-egress-seal.XXXXXX")"
project="kvbench-egress-seal-$(id -u)-${BASHPID}"
overlay="$temp_root/compose-seal-test.yaml"
state_root="$temp_root/state"
mkdir -p "$state_root/workspaces"
compose=()

export HARBOR_VLLM_RUNTIME_DIR="$runtime_dir"
export HARBOR_KVBENCH_STATE_ROOT="$state_root"
export HARBOR_SWEBENCH_CORPUS_SOURCE="$corpus_source"
export KV_MAIN_IMAGE="$main_image"

cleanup() {
  set +eu
  if ((${#compose[@]})); then
    "${compose[@]}" down --volumes --remove-orphans >/dev/null 2>&1
  fi
  if [[ -n "${temp_root:-}" && -d "$temp_root" && "$temp_root" != / ]]; then
    rm -rf -- "$temp_root"
  fi
}
trap cleanup EXIT INT TERM

cat >"$overlay" <<'YAML'
services:
  bench-controller:
    environment:
      # Disposable topology test: no release public measurement is run and no
      # immutable Direct anchor is mounted.
      RELEASE_PUBLIC_DIRECT_ANCHOR_REQUIRED: "0"

  main:
    networks:
      - front
      - seal-egress

  egress-sink:
    image: "${KV_MAIN_IMAGE:?set KV_MAIN_IMAGE}"
    pull_policy: never
    entrypoint: ["python3", "-m", "http.server", "8080", "--bind", "0.0.0.0"]
    networks:
      - seal-egress
    healthcheck:
      test:
        - CMD
        - python3
        - -c
        - "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8080', timeout=2).read(1)"
      interval: 1s
      timeout: 2s
      retries: 30

networks:
  seal-egress:
    driver: bridge
    internal: false
YAML

compose=(
  docker compose
  --project-name "$project"
  --project-directory "$task_dir/environment"
  -f "$task_dir/scripts/compose-main-base.yaml"
  -f "$task_dir/environment/docker-compose.yaml"
  -f "$overlay"
)

"${compose[@]}" config --quiet
# Build only the two images whose source implements this contract. Existing
# running calibration containers retain their immutable image IDs.
"${compose[@]}" build sandbox-worker bench-controller
"${compose[@]}" up --detach --wait --no-build

main_id="$("${compose[@]}" ps --quiet main)"
worker_id="$("${compose[@]}" ps --quiet sandbox-worker)"
sink_id="$("${compose[@]}" ps --quiet egress-sink)"
[[ -n "$main_id" && -n "$worker_id" && -n "$sink_id" ]] \
  || die "disposable Compose project omitted a required service"
sink_ip="$(docker inspect --format '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "$sink_id")"
[[ "$sink_ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "could not resolve sink IP"

candidate_connect_sink() {
  "${compose[@]}" exec -T --user candidate main python3 - "$sink_ip" <<'PY'
import socket, sys
with socket.create_connection((sys.argv[1], 8080), timeout=3) as connection:
    connection.sendall(b"GET / HTTP/1.0\r\nHost: sink\r\n\r\n")
    if not connection.recv(32).startswith(b"HTTP/"):
        raise SystemExit("sink returned an invalid response")
PY
}

controller_challenge() {
  "${compose[@]}" exec -T --user root main python3 - <<'PY'
import json
import urllib.request
from pathlib import Path

token = Path("/run/kvbench-admin/token").read_text().strip()
request = urllib.request.Request(
    "http://bench-controller:7000/admin/final/network-seal/challenge",
    data=b"{}",
    method="POST",
    headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"},
)
with urllib.request.urlopen(request, timeout=10) as response:
    payload = json.load(response)
if payload.get("schema_version") != 1 or len(payload.get("challenge", "")) != 64:
    raise SystemExit("controller returned an invalid seal challenge")
print(payload["challenge"])
PY
}

seal_main() {
  local challenge="$1"
  "${compose[@]}" exec -T --user root main python3 - "$challenge" <<'PY'
import hashlib
import hmac
import json
import socket
import sys
from pathlib import Path

challenge = sys.argv[1]
request = {
    "action": "seal_main_egress",
    "schema_version": 2,
    "challenge": challenge,
}
client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
client.settimeout(30)
client.connect("/run/kvbench-sandbox/control.sock")
client.sendall(json.dumps(request, separators=(",", ":")).encode() + b"\n")
client.shutdown(socket.SHUT_WR)
chunks = []
size = 0
while True:
    chunk = client.recv(65536)
    if not chunk:
        break
    size += len(chunk)
    if size > 256 * 1024:
        raise SystemExit("worker seal response exceeded 256 KiB")
    chunks.append(chunk)
client.close()
evidence = json.loads(b"".join(chunks))
if "protocol_error" in evidence:
    raise SystemExit("worker rejected seal: " + str(evidence["protocol_error"]))
signature = evidence.pop("signature", None)
canonical = json.dumps(
    evidence, ensure_ascii=True, separators=(",", ":"), sort_keys=True
).encode()
token = Path("/run/kvbench-admin/token").read_text().strip().encode()
expected = hmac.new(
    token, b"kvbench-main-egress-seal-v2\n" + canonical, hashlib.sha256
).hexdigest()
if not isinstance(signature, str) or not hmac.compare_digest(signature, expected):
    raise SystemExit("worker seal HMAC is invalid")
evidence["signature"] = signature
if evidence.get("challenge") != challenge:
    raise SystemExit("worker seal challenge mismatch")
print(json.dumps(evidence, separators=(",", ":"), sort_keys=True))
PY
}

candidate_connect_sink \
  || die "candidate could not reach the disposable external sink before seal"

# The same named volume is visible in main, but its directory/socket are 0700/
# 0600 root-owned. UID 1000 must not be able to invoke any worker RPC.
if "${compose[@]}" exec -T --user candidate main python3 - <<'PY' >/dev/null 2>&1
import socket
client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
client.connect("/run/kvbench-sandbox/control.sock")
PY
then
  die "candidate UID connected to the root-only sandbox-control socket"
fi

challenge_one="$(controller_challenge)"
evidence_one="$(seal_main "$challenge_one")"
jq -e '
  .schema_version == 2 and
  .action == "seal_main_egress" and
  .challenge == $challenge and
  (.controller.image_id | test("^sha256:[0-9a-f]{64}$")) and
  .controller.compose_service == "bench-controller" and
  .topology.non_internal_before >= 1 and
  .topology.non_internal_after == 0 and
  .topology.front_preserved == true and
  .topology.already_sealed == false and
  (.topology.detached_network_ids | length) >= 1
' --arg challenge "$challenge_one" <<<"$evidence_one" >/dev/null \
  || die "first seal evidence is malformed"

front_id="$(docker network inspect --format '{{.Id}}' "${project}_front")"
main_network_ids="$(docker inspect "$main_id" | jq -c '.[0].NetworkSettings.Networks | [.[] | .NetworkID] | sort')"
jq -e --arg front "$front_id" '. == [$front]' <<<"$main_network_ids" >/dev/null \
  || die "main retained a network other than internal front: $main_network_ids"

if candidate_connect_sink >/dev/null 2>&1; then
  die "candidate still reached the external sink after egress seal"
fi

# Both trusted benchmark paths must remain available through internal front.
"${compose[@]}" exec -T --user candidate main \
  curl -fsS http://127.0.0.1:8100/health >/dev/null
"${compose[@]}" exec -T --user candidate main \
  curl -fsS http://bench-controller:7000/health >/dev/null

challenge_two="$(controller_challenge)"
evidence_two="$(seal_main "$challenge_two")"
jq -e '
  .challenge == $challenge and
  .topology.non_internal_before == 0 and
  .topology.non_internal_after == 0 and
  .topology.already_sealed == true and
  (.topology.detached_network_ids | length) == 0
' --arg challenge "$challenge_two" <<<"$evidence_two" >/dev/null \
  || die "second seal was not idempotent"

jq -n \
  --arg project "$project" \
  --arg main_id "$main_id" \
  --arg worker_id "$worker_id" \
  --arg front_network_id "$front_id" \
  '{
    schema_version: 1,
    kind: "main-egress-seal-container-integration",
    passed: true,
    project: $project,
    main_container_id: $main_id,
    worker_container_id: $worker_id,
    front_network_id: $front_network_id,
    candidate_socket_access: false,
    external_sink_reachable_before: true,
    external_sink_reachable_after: false,
    second_seal_idempotent: true,
    trusted_front_health_preserved: true
  }'
