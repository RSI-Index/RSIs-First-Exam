#!/usr/bin/env python3
"""Generate the author-side immutable release manifest after calibration."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


sys.path.insert(0, str(Path(__file__).resolve().parent))
from evidence_contract import (  # noqa: E402
    PRESSURE_QUALIFICATION_PATHS,
    PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS,
    publishable_model_runtime_identity,
    reject_private_runtime_identity,
    runtime_boot_identity_sha256,
    validate_audited_oversubscribed_working_set,
    validate_publishable_model_runtime_identity,
    validate_finite_agent_execution_interval,
)


TASK_ROOT = Path(__file__).resolve().parents[1]
REPOSITORY_ROOT = TASK_ROOT.parents[1]
QWEN_PROFILE = TASK_ROOT / "environment" / "vllm-runtime" / "model-profile-qwen3.6-27b.json"
QWEN_REPOSITORY = "Qwen/Qwen3.6-27B"
QWEN_REVISION = "6a9e13bd6fc8f0983b9b99948120bc37f49c13e9"
QWEN_PROFILE_ID = "qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2"
QWEN_PROFILE_SHA256 = "3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46"
QWEN_TMUX_SESSION = "harbor-kv-qwen36-27b"
QWEN_CONTAINER_NAME = "harbor-kv-qwen36-27b-host"
REFERENCE_GATEWAY_TREE = TASK_ROOT / "solution" / "reference_gateway"
REFERENCE_SOLVE_SH = TASK_ROOT / "solution" / "solve.sh"
REFERENCE_SUBMISSION_MODES = {
    "gateway.py": 0o644,
    "scheduler.py": 0o644,
    "THIRD_PARTY_LICENSE.md": 0o644,
    "launch.sh": 0o755,
}
REFERENCE_SOLVE_SH_BYTES = b"""#!/usr/bin/env bash
set -euo pipefail

rm -rf /app/submission
install -d -m 0755 /app/submission
install -m 0644 \\
  /solution/reference_gateway/gateway.py \\
  /solution/reference_gateway/scheduler.py \\
  /solution/reference_gateway/THIRD_PARTY_LICENSE.md \\
  /app/submission/
install -m 0755 /solution/reference_gateway/launch.sh /app/submission/launch.sh
"""
DEFAULT_IMAGES = {
    "main": "harbor-kv/main:qwen36-27b-tp2-public30-r2",
    "model_api": "harbor-kv/model-api:qwen36-27b-tp2-public30-r2",
    "bench_controller": "harbor-kv/bench-controller:qwen36-27b-tp2-public30-r2",
    "sandbox_worker": "harbor-kv/sandbox-worker:qwen36-27b-tp2-public30-r2",
}
REAL_AGENT_EXECUTION_SURFACE_SCHEMA_VERSION = 1
REAL_AGENT_EXECUTION_SURFACE_ALLOWLIST = (
    "harbor_ext/__init__.py",
    "harbor_ext/agent_shell_safety.py",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/codex-egress.compose.yaml",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/launch-gpt-5.6-luna-max-tmux.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/launch-gpt-5.6-luna-xhigh-tmux.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/launch-gpt-5.6-sol-ultra-one-round-tmux.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/launch-gpt-5.6-terra-max-tmux.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/monitor-kvbench-continuation.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/run-codex-gpt-5.6-luna-max.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/run-codex-gpt-5.6-luna-xhigh.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/run-codex-gpt-5.6-terra-max.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/run-codex-round-loop-common.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/status-gpt-5.6-luna-max.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/status-gpt-5.6-luna-xhigh.sh",
    "harbor_run_scripts/concurrent-agent-serving-optimizer-qwen36-27b/status-gpt-5.6-terra-max.sh",
    "local_ext/__init__.py",
    "local_ext/codex_auth_upload_no_search.py",
    "local_ext/concurrent_agent_serving_codex_continuation.py",
)
RELEASE_QUALIFICATION_KEY = "release_qualification_profiles"
RELEASE_EVIDENCE_POLICY = {
    "schema_version": 3,
    "policy_id": "single-oracle-public1800-anchor-hidden-committed-pair-v6-tier-qualified-v3",
    "minimum_sweep_series": 0,
    "minimum_frozen_candidate_reports": 0,
    "minimum_oracle_reports": 1,
    "public_pair_profile": "public-pressure-192",
    "public_measurement_window_sec": 1800,
    "public_direct_anchor_required": True,
    "hidden_leg_protocol": "nonce-committed-ab-or-ba",
    "hidden_leg_count": 2,
    "hidden_candidate_leg_count": 1,
    "candidate_epoch_reset_required": True,
    "deep_tier_required_in_hidden_candidate_leg": True,
    "deep_and_mixed_tiers_required_in_public_candidate_leg": True,
    "reference_source": "formal_public1800_anchor_and_hidden_committed_pair",
}
EXPECTED_V5_TIER_POLICY = {
    "algorithm": "thunderagent-program-aware-single-backend",
    "scheduler_policy_schema_version": 4,
    "queue_policy": "thunderagent-tiered-sjf-service-lag-age-reservation-swap-v5",
    "fair_service_until_step": 12,
    "deep_request_first_step": 13,
    "protected_request_policy": "v4-exact-through-step-12",
    "deep_request_policy": "total_tokens-sjf-with-service-lag-bypass-from-step-13",
    "normal_restore_order": (
        "aged-then-protected-request-ordinal-then-deep-total-tokens-then-idle-acting"
    ),
    "deep_restore_order": "total_tokens-then-request-wait-age-then-program-id",
    "deep_reentry_bypasses_service_lag": True,
}
DEEP_SIGNAL_NAMES = {
    "offers",
    "waiters_peak",
    "wait_count",
    "lag_bypass",
    "resumes",
    "sjf_ticks",
}
PROFILE_DEFAULTS = {
    "warmup_requests": 2,
    "warmup_context_bytes": 2048,
    "warmup_steps": 1,
    "workload_family": "synthetic-fixture",
    "metrics_sample_interval_sec": 1.0,
    "metrics_request_timeout_sec": 15,
    "pressure_required": False,
    "pressure_kv_threshold": 0.85,
    "pressure_kv_p95_min": 0.85,
    "pressure_time_fraction_min": 0.10,
    "pressure_min_samples": 5,
    "corpus_partition": "fixture",
    "corpus_unique_instances_min": 1,
    "tool_timeout_sec": 60,
    "sandbox_prepare_concurrency": 16,
    "backend_stall_timeout_sec": 30,
    "candidate_admission_stall_timeout_sec": 60,
}

PUBLISHABLE_HARBOR_RUNTIME_KEYS = frozenset(
    {
        "schema_version",
        "layout",
        "harbor_version",
        "distribution_version",
        "entrypoint_sha256",
        "pyvenv_cfg_sha256",
        "uv_receipt_sha256",
        "interpreter_implementation",
        "interpreter_version",
        "interpreter_sha256",
        "stdlib_file_count",
        "stdlib_tree_sha256",
        "stdlib_tree_policy",
        "stdlib_zip",
        "dist_info_name",
        "module_relative_path",
        "module_sha256",
        "site_packages_file_count",
        "site_packages_tree_sha256",
        "tree_policy",
        "pth_policy",
        "isolated_import_required",
    }
)


def publishable_harbor_runtime_identity(identity: object) -> dict:
    """Remove machine-local paths from a fully validated Harbor identity."""

    if not isinstance(identity, dict):
        raise ValueError("Harbor runtime identity is not an object")
    raw_zip = identity.get("stdlib_zip")
    if not isinstance(raw_zip, dict) or not isinstance(raw_zip.get("present"), bool):
        raise ValueError("Harbor standard-library zip identity is malformed")
    public_zip = {"present": raw_zip["present"]}
    if raw_zip["present"]:
        public_zip["sha256"] = raw_zip.get("sha256")
    projected = {
        "schema_version": identity.get("schema_version"),
        "layout": identity.get("layout"),
        "harbor_version": identity.get("harbor_version"),
        "distribution_version": identity.get("distribution_version"),
        "entrypoint_sha256": identity.get("entrypoint_sha256"),
        "pyvenv_cfg_sha256": identity.get("pyvenv_cfg_sha256"),
        "uv_receipt_sha256": identity.get("uv_receipt_sha256"),
        "interpreter_implementation": identity.get("interpreter_implementation"),
        "interpreter_version": identity.get("interpreter_version"),
        "interpreter_sha256": identity.get("interpreter_sha256"),
        "stdlib_file_count": identity.get("stdlib_file_count"),
        "stdlib_tree_sha256": identity.get("stdlib_tree_sha256"),
        "stdlib_tree_policy": identity.get("stdlib_tree_policy"),
        "stdlib_zip": public_zip,
        "dist_info_name": identity.get("dist_info_name"),
        "module_relative_path": identity.get("module_relative_path"),
        "module_sha256": identity.get("module_sha256"),
        "site_packages_file_count": identity.get("site_packages_file_count"),
        "site_packages_tree_sha256": identity.get("site_packages_tree_sha256"),
        "tree_policy": identity.get("tree_policy"),
        "pth_policy": identity.get("pth_policy"),
        "isolated_import_required": identity.get("isolated_import_required"),
    }
    if set(projected) != PUBLISHABLE_HARBOR_RUNTIME_KEYS:
        raise ValueError("publishable Harbor runtime fields drift")
    sha_fields = (
        "entrypoint_sha256",
        "pyvenv_cfg_sha256",
        "uv_receipt_sha256",
        "interpreter_sha256",
        "stdlib_tree_sha256",
        "module_sha256",
        "site_packages_tree_sha256",
    )
    if (
        projected.get("schema_version") != 1
        or projected.get("layout") != "uv-tool-venv-v1"
        or not all(
            isinstance(projected.get(key), str) and projected.get(key)
            for key in (
                "harbor_version",
                "distribution_version",
                "interpreter_implementation",
                "interpreter_version",
                "stdlib_tree_policy",
                "dist_info_name",
                "module_relative_path",
                "tree_policy",
                "pth_policy",
            )
        )
        or any(
            re.fullmatch(r"[0-9a-f]{64}", str(projected.get(key, ""))) is None
            for key in sha_fields
        )
        or any(
            isinstance(projected.get(key), bool)
            or not isinstance(projected.get(key), int)
            or projected[key] <= 0
            for key in ("stdlib_file_count", "site_packages_file_count")
        )
        or projected.get("isolated_import_required") is not True
        or (
            public_zip["present"]
            and re.fullmatch(r"[0-9a-f]{64}", str(public_zip.get("sha256", "")))
            is None
        )
        or (not public_zip["present"] and set(public_zip) != {"present"})
    ):
        raise ValueError("publishable Harbor runtime identity is malformed")
    return projected


def policy_contract_sha256(policy: dict) -> str:
    immutable = {
        key: value
        for key, value in policy.items()
        if key not in {"release_ready", "not_ready_reasons"}
    }
    encoded = json.dumps(immutable, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def canonical_json(value: object) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def canonical_profile_config(name: str, configured: dict) -> dict:
    return {**PROFILE_DEFAULTS, **configured, "name": name}


def release_qualification_profiles(payload: dict) -> tuple[str, ...]:
    """Load the optional ordered release-sweep list, never enabled diagnostics.

    The single-Oracle research release does not require a Direct calibration
    sweep.  An empty list is therefore an explicit frozen choice, not a signal
    to infer every enabled diagnostic profile.
    """

    configured = payload.get("profiles")
    if not isinstance(configured, dict) or any(
        not isinstance(config, dict) for config in configured.values()
    ):
        raise SystemExit("calibration profile contract is malformed")
    selected = payload.get(RELEASE_QUALIFICATION_KEY)
    if not isinstance(selected, list):
        raise SystemExit(f"{RELEASE_QUALIFICATION_KEY} must be a JSON list")
    if any(not isinstance(name, str) or not name for name in selected):
        raise SystemExit(
            f"{RELEASE_QUALIFICATION_KEY} entries must be non-empty strings"
        )
    if len(selected) != len(set(selected)):
        raise SystemExit(f"{RELEASE_QUALIFICATION_KEY} contains duplicate entries")
    missing = [name for name in selected if name not in configured]
    if missing:
        raise SystemExit(
            f"{RELEASE_QUALIFICATION_KEY} references missing profiles: {missing}"
        )
    disabled = [name for name in selected if configured[name].get("enabled") is not True]
    if disabled:
        raise SystemExit(
            f"{RELEASE_QUALIFICATION_KEY} references disabled profiles: {disabled}"
        )
    return tuple(selected)


def expected_qwen_provenance(
    profile: dict,
    profile_sha256: str,
    attestation: dict,
) -> dict:
    source = profile.get("source") or {}
    runtime = profile.get("runtime") or {}
    return {
        "profile_id": profile.get("profile_id"),
        "profile_sha256": profile_sha256,
        "model_revision": source.get("revision"),
        "runtime_image_id": runtime.get("runtime_image_id"),
        "tensor_parallel_size": runtime.get("tensor_parallel_size"),
        "kv_cache_dtype": runtime.get("kv_cache_dtype"),
        "runtime_boot_identity_sha256": runtime_boot_identity_sha256(
            attestation
        ),
    }


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def harbor_runtime_identity(harbor_bin: Path) -> dict:
    """Bind the actual Harbor launcher, interpreter, and Harbor source tree.

    A version string alone is not an execution identity: an alternate
    ``HARBOR_BIN`` can report the same version while importing modified source.
    Resolve Harbor's uv tool environment without executing it, ignore only
    dynamic ``__pycache__`` trees, and hash the complete site-packages tree.
    This also binds dependencies, ``.pth`` files, and import customizers.
    """

    try:
        entrypoint = harbor_bin.expanduser().resolve(strict=True)
    except OSError as exc:
        raise OSError(f"Harbor entrypoint is unavailable: {harbor_bin}") from exc
    entrypoint_stat = entrypoint.stat()
    if not stat.S_ISREG(entrypoint_stat.st_mode) or not os.access(entrypoint, os.X_OK):
        raise OSError(f"Harbor entrypoint is not an executable regular file: {entrypoint}")

    interpreter = entrypoint.parent / "python"
    try:
        interpreter_realpath = interpreter.resolve(strict=True)
    except OSError as exc:
        raise OSError(f"Harbor interpreter is unavailable beside {entrypoint}") from exc
    interpreter_stat = interpreter_realpath.stat()
    if not stat.S_ISREG(interpreter_stat.st_mode) or not os.access(
        interpreter, os.X_OK
    ):
        raise OSError(
            f"Harbor interpreter is not an executable regular file: {interpreter_realpath}"
        )

    venv_root = entrypoint.parent.parent
    pyvenv_cfg = venv_root / "pyvenv.cfg"
    uv_receipt = venv_root / "uv-receipt.toml"
    for path, label in (
        (pyvenv_cfg, "Harbor pyvenv.cfg"),
        (uv_receipt, "Harbor uv receipt"),
    ):
        metadata = path.lstat()
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise OSError(f"{label} is not a regular non-symlink file: {path}")

    venv_config: dict[str, str] = {}
    for line in pyvenv_cfg.read_text(encoding="utf-8").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        venv_config[key.strip().lower()] = value.strip()
    if (
        venv_config.get("implementation") != "CPython"
        or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", venv_config.get("version_info", ""))
        or not venv_config.get("home")
        or venv_config.get("include-system-site-packages", "").lower() != "false"
    ):
        raise OSError("Harbor pyvenv.cfg is not the frozen isolated CPython layout")

    version_parts = venv_config["version_info"].split(".")
    python_abi = f"python{version_parts[0]}.{version_parts[1]}"
    interpreter_home = Path(venv_config["home"]).expanduser().resolve(strict=True)
    expected_interpreter = (interpreter_home / python_abi).resolve(strict=True)
    if expected_interpreter != interpreter_realpath:
        raise OSError("Harbor interpreter target disagrees with pyvenv.cfg home/version")
    stdlib_path = interpreter_home.parent / "lib" / python_abi
    stdlib_lstat = stdlib_path.lstat()
    if stat.S_ISLNK(stdlib_lstat.st_mode) or not stat.S_ISDIR(stdlib_lstat.st_mode):
        raise OSError("Harbor base standard-library root is not a real directory")
    stdlib_path = stdlib_path.resolve(strict=True)
    for customizer_pattern in ("sitecustomize*", "usercustomize*"):
        if list(stdlib_path.glob(customizer_pattern)):
            raise OSError(
                f"Harbor standard library contains forbidden {customizer_pattern}"
            )

    stdlib_records: list[dict] = []
    for current_root, directory_names, file_names in os.walk(
        stdlib_path, topdown=True, followlinks=False
    ):
        current = Path(current_root)
        current_relative = current.relative_to(stdlib_path)
        kept_directories: list[str] = []
        for name in sorted(directory_names):
            if name == "__pycache__" or (
                current == stdlib_path and name == "site-packages"
            ):
                continue
            child = current / name
            child_stat = child.lstat()
            if stat.S_ISLNK(child_stat.st_mode) or not stat.S_ISDIR(
                child_stat.st_mode
            ):
                raise OSError(
                    "Harbor standard library contains a non-directory/symlink: "
                    + (current_relative / name).as_posix()
                )
            kept_directories.append(name)
        directory_names[:] = kept_directories
        for name in sorted(file_names):
            path = current / name
            relative = (current_relative / name).as_posix()
            metadata = path.lstat()
            if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
                raise OSError(
                    f"Harbor standard library contains a non-regular path: {relative}"
                )
            stdlib_records.append(
                {
                    "path": relative,
                    "mode": stat.S_IMODE(metadata.st_mode),
                    "size": metadata.st_size,
                    "sha256": digest(path),
                }
            )
    if not stdlib_records:
        raise OSError("Harbor base standard-library tree is empty")
    stdlib_digest = hashlib.sha256(b"harbor-runtime-stdlib-v1\n")
    for record in stdlib_records:
        stdlib_digest.update(canonical_json(record).encode())
        stdlib_digest.update(b"\n")
    stdlib_zip = interpreter_home.parent / "lib" / (
        f"python{version_parts[0]}{version_parts[1]}.zip"
    )
    if stdlib_zip.exists() or stdlib_zip.is_symlink():
        zip_stat = stdlib_zip.lstat()
        if stat.S_ISLNK(zip_stat.st_mode) or not stat.S_ISREG(zip_stat.st_mode):
            raise OSError("Harbor standard-library zip is not a regular file")
        stdlib_zip_identity: dict[str, object] = {
            "present": True,
            "path": str(stdlib_zip),
            "sha256": digest(stdlib_zip),
        }
    else:
        stdlib_zip_identity = {"present": False, "path": str(stdlib_zip)}

    site_package_candidates = [
        path
        for path in venv_root.glob("lib/python*/site-packages")
        if path.is_dir() and not path.is_symlink()
    ]
    if len(site_package_candidates) != 1:
        raise OSError("Harbor uv environment must contain exactly one site-packages tree")
    site_packages = site_package_candidates[0].resolve(strict=True)
    pth_files = sorted(site_packages.glob("*.pth"), key=lambda path: path.name)
    if [path.name for path in pth_files] != ["_virtualenv.pth"]:
        raise OSError("Harbor site-packages has an unsupported executable/path .pth set")
    pth_stat = pth_files[0].lstat()
    if (
        stat.S_ISLNK(pth_stat.st_mode)
        or not stat.S_ISREG(pth_stat.st_mode)
        or pth_files[0].read_text(encoding="utf-8").strip() != "import _virtualenv"
    ):
        raise OSError("Harbor _virtualenv.pth import contract is not exact")
    virtualenv_module = site_packages / "_virtualenv.py"
    virtualenv_stat = virtualenv_module.lstat()
    if stat.S_ISLNK(virtualenv_stat.st_mode) or not stat.S_ISREG(
        virtualenv_stat.st_mode
    ):
        raise OSError("Harbor _virtualenv.pth target is not frozen in site-packages")
    for customizer_name in ("sitecustomize.py", "usercustomize.py"):
        if (site_packages / customizer_name).exists() or (
            site_packages / customizer_name
        ).is_symlink():
            raise OSError(f"Harbor site-packages contains forbidden {customizer_name}")
    package_root = site_packages / "harbor"
    dist_info_candidates = sorted(site_packages.glob("harbor-*.dist-info"))
    if (
        not package_root.is_dir()
        or package_root.is_symlink()
        or len(dist_info_candidates) != 1
        or not dist_info_candidates[0].is_dir()
        or dist_info_candidates[0].is_symlink()
    ):
        raise OSError("Harbor package or dist-info identity is ambiguous")
    dist_info = dist_info_candidates[0]
    metadata_path = dist_info / "METADATA"
    metadata_stat = metadata_path.lstat()
    if stat.S_ISLNK(metadata_stat.st_mode) or not stat.S_ISREG(metadata_stat.st_mode):
        raise OSError("Harbor dist-info METADATA is not a regular non-symlink file")
    metadata_text = metadata_path.read_text(encoding="utf-8")
    name_match = re.search(r"(?m)^Name:\s*([^\s]+)\s*$", metadata_text)
    version_match = re.search(r"(?m)^Version:\s*([^\s]+)\s*$", metadata_text)
    if name_match is None or name_match.group(1).lower() != "harbor" or version_match is None:
        raise OSError("Harbor dist-info METADATA has no exact name/version identity")
    distribution_version = version_match.group(1)
    module_init = package_root / "__init__.py"
    module_metadata = module_init.lstat()
    if stat.S_ISLNK(module_metadata.st_mode) or not stat.S_ISREG(module_metadata.st_mode):
        raise OSError("Harbor import root is not a regular non-symlink module")

    records: list[dict] = []
    for path in sorted(
        site_packages.rglob("*"),
        key=lambda item: item.relative_to(site_packages).as_posix(),
    ):
        relative = path.relative_to(site_packages)
        if "__pycache__" in relative.parts:
            continue
        metadata = path.lstat()
        if stat.S_ISLNK(metadata.st_mode):
            raise OSError(f"Harbor site-packages contains a symlink: {relative.as_posix()}")
        if stat.S_ISDIR(metadata.st_mode):
            continue
        if not stat.S_ISREG(metadata.st_mode):
            raise OSError(
                f"Harbor site-packages contains a non-regular path: {relative.as_posix()}"
            )
        records.append(
            {
                "path": relative.as_posix(),
                "mode": stat.S_IMODE(metadata.st_mode),
                "size": metadata.st_size,
                "sha256": digest(path),
            }
        )
    if not records:
        raise OSError("Harbor site-packages tree is empty")
    tree_digest = hashlib.sha256(b"harbor-runtime-site-packages-v1\n")
    for record in records:
        tree_digest.update(canonical_json(record).encode())
        tree_digest.update(b"\n")
    return {
        "schema_version": 1,
        "layout": "uv-tool-venv-v1",
        "harbor_version": distribution_version,
        "distribution_version": distribution_version,
        "entrypoint_path": str(entrypoint),
        "entrypoint_sha256": digest(entrypoint),
        "venv_root": str(venv_root),
        "pyvenv_cfg_sha256": digest(pyvenv_cfg),
        "uv_receipt_sha256": digest(uv_receipt),
        "interpreter_path": str(interpreter),
        "interpreter_realpath": str(interpreter_realpath),
        "interpreter_implementation": venv_config["implementation"],
        "interpreter_version": venv_config["version_info"],
        "interpreter_sha256": digest(interpreter_realpath),
        "stdlib_path": str(stdlib_path),
        "stdlib_file_count": len(stdlib_records),
        "stdlib_tree_sha256": stdlib_digest.hexdigest(),
        "stdlib_tree_policy": "all-regular-except-site-packages-and-__pycache__-v1",
        "stdlib_zip": stdlib_zip_identity,
        "package_root": str(package_root),
        "dist_info_name": dist_info.name,
        "module_relative_path": module_init.relative_to(site_packages).as_posix(),
        "module_sha256": digest(module_init),
        "site_packages_path": str(site_packages),
        "site_packages_file_count": len(records),
        "site_packages_tree_sha256": tree_digest.hexdigest(),
        "tree_policy": "all-regular-files-except-__pycache__-v1",
        "pth_policy": "exact-_virtualenv.pth-import-local-module-v1",
        "isolated_import_required": True,
    }


def repository_root_for_task(task_root: Path = TASK_ROOT) -> Path:
    """Resolve the repository that owns one canonical ``harbor_tasks`` task.

    The real-agent launcher is deliberately outside the task tree, so it cannot
    be covered by ``critical_files``.  Accept only the repository layout used by
    Harbor tasks instead of searching parent directories heuristically.
    """

    resolved = task_root.resolve(strict=True)
    if resolved.parent.name != "harbor_tasks":
        raise OSError(
            "task root is not an immediate child of the repository harbor_tasks directory: "
            f"{resolved}"
        )
    repository_root = resolved.parents[1]
    if repository_root.is_symlink() or not repository_root.is_dir():
        raise OSError(f"repository root is not a real directory: {repository_root}")
    return repository_root


def real_agent_execution_surface(
    repository_root: Path = REPOSITORY_ROOT,
) -> dict:
    """Hash the exact host-side code/config allowed to launch a real agent.

    This is an explicit allowlist, not a directory walk: adding a convenience
    script, test, or README beside the runner must not silently expand the
    trusted release execution surface.
    """

    root = repository_root.resolve(strict=True)
    files_sha256: dict[str, str] = {}
    for relative_name in REAL_AGENT_EXECUTION_SURFACE_ALLOWLIST:
        relative = Path(relative_name)
        if relative.is_absolute() or relative.as_posix() != relative_name:
            raise OSError(f"invalid repository-relative execution path: {relative_name}")
        path = root / relative
        try:
            metadata = path.lstat()
        except OSError as exc:
            raise OSError(
                f"real-agent execution file is missing: {relative_name}"
            ) from exc
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise OSError(
                f"real-agent execution path is not a regular non-symlink file: {relative_name}"
            )
        files_sha256[relative_name] = digest(path)

    if tuple(sorted(files_sha256)) != REAL_AGENT_EXECUTION_SURFACE_ALLOWLIST:
        raise OSError("real-agent execution allowlist constant is not sorted and exact")
    tree_digest = hashlib.sha256(b"real-agent-execution-surface-v1\n")
    for relative_name, sha256 in files_sha256.items():
        record = canonical_json({"path": relative_name, "sha256": sha256})
        tree_digest.update(record.encode())
        tree_digest.update(b"\n")
    return {
        "schema_version": REAL_AGENT_EXECUTION_SURFACE_SCHEMA_VERSION,
        "allowlist": list(REAL_AGENT_EXECUTION_SURFACE_ALLOWLIST),
        "files_sha256": files_sha256,
        "tree_sha256": tree_digest.hexdigest(),
    }


def reference_gateway_tree_sha256(root: Path = REFERENCE_GATEWAY_TREE) -> str:
    """Hash all authored Oracle files using stable relative-path records."""

    if root.is_symlink() or not root.is_dir():
        raise OSError(f"Oracle reference tree is not a real directory: {root}")
    records: list[bytes] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink():
            raise OSError(f"Oracle reference tree contains a symlink: {relative.as_posix()}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise OSError(f"Oracle reference tree contains a special file: {relative.as_posix()}")
        payload = path.read_bytes()
        record = {
            "path": relative.as_posix(),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "size": len(payload),
        }
        records.append(json.dumps(record, separators=(",", ":"), sort_keys=True).encode())
    if not records:
        raise OSError(f"Oracle reference tree has no authored files: {root}")
    tree_digest = hashlib.sha256(b"reference-gateway-tree-v1\n")
    for record in records:
        tree_digest.update(record)
        tree_digest.update(b"\n")
    return tree_digest.hexdigest()


def reference_submission_sha256(
    root: Path = REFERENCE_GATEWAY_TREE,
    solve_sh: Path = REFERENCE_SOLVE_SH,
) -> str:
    """Hash the exact ``/app/submission`` tree installed by ``solve.sh``.

    This deliberately uses the same record format as the trusted verifier's
    frozen-submission digest.  Source modes are irrelevant: ``solve.sh`` sets
    the destination directory to 0755, launch.sh to 0755, and all other
    authored files to 0644.
    """

    if solve_sh.is_symlink() or not solve_sh.is_file():
        raise OSError(f"Oracle solve script is not a regular file: {solve_sh}")
    if solve_sh.read_bytes() != REFERENCE_SOLVE_SH_BYTES:
        raise OSError("Oracle solve.sh no longer installs the frozen four-file contract")
    if root.is_symlink() or not root.is_dir():
        raise OSError(f"Oracle reference tree is not a real directory: {root}")
    digest_value = hashlib.sha256()
    root_record = {
        "kind": "directory",
        "path": ".",
        "executable": True,
        "size": 0,
        "sha256": "",
    }
    digest_value.update(
        json.dumps(root_record, separators=(",", ":"), sort_keys=True).encode()
    )
    digest_value.update(b"\n")
    for name in sorted(REFERENCE_SUBMISSION_MODES):
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise OSError(f"Oracle submission source is not a regular file: {path}")
        payload = path.read_bytes()
        record = {
            "kind": "file",
            "path": name,
            "executable": bool(REFERENCE_SUBMISSION_MODES[name] & 0o111),
            "size": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
        }
        digest_value.update(
            json.dumps(record, separators=(",", ":"), sort_keys=True).encode()
        )
        digest_value.update(b"\n")
    return digest_value.hexdigest()


def critical_files(root: Path = TASK_ROOT) -> Iterable[Path]:
    for relative in ("task.toml", "instruction.md"):
        yield root / relative
    for directory in ("environment", "tests", "scripts", "solution"):
        for path in sorted((root / directory).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                yield path


def tree_manifest(
    paths: Iterable[Path], root: Path = TASK_ROOT
) -> tuple[dict[str, str], str]:
    files = {str(path.relative_to(root)): digest(path) for path in paths}
    encoded = "\n".join(f"{name}:{sha}" for name, sha in sorted(files.items())).encode()
    return files, hashlib.sha256(encoded).hexdigest()


def command(*argv: str) -> str:
    completed = subprocess.run(argv, check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return completed.stdout.strip()


def load_object(path: Path) -> dict:
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"cannot read JSON object {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit(f"expected a JSON object in {path}")
    return value


def load_regular_object_and_digest(path: Path, label: str) -> tuple[dict, str]:
    """Read one non-symlink regular JSON file once and hash those exact bytes."""

    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise SystemExit(f"cannot open {label} {path}: {exc}") from exc
    try:
        observed = os.fstat(descriptor)
        if not stat.S_ISREG(observed.st_mode):
            raise SystemExit(f"{label} is not a regular file: {path}")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            raw = stream.read()
    finally:
        os.close(descriptor)
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"cannot parse {label} {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit(f"expected a JSON object in {label} {path}")
    return value, hashlib.sha256(raw).hexdigest()


def atomic_write_new(path: Path, rendered: str) -> None:
    """Publish a complete manifest without following or overwriting a path."""

    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink() or path.exists():
        raise SystemExit(f"refusing to overwrite release manifest output: {path}")
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w") as stream:
            stream.write(rendered)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        try:
            os.link(temporary, path)
        except FileExistsError as exc:
            raise SystemExit(f"refusing to overwrite release manifest output: {path}") from exc
    finally:
        temporary.unlink(missing_ok=True)


def validate_calibration_run(
    run: dict,
    *,
    profile_name: str,
    expected_profile_config: dict,
    expected_release_id: str,
    expected_controller_config_sha256: str,
    expected_model_provenance: dict,
    expected_model_adapter: dict,
    expected_quality_gates: dict,
    evidence_name: str,
) -> None:
    """Reject a sweep row that is not the exact measured release contract."""

    prefix = f"Qwen calibration run contract mismatch in {evidence_name}:{profile_name}"
    try:
        validate_finite_agent_execution_interval(
            run,
            prefix,
            require_live_samples=True,
        )
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    if run.get("profile") != profile_name or run.get("mode") != "baseline":
        raise SystemExit(f"{prefix}: profile/mode")
    if canonical_json(run.get("profile_config")) != canonical_json(
        expected_profile_config
    ):
        raise SystemExit(f"{prefix}: profile_config")
    if run.get("release_id") != expected_release_id:
        raise SystemExit(f"{prefix}: release_id")
    if run.get("controller_config_sha256") != expected_controller_config_sha256:
        raise SystemExit(f"{prefix}: controller_config_sha256")
    if canonical_json(run.get("model_provenance")) != canonical_json(
        expected_model_provenance
    ):
        raise SystemExit(f"{prefix}: model_provenance")
    run_adapter = {
        **expected_model_adapter,
        "effective_max_tokens": expected_profile_config.get("max_tokens"),
    }
    if canonical_json(run.get("model_adapter")) != canonical_json(run_adapter):
        raise SystemExit(f"{prefix}: model_adapter")
    if run.get("infrastructure_failure") is not None:
        raise SystemExit(f"{prefix}: infrastructure_failure")
    if run.get("backend_audit", {}).get("passed") is not True:
        raise SystemExit(f"{prefix}: backend_audit")
    if run.get("warmup_audit", {}).get("passed") is not True:
        raise SystemExit(f"{prefix}: warmup_audit")
    pressure = run.get("pressure_validation", {})
    if pressure.get("valid") is not True:
        raise SystemExit(f"{prefix}: pressure_validation")
    expected_pressure_required = expected_profile_config.get("pressure_required") is True
    contention = pressure.get("contention_evidence", {})
    if (
        pressure.get("qualification_schema_version") != 1
        or pressure.get("required") is not expected_pressure_required
        or contention.get("required") is not expected_pressure_required
        or contention.get("valid") is not True
    ):
        raise SystemExit(f"{prefix}: pressure_contention_evidence")
    if expected_pressure_required:
        paths = contention.get("qualification_paths")
        if (
            not isinstance(paths, list)
            or not paths
            or not all(
                isinstance(path, str) and path in PRESSURE_QUALIFICATION_PATHS
                for path in paths
            )
        ):
            raise SystemExit(f"{prefix}: pressure_qualification_path")
        if (
            "audited_active_working_set" in paths
            and (contention.get("active_working_set") or {}).get("valid") is not True
        ):
            raise SystemExit(f"{prefix}: active_working_set_evidence")
        if "audited_oversubscribed_working_set" in paths:
            try:
                validate_audited_oversubscribed_working_set(contention, prefix)
            except ValueError as exc:
                raise SystemExit(str(exc)) from exc
        preemption = contention.get("preemption") or {}
        preemption_delta = preemption.get("preemptions_delta")
        if "vllm_preemption" in paths and not (
            preemption.get("valid") is True
            and isinstance(preemption_delta, (int, float))
            and not isinstance(preemption_delta, bool)
            and float(preemption_delta) > 0
        ):
            raise SystemExit(f"{prefix}: preemption_evidence")
    success = run.get("request_success_rate")
    if (
        isinstance(success, bool)
        or not isinstance(success, (int, float))
        or float(success) < 1.0
    ):
        raise SystemExit(f"{prefix}: request_success_rate")
    sampler_errors = (
        (run.get("vllm_metrics") or {}).get("live_series") or {}
    ).get("sampler_error_count")
    if (
        isinstance(sampler_errors, bool)
        or not isinstance(sampler_errors, int)
        or sampler_errors != 0
    ):
        raise SystemExit(f"{prefix}: metrics_sampler_errors")
    for result_key, gate_key in (
        ("valid_step_ratio", "minimum_valid_step_ratio"),
    ):
        value = run.get(result_key)
        floor = expected_quality_gates.get(gate_key)
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or isinstance(floor, bool)
            or not isinstance(floor, (int, float))
            or float(value) < float(floor)
        ):
            raise SystemExit(f"{prefix}: {result_key}")
    progress = run.get("minimum_workflow_progress")
    progress_floor = expected_quality_gates.get("minimum_workflow_progress")
    if (
        isinstance(progress, bool)
        or not isinstance(progress, int)
        or isinstance(progress_floor, bool)
        or not isinstance(progress_floor, int)
        or progress < progress_floor
    ):
        raise SystemExit(f"{prefix}: minimum_workflow_progress")


def _tier_signal_map(value: object, label: str, *, positive: bool) -> dict[str, int]:
    if not isinstance(value, dict) or set(value) != DEEP_SIGNAL_NAMES:
        raise SystemExit(f"{label} deep-signal schema drift")
    for name, signal in value.items():
        if (
            isinstance(signal, bool)
            or not isinstance(signal, int)
            or signal < 0
            or (positive and signal == 0)
            or (not positive and signal != 0)
        ):
            expected = "positive" if positive else "zero"
            raise SystemExit(f"{label} deep signal is not {expected}: {name}")
    return value


def validate_oracle_tier_qualification(
    payload: dict,
    *,
    evidence_name: str,
    expected_release_id: str,
    expected_tree_sha256: str,
    expected_scoring_policy_sha256: str,
    expected_controller_config_sha256: str,
    expected_controller_image_id: str,
    expected_model_provenance: dict,
) -> None:
    """Fail closed unless one Oracle export binds anchor, public, and hidden pair."""

    raw_public = payload.get("raw_public_pair")
    if (
        not isinstance(raw_public, dict)
        or set(raw_public) != {"sha256", "bytes"}
        or not isinstance(raw_public.get("sha256"), str)
        or re.fullmatch(r"[0-9a-f]{64}", raw_public["sha256"]) is None
        or isinstance(raw_public.get("bytes"), bool)
        or not isinstance(raw_public.get("bytes"), int)
        or not 0 < raw_public["bytes"] <= 16 * 1024 * 1024
    ):
        raise SystemExit(f"Qwen Oracle public raw-file digest is invalid: {evidence_name}")

    anchor = payload.get("public_direct_anchor")
    expected_anchor_keys = {
        "schema_version",
        "kind",
        "sha256",
        "bytes",
        "release_id",
        "profile",
        "source_report_sha256",
        "scoring_policy_sha256",
        "baseline_sha256",
        "controller_config_sha256",
        "controller_image_id",
        "corpus_fingerprint",
        "model_provenance_sha256",
    }
    expected_model_provenance_sha256 = hashlib.sha256(
        canonical_json(expected_model_provenance).encode()
    ).hexdigest()
    if (
        not isinstance(anchor, dict)
        or set(anchor) != expected_anchor_keys
        or anchor.get("schema_version") != 1
        or anchor.get("kind") != "kvbench-release-public-direct-anchor"
        or not isinstance(anchor.get("sha256"), str)
        or re.fullmatch(r"[0-9a-f]{64}", anchor["sha256"]) is None
        or isinstance(anchor.get("bytes"), bool)
        or not isinstance(anchor.get("bytes"), int)
        or not 0 < anchor["bytes"] <= 16 * 1024 * 1024
        or anchor.get("release_id") != expected_release_id
        or anchor.get("profile") != RELEASE_EVIDENCE_POLICY["public_pair_profile"]
        or anchor.get("source_report_sha256") != raw_public["sha256"]
        or anchor.get("scoring_policy_sha256") != expected_scoring_policy_sha256
        or not isinstance(anchor.get("baseline_sha256"), str)
        or re.fullmatch(r"[0-9a-f]{64}", anchor["baseline_sha256"]) is None
        or anchor.get("controller_config_sha256")
        != expected_controller_config_sha256
        or anchor.get("controller_image_id") != expected_controller_image_id
        or not isinstance(anchor.get("corpus_fingerprint"), str)
        or re.fullmatch(r"[0-9a-f]{64}", anchor["corpus_fingerprint"]) is None
        or anchor.get("model_provenance_sha256")
        != expected_model_provenance_sha256
    ):
        raise SystemExit(f"Qwen Oracle public Direct anchor binding drift: {evidence_name}")

    qualification = payload.get("tier_qualification")
    if (
        not isinstance(qualification, dict)
        or qualification.get("schema_version") != 2
        or qualification.get("reference_gateway_tree_sha256")
        != expected_tree_sha256
        or qualification.get("policy") != EXPECTED_V5_TIER_POLICY
    ):
        raise SystemExit(f"Qwen Oracle v5 tier qualification is missing: {evidence_name}")

    public = qualification.get("public")
    if (
        not isinstance(public, dict)
        or public.get("profile") != RELEASE_EVIDENCE_POLICY["public_pair_profile"]
        or public.get("measurement_window_sec")
        != RELEASE_EVIDENCE_POLICY["public_measurement_window_sec"]
        or public.get("passed") is not True
        or public.get("policy") != EXPECTED_V5_TIER_POLICY
        or isinstance(public.get("mixed_request_tier_ticks"), bool)
        or not isinstance(public.get("mixed_request_tier_ticks"), int)
        or public["mixed_request_tier_ticks"] <= 0
        or public.get("release_id") != expected_release_id
        or public.get("controller_config_sha256")
        != expected_controller_config_sha256
        or canonical_json(public.get("model_provenance"))
        != canonical_json(expected_model_provenance)
        or public.get("reference_gateway_tree_sha256") != expected_tree_sha256
        or public.get("bench_controller_image_id") != expected_controller_image_id
    ):
        raise SystemExit(f"Qwen Oracle public protected-tier binding drift: {evidence_name}")
    _tier_signal_map(
        public.get("deep_signals"),
        f"Qwen Oracle public {evidence_name}",
        positive=True,
    )

    hidden = qualification.get("hidden")
    observation = hidden.get("observation") if isinstance(hidden, dict) else None
    if (
        not isinstance(hidden, dict)
        or hidden.get("profile") != "hidden-pressure-192"
        or hidden.get("leg_order_protocol")
        != "sha256-domain-separated-first-byte-lsb-v1"
        or hidden.get("leg_order")
        not in (["baseline", "candidate"], ["candidate", "baseline"])
        or hidden.get("candidate_leg_ordinal")
        != hidden["leg_order"].index("candidate") + 1
        or hidden.get("candidate_process_epoch_count") != 1
        or not isinstance(observation, dict)
        or observation.get("leg_ordinal") != hidden.get("candidate_leg_ordinal")
    ):
        raise SystemExit(f"Qwen Oracle hidden tier observations are invalid: {evidence_name}")
    if (
        observation.get("policy") != EXPECTED_V5_TIER_POLICY
        or isinstance(observation.get("mixed_request_tier_ticks"), bool)
        or not isinstance(observation.get("mixed_request_tier_ticks"), int)
        or observation["mixed_request_tier_ticks"] < 0
    ):
        raise SystemExit(
            f"Qwen Oracle hidden v5 policy observation drift: {evidence_name}"
        )
    _tier_signal_map(
        observation.get("deep_signals"),
        f"Qwen Oracle hidden leg {observation.get('leg_ordinal')} {evidence_name}",
        positive=True,
    )


def collect_release_evidence(
    calibration_root: Path,
    index_path: Path,
    output_path: Path,
    *,
    expected_release_id: str,
    expected_profile_sha256: str,
    expected_reference_gateway_tree_sha256: str | None = None,
    expected_reference_submission_sha256: str | None = None,
    expected_controller_image_id: str | None = None,
    expected_scoring_policy_sha256: str | None = None,
    expected_policy_contract_sha256: str | None = None,
    expected_corpus_manifest_sha256: str | None = None,
    required_calibration_profiles: tuple[str, ...] = (),
    expected_calibration_profiles: dict[str, dict] | None = None,
    expected_calibration_profiles_sha256: str | None = None,
    expected_model_provenance: dict | None = None,
    expected_model_required_files: dict[str, str] | None = None,
    expected_publishable_model_identity: dict | None = None,
    expected_quality_gates: dict | None = None,
    expected_hidden_profiles: frozenset[str] = frozenset(),
    expected_reference_speedups: dict[str, float] | None = None,
    expected_max_p99_step_latency_ratio: float | None = None,
    minimum_sweep_series: int = RELEASE_EVIDENCE_POLICY["minimum_sweep_series"],
    minimum_oracle_reports: int = RELEASE_EVIDENCE_POLICY["minimum_oracle_reports"],
    minimum_frozen_candidate_reports: int = RELEASE_EVIDENCE_POLICY[
        "minimum_frozen_candidate_reports"
    ],
) -> tuple[dict[str, str], str, str]:
    """Collect only explicitly indexed Qwen release evidence.

    Historical calibration files intentionally remain beside the active
    release directory.  Never discover evidence with a broad glob: doing so
    can silently bind results from an older model to a new release.
    """

    if expected_release_id.startswith("development"):
        raise SystemExit("Qwen release evidence cannot use a development release ID")
    calibration_root = calibration_root.expanduser().resolve(strict=True)
    supplied_index = index_path.expanduser()
    if supplied_index.is_symlink():
        raise SystemExit("Qwen release evidence index must not be a symlink")
    index_path = supplied_index.resolve(strict=True)
    expected_index = calibration_root / "qwen36-release" / "evidence-index.json"
    if index_path != expected_index:
        raise SystemExit(
            "Qwen release evidence index must be calibration/qwen36-release/evidence-index.json"
        )
    if not stat.S_ISREG(index_path.stat().st_mode):
        raise SystemExit("Qwen release evidence index is not a regular file")

    index, index_sha256 = load_regular_object_and_digest(
        index_path, "Qwen release evidence index"
    )
    if set(index) != {
        "schema_version",
        "release_id",
        "model_profile_sha256",
        "files",
    }:
        raise SystemExit("Qwen release evidence index fields drift")
    if type(index.get("schema_version")) is not int or index["schema_version"] != 1:
        raise SystemExit("Qwen release evidence index has the wrong schema_version")
    if index.get("release_id") != expected_release_id:
        raise SystemExit("Qwen release evidence index release_id does not match the scoring policy")
    if index.get("model_profile_sha256") != expected_profile_sha256:
        raise SystemExit("Qwen release evidence index model profile digest mismatch")
    names = index.get("files")
    if not isinstance(names, list) or not names:
        raise SystemExit("Qwen release evidence index must contain a non-empty files list")

    evidence_dir = index_path.parent
    output_path = output_path.expanduser().resolve()
    evidence: dict[str, str] = {}
    seen: set[str] = set()
    sweep_series: set[tuple[str, ...]] = set()
    sweep_controller_configs: set[str] = set()
    sweep_run_ids: set[str] = set()
    sweep_nonces: set[str] = set()
    oracle_reports: set[str] = set()
    public_direct_anchors: set[str] = set()
    frozen_candidate_reports: set[str] = set()
    verifier_controller_configs: set[str] = set()
    for name in names:
        if not isinstance(name, str) or not name or Path(name).name != name:
            raise SystemExit("Qwen release evidence entries must be relative JSON basenames")
        if name in seen:
            raise SystemExit(f"duplicate Qwen release evidence entry: {name}")
        seen.add(name)
        if name == index_path.name or Path(name).suffix != ".json":
            raise SystemExit(f"invalid Qwen release evidence filename: {name}")

        supplied_path = evidence_dir / name
        if supplied_path.is_symlink():
            raise SystemExit(f"Qwen release evidence must not be a symlink: {name}")
        try:
            path = supplied_path.resolve(strict=True)
        except OSError as exc:
            raise SystemExit(f"missing Qwen release evidence: {name}") from exc
        if path.parent != evidence_dir or path == output_path:
            raise SystemExit(f"Qwen release evidence escaped its dedicated directory: {name}")
        if not stat.S_ISREG(path.stat().st_mode):
            raise SystemExit(f"Qwen release evidence is not a regular file: {name}")

        payload, payload_sha256 = load_regular_object_and_digest(
            path, "Qwen release evidence"
        )
        try:
            reject_private_runtime_identity(payload, f"Qwen release evidence {name}")
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        kind = payload.get("kind")
        if kind not in {
            "real-swe-baseline-calibration-sweep",
            "sanitized-full-verifier-evidence",
        }:
            raise SystemExit(f"unsupported Qwen release evidence kind in {name}: {kind!r}")
        expected_payload_schema = (
            2 if kind == "sanitized-full-verifier-evidence" else 1
        )
        if (
            type(payload.get("schema_version")) is not int
            or payload["schema_version"] != expected_payload_schema
        ):
            raise SystemExit(f"Qwen release evidence schema mismatch: {name}")
        if payload.get("release_id") != expected_release_id:
            raise SystemExit(f"Qwen release evidence release_id mismatch: {name}")
        if payload.get("model_profile_sha256") != expected_profile_sha256:
            raise SystemExit(f"Qwen release evidence model profile digest mismatch: {name}")
        if payload.get("status") != "complete" or payload.get("errors") != []:
            raise SystemExit(f"Qwen release evidence is incomplete or contains errors: {name}")

        if kind == "real-swe-baseline-calibration-sweep":
            profile_order = payload.get("profile_order")
            runs = payload.get("runs")
            if (
                not isinstance(profile_order, list)
                or not profile_order
                or not isinstance(runs, dict)
                or not runs
                or set(runs) != set(profile_order)
                or len(set(profile_order)) != len(profile_order)
                or any(not isinstance(runs.get(profile), dict) or not runs[profile] for profile in profile_order)
            ):
                raise SystemExit(f"Qwen calibration sweep has incomplete profile results: {name}")
            if required_calibration_profiles and tuple(profile_order) != required_calibration_profiles:
                raise SystemExit(f"Qwen calibration sweep profile set/order mismatch: {name}")
            expected_selection = {
                "mode": "release_qualification_allowlist",
                "profiles": list(required_calibration_profiles),
            }
            if canonical_json(payload.get("profile_selection")) != canonical_json(
                expected_selection
            ):
                raise SystemExit(
                    f"Qwen calibration sweep was not run from the exact release allowlist: {name}"
                )
            if (
                expected_calibration_profiles is None
                or expected_model_provenance is None
                or expected_quality_gates is None
                or expected_controller_image_id is None
            ):
                raise SystemExit("release freeze omitted the calibration run contract")
            if set(profile_order) != set(expected_calibration_profiles):
                raise SystemExit(f"Qwen calibration profile contract set drift: {name}")
            if (
                expected_calibration_profiles_sha256 is not None
                and payload.get("calibration_profiles_sha256")
                != expected_calibration_profiles_sha256
            ):
                raise SystemExit(f"Qwen calibration profile-file drift: {name}")
            if payload.get("controller_image_id") != expected_controller_image_id:
                raise SystemExit(f"Qwen calibration controller image drift: {name}")
            if (
                expected_policy_contract_sha256 is not None
                and payload.get("scoring_policy_contract_sha256")
                != expected_policy_contract_sha256
            ):
                raise SystemExit(f"Qwen calibration policy contract drift: {name}")
            if (
                expected_corpus_manifest_sha256 is not None
                and payload.get("corpus_manifest_sha256")
                != expected_corpus_manifest_sha256
            ):
                raise SystemExit(f"Qwen calibration corpus manifest drift: {name}")
            if canonical_json(payload.get("quality_gates")) != canonical_json(
                expected_quality_gates
            ):
                raise SystemExit(f"Qwen calibration quality-gate drift: {name}")
            readiness = payload.get("controller_readiness")
            if not isinstance(readiness, dict):
                raise SystemExit(f"Qwen calibration readiness is missing: {name}")
            controller_config_sha256 = readiness.get("controller_config_sha256")
            if not isinstance(controller_config_sha256, str) or not re.fullmatch(
                r"[0-9a-f]{64}", controller_config_sha256
            ):
                raise SystemExit(f"Qwen calibration controller digest is invalid: {name}")
            if (
                readiness.get("release_id") != expected_release_id
                or (
                    expected_policy_contract_sha256 is not None
                    and readiness.get("policy_contract_sha256")
                    != expected_policy_contract_sha256
                )
                or (
                    expected_corpus_manifest_sha256 is not None
                    and readiness.get("corpus_manifest_sha256")
                    != expected_corpus_manifest_sha256
                )
            ):
                raise SystemExit(f"Qwen calibration readiness provenance drift: {name}")
            model_adapter = readiness.get("model_adapter")
            if not isinstance(model_adapter, dict) or not model_adapter:
                raise SystemExit(f"Qwen calibration adapter provenance is missing: {name}")
            sweep_controller_configs.add(controller_config_sha256)
            run_ids = tuple(str(runs[profile].get("run_id") or "") for profile in profile_order)
            if any(not run_id for run_id in run_ids):
                raise SystemExit(f"Qwen calibration sweep has a missing run ID: {name}")
            if any(run_id in sweep_run_ids for run_id in run_ids):
                raise SystemExit(f"Qwen calibration sweep reuses a run ID: {name}")
            for profile_name, run_id in zip(profile_order, run_ids):
                run = runs[profile_name]
                validate_calibration_run(
                    run,
                    profile_name=profile_name,
                    expected_profile_config=expected_calibration_profiles[profile_name],
                    expected_release_id=expected_release_id,
                    expected_controller_config_sha256=controller_config_sha256,
                    expected_model_provenance=expected_model_provenance,
                    expected_model_adapter=model_adapter,
                    expected_quality_gates=expected_quality_gates,
                    evidence_name=name,
                )
                nonce = run.get("workload_nonce_sha256")
                if not isinstance(nonce, str) or not re.fullmatch(r"[0-9a-f]{64}", nonce):
                    raise SystemExit(
                        f"Qwen calibration run nonce is missing: {name}:{profile_name}"
                    )
                if nonce in sweep_nonces:
                    raise SystemExit(
                        f"Qwen calibration sweep reuses a workload nonce: {name}:{profile_name}"
                    )
                sweep_nonces.add(nonce)
                sweep_run_ids.add(run_id)
            sweep_series.add(run_ids)
        elif kind == "sanitized-full-verifier-evidence":
            benchmark = payload.get("benchmark") or {}
            attestation = (payload.get("checks") or {}).get("attestation") or {}
            artifacts = payload.get("artifacts") or {}
            if not isinstance(benchmark, dict) or not isinstance(artifacts, dict):
                raise SystemExit(f"Qwen full-verifier evidence is malformed: {name}")
            try:
                attestation = validate_publishable_model_runtime_identity(attestation)
            except ValueError as exc:
                raise SystemExit(
                    f"Qwen full-verifier runtime identity is invalid: {name}: {exc}"
                ) from exc
            evidence_boot_identity = attestation["runtime_boot_identity_sha256"]
            if (
                payload.get("passed") is not True
                or benchmark.get("hard_gates_passed") is not True
                or benchmark.get("status") != "ok"
                or benchmark.get("release_id") != expected_release_id
                or benchmark.get("model_profile_sha256")
                != expected_profile_sha256
                or (
                    expected_model_provenance is not None
                    and canonical_json(benchmark.get("model_provenance"))
                    != canonical_json(expected_model_provenance)
                )
                or (
                    expected_corpus_manifest_sha256 is not None
                    and payload.get("corpus_manifest_sha256")
                    != expected_corpus_manifest_sha256
                )
                or (
                    expected_policy_contract_sha256 is not None
                    and benchmark.get("policy_contract_sha256")
                    != expected_policy_contract_sha256
                )
                or payload.get("run_kind") not in {"oracle", "frozen-candidate"}
                or attestation.get("profile_sha256") != expected_profile_sha256
                or attestation.get("profile_id") != QWEN_PROFILE_ID
                or attestation.get("state") != "ready"
                or attestation.get("model_mount_read_only") is not True
                or attestation.get("model_revision") != QWEN_REVISION
                or attestation.get("model_config_sha256")
                != (expected_model_required_files or {}).get("config.json")
                or attestation.get("model_weight_index_sha256")
                != (expected_model_required_files or {}).get(
                    "model.safetensors.index.json"
                )
                or attestation.get("tensor_parallel_size") != 2
                or attestation.get("kv_cache_dtype") != "fp8"
                or (
                    expected_model_provenance is not None
                    and attestation.get("runtime_image_id")
                    != expected_model_provenance.get("runtime_image_id")
                )
                or attestation.get("tool_call_parser") is not None
                or attestation.get("reasoning_parser") != "qwen3"
                or (
                    expected_publishable_model_identity is not None
                    and canonical_json(attestation)
                    != canonical_json(expected_publishable_model_identity)
                )
                or (
                    expected_model_provenance is not None
                    and evidence_boot_identity
                    != expected_model_provenance.get(
                        "runtime_boot_identity_sha256"
                    )
                )
            ):
                raise SystemExit(f"Qwen full-verifier evidence did not pass: {name}")
            verifier_controller_config = benchmark.get("controller_config_sha256")
            if not isinstance(verifier_controller_config, str) or not re.fullmatch(
                r"[0-9a-f]{64}", verifier_controller_config
            ):
                raise SystemExit(f"Qwen verifier controller digest is invalid: {name}")
            verifier_controller_configs.add(verifier_controller_config)
            lifecycle = benchmark.get("candidate_lifecycle")
            network_seal = (
                lifecycle.get("network_egress_seal")
                if isinstance(lifecycle, dict)
                else None
            )
            attested_controller_image_id = (
                network_seal.get("controller_image_id")
                if isinstance(network_seal, dict)
                else None
            )
            if (
                not isinstance(network_seal, dict)
                or network_seal.get("schema_version") != 2
                or network_seal.get("protocol")
                != "same-compose-main-egress-hmac-v2"
                or network_seal.get("sealed") is not True
                or not isinstance(attested_controller_image_id, str)
                or re.fullmatch(
                    r"sha256:[0-9a-f]{64}", attested_controller_image_id
                )
                is None
                or artifacts.get("bench_controller_image_id")
                != attested_controller_image_id
            ):
                raise SystemExit(
                    f"Qwen verifier controller image is not bound to its trusted raw seal: {name}"
                )
            profiles = benchmark.get("profiles")
            if expected_hidden_profiles and (
                not isinstance(profiles, dict)
                or set(profiles) != set(expected_hidden_profiles)
            ):
                raise SystemExit(f"Qwen verifier hidden profile set drift: {name}")
            if not isinstance(profiles, dict) or not profiles:
                raise SystemExit(f"Qwen verifier profiles are missing: {name}")
            if benchmark.get("schema_version") != 2 or len(profiles) != 1:
                raise SystemExit(
                    f"Qwen verifier is not the schema-2 single hidden pair: {name}"
                )
            for profile_name, profile_report in profiles.items():
                legs = (
                    profile_report.get("legs")
                    if isinstance(profile_report, dict)
                    else None
                )
                commitment = (
                    profile_report.get("leg_order_commitment")
                    if isinstance(profile_report, dict)
                    else None
                )
                observed_order = (
                    [leg.get("mode") for leg in legs]
                    if isinstance(legs, list)
                    and len(legs) == 2
                    and all(isinstance(leg, dict) for leg in legs)
                    else None
                )
                if (
                    observed_order
                    not in (["baseline", "candidate"], ["candidate", "baseline"])
                    or not isinstance(commitment, dict)
                    or commitment.get("schema_version") != 1
                    or commitment.get("protocol")
                    != "sha256-domain-separated-first-byte-lsb-v1"
                    or commitment.get("context") != "kvbench-final-leg-order-v1"
                    or commitment.get("order") != observed_order
                    or not isinstance(commitment.get("workload_nonce_sha256"), str)
                    or re.fullmatch(
                        r"[0-9a-f]{64}", commitment["workload_nonce_sha256"]
                    )
                    is None
                    or (
                        ["candidate", "baseline"]
                        if hashlib.sha256(
                            b"kvbench-final-leg-order-v1\n"
                            + commitment["workload_nonce_sha256"].encode("ascii")
                        ).digest()[0]
                        & 1
                        else ["baseline", "candidate"]
                    )
                    != observed_order
                ):
                    raise SystemExit(
                        "Qwen full-verifier hidden pair order is not nonce-committed AB/BA: "
                        f"{name}:{profile_name}"
                    )
            only_profile = next(iter(profiles.values()))
            formal_order = [leg["mode"] for leg in only_profile["legs"]]
            epochs = lifecycle.get("epochs") if isinstance(lifecycle, dict) else None
            if (
                not isinstance(lifecycle, dict)
                or lifecycle.get("schema_version") != 1
                or lifecycle.get("epoch_count") != 2
                or lifecycle.get("candidate_process_epoch_count") != 1
                or not isinstance(epochs, list)
                or len(epochs) != 2
                or any(not isinstance(epoch, dict) for epoch in epochs)
                or [epoch.get("leg_ordinal") for epoch in epochs] != [1, 2]
                or [epoch.get("mode") for epoch in epochs] != formal_order
            ):
                raise SystemExit(
                    f"Qwen verifier candidate lifecycle is not one fresh pair: {name}"
                )
            candidate_epoch = epochs[formal_order.index("candidate")]
            candidate_identity = candidate_epoch.get(
                "gateway_process_identity_sha256"
            )
            if (
                not isinstance(candidate_identity, str)
                or re.fullmatch(r"[0-9a-f]{64}", candidate_identity) is None
            ):
                raise SystemExit(
                    f"Qwen verifier candidate process epoch is invalid: {name}"
                )
            if (
                isinstance(expected_max_p99_step_latency_ratio, bool)
                or not isinstance(expected_max_p99_step_latency_ratio, (int, float))
                or not math.isfinite(float(expected_max_p99_step_latency_ratio))
                or float(expected_max_p99_step_latency_ratio) <= 1.0
            ):
                raise SystemExit(
                    "release freeze omitted a valid p99 step latency ratio contract"
                )
            maximum_allowed_ratio = float(expected_max_p99_step_latency_ratio)
            recomputed_tail_profiles: dict[str, dict] = {}
            for profile_name, profile_report in profiles.items():
                legs = profile_report["legs"]
                by_mode = {leg["mode"]: leg for leg in legs}
                baseline_value = by_mode["baseline"].get("p99_step_latency_sec")
                candidate_value = by_mode["candidate"].get("p99_step_latency_sec")
                if any(
                    isinstance(value, bool)
                    or not isinstance(value, (int, float))
                    or not math.isfinite(float(value))
                    or float(value) <= 0.0
                    for value in (baseline_value, candidate_value)
                ):
                    raise SystemExit(
                        "Qwen verifier pair p99 step latency is invalid: "
                        f"{name}:{profile_name}"
                    )
                baseline_value = float(baseline_value)
                candidate_value = float(candidate_value)
                ratio = candidate_value / baseline_value
                recomputed = {
                    "schema_version": 2,
                    "metric": "p99_step_latency_sec",
                    "pairing": "candidate_over_baseline:single_committed_pair",
                    "baseline_p99_step_latency_sec": baseline_value,
                    "candidate_p99_step_latency_sec": candidate_value,
                    "ratio": ratio,
                    "maximum_allowed_ratio": maximum_allowed_ratio,
                    "passed": ratio <= maximum_allowed_ratio,
                }
                if profile_report.get("tail_anti_gaming") != recomputed:
                    raise SystemExit(
                        "Qwen verifier profile tail report disagrees with its legs: "
                        f"{name}:{profile_name}"
                    )
                if not recomputed["passed"]:
                    raise SystemExit(
                        "Qwen verifier single-pair p99 step tail exceeded policy: "
                        f"{name}:{profile_name}"
                    )
                recomputed_tail_profiles[profile_name] = recomputed
            expected_tail_report = {
                "schema_version": 2,
                "metric": "p99_step_latency_sec",
                "pairing": "candidate_over_baseline:single_committed_pair",
                "maximum_allowed_ratio": maximum_allowed_ratio,
                "all_profiles_passed": True,
                "profiles": recomputed_tail_profiles,
            }
            if payload.get("tail_anti_gaming") != expected_tail_report:
                raise SystemExit(
                    f"Qwen verifier exported tail report is not independently current: {name}"
                )
            if payload.get("run_kind") == "oracle":
                if (
                    expected_reference_submission_sha256 is None
                    or expected_reference_speedups is None
                    or not expected_reference_speedups
                ):
                    raise SystemExit("release freeze omitted the Oracle identity/performance contract")
                if any(
                    not isinstance(profile_name, str)
                    or not profile_name
                    or isinstance(reference, bool)
                    or not isinstance(reference, (int, float))
                    or not math.isfinite(float(reference))
                    or float(reference) <= 0
                    for profile_name, reference in expected_reference_speedups.items()
                ):
                    raise SystemExit("release freeze has a malformed Oracle reference-speedup contract")
                lifecycle = benchmark.get("candidate_lifecycle")
                if (
                    not isinstance(lifecycle, dict)
                    or lifecycle.get("schema_version") != 1
                    or lifecycle.get("frozen_submission_sha256")
                    != expected_reference_submission_sha256
                    or artifacts.get("reference_submission_sha256")
                    != expected_reference_submission_sha256
                ):
                    raise SystemExit(f"Qwen Oracle frozen submission drift: {name}")
                if set(profiles) != set(expected_reference_speedups):
                    raise SystemExit(f"Qwen Oracle performance profile set drift: {name}")
                aggregate_performance = benchmark.get("performance_score")
                if (
                    isinstance(aggregate_performance, bool)
                    or not isinstance(aggregate_performance, (int, float))
                    or not math.isfinite(float(aggregate_performance))
                    or float(aggregate_performance) != 1.0
                ):
                    raise SystemExit(f"Qwen Oracle aggregate performance is below reference: {name}")
            for profile_name, profile_report in profiles.items():
                if payload.get("run_kind") == "oracle":
                    if not isinstance(profile_report, dict):
                        raise SystemExit(
                            f"Qwen Oracle profile report is malformed: {name}:{profile_name}"
                        )
                    speedup = profile_report.get("speedup")
                    observed_reference = profile_report.get("reference_speedup")
                    profile_performance = profile_report.get("performance_score")
                    expected_reference = expected_reference_speedups[profile_name]
                    numeric_values = (speedup, observed_reference, profile_performance)
                    if any(
                        isinstance(value, bool)
                        or not isinstance(value, (int, float))
                        or not math.isfinite(float(value))
                        for value in numeric_values
                    ):
                        raise SystemExit(
                            f"Qwen Oracle profile performance is malformed: {name}:{profile_name}"
                        )
                    if float(observed_reference) != float(expected_reference):
                        raise SystemExit(
                            f"Qwen Oracle reference speedup drift: {name}:{profile_name}"
                        )
                    if (
                        float(speedup) <= 1.0
                        or float(speedup) < float(expected_reference)
                        or float(profile_performance) != 1.0
                    ):
                        raise SystemExit(
                            f"Qwen Oracle did not beat baseline/reference: {name}:{profile_name}"
                        )
                legs = (
                    profile_report.get("legs")
                    if isinstance(profile_report, dict)
                    else None
                )
                if not isinstance(legs, list) or not legs:
                    raise SystemExit(
                        f"Qwen verifier profile legs are missing: {name}:{profile_name}"
                    )
                for leg in legs:
                    if not isinstance(leg, dict):
                        raise SystemExit(
                            f"Qwen verifier profile leg is invalid: {name}:{profile_name}"
                        )
                    try:
                        validate_finite_agent_execution_interval(
                            leg,
                            f"Qwen verifier evidence {name}:{profile_name}",
                            require_live_samples=False,
                        )
                    except ValueError as exc:
                        raise SystemExit(str(exc)) from exc
                    config = leg.get("profile_config")
                    pressure = leg.get("pressure_validation")
                    if not isinstance(config, dict) or not isinstance(pressure, dict):
                        raise SystemExit(
                            f"Qwen verifier pressure contract is missing: {name}:{profile_name}"
                        )
                    expected_required = bool(
                        config.get("pressure_required") is True
                        and leg.get("mode") == "baseline"
                    )
                    contention = pressure.get("contention_evidence")
                    if (
                        pressure.get("qualification_schema_version") != 1
                        or pressure.get("required") is not expected_required
                        or pressure.get("valid") is not True
                        or not isinstance(contention, dict)
                        or contention.get("required") is not expected_required
                        or contention.get("valid") is not True
                    ):
                        raise SystemExit(
                            f"Qwen verifier KV evidence is invalid: {name}:{profile_name}"
                        )
                    if expected_required:
                        paths = contention.get("qualification_paths")
                        if (
                            not isinstance(paths, list)
                            or not paths
                            or not all(
                                isinstance(path, str)
                                and path in PRESSURE_QUALIFICATION_PATHS
                                for path in paths
                            )
                        ):
                            raise SystemExit(
                                "Qwen verifier has no safe KV qualification path: "
                                f"{name}:{profile_name}"
                            )
                        if (
                            "audited_active_working_set" in paths
                            and (contention.get("active_working_set") or {}).get(
                                "valid"
                            )
                            is not True
                        ):
                            raise SystemExit(
                                "Qwen verifier active-working-set evidence is invalid: "
                                f"{name}:{profile_name}"
                            )
                        if "audited_oversubscribed_working_set" in paths:
                            try:
                                validate_audited_oversubscribed_working_set(
                                    contention,
                                    f"Qwen verifier evidence {name}:{profile_name}",
                                )
                            except ValueError as exc:
                                raise SystemExit(str(exc)) from exc
                        preemption = contention.get("preemption") or {}
                        preemption_delta = preemption.get("preemptions_delta")
                        if "vllm_preemption" in paths and not (
                            preemption.get("valid") is True
                            and isinstance(preemption_delta, (int, float))
                            and not isinstance(preemption_delta, bool)
                            and float(preemption_delta) > 0
                        ):
                            raise SystemExit(
                                "Qwen verifier preemption evidence is invalid: "
                                f"{name}:{profile_name}"
                            )
            if (
                expected_controller_image_id is not None
                and artifacts.get("bench_controller_image_id")
                != expected_controller_image_id
            ):
                raise SystemExit(f"Qwen verifier controller image drift: {name}")
            if (
                payload.get("run_kind") == "oracle"
                and expected_reference_gateway_tree_sha256 is not None
                and artifacts.get("reference_gateway_tree_sha256")
                != expected_reference_gateway_tree_sha256
            ):
                raise SystemExit(f"Qwen Oracle reference tree drift: {name}")
            if payload.get("run_kind") == "oracle":
                if (
                    expected_reference_gateway_tree_sha256 is None
                    or expected_controller_image_id is None
                    or expected_scoring_policy_sha256 is None
                    or expected_model_provenance is None
                ):
                    raise SystemExit(
                        "release freeze omitted the Oracle v5 tier binding contract"
                    )
                validate_oracle_tier_qualification(
                    payload,
                    evidence_name=name,
                    expected_release_id=expected_release_id,
                    expected_tree_sha256=expected_reference_gateway_tree_sha256,
                    expected_scoring_policy_sha256=expected_scoring_policy_sha256,
                    expected_controller_config_sha256=verifier_controller_config,
                    expected_controller_image_id=expected_controller_image_id,
                    expected_model_provenance=expected_model_provenance,
                )
            raw_report = payload.get("raw_private_report") or {}
            raw_sha256 = raw_report.get("sha256")
            raw_bytes = raw_report.get("bytes")
            if (
                set(raw_report) != {"sha256", "bytes"}
                or not isinstance(raw_sha256, str)
                or not re.fullmatch(r"[0-9a-f]{64}", raw_sha256)
                or isinstance(raw_bytes, bool)
                or not isinstance(raw_bytes, int)
                or not 0 < raw_bytes <= 64 * 1024 * 1024
            ):
                raise SystemExit(f"Qwen verifier raw report digest is missing: {name}")
            if payload.get("run_kind") == "oracle":
                oracle_reports.add(raw_sha256)
                anchor_binding = payload.get("public_direct_anchor")
                if not isinstance(anchor_binding, dict):
                    raise SystemExit(
                        f"Qwen Oracle public Direct anchor is missing: {name}"
                    )
                public_direct_anchors.add(str(anchor_binding.get("sha256")))
            else:
                frozen_candidate_reports.add(raw_sha256)

        evidence[f"qwen36-release/{name}"] = payload_sha256

    if len(sweep_series) < minimum_sweep_series:
        raise SystemExit(
            f"insufficient distinct Qwen calibration sweeps: {len(sweep_series)}<{minimum_sweep_series}"
        )
    if len(sweep_controller_configs) > 1:
        raise SystemExit("Qwen calibration sweeps used different controller configurations")
    if len(oracle_reports) < minimum_oracle_reports:
        raise SystemExit(
            f"insufficient distinct Qwen Oracle reports: {len(oracle_reports)}<{minimum_oracle_reports}"
        )
    if len(public_direct_anchors) != 1:
        raise SystemExit(
            "Qwen release evidence must bind exactly one public Direct anchor"
        )
    public_direct_anchor_sha256 = next(iter(public_direct_anchors))
    if re.fullmatch(r"[0-9a-f]{64}", public_direct_anchor_sha256) is None:
        raise SystemExit("Qwen public Direct anchor digest is invalid")
    if len(frozen_candidate_reports) < minimum_frozen_candidate_reports:
        raise SystemExit(
            "insufficient distinct frozen-candidate reports: "
            f"{len(frozen_candidate_reports)}<{minimum_frozen_candidate_reports}"
        )
    if len(verifier_controller_configs) > 1:
        raise SystemExit("Qwen verifier reports used different controller configurations")
    if (
        sweep_controller_configs
        and verifier_controller_configs
        and sweep_controller_configs != verifier_controller_configs
    ):
        raise SystemExit(
            "Qwen calibration and verifier evidence used different controller configurations"
        )
    return (
        dict(sorted(evidence.items())),
        index_sha256,
        public_direct_anchor_sha256,
    )


def validate_external_attestation(
    attestation_path: Path,
    attestation: dict,
    profile_path: Path,
    profile: dict,
    model_path: Path,
) -> dict:
    profile_sha256 = digest(profile_path)
    runtime = profile.get("runtime") or {}
    model = attestation.get("model") or {}
    process = attestation.get("process") or {}
    container = attestation.get("container") or {}
    transport = attestation.get("transport") or {}
    gpus = attestation.get("gpus") or []
    if (
        profile_path != QWEN_PROFILE.resolve()
        or profile_sha256 != QWEN_PROFILE_SHA256
        or profile.get("profile_id") != QWEN_PROFILE_ID
        or (profile.get("source") or {}).get("repository") != QWEN_REPOSITORY
        or (profile.get("source") or {}).get("revision") != QWEN_REVISION
    ):
        raise SystemExit("selected model profile is not the frozen Qwen3.6-27B revision")
    if (
        attestation.get("schema_version") != 1
        or attestation.get("state") != "ready"
        or attestation.get("preflight_status") != "ok"
        or attestation.get("model_mount_read_only") is not True
    ):
        raise SystemExit("external Qwen vLLM attestation is not release-ready")
    if (
        attestation.get("profile_id") != QWEN_PROFILE_ID
        or attestation.get("profile_sha256") != profile_sha256
        or model.get("profile_id") != QWEN_PROFILE_ID
        or model.get("revision") != QWEN_REVISION
        or model.get("file_hashes") != profile.get("required_files")
    ):
        raise SystemExit("external Qwen model/profile attestation mismatch")
    weights = profile.get("weights") or {}
    for observed, expected, label in (
        (model.get("shard_count"), weights.get("shard_count"), "shard_count"),
        (model.get("tensor_count"), weights.get("index_tensor_count"), "tensor_count"),
        (model.get("index_total_size"), weights.get("index_total_size"), "index_total_size"),
        (model.get("stat_total_size"), weights.get("stat_total_size"), "stat_total_size"),
        (
            model.get("hf_symlink_manifest_sha256"),
            weights.get("hf_symlink_manifest_sha256"),
            "hf_symlink_manifest_sha256",
        ),
    ):
        if observed != expected:
            raise SystemExit(f"external Qwen {label} attestation mismatch")
    if Path(str(model.get("model_path", ""))).resolve() != model_path:
        raise SystemExit("external Qwen attestation names a different model snapshot")
    if attestation.get("runtime") != runtime:
        raise SystemExit("external Qwen runtime differs from the frozen model profile")
    if attestation.get("observed_vllm_package_version") != runtime.get("vllm_package_version"):
        raise SystemExit("external Qwen observed vLLM package version mismatch")
    if (
        process.get("tmux_session") != QWEN_TMUX_SESSION
        or isinstance(process.get("wrapper_pid"), bool)
        or not isinstance(process.get("wrapper_pid"), int)
        or process["wrapper_pid"] < 2
        or isinstance(process.get("wrapper_start_ticks"), bool)
        or not isinstance(process.get("wrapper_start_ticks"), int)
        or process["wrapper_start_ticks"] < 1
    ):
        raise SystemExit("external Qwen tmux/process identity mismatch")
    if (
        container.get("name") != QWEN_CONTAINER_NAME
        or container.get("image_ref") != runtime.get("runtime_image_ref")
        or container.get("image_id") != runtime.get("runtime_image_id")
        or container.get("environment") != {"VLLM_SERVER_DEV_MODE": "1"}
        or not re.fullmatch(r"[0-9a-f]{64}", str(container.get("id", "")))
        or not re.fullmatch(r"[0-9a-f]{64}", str(container.get("launch_token_sha256", "")))
    ):
        raise SystemExit("external Qwen container identity mismatch")
    socket_path = Path(str(transport.get("socket_path", "")))
    if (
        transport.get("kind") != "unix"
        or transport.get("container_socket_path") != runtime.get("container_socket_path")
        or not socket_path.is_absolute()
        or socket_path.name != "vllm.sock"
        or socket_path.parent != attestation_path.parent
    ):
        raise SystemExit("external Qwen UDS transport attestation mismatch")
    try:
        socket_mode = socket_path.lstat().st_mode
    except OSError as exc:
        raise SystemExit(f"external Qwen UDS is unavailable: {socket_path}") from exc
    if not stat.S_ISSOCK(socket_mode):
        raise SystemExit(f"external Qwen upstream is not a Unix socket: {socket_path}")
    gpu_contract = profile.get("gpu_contract") or {}
    expected_gpu_indices = gpu_contract.get("host_indices")
    if (
        not isinstance(gpus, list)
        or expected_gpu_indices != [6, 7]
        or len(gpus) != 2
        or len({gpu.get("uuid") for gpu in gpus}) != 2
        or [gpu.get("index") for gpu in gpus] != expected_gpu_indices
    ):
        raise SystemExit("external Qwen attestation does not contain the TP2 GPU set")
    for gpu in gpus:
        if (
            gpu.get("name") != "NVIDIA H100 NVL"
            or int(gpu.get("memory_mib", 0)) < 95000
            or gpu.get("compute_capability") != "9.0"
        ):
            raise SystemExit(f"external Qwen GPU attestation mismatch: {gpu}")
    observed_image_id = command(
        "docker", "image", "inspect", "--format", "{{.Id}}", runtime["runtime_image_ref"]
    )
    if observed_image_id != runtime.get("runtime_image_id"):
        raise SystemExit("external Qwen runtime image tag no longer resolves to the frozen image ID")
    try:
        return publishable_model_runtime_identity(attestation)
    except ValueError as exc:
        raise SystemExit(f"external Qwen publishable identity is invalid: {exc}") from exc


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument("--model-profile", type=Path, default=QWEN_PROFILE)
    parser.add_argument(
        "--attestation",
        type=Path,
        default=(
            Path(os.environ["HARBOR_VLLM_RUNTIME_DIR"]) / "attestation.json"
            if os.environ.get("HARBOR_VLLM_RUNTIME_DIR")
            else None
        ),
        help="ready host-vLLM attestation (defaults to HARBOR_VLLM_RUNTIME_DIR/attestation.json)",
    )
    parser.add_argument(
        "--corpus-root",
        type=Path,
        default=Path(
            os.environ.get(
                "HARBOR_SWEBENCH_CORPUS_SOURCE",
                "~/.cache/harbor-kv-scheduler-v2/swebench-lite",
            )
        ).expanduser(),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=TASK_ROOT / "calibration" / "release-manifest.json",
    )
    parser.add_argument(
        "--harbor-bin",
        type=Path,
        default=None,
        help="Harbor executable whose isolated runtime is frozen into the manifest",
    )
    args = parser.parse_args()
    model_path = args.model_path.resolve(strict=True)
    profile_path = args.model_profile.resolve(strict=True)
    if args.attestation is None:
        raise SystemExit(
            "--attestation or HARBOR_VLLM_RUNTIME_DIR is required; release freeze needs a ready external Qwen runtime"
        )
    attestation_path = args.attestation.resolve(strict=True)
    profile = load_object(profile_path)
    attestation = load_object(attestation_path)
    external_runtime = validate_external_attestation(
        attestation_path, attestation, profile_path, profile, model_path
    )
    corpus_root = args.corpus_root.resolve(strict=True)
    corpus_manifest_path = corpus_root / "manifest.json"
    corpus_manifest = json.loads(corpus_manifest_path.read_text())
    corpus_entries = corpus_manifest.get("instances")
    expected_corpus_entries = int(corpus_manifest.get("selected_instance_count") or 300)
    if not isinstance(corpus_entries, list) or len(corpus_entries) != expected_corpus_entries:
        raise SystemExit("SWE-bench Lite corpus manifest is incomplete")
    command(
        "python3",
        str(TASK_ROOT / "scripts" / "validate-staged-corpus.py"),
        str(corpus_manifest_path),
    )
    policy_path = TASK_ROOT / "environment" / "bench-controller" / "profiles" / "scoring-policy.json"
    policy = json.loads(policy_path.read_text())
    if policy.get("release_ready") is not True:
        raise SystemExit("scoring policy is not release-ready")
    release_id = policy.get("release_id")
    if (
        not isinstance(release_id, str)
        or not release_id
        or release_id.startswith("development")
    ):
        raise SystemExit("scoring policy has no non-development release ID")

    selected_harbor = args.harbor_bin
    if selected_harbor is None:
        discovered_harbor = shutil.which("harbor")
        if not discovered_harbor:
            raise SystemExit("Harbor is unavailable; pass --harbor-bin")
        selected_harbor = Path(discovered_harbor)
    try:
        harbor_runtime = publishable_harbor_runtime_identity(
            harbor_runtime_identity(selected_harbor)
        )
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        raise SystemExit(f"cannot freeze Harbor runtime identity: {exc}") from exc

    files, tree_sha = tree_manifest(critical_files())
    try:
        execution_surface = real_agent_execution_surface(
            repository_root_for_task(TASK_ROOT)
        )
    except OSError as exc:
        raise SystemExit(
            f"cannot freeze the real-agent execution surface: {exc}"
        ) from exc
    images = {}
    for name, reference in DEFAULT_IMAGES.items():
        images[name] = {
            "reference": reference,
            "image_id": command("docker", "image", "inspect", "--format", "{{.Id}}", reference),
        }
    reference_gateway_tree_digest = reference_gateway_tree_sha256()
    reference_submission_digest = reference_submission_sha256()
    calibration_profiles_payload = load_object(
        TASK_ROOT / "environment" / "bench-controller" / "profiles" / "calibration.json"
    )
    calibration_profiles = calibration_profiles_payload.get("profiles")
    required_calibration_profiles = release_qualification_profiles(
        calibration_profiles_payload
    )
    expected_calibration_profiles = {
        name: canonical_profile_config(name, calibration_profiles[name])
        for name in required_calibration_profiles
    }
    expected_quality_gates = {
        "minimum_valid_step_ratio": float(policy["min_valid_step_ratio"]),
        "minimum_workflow_progress": int(policy["minimum_workflow_progress"]),
    }
    expected_hidden_profiles = frozenset(
        str(entry["name"]) for entry in policy["hidden_profiles"]
    )
    expected_reference_speedups = {
        str(entry["name"]): float(entry["reference_speedup"])
        for entry in policy["hidden_profiles"]
    }
    evidence, evidence_index_sha256, public_direct_anchor_sha256 = collect_release_evidence(
        TASK_ROOT / "calibration",
        TASK_ROOT / "calibration" / "qwen36-release" / "evidence-index.json",
        args.output,
        expected_release_id=release_id,
        expected_profile_sha256=QWEN_PROFILE_SHA256,
        expected_reference_gateway_tree_sha256=reference_gateway_tree_digest,
        expected_reference_submission_sha256=reference_submission_digest,
        expected_controller_image_id=images["bench_controller"]["image_id"],
        expected_scoring_policy_sha256=digest(policy_path),
        expected_policy_contract_sha256=policy_contract_sha256(policy),
        expected_corpus_manifest_sha256=digest(corpus_manifest_path),
        required_calibration_profiles=required_calibration_profiles,
        expected_calibration_profiles=expected_calibration_profiles,
        expected_calibration_profiles_sha256=digest(
            TASK_ROOT
            / "environment"
            / "bench-controller"
            / "profiles"
            / "calibration.json"
        ),
        expected_model_provenance=expected_qwen_provenance(
            profile, digest(profile_path), attestation
        ),
        expected_model_required_files=profile.get("required_files"),
        expected_publishable_model_identity=external_runtime,
        expected_quality_gates=expected_quality_gates,
        expected_hidden_profiles=expected_hidden_profiles,
        expected_reference_speedups=expected_reference_speedups,
        expected_max_p99_step_latency_ratio=float(
            policy["max_p99_step_latency_ratio"]
        ),
        minimum_sweep_series=RELEASE_EVIDENCE_POLICY["minimum_sweep_series"],
        minimum_oracle_reports=RELEASE_EVIDENCE_POLICY["minimum_oracle_reports"],
        minimum_frozen_candidate_reports=RELEASE_EVIDENCE_POLICY[
            "minimum_frozen_candidate_reports"
        ],
    )

    config = model_path / "config.json"
    weight_index = model_path / "model.safetensors.index.json"
    if (
        model_path.name != QWEN_REVISION
        or digest(config) != profile["required_files"]["config.json"]
        or digest(weight_index)
        != profile["required_files"]["model.safetensors.index.json"]
    ):
        raise SystemExit("--model-path is not the frozen Qwen3.6-27B snapshot")
    manifest = {
        "schema_version": 3,
        "release_id": policy["release_id"],
        "generated_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "harbor_version": harbor_runtime["harbor_version"],
        "harbor_runtime": harbor_runtime,
        "model": {
            "model_id": QWEN_REPOSITORY,
            "revision": QWEN_REVISION,
            "config_sha256": digest(config),
            "weight_index_sha256": digest(weight_index),
        },
        "runtime": {
            "lifecycle": "external-host-vllm",
            "transport": "unix-domain-socket",
            "model_profile_path": str(profile_path.relative_to(TASK_ROOT)),
            "model_profile_id": profile["profile_id"],
            "model_profile_sha256": digest(profile_path),
            "external_vllm": external_runtime,
            "task_images": images,
        },
        "benchmark": {
            "controller_config_files": {
                path.name: digest(path)
                for path in sorted((TASK_ROOT / "environment" / "bench-controller" / "profiles").glob("*.json"))
            },
            "scoring_policy_sha256": digest(policy_path),
            "scoring_policy_contract_sha256": policy_contract_sha256(policy),
            "release_evidence_policy": RELEASE_EVIDENCE_POLICY,
            "reference_gateway_tree_sha256": reference_gateway_tree_digest,
            "reference_submission_sha256": reference_submission_digest,
            "mini_swe_version": "1.14.4",
            # These are distinct upstream provenance lines.  a989f24 is the
            # mini-SWE workload vendoring point; the Oracle scheduler is
            # derived from the clean ThunderAgent implementation at 7ddc861.
            "mini_swe_vendor_source_commit": "a989f24c2d53096e243aae39775637b8ddd0e380",
            "oracle_scheduler_source_commit": "7ddc8610270e56d3b109eed8796b3a4360fc67c9",
            "corpus": {
                "manifest_sha256": digest(corpus_manifest_path),
                "dataset": corpus_manifest.get("dataset"),
                "dataset_revision": corpus_manifest.get("dataset_revision"),
                "dataset_parquet_sha256": corpus_manifest.get("dataset_parquet_sha256"),
                "partition_policy": corpus_manifest.get("partition_policy"),
                "corpus_mode": corpus_manifest.get("corpus_mode", "full-300"),
                "source_instance_count": corpus_manifest.get("source_instance_count", 300),
                "instance_count": len(corpus_entries),
                "image_lock_sha256": hashlib.sha256(
                    "\n".join(
                        f"{entry['instance_id']}:{entry['official_manifest_digest']}:"
                        f"{entry['image_digest']}:{entry['runtime_head_commit']}"
                        for entry in sorted(corpus_entries, key=lambda item: item["instance_id"])
                    ).encode()
                ).hexdigest(),
            },
        },
        "critical_tree_sha256": tree_sha,
        "critical_files": files,
        "real_agent_execution_surface": execution_surface,
        "calibration_evidence_index_sha256": evidence_index_sha256,
        "calibration_evidence_sha256": evidence,
        "public_direct_anchor_sha256": public_direct_anchor_sha256,
    }
    try:
        reject_private_runtime_identity(manifest, "release manifest")
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    rendered = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    atomic_write_new(args.output, rendered)
    print(f"wrote {args.output} ({tree_sha})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
