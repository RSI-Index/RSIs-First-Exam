"""Shared fail-closed contracts for trusted release evidence."""

from __future__ import annotations

import hashlib
import json
import math
import re
from typing import Any


INTERVAL_KEYS = {
    "schema_version",
    "start_event",
    "end_event",
    "duration_clock",
    "started_unix",
    "ended_unix",
    "elapsed_sec",
    "expected_agent_runs",
    "observed_agent_runs",
    "complete",
}

# This is the complete publishable model/runtime identity.  Host paths and
# process/container/GPU identifiers are intentionally absent.  The raw
# attestation remains a trusted input and is represented outside that boundary
# only by ``runtime_boot_identity_sha256``.
PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS = frozenset(
    {
        "schema_version",
        "state",
        "profile_id",
        "profile_sha256",
        "model_revision",
        "model_config_sha256",
        "model_weight_index_sha256",
        "runtime_image_id",
        "vllm_package_version",
        "tensor_parallel_size",
        "kv_cache_dtype",
        "tool_call_parser",
        "reasoning_parser",
        "model_mount_read_only",
        "runtime_boot_identity_sha256",
    }
)

PRIVATE_RUNTIME_IDENTITY_KEYS = frozenset(
    {
        "attestation_path",
        "container_id",
        "container_socket_path",
        "entrypoint_path",
        "gpu_uuids",
        "interpreter_path",
        "interpreter_realpath",
        "launch_token_sha256",
        "model_path",
        "package_root",
        "site_packages_path",
        "snapshot_path",
        "socket_path",
        "stdlib_path",
        "venv_root",
        "wrapper_pid",
        "wrapper_start_ticks",
        "uuid",
    }
)

PRESSURE_QUALIFICATION_PATHS = frozenset(
    {
        "audited_active_working_set",
        "audited_oversubscribed_working_set",
        "vllm_preemption",
    }
)

OVERSUBSCRIBED_CORROBORATION_PATHS = frozenset(
    {
        "synchronized_waiting",
        "leg_local_cache_churn",
    }
)

def _sha256(value: object, *, docker: bool = False) -> bool:
    if not isinstance(value, str):
        return False
    pattern = r"sha256:[0-9a-f]{64}" if docker else r"[0-9a-f]{64}"
    return re.fullmatch(pattern, value) is not None


def validate_publishable_model_runtime_identity(identity: object) -> dict[str, Any]:
    """Validate the exact non-identifying release representation."""

    if not isinstance(identity, dict):
        raise ValueError("publishable model runtime identity is not an object")
    if set(identity) != PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS:
        raise ValueError("publishable model runtime identity fields drift")
    if (
        identity.get("schema_version") != 1
        or identity.get("state") != "ready"
        or not isinstance(identity.get("profile_id"), str)
        or not identity["profile_id"]
        or not _sha256(identity.get("profile_sha256"))
        or not isinstance(identity.get("model_revision"), str)
        or not identity["model_revision"]
        or not _sha256(identity.get("model_config_sha256"))
        or not _sha256(identity.get("model_weight_index_sha256"))
        or not _sha256(identity.get("runtime_image_id"), docker=True)
        or not isinstance(identity.get("vllm_package_version"), str)
        or not identity["vllm_package_version"]
        or isinstance(identity.get("tensor_parallel_size"), bool)
        or not isinstance(identity.get("tensor_parallel_size"), int)
        or identity["tensor_parallel_size"] <= 0
        or not isinstance(identity.get("kv_cache_dtype"), str)
        or not identity["kv_cache_dtype"]
        or (
            identity.get("tool_call_parser") is not None
            and not isinstance(identity.get("tool_call_parser"), str)
        )
        or (
            identity.get("reasoning_parser") is not None
            and not isinstance(identity.get("reasoning_parser"), str)
        )
        or identity.get("model_mount_read_only") is not True
        or not _sha256(identity.get("runtime_boot_identity_sha256"))
    ):
        raise ValueError("publishable model runtime identity is malformed")
    return dict(identity)


def publishable_model_runtime_identity(attestation: object) -> dict[str, Any]:
    """Project a private host attestation into the exact release allowlist."""

    if not isinstance(attestation, dict):
        raise ValueError("model attestation is not an object")
    model = attestation.get("model")
    runtime = attestation.get("runtime")
    if not isinstance(model, dict) or not isinstance(runtime, dict):
        raise ValueError("model attestation has no model/runtime objects")
    file_hashes = model.get("file_hashes")
    if not isinstance(file_hashes, dict):
        raise ValueError("model attestation has no required-file identity")
    identity = {
        "schema_version": attestation.get("schema_version"),
        "state": attestation.get("state"),
        "profile_id": attestation.get("profile_id"),
        "profile_sha256": attestation.get("profile_sha256"),
        "model_revision": model.get("revision"),
        "model_config_sha256": file_hashes.get("config.json"),
        "model_weight_index_sha256": file_hashes.get(
            "model.safetensors.index.json"
        ),
        "runtime_image_id": runtime.get("runtime_image_id"),
        "vllm_package_version": attestation.get("observed_vllm_package_version"),
        "tensor_parallel_size": runtime.get("tensor_parallel_size"),
        "kv_cache_dtype": runtime.get("kv_cache_dtype"),
        "tool_call_parser": runtime.get("tool_call_parser"),
        "reasoning_parser": runtime.get("reasoning_parser"),
        "model_mount_read_only": attestation.get("model_mount_read_only"),
        "runtime_boot_identity_sha256": runtime_boot_identity_sha256(attestation),
    }
    return validate_publishable_model_runtime_identity(identity)


def reject_private_runtime_identity(value: object, context: str) -> None:
    """Reject release payloads containing raw host-runtime identity.

    This is a defense-in-depth recursive check.  Exact object allowlists remain
    authoritative; this catches a future field added elsewhere in evidence or
    the manifest before it can accidentally publish a host path or raw epoch.
    """

    def walk(item: object, location: str) -> None:
        if isinstance(item, dict):
            for key, child in item.items():
                if not isinstance(key, str):
                    raise ValueError(
                        f"{context} contains a non-string key at {location}"
                    )
                raw_pid_key = (
                    key == "pid"
                    or key == "pids"
                    or key.endswith("_pid")
                    or key.endswith("_pids")
                    or key.endswith("_start_ticks")
                )
                raw_container_id_key = key.endswith("container_id") or (
                    key == "id" and location.endswith(".container")
                )
                raw_gpu_uuid_key = key == "uuid" or key.endswith("_uuid") or key.endswith(
                    "_uuids"
                )
                if (
                    key in PRIVATE_RUNTIME_IDENTITY_KEYS
                    or raw_pid_key
                    or raw_container_id_key
                    or raw_gpu_uuid_key
                ):
                    raise ValueError(
                        f"{context} contains private runtime field at {location}.{key}"
                    )
                walk(child, f"{location}.{key}")
        elif isinstance(item, list):
            for index, child in enumerate(item):
                walk(child, f"{location}[{index}]")
        elif isinstance(item, str) and item.startswith(("/", "~")):
            raise ValueError(
                f"{context} contains an absolute/private path at {location}"
            )

    walk(value, "$")


def runtime_boot_identity_sha256(attestation: object) -> str:
    """Derive the controller's opaque host-vLLM boot/process identity."""

    if not isinstance(attestation, dict):
        raise ValueError("model attestation is not an object")
    process = attestation.get("process")
    container = attestation.get("container")
    ready_unix = attestation.get("ready_unix")
    if (
        attestation.get("schema_version") != 1
        or attestation.get("state") != "ready"
        or not isinstance(process, dict)
        or not isinstance(container, dict)
        or isinstance(ready_unix, bool)
        or not isinstance(ready_unix, (int, float))
        or not math.isfinite(float(ready_unix))
        or float(ready_unix) <= 0
    ):
        raise ValueError("model attestation has no valid ready runtime identity")
    wrapper_pid = process.get("wrapper_pid")
    wrapper_start_ticks = process.get("wrapper_start_ticks")
    if (
        isinstance(wrapper_pid, bool)
        or not isinstance(wrapper_pid, int)
        or wrapper_pid <= 0
        or isinstance(wrapper_start_ticks, bool)
        or not isinstance(wrapper_start_ticks, int)
        or wrapper_start_ticks <= 0
    ):
        raise ValueError("model attestation has no valid process identity")
    container_id = container.get("id")
    launch_token_sha256 = container.get("launch_token_sha256")
    if (
        not isinstance(container_id, str)
        or re.fullmatch(r"[0-9a-f]{64}", container_id) is None
        or not isinstance(launch_token_sha256, str)
        or re.fullmatch(r"[0-9a-f]{64}", launch_token_sha256) is None
    ):
        raise ValueError("model attestation has no valid container launch identity")
    canonical = json.dumps(
        {
            "schema_version": 1,
            "ready_unix": float(ready_unix),
            "process": {
                "wrapper_pid": wrapper_pid,
                "wrapper_start_ticks": wrapper_start_ticks,
            },
            "container": {
                "id": container_id,
                "launch_token_sha256": launch_token_sha256,
            },
        },
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(canonical).hexdigest()


def _number(value: object) -> float | None:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
    ):
        return None
    return float(value)


def validate_audited_oversubscribed_working_set(
    contention: object,
    context: str,
) -> None:
    """Validate the occupancy-independent oversubscription qualification path."""

    if not isinstance(contention, dict):
        raise ValueError(f"{context}: contention evidence is not an object")
    oversubscribed = contention.get("oversubscribed_working_set")
    if not isinstance(oversubscribed, dict):
        raise ValueError(f"{context}: oversubscribed working-set evidence is missing")
    threshold = _number(oversubscribed.get("demand_ratio_threshold"))
    corroboration = oversubscribed.get("corroboration_paths")
    if (
        oversubscribed.get("valid") is not True
        or oversubscribed.get("occupancy_independent") is not True
        or threshold != 1.0
        or not isinstance(corroboration, list)
        or not corroboration
        or not all(
            isinstance(path, str)
            and path in OVERSUBSCRIBED_CORROBORATION_PATHS
            for path in corroboration
        )
    ):
        raise ValueError(f"{context}: oversubscribed working-set evidence is invalid")
    for path in corroboration:
        subevidence = oversubscribed.get(path)
        if not isinstance(subevidence, dict) or subevidence.get("valid") is not True:
            raise ValueError(
                f"{context}: oversubscribed {path} evidence is invalid"
            )


def validate_finite_agent_execution_interval(
    leg: dict[str, Any],
    context: str,
    *,
    require_live_samples: bool,
) -> dict[str, Any]:
    """Validate timing, rate, and sample-cutoff identity for one finite leg."""

    interval = leg.get("agent_execution_interval")
    if not isinstance(interval, dict):
        raise ValueError(f"{context}: missing agent_execution_interval")
    if set(interval) != INTERVAL_KEYS:
        raise ValueError(f"{context}: agent_execution_interval fields drift")
    if (
        interval.get("schema_version") != 1
        or interval.get("start_event") != "measured_leg_started"
        or interval.get("end_event") != "last_agent_run_termination"
        or interval.get("duration_clock") != "monotonic"
        or interval.get("complete") is not True
    ):
        raise ValueError(f"{context}: invalid agent_execution_interval schema")

    started = _number(interval.get("started_unix"))
    ended = _number(interval.get("ended_unix"))
    elapsed = _number(interval.get("elapsed_sec"))
    if started is None or ended is None or elapsed is None or elapsed <= 0 or ended < started:
        raise ValueError(f"{context}: invalid finite interval timestamps")
    profile = leg.get("profile_config")
    workflows = profile.get("workflows") if isinstance(profile, dict) else None
    if (
        not isinstance(workflows, int)
        or isinstance(workflows, bool)
        or workflows <= 0
        or interval.get("expected_agent_runs") != workflows
        or interval.get("observed_agent_runs") != workflows
    ):
        raise ValueError(f"{context}: finite interval workflow count mismatch")
    for field, expected in (
        ("started_unix", started),
        ("ended_unix", ended),
        ("elapsed_sec", elapsed),
    ):
        observed = _number(leg.get(field))
        if observed is None or not math.isclose(
            observed, expected, rel_tol=1e-9, abs_tol=1e-6
        ):
            raise ValueError(f"{context}: finite interval {field} mismatch")
    wall_elapsed = _number(leg.get("wall_elapsed_sec"))
    if wall_elapsed is None or wall_elapsed + 1e-6 < elapsed:
        raise ValueError(f"{context}: wall elapsed precedes finite interval")
    valid_steps = leg.get("valid_steps")
    rate = _number(leg.get("valid_steps_per_min"))
    if (
        not isinstance(valid_steps, int)
        or isinstance(valid_steps, bool)
        or valid_steps < 0
        or rate is None
        or not math.isclose(
            rate, valid_steps * 60.0 / elapsed, rel_tol=1e-9, abs_tol=1e-9
        )
    ):
        raise ValueError(f"{context}: finite throughput rate identity mismatch")
    window = leg.get("measurement_window")
    if (
        not isinstance(window, dict)
        or window.get("configured") is not False
        or window.get("deadline_reached") is not False
        or window.get("termination") != "finite_workload"
    ):
        raise ValueError(f"{context}: finite measurement-window contract mismatch")
    if require_live_samples:
        samples = (leg.get("vllm_metrics") or {}).get("live_samples")
        if not isinstance(samples, list) or not samples:
            raise ValueError(f"{context}: finite live samples are missing")
        for sample in samples:
            created = _number(sample.get("created_unix")) if isinstance(sample, dict) else None
            if created is None or created > ended + 1e-6:
                raise ValueError(f"{context}: live sample exceeds last agent termination")
        sampler_errors = ((leg.get("vllm_metrics") or {}).get("live_series") or {}).get(
            "sampler_error_count"
        )
        if (
            not isinstance(sampler_errors, int)
            or isinstance(sampler_errors, bool)
            or sampler_errors != 0
        ):
            raise ValueError(f"{context}: finite metrics sampler reported errors")
    return interval
