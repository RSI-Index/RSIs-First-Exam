#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STATE_ROOT="${HARBOR_KVBENCH_STATE_ROOT:-$HOME/.cache/harbor-kv-scheduler-v2}"

if ! docker info >/dev/null 2>&1; then
  if [[ "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" == 1 ]]; then
    echo "Docker remains unavailable after entering the docker group" >&2
    exit 2
  fi
  printf -v reexec 'KV_TASK_DOCKER_GROUP_REEXEC=1 HARBOR_KVBENCH_STATE_ROOT=%q exec %q' "$STATE_ROOT" "$0"
  for argument in "$@"; do
    printf -v quoted ' %q' "$argument"
    reexec+="$quoted"
  done
  exec sg docker -c "$reexec"
fi

exec uv run \
  --isolated \
  --no-project \
  --python 3.12 \
  --with pyarrow==19.0.1 \
  python "$SCRIPT_DIR/stage-swebench-lite.py" \
  --output-root "$STATE_ROOT/swebench-lite" \
  "$@"
