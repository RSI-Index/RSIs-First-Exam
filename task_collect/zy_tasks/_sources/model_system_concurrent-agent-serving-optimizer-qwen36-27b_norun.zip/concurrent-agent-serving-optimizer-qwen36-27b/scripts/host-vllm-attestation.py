#!/usr/bin/env python3
"""Create and verify ownership-bound host-vLLM attestations.

The launcher keeps this helper deliberately independent from Docker and tmux.
It atomically records their already-validated identities and protects stop from
acting on a recycled PID, a different tmux pane, or an unrelated container.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import tempfile
import time
from pathlib import Path
from typing import Any


class AttestationError(RuntimeError):
    pass


def load_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise AttestationError(f"cannot read JSON object {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise AttestationError(f"expected JSON object in {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def process_start_ticks(pid: int) -> int:
    try:
        raw = Path(f"/proc/{pid}/stat").read_text()
    except OSError as exc:
        raise AttestationError(f"process {pid} is not live") from exc
    close = raw.rfind(")")
    fields = raw[close + 2 :].split()
    if close < 1 or len(fields) < 20:
        raise AttestationError(f"cannot parse /proc/{pid}/stat")
    return int(fields[19])


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o444)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def require_identity(value: dict[str, Any], args: argparse.Namespace) -> None:
    expected = {
        "process.tmux_session": args.session,
        "process.wrapper_pid": args.wrapper_pid,
        "container.name": args.container_name,
        "container.id": args.container_id,
        "container.launch_token_sha256": args.launch_token_sha256,
    }
    for dotted, wanted in expected.items():
        section, key = dotted.split(".")
        observed = value.get(section, {}).get(key)
        if observed != wanted:
            raise AttestationError(f"attested {dotted} changed: {observed!r} != {wanted!r}")
    recorded_ticks = value.get("process", {}).get("wrapper_start_ticks")
    live_ticks = process_start_ticks(args.wrapper_pid)
    if recorded_ticks != live_ticks:
        raise AttestationError(
            f"wrapper PID {args.wrapper_pid} was recycled: {live_ticks!r} != {recorded_ticks!r}"
        )


def write_starting(args: argparse.Namespace) -> None:
    profile = load_object(args.profile)
    preflight = load_object(args.preflight)
    command = json.loads(args.command_json)
    if not isinstance(command, list) or not command or not all(isinstance(v, str) for v in command):
        raise AttestationError("--command-json must be a non-empty JSON string array")
    if preflight.get("status") != "ok":
        raise AttestationError("preflight report is not successful")
    profile_sha256 = sha256_file(args.profile)
    if preflight.get("model_profile_sha256") != profile_sha256:
        raise AttestationError("preflight report does not match the selected model profile")
    runtime = profile.get("runtime", {})
    if runtime.get("runtime_image_ref") != args.image_ref:
        raise AttestationError("runtime image reference differs from the frozen profile")
    if runtime.get("runtime_image_id") != args.image_id:
        raise AttestationError("runtime image ID differs from the frozen profile")
    if runtime.get("vllm_package_version") != args.observed_vllm_package_version:
        raise AttestationError("observed vLLM package version differs from the frozen profile")
    if runtime.get("server_dev_mode") is not True:
        raise AttestationError("frozen runtime does not enable the trusted cache-reset router")
    if args.socket != args.runtime_dir / "vllm.sock":
        raise AttestationError("socket path must be RUNTIME_DIR/vllm.sock")

    now = time.time()
    value = {
        "schema_version": 1,
        "state": "starting",
        "created_unix": now,
        "ready_unix": None,
        "profile_id": profile["profile_id"],
        "profile_sha256": profile_sha256,
        "preflight_status": preflight["status"],
        "preflight_created_unix": preflight.get("created_unix"),
        "model_mount_read_only": True,
        "model": preflight["model"],
        "gpus": preflight["gpus"],
        "runtime": runtime,
        "observed_vllm_package_version": args.observed_vllm_package_version,
        "transport": {
            "kind": "unix",
            "socket_path": str(args.socket),
            "container_socket_path": runtime["container_socket_path"],
        },
        "process": {
            "tmux_session": args.session,
            "wrapper_pid": args.wrapper_pid,
            "wrapper_start_ticks": process_start_ticks(args.wrapper_pid),
        },
        "container": {
            "name": args.container_name,
            "id": args.container_id,
            "image_ref": args.image_ref,
            "image_id": args.image_id,
            "launch_token_sha256": args.launch_token_sha256,
            "environment": {"VLLM_SERVER_DEV_MODE": "1"},
        },
        "vllm_command": command,
    }
    atomic_json(args.output, value)


def mark(args: argparse.Namespace, state: str) -> None:
    value = load_object(args.attestation)
    if value.get("schema_version") != 1:
        raise AttestationError("unsupported attestation schema")
    require_identity(value, args)
    if state == "ready":
        try:
            mode = args.socket.lstat().st_mode
        except OSError as exc:
            raise AttestationError(f"vLLM socket is unavailable: {args.socket}") from exc
        if not stat.S_ISSOCK(mode):
            raise AttestationError(f"vLLM path is not a socket: {args.socket}")
        value["ready_unix"] = time.time()
    value["state"] = state
    value[f"{state}_unix"] = time.time()
    atomic_json(args.attestation, value)


def check(args: argparse.Namespace) -> None:
    value = load_object(args.attestation)
    if value.get("schema_version") != 1:
        raise AttestationError("unsupported attestation schema")
    require_identity(value, args)
    print(json.dumps({"status": "ok", "state": value.get("state")}, sort_keys=True))


def add_identity(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--session", required=True)
    parser.add_argument("--wrapper-pid", type=int, required=True)
    parser.add_argument("--container-name", required=True)
    parser.add_argument("--container-id", required=True)
    parser.add_argument("--launch-token-sha256", required=True)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    commands = result.add_subparsers(dest="action", required=True)
    write = commands.add_parser("write-starting")
    write.add_argument("--profile", type=Path, required=True)
    write.add_argument("--preflight", type=Path, required=True)
    write.add_argument("--runtime-dir", type=Path, required=True)
    write.add_argument("--socket", type=Path, required=True)
    write.add_argument("--output", type=Path, required=True)
    write.add_argument("--image-ref", required=True)
    write.add_argument("--image-id", required=True)
    write.add_argument("--observed-vllm-package-version", required=True)
    write.add_argument("--command-json", required=True)
    add_identity(write)
    for name in ("ready", "stopping", "exited", "check"):
        subparser = commands.add_parser(name)
        subparser.add_argument("--attestation", type=Path, required=True)
        subparser.add_argument("--socket", type=Path)
        add_identity(subparser)
    return result


def main() -> int:
    args = parser().parse_args()
    if args.action == "write-starting":
        write_starting(args)
    elif args.action == "ready":
        if args.socket is None:
            raise AttestationError("ready requires --socket")
        mark(args, "ready")
    elif args.action == "stopping":
        mark(args, "stopping")
    elif args.action == "exited":
        mark(args, "exited")
    else:
        check(args)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AttestationError, KeyError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}), file=os.sys.stderr)
        raise SystemExit(2) from exc
