#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
ACTION="${1:-}"
ORIGINAL_ARGUMENTS=("$@")
RUNTIME_DIR="${HARBOR_VLLM_RUNTIME_DIR:-/tmp/harbor-kv-qwen36-27b-${UID}}"
REFERENCE_GATEWAY_DIR="${KV_AUTHOR_REFERENCE_GATEWAY_DIR:-$TASK_DIR/solution/reference_gateway}"
PROJECT_NAME="kvbench-qwen36-public30"
LOCAL_VERIFIER_LOGS="${KV_LOCAL_VERIFIER_LOGS:-/tmp/kvbench-local-verifier-${PROJECT_NAME}}"

usage() {
  cat <<'EOF'
Usage: scripts/calibration-stack.sh ACTION [options]

This script manages only Harbor task services. The fixed Qwen3.6-27B TP2 vLLM
on physical GPUs 6 and 7 is owned by scripts/host-vllm-qwen36-27b.sh and is
never started or stopped here.

Actions:
  build                Build task images; do not start any service
  start                Require ready external Qwen TP2, then start task services
  restart-controller   Rebuild/recreate controller and sandbox worker
  stop-oracle          Stop only the author reference gateway (direct A stays available)
  restart-oracle       Fresh-recreate only the author reference gateway
  stop                 Stop task services; preserve evidence volumes and external Qwen
  status               Show task Compose state and external model status
  logs                 Show recent task service logs
  verify-phase0-local  Run only the infrastructure verifier
  verify-local         Run the full verifier in the foreground
  verify-local-start   Start the full verifier detached
  verify-local-status  Show detached verifier state and evidence files

Options:
  --runtime-dir PATH   External Qwen UDS/attestation directory
  --output-dir PATH    Host directory for local verifier evidence
EOF
}

[[ -n "$ACTION" ]] || { usage >&2; exit 2; }
if [[ -n "${KV_CALIBRATION_PROJECT+x}" ]]; then
  echo "KV_CALIBRATION_PROJECT overrides are forbidden; the task project is fixed as $PROJECT_NAME" >&2
  exit 2
fi
if [[ "$ACTION" == -h || "$ACTION" == --help ]]; then
  usage
  exit 0
fi
shift
while (($#)); do
  case "$1" in
    --runtime-dir)
      RUNTIME_DIR="${2:?--runtime-dir requires a value}"
      shift 2
      ;;
    --output-dir)
      LOCAL_VERIFIER_LOGS="${2:?--output-dir requires a value}"
      shift 2
      ;;
    --model-path|--model-profile|--compose-overlay|--gpu-indices)
      echo "$1 belongs to the retired task-owned vLLM path; use scripts/host-vllm-qwen36-27b.sh" >&2
      exit 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

[[ "$RUNTIME_DIR" == /* ]] || { echo "--runtime-dir must be absolute" >&2; exit 2; }
[[ "$REFERENCE_GATEWAY_DIR" == /* ]] \
  || { echo "KV_AUTHOR_REFERENCE_GATEWAY_DIR must be absolute" >&2; exit 2; }
[[ -d "$REFERENCE_GATEWAY_DIR" && ! -L "$REFERENCE_GATEWAY_DIR" ]] \
  || { echo "author reference gateway directory is unavailable: $REFERENCE_GATEWAY_DIR" >&2; exit 2; }
REFERENCE_GATEWAY_DIR="$(realpath -e -- "$REFERENCE_GATEWAY_DIR")"
LOCAL_VERIFIER_LOGS="$(realpath -m -- "$LOCAL_VERIFIER_LOGS")"
export HARBOR_VLLM_RUNTIME_DIR="$RUNTIME_DIR"
export KV_AUTHOR_REFERENCE_GATEWAY_DIR="$REFERENCE_GATEWAY_DIR"
export HARBOR_KVBENCH_STATE_ROOT="${HARBOR_KVBENCH_STATE_ROOT:-$HOME/.cache/harbor-kv-qwen36-public30}"
# The staged corpus is immutable and shared read-only across author diagnostics;
# mutable workspace and Compose state remain isolated under the Qwen-specific root.
export HARBOR_SWEBENCH_CORPUS_SOURCE="${HARBOR_SWEBENCH_CORPUS_SOURCE:-$HOME/.cache/harbor-kv-scheduler-v2/swebench-lite}"
export KV_TASK_DIR="$TASK_DIR"
export KV_LOCAL_VERIFIER_LOGS="$LOCAL_VERIFIER_LOGS"

if ! docker info >/dev/null 2>&1; then
  [[ "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" != 1 ]] \
    || { echo "Docker remains unavailable after entering the docker group" >&2; exit 2; }
  user_name="$(id -un)"
  getent group docker | awk -F: -v user="$user_name" '
    BEGIN { found=1 }
    { n=split($4,a,","); for(i=1;i<=n;i++) if(a[i]==user) found=0 }
    END { exit found }
  ' || { echo "Docker is unavailable and $user_name is not listed in the docker group" >&2; exit 2; }
  command=(env KV_TASK_DOCKER_GROUP_REEXEC=1 \
    "KV_LOCAL_VERIFIER_LOGS=$LOCAL_VERIFIER_LOGS" \
    "HARBOR_VLLM_RUNTIME_DIR=$RUNTIME_DIR" \
    "KV_AUTHOR_REFERENCE_GATEWAY_DIR=$REFERENCE_GATEWAY_DIR" \
    "$0" "${ORIGINAL_ARGUMENTS[@]}")
  command_string=""
  for argument in "${command[@]}"; do
    printf -v quoted '%q' "$argument"
    command_string+="${command_string:+ }$quoted"
  done
  exec sg docker -c "$command_string"
fi

install -d -m 0755 "$HARBOR_KVBENCH_STATE_ROOT/workspaces"

compose=(
  docker compose
  --project-name "$PROJECT_NAME"
  --project-directory "$TASK_DIR/environment"
  -f "$TASK_DIR/scripts/compose-main-base.yaml"
  -f "$TASK_DIR/environment/docker-compose.yaml"
  -f "$TASK_DIR/scripts/compose-calibration.yaml"
)
verifier_compose=("${compose[@]}" -f "$TASK_DIR/scripts/compose-local-verifier.yaml")

require_corpus() {
  if [[ ! -f "$HARBOR_SWEBENCH_CORPUS_SOURCE/manifest.json" ]]; then
    echo "pinned SWE-bench Lite corpus is not staged: $HARBOR_SWEBENCH_CORPUS_SOURCE/manifest.json" >&2
    echo "run scripts/stage-swebench-lite.sh first" >&2
    return 4
  fi
  python3 "$SCRIPT_DIR/validate-staged-corpus.py" "$HARBOR_SWEBENCH_CORPUS_SOURCE/manifest.json" >/dev/null
}

require_external_model() {
  "$SCRIPT_DIR/host-vllm-qwen36-27b.sh" status >/dev/null || {
    echo "external Qwen3.6-27B TP2 on GPUs 6 and 7 is not ready; run scripts/host-vllm-qwen36-27b.sh start" >&2
    return 4
  }
}

prepare_local_verifier() {
  require_external_model
  require_corpus
  mkdir -p "$LOCAL_VERIFIER_LOGS"
  # The verifier deliberately seals this bind mount as root:0700 before it
  # writes candidate-controlled logs.  A later author-side rerun must not try
  # to chmod that host path as the invoking (non-root) user; Docker can mount
  # it and the trusted root process in `main` can safely reuse it.
  "${verifier_compose[@]}" up --detach --no-deps --force-recreate main
  main_container="$("${verifier_compose[@]}" ps --quiet main)"
  [[ -n "$main_container" ]] || { echo "local verifier main container is unavailable" >&2; exit 2; }
  # /app is deliberately root-owned in the release image, so only the trusted
  # author harness may replace its submission child. Hand the exact copied
  # tree back to UID/GID 1000 before any verifier executes candidate code.
  docker exec --user 0:0 "$main_container" sh -ceu '
    rm -rf /app/submission
    cp -R /opt/reference-gateway /app/submission
    chown -R candidate:candidate /app/submission
  '
  docker exec "$main_container" sh -ceu '
    install -d -o root -g root -m 0755 /tests
    rm -f /logs/verifier/test-stdout.txt /logs/verifier/exit-code.txt
  '
  docker cp "$TASK_DIR/tests/." "$main_container:/tests"
}

case "$ACTION" in
  build)
    # The model may be stopped while task images are built. Compose still gets
    # the canonical runtime path so the rendered topology is deterministic.
    "${compose[@]}" config --quiet
    "${compose[@]}" build
    ;;
  start)
    require_external_model
    require_corpus
    "${compose[@]}" config --quiet
    "${compose[@]}" up --detach --build --wait --wait-timeout 300
    "${compose[@]}" ps
    ;;
  restart-controller)
    require_external_model
    require_corpus
    "${compose[@]}" build bench-controller sandbox-worker
    "${compose[@]}" up --detach --no-deps --force-recreate sandbox-worker bench-controller
    "${compose[@]}" ps bench-controller sandbox-worker
    ;;
  stop-oracle)
    "${compose[@]}" stop main
    "${compose[@]}" ps main
    ;;
  restart-oracle)
    require_external_model
    require_corpus
    "${compose[@]}" up --detach --no-deps --force-recreate main
    main_container="$("${compose[@]}" ps --quiet main)"
    [[ -n "$main_container" ]] || { echo "author reference gateway was not created" >&2; exit 2; }
    for _ in $(seq 1 60); do
      if docker exec "$main_container" python3 -c \
        'import urllib.request; urllib.request.urlopen("http://127.0.0.1:9000/health", timeout=2).read()' \
        >/dev/null 2>&1; then
        "${compose[@]}" ps main
        exit 0
      fi
      sleep 1
    done
    echo "author reference gateway did not become healthy" >&2
    "${compose[@]}" logs --tail 100 main >&2
    exit 3
    ;;
  stop)
    "${compose[@]}" down --timeout 300 --remove-orphans
    echo "Task services stopped; evidence volumes and external Qwen were preserved."
    ;;
  status)
    "${compose[@]}" ps
    "$SCRIPT_DIR/host-vllm-qwen36-27b.sh" status
    ;;
  logs)
    "${compose[@]}" logs --tail 200
    ;;
  verify-phase0-local)
    prepare_local_verifier
    docker exec "$main_container" python3 /tests/verify_phase0.py \
      --submission /app/submission \
      --backend http://127.0.0.1:8100/v1 \
      --admin-base http://127.0.0.1:8100 \
      --admin-token-file /run/kvbench-admin/token \
      --report /logs/verifier/phase0-report.json \
      --reward-json /logs/verifier/phase0-reward.json \
      --reward-txt /logs/verifier/phase0-reward.txt
    ;;
  verify-local)
    prepare_local_verifier
    docker exec "$main_container" /tests/test.sh
    ;;
  verify-local-start)
    prepare_local_verifier
    docker exec --detach "$main_container" sh -c '
      set +e
      /tests/test.sh > /logs/verifier/test-stdout.txt 2>&1
      status=$?
      temporary="/logs/verifier/.exit-code.$$.tmp"
      printf "%s\n" "$status" > "$temporary"
      chmod 0600 "$temporary"
      mv -f -- "$temporary" /logs/verifier/exit-code.txt
      exit "$status"
    '
    echo "Detached verifier started; evidence: $LOCAL_VERIFIER_LOGS"
    ;;
  verify-local-status)
    main_container="$("${verifier_compose[@]}" ps --quiet main)"
    [[ -n "$main_container" ]] || { echo "local verifier main container is unavailable" >&2; exit 2; }
    "${verifier_compose[@]}" ps
    status=0
    # test.sh deliberately seals this bind root as container root. Read only a
    # fixed public allowlist through a root docker exec; never enumerate the
    # host directory or reveal author-only private report/log names.
    docker exec --interactive --user 0:0 "$main_container" python3 - <<'PY' || status=$?
import errno
import os
import re
import stat
import subprocess
import sys

VERIFIER_ROOT = "/logs/verifier"
ALLOWLIST = (
    ("exit-code.txt", 16),
    ("report.json", 1024 * 1024),
    ("reward.json", 64 * 1024),
    ("reward.txt", 64),
    ("test-stdout.txt", 8 * 1024 * 1024),
)


def fail(message: str) -> None:
    print(f"local verifier status reader failed: {message}", file=sys.stderr)
    raise SystemExit(4)


root_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC
if hasattr(os, "O_NOFOLLOW"):
    root_flags |= os.O_NOFOLLOW
try:
    root_descriptor = os.open(VERIFIER_ROOT, root_flags)
except OSError as exc:
    fail(f"output root unavailable ({exc.errno})")

exit_code_payload: bytes | None = None
try:
    for name, size_limit in ALLOWLIST:
        flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        try:
            descriptor = os.open(name, flags, dir_fd=root_descriptor)
        except FileNotFoundError:
            continue
        except OSError as exc:
            fail(f"unsafe allowlisted entry {name} ({exc.errno})")
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode):
                fail(f"allowlisted entry is not regular: {name}")
            if info.st_size < 0 or info.st_size > size_limit:
                fail(f"allowlisted entry exceeds size cap: {name}")
            print(f"{name} {info.st_size} bytes")
            if name == "exit-code.txt":
                exit_code_payload = os.read(descriptor, size_limit + 1)
        finally:
            os.close(descriptor)
finally:
    os.close(root_descriptor)

if exit_code_payload is not None:
    if re.fullmatch(rb"(?:0|[1-9][0-9]{0,2})\n?", exit_code_payload) is None:
        fail("exit-code.txt is malformed")
    verifier_status = int(exit_code_payload.strip())
    if verifier_status > 255:
        fail("exit-code.txt is outside 0..255")
    print(f"verifier finished with exit code {verifier_status}")
    raise SystemExit(verifier_status)

patterns = (
    r"(^|[[:space:]])/tests/test[.]sh([[:space:]]|$)",
    r"(^|[[:space:]])/tests/verify[.]py([[:space:]]|$)",
)
running = False
for pattern in patterns:
    observed = subprocess.run(
        ["/usr/bin/pgrep", "-f", pattern],
        check=False,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if observed.returncode == 0:
        running = True
    elif observed.returncode != 1:
        fail("could not inspect verifier process state")
if running:
    print("verifier is running")
    raise SystemExit(0)
print("verifier process is absent and no exit-code.txt was written", file=sys.stderr)
raise SystemExit(3)
PY
    exit "$status"
    ;;
  *)
    echo "unknown action: $ACTION" >&2
    usage >&2
    exit 2
    ;;
esac
