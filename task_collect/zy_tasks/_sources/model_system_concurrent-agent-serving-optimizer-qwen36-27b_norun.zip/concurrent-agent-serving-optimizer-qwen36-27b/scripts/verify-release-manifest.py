#!/usr/bin/env python3
"""Fail closed unless the frozen release manifest still names this release.

The freezer proves that release evidence was sufficient at publication time.
This verifier is the complementary launch-time gate: it recomputes every
locally mutable identity bound by that manifest before a real Harbor agent may
run.  It is read-only and never starts, restarts, builds, or removes anything.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import stat
import subprocess
import sys
from pathlib import Path
from typing import Callable


TASK_ROOT = Path(__file__).resolve().parents[1]
FREEZER_PATH = TASK_ROOT / "scripts" / "freeze-release-manifest.py"
FREEZER_SPEC = importlib.util.spec_from_file_location(
    "freeze_release_manifest_for_currentness", FREEZER_PATH
)
if FREEZER_SPEC is None or FREEZER_SPEC.loader is None:  # pragma: no cover
    raise RuntimeError(f"cannot import release freezer: {FREEZER_PATH}")
FREEZER = importlib.util.module_from_spec(FREEZER_SPEC)
FREEZER_SPEC.loader.exec_module(FREEZER)

DOCKER_IMAGE_ID_RE = re.compile(r"sha256:[0-9a-f]{64}")


class ManifestVerificationError(RuntimeError):
    """The release manifest is missing, malformed, or no longer current."""


def reject(message: str) -> None:
    raise ManifestVerificationError(message)


def require_object(value: object, label: str) -> dict:
    if not isinstance(value, dict):
        reject(f"{label} must be a JSON object")
    return value


def require_exact_keys(value: dict, keys: set[str] | frozenset[str], label: str) -> None:
    if set(value) != set(keys):
        reject(f"{label} fields differ from the release allowlist")


def load_regular_json(path: Path, label: str) -> tuple[dict, str]:
    try:
        value, sha256 = FREEZER.load_regular_object_and_digest(path, label)
    except SystemExit as exc:
        reject(str(exc))
    return value, sha256


def docker_image_id(reference: str) -> str:
    try:
        return FREEZER.command(
            "docker", "image", "inspect", "--format", "{{.Id}}", reference
        )
    except Exception as exc:
        reject(f"cannot resolve frozen task image {reference}: {exc}")


def exact_evidence_set(
    *,
    manifest: dict,
    manifest_path: Path,
    release_id: str,
    profile_sha256: str,
) -> None:
    evidence_directory_path = manifest_path.parent / "qwen36-release"
    if evidence_directory_path.is_symlink():
        reject("Qwen release evidence directory must not be a symlink")
    index_path = evidence_directory_path / "evidence-index.json"
    index, index_sha256 = load_regular_json(
        index_path, "Qwen release evidence index"
    )
    require_exact_keys(
        index,
        {"schema_version", "release_id", "model_profile_sha256", "files"},
        "Qwen release evidence index",
    )
    if manifest.get("calibration_evidence_index_sha256") != index_sha256:
        reject("Qwen release evidence index digest differs from the manifest")
    if (
        index.get("schema_version") != 1
        or index.get("release_id") != release_id
        or index.get("model_profile_sha256") != profile_sha256
    ):
        reject("Qwen release evidence index identity differs from the manifest")
    names = index.get("files")
    if (
        not isinstance(names, list)
        or not names
        or any(
            not isinstance(name, str)
            or not name
            or Path(name).name != name
            or Path(name).suffix != ".json"
            or name == index_path.name
            for name in names
        )
        or len(names) != len(set(names))
    ):
        reject("Qwen release evidence index has an invalid exact files list")

    expected = {f"qwen36-release/{name}" for name in names}
    frozen = require_object(
        manifest.get("calibration_evidence_sha256"),
        "manifest calibration_evidence_sha256",
    )
    if set(frozen) != expected:
        reject("manifest evidence file set differs from the evidence index")

    evidence_dir = index_path.parent.resolve(strict=True)
    observed_json_names: set[str] = set()
    observed_public_direct_anchors: set[str] = set()
    for entry in evidence_dir.iterdir():
        if entry.name == index_path.name:
            observed_json_names.add(entry.name)
            continue
        if entry.suffix != ".json":
            continue
        if entry.is_symlink():
            reject(f"Qwen release evidence must not be a symlink: {entry.name}")
        if not stat.S_ISREG(entry.stat().st_mode):
            reject(f"Qwen release evidence is not a regular file: {entry.name}")
        observed_json_names.add(entry.name)
    if observed_json_names != {index_path.name, *names}:
        reject("Qwen release evidence directory has unindexed or missing JSON files")

    for name in names:
        path = evidence_dir / name
        payload, observed_sha256 = load_regular_json(path, "Qwen release evidence")
        try:
            FREEZER.reject_private_runtime_identity(
                payload, f"Qwen release evidence {name}"
            )
        except ValueError as exc:
            reject(str(exc))
        if frozen[f"qwen36-release/{name}"] != observed_sha256:
            reject(f"Qwen release evidence digest differs from the manifest: {name}")
        anchor = payload.get("public_direct_anchor")
        if anchor is not None:
            if (
                not isinstance(anchor, dict)
                or anchor.get("kind") != "kvbench-release-public-direct-anchor"
                or not isinstance(anchor.get("sha256"), str)
                or re.fullmatch(r"[0-9a-f]{64}", anchor["sha256"]) is None
            ):
                reject(f"Qwen public Direct anchor binding is malformed: {name}")
            observed_public_direct_anchors.add(anchor["sha256"])
    if observed_public_direct_anchors != {
        manifest.get("public_direct_anchor_sha256")
    }:
        reject("public Direct anchor digest differs from current release evidence")


def verify_release_manifest(
    *,
    manifest_path: Path,
    readiness_path: Path,
    policy_path: Path,
    attestation_path: Path,
    model_path: Path | None,
    corpus_manifest_path: Path,
    task_root: Path = TASK_ROOT,
    image_id_resolver: Callable[[str], str] = docker_image_id,
    external_attestation_validator: Callable[..., dict] | None = None,
    harbor_bin_path: Path | None = None,
    harbor_identity_resolver: Callable[[Path], dict] | None = None,
    pre_author_gate: bool = False,
) -> dict:
    """Verify one manifest against current files, live runtime, and images.

    The injectable resolvers exist only so CPU mutation tests can use temporary
    fixtures.  The command-line entrypoint always uses Docker inspection and
    the full external-attestation validator from the release freezer.
    """

    task_root = task_root.resolve(strict=True)
    manifest_path = manifest_path.expanduser()
    manifest, _manifest_sha256 = load_regular_json(
        manifest_path, "release manifest"
    )
    require_exact_keys(
        manifest,
        {
            "schema_version",
            "release_id",
            "generated_at_utc",
            "harbor_version",
            "harbor_runtime",
            "model",
            "runtime",
            "benchmark",
            "critical_tree_sha256",
            "critical_files",
            "real_agent_execution_surface",
            "calibration_evidence_index_sha256",
            "calibration_evidence_sha256",
            "public_direct_anchor_sha256",
        },
        "release manifest",
    )
    try:
        FREEZER.reject_private_runtime_identity(manifest, "release manifest")
    except ValueError as exc:
        reject(str(exc))
    readiness, _readiness_sha256 = load_regular_json(
        readiness_path.expanduser(), "release readiness"
    )
    policy, policy_sha256 = load_regular_json(
        policy_path.expanduser(), "scoring policy"
    )
    expected_paths = {
        "release manifest": task_root / "calibration" / "release-manifest.json",
        "release readiness": task_root / "calibration" / "release-readiness.json",
        "scoring policy": (
            task_root
            / "environment"
            / "bench-controller"
            / "profiles"
            / "scoring-policy.json"
        ),
    }
    supplied_paths = {
        "release manifest": manifest_path,
        "release readiness": readiness_path.expanduser(),
        "scoring policy": policy_path.expanduser(),
    }
    for label, expected_path in expected_paths.items():
        if (
            supplied_paths[label].resolve(strict=True)
            != expected_path.resolve(strict=True)
        ):
            reject(f"{label} is not the current task's canonical file")

    if (
        manifest.get("schema_version") != 3
        or policy.get("schema_version") != 2
        or readiness.get("schema_version") != 2
    ):
        reject("manifest schema_version is not 3 or policy/readiness schema_version is not 2")
    release_id = manifest.get("release_id")
    if (
        not isinstance(release_id, str)
        or not release_id
        or release_id.startswith("development")
        or policy.get("release_id") != release_id
        or readiness.get("release_id") != release_id
    ):
        reject("manifest, scoring policy, and readiness release_id do not agree")
    if policy.get("release_ready") is not True:
        reject("scoring policy release_ready is not true")
    author_gate = readiness.get("real_agent_test_allowed")
    if pre_author_gate:
        if author_gate is not False:
            reject(
                "pre-author currentness requires real_agent_test_allowed to remain false"
            )
    elif author_gate is not True:
        reject("release readiness real_agent_test_allowed is not true")

    if harbor_bin_path is None:
        discovered_harbor = shutil.which("harbor")
        if not discovered_harbor:
            reject("Harbor is unavailable for runtime currentness verification")
        harbor_bin_path = Path(discovered_harbor)
    identity_resolver = harbor_identity_resolver or FREEZER.harbor_runtime_identity
    try:
        observed_harbor_runtime = identity_resolver(harbor_bin_path)
    except (OSError, subprocess.SubprocessError, ValueError, TypeError) as exc:
        reject(f"cannot resolve current Harbor runtime identity: {exc}")
    frozen_harbor_runtime = require_object(
        manifest.get("harbor_runtime"), "manifest harbor_runtime"
    )
    require_exact_keys(
        frozen_harbor_runtime,
        FREEZER.PUBLISHABLE_HARBOR_RUNTIME_KEYS,
        "manifest harbor_runtime",
    )
    try:
        observed_publishable_harbor = FREEZER.publishable_harbor_runtime_identity(
            observed_harbor_runtime
        )
        frozen_harbor_runtime = FREEZER.publishable_harbor_runtime_identity(
            frozen_harbor_runtime
        )
    except ValueError as exc:
        reject(f"Harbor release identity is malformed: {exc}")
    if frozen_harbor_runtime != observed_publishable_harbor:
        reject("Harbor entrypoint, interpreter, package tree, or version drifted")
    if manifest.get("harbor_version") != observed_publishable_harbor.get(
        "harbor_version"
    ):
        reject("manifest harbor_version disagrees with the bound Harbor runtime")

    current_files, current_tree_sha256 = FREEZER.tree_manifest(
        FREEZER.critical_files(task_root), task_root
    )
    if manifest.get("critical_files") != current_files:
        reject("critical_files differs from the current task tree")
    if manifest.get("critical_tree_sha256") != current_tree_sha256:
        reject("critical_tree_sha256 differs from the current task tree")

    try:
        repository_root = FREEZER.repository_root_for_task(task_root)
        current_execution_surface = FREEZER.real_agent_execution_surface(
            repository_root
        )
    except OSError as exc:
        reject(f"cannot hash current real-agent execution surface: {exc}")
    frozen_execution_surface = require_object(
        manifest.get("real_agent_execution_surface"),
        "manifest real_agent_execution_surface",
    )
    if frozen_execution_surface != current_execution_surface:
        reject(
            "real-agent execution allowlist, file digests, or tree digest differs "
            "from the manifest"
        )

    benchmark = require_object(manifest.get("benchmark"), "manifest benchmark")
    controller_files = require_object(
        benchmark.get("controller_config_files"),
        "manifest controller_config_files",
    )
    current_controller_files = {
        path.name: FREEZER.digest(path)
        for path in sorted(
            (task_root / "environment" / "bench-controller" / "profiles").glob(
                "*.json"
            )
        )
    }
    if controller_files != current_controller_files:
        reject("controller configuration file map differs from the manifest")
    policy_contract_sha256 = FREEZER.policy_contract_sha256(policy)
    if (
        benchmark.get("scoring_policy_sha256") != policy_sha256
        or controller_files.get("scoring-policy.json") != policy_sha256
    ):
        reject("scoring policy file digest differs from the manifest")
    if benchmark.get("scoring_policy_contract_sha256") != policy_contract_sha256:
        reject("scoring policy contract digest differs from the manifest")
    if benchmark.get("release_evidence_policy") != FREEZER.RELEASE_EVIDENCE_POLICY:
        reject("release evidence policy differs from the single-Oracle pair contract")

    runtime = require_object(manifest.get("runtime"), "manifest runtime")
    model = require_object(manifest.get("model"), "manifest model")
    require_exact_keys(
        model,
        {"model_id", "revision", "config_sha256", "weight_index_sha256"},
        "manifest model",
    )
    require_exact_keys(
        runtime,
        {
            "lifecycle",
            "transport",
            "model_profile_path",
            "model_profile_id",
            "model_profile_sha256",
            "external_vllm",
            "task_images",
        },
        "manifest runtime",
    )
    profile_relative = runtime.get("model_profile_path")
    if profile_relative != "environment/vllm-runtime/model-profile-qwen3.6-27b.json":
        reject("manifest names an unexpected Qwen model profile path")
    profile_path = task_root / profile_relative
    profile, profile_sha256 = load_regular_json(profile_path, "Qwen model profile")
    source = require_object(profile.get("source"), "Qwen profile source")
    profile_runtime = require_object(profile.get("runtime"), "Qwen profile runtime")
    required_files = require_object(
        profile.get("required_files"), "Qwen profile required_files"
    )
    if (
        profile_sha256 != FREEZER.QWEN_PROFILE_SHA256
        or profile.get("profile_id") != FREEZER.QWEN_PROFILE_ID
        or source.get("repository") != FREEZER.QWEN_REPOSITORY
        or source.get("revision") != FREEZER.QWEN_REVISION
        or runtime.get("model_profile_id") != FREEZER.QWEN_PROFILE_ID
        or runtime.get("model_profile_sha256") != profile_sha256
        or runtime.get("lifecycle") != "external-host-vllm"
        or runtime.get("transport") != "unix-domain-socket"
        or model.get("model_id") != FREEZER.QWEN_REPOSITORY
        or model.get("revision") != FREEZER.QWEN_REVISION
        or model.get("config_sha256") != required_files.get("config.json")
        or model.get("weight_index_sha256")
        != required_files.get("model.safetensors.index.json")
        or DOCKER_IMAGE_ID_RE.fullmatch(
            str(profile_runtime.get("runtime_image_id", ""))
        )
        is None
        or not isinstance(profile_runtime.get("vllm_package_version"), str)
        or not profile_runtime.get("vllm_package_version")
        or profile_runtime.get("tensor_parallel_size") != 2
        or profile_runtime.get("kv_cache_dtype") != "fp8"
    ):
        reject("frozen Qwen profile, revision, vLLM, TP2, or FP8 identity drifted")

    attestation, _attestation_sha256 = load_regular_json(
        attestation_path.expanduser(), "external Qwen attestation"
    )
    attested_model = require_object(
        attestation.get("model"), "external Qwen attestation model"
    )
    private_model_path = attested_model.get("model_path")
    if (
        not isinstance(private_model_path, str)
        or not Path(private_model_path).is_absolute()
        or Path(private_model_path).name != FREEZER.QWEN_REVISION
    ):
        reject("live external Qwen attestation has no frozen private model path")
    attested_model_path = Path(private_model_path)
    selected_model_path = model_path.expanduser() if model_path is not None else attested_model_path
    if (
        not selected_model_path.is_absolute()
        or selected_model_path.name != FREEZER.QWEN_REVISION
        or selected_model_path != attested_model_path
    ):
        reject("caller model path and live private attestation do not match")
    validator = external_attestation_validator or FREEZER.validate_external_attestation
    try:
        observed_external = validator(
            attestation_path.expanduser().resolve(strict=True),
            attestation,
            profile_path.resolve(strict=True),
            profile,
            (
                selected_model_path
                if external_attestation_validator is not None
                else selected_model_path.resolve(strict=True)
            ),
        )
    except (OSError, SystemExit, subprocess.SubprocessError) as exc:
        reject(f"live external Qwen attestation is invalid: {exc}")
    frozen_external = require_object(
        runtime.get("external_vllm"), "manifest external_vllm"
    )
    require_exact_keys(
        frozen_external,
        FREEZER.PUBLISHABLE_MODEL_RUNTIME_IDENTITY_KEYS,
        "manifest external_vllm",
    )
    try:
        frozen_external = FREEZER.validate_publishable_model_runtime_identity(
            frozen_external
        )
        observed_external = FREEZER.validate_publishable_model_runtime_identity(
            observed_external
        )
    except ValueError as exc:
        reject(f"live or frozen Qwen publishable identity is malformed: {exc}")
    if frozen_external != observed_external:
        reject("live external Qwen attestation differs from the frozen manifest")

    task_images = require_object(runtime.get("task_images"), "manifest task_images")
    if set(task_images) != set(FREEZER.DEFAULT_IMAGES):
        reject("manifest does not bind exactly the four task images")
    for name, reference in FREEZER.DEFAULT_IMAGES.items():
        frozen_image = require_object(task_images.get(name), f"task image {name}")
        require_exact_keys(
            frozen_image, {"reference", "image_id"}, f"task image {name}"
        )
        image_id = frozen_image.get("image_id")
        if (
            frozen_image.get("reference") != reference
            or not isinstance(image_id, str)
            or DOCKER_IMAGE_ID_RE.fullmatch(image_id) is None
            or image_id_resolver(reference) != image_id
        ):
            reject(f"task image identity differs from the manifest: {name}")

    _corpus, corpus_sha256 = load_regular_json(
        corpus_manifest_path.expanduser(), "staged corpus manifest"
    )
    corpus = require_object(benchmark.get("corpus"), "manifest benchmark corpus")
    if corpus.get("manifest_sha256") != corpus_sha256:
        reject("staged corpus digest differs from the manifest")

    reference_root = task_root / "solution" / "reference_gateway"
    try:
        gateway_tree_sha256 = FREEZER.reference_gateway_tree_sha256(reference_root)
        submission_sha256 = FREEZER.reference_submission_sha256(
            reference_root, task_root / "solution" / "solve.sh"
        )
    except OSError as exc:
        reject(f"cannot hash current Oracle reference implementation: {exc}")
    if benchmark.get("reference_gateway_tree_sha256") != gateway_tree_sha256:
        reject("Oracle reference gateway tree differs from the manifest")
    if benchmark.get("reference_submission_sha256") != submission_sha256:
        reject("Oracle reference submission differs from the manifest")

    exact_evidence_set(
        manifest=manifest,
        manifest_path=manifest_path,
        release_id=release_id,
        profile_sha256=profile_sha256,
    )
    return {
        "release_id": release_id,
        "critical_tree_sha256": current_tree_sha256,
        "real_agent_execution_tree_sha256": current_execution_surface[
            "tree_sha256"
        ],
        "real_agent_execution_file_count": len(
            current_execution_surface["files_sha256"]
        ),
        "model_profile_sha256": profile_sha256,
        "corpus_manifest_sha256": corpus_sha256,
        "reference_gateway_tree_sha256": gateway_tree_sha256,
        "reference_submission_sha256": submission_sha256,
        "release_evidence_policy_id": FREEZER.RELEASE_EVIDENCE_POLICY["policy_id"],
        "public_direct_anchor_sha256": manifest["public_direct_anchor_sha256"],
        "task_image_count": len(task_images),
        "evidence_file_count": len(manifest["calibration_evidence_sha256"]),
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Verify that the immutable Qwen release manifest is still current"
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=TASK_ROOT / "calibration" / "release-manifest.json",
    )
    parser.add_argument(
        "--readiness",
        type=Path,
        default=TASK_ROOT / "calibration" / "release-readiness.json",
    )
    parser.add_argument(
        "--policy",
        type=Path,
        default=(
            TASK_ROOT
            / "environment"
            / "bench-controller"
            / "profiles"
            / "scoring-policy.json"
        ),
    )
    runtime_default = Path(
        os.environ.get(
            "HARBOR_VLLM_RUNTIME_DIR", f"/tmp/harbor-kv-qwen36-27b-{os.getuid()}"
        )
    )
    parser.add_argument(
        "--attestation",
        type=Path,
        default=runtime_default / "attestation.json",
    )
    parser.add_argument(
        "--model-path",
        type=Path,
        default=(
            Path(os.environ["HARBOR_VLLM_MODEL_PATH"])
            if os.environ.get("HARBOR_VLLM_MODEL_PATH")
            else None
        ),
        help="private live Qwen snapshot path; never copied into the release manifest",
    )
    state_root = Path(
        os.environ.get(
            "HARBOR_KVBENCH_STATE_ROOT",
            str(Path.home() / ".cache" / "harbor-kv-scheduler-v2"),
        )
    )
    parser.add_argument(
        "--corpus-manifest",
        type=Path,
        default=Path(
            os.environ.get(
                "HARBOR_SWEBENCH_CORPUS_SOURCE", str(state_root / "swebench-lite")
            )
        )
        / "manifest.json",
    )
    parser.add_argument(
        "--pre-author-gate",
        action="store_true",
        help=(
            "validate the complete frozen release while requiring the author "
            "real_agent_test_allowed bit to still be false"
        ),
    )
    parser.add_argument(
        "--harbor-bin",
        type=Path,
        default=None,
        help="actual Harbor executable to compare with the frozen runtime identity",
    )
    args = parser.parse_args()
    try:
        result = verify_release_manifest(
            manifest_path=args.manifest,
            readiness_path=args.readiness,
            policy_path=args.policy,
            attestation_path=args.attestation,
            model_path=args.model_path,
            corpus_manifest_path=args.corpus_manifest,
            harbor_bin_path=args.harbor_bin,
            pre_author_gate=args.pre_author_gate,
        )
    except (ManifestVerificationError, OSError, KeyError, TypeError, ValueError) as exc:
        print(f"release manifest currentness failed: {exc}", file=sys.stderr)
        return 4
    print(
        "Release manifest currentness passed: "
        + json.dumps(result, separators=(",", ":"), sort_keys=True)
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
