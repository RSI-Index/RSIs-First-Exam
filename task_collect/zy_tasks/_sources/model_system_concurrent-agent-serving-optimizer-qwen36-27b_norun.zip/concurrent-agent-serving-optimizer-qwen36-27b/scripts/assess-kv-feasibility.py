#!/usr/bin/env python3
"""Check whether a fixed KV budget can be both safe and pressurized."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


GIB = 1024**3


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    with tempfile.NamedTemporaryFile(prefix=f".{path.name}.", dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--target-profile", default="calibration-72")
    parser.add_argument("--available-kv-gib", type=float, required=True)
    parser.add_argument("--observed-token-capacity", type=int, required=True)
    parser.add_argument("--target-kv-p95", type=float, default=0.90)
    parser.add_argument("--single-request-safety-factor", type=float, default=1.10)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output = args.output.expanduser().resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite KV feasibility evidence: {output}")
    if not 1 <= args.available_kv_gib <= 80:
        raise ValueError("--available-kv-gib must be in 1..80")
    if args.observed_token_capacity <= 0:
        raise ValueError("--observed-token-capacity must be positive")
    if not 0.80 <= args.target_kv_p95 < 1.0:
        raise ValueError("--target-kv-p95 must be in [0.80, 1.0)")
    if not 1.0 <= args.single_request_safety_factor <= 2.0:
        raise ValueError("--single-request-safety-factor must be in [1.0, 2.0]")

    sources = []
    natural_p95_values = []
    natural_max_values = []
    total_token_max_values = []
    target_config: dict[str, Any] | None = None
    for raw_path in args.input:
        path = raw_path.expanduser().resolve(strict=True)
        sweep = json.loads(path.read_text())
        if sweep.get("kind") != "real-swe-baseline-calibration-sweep":
            raise ValueError(f"not a real-SWE baseline sweep: {path}")
        run = sweep.get("runs", {}).get(args.target_profile)
        if not isinstance(run, dict):
            raise ValueError(f"target profile is absent from {path}: {args.target_profile}")
        series = run.get("vllm_metrics", {}).get("live_series", {})
        natural_p95 = series.get("kv_cache_usage_p95")
        natural_max = series.get("kv_cache_usage_max")
        if not isinstance(natural_p95, (int, float)) or not isinstance(natural_max, (int, float)):
            raise ValueError(f"target run has no KV summary: {path}")
        natural_p95_values.append(float(natural_p95))
        natural_max_values.append(float(natural_max))
        token_max = run.get("request_token_distribution", {}).get("total_tokens", {}).get("max")
        if isinstance(token_max, (int, float)):
            total_token_max_values.append(int(token_max))
        target_config = dict(run.get("profile_config", {}))
        sources.append(
            {
                "path": str(path),
                "sha256": sha256(path),
                "top_level_status": sweep.get("status"),
                "backend_audit_passed": run.get("backend_audit", {}).get("passed"),
                "request_success_rate": run.get("request_success_rate"),
                "infrastructure_failure": run.get("infrastructure_failure"),
                "natural_kv_p95": float(natural_p95),
                "natural_kv_max": float(natural_max),
                "observed_total_token_max": token_max,
                "model_profile_sha256": sweep.get("model_profile_sha256"),
            }
        )

    if not total_token_max_values:
        raise ValueError("none of the inputs contains request total-token telemetry")
    assert target_config is not None
    capacity_bytes = round(args.available_kv_gib * GIB)
    conservative_p95 = max(natural_p95_values)
    conservative_max = max(natural_max_values)
    observed_total_token_max = max(total_token_max_values)

    pressure_continuous_bytes = capacity_bytes * conservative_p95 / args.target_kv_p95
    pressure_budget_gib = max(1, math.floor(pressure_continuous_bytes / GIB))
    pressure_budget_bytes = pressure_budget_gib * GIB
    safe_continuous_bytes = (
        capacity_bytes
        * observed_total_token_max
        * args.single_request_safety_factor
        / args.observed_token_capacity
    )
    safe_budget_gib = math.ceil(safe_continuous_bytes / GIB)
    safe_budget_bytes = safe_budget_gib * GIB
    feasible = safe_budget_bytes <= pressure_budget_bytes

    def projected(budget_bytes: int) -> dict[str, float]:
        scale = capacity_bytes / budget_bytes
        return {
            "kv_p95": conservative_p95 * scale,
            "kv_max": conservative_max * scale,
        }

    evidence = {
        "schema_version": 1,
        "kind": "fixed-kv-budget-feasibility",
        "status": "feasible" if feasible else "infeasible_at_current_model_and_workload",
        "created_at_utc": utc_now(),
        "target_profile": args.target_profile,
        "sources": sources,
        "natural_capacity": {
            "bytes_per_gpu": capacity_bytes,
            "gib_per_gpu": args.available_kv_gib,
            "observed_token_capacity": args.observed_token_capacity,
        },
        "conservative_observations": {
            "kv_p95": conservative_p95,
            "kv_max": conservative_max,
            "total_tokens_max": observed_total_token_max,
        },
        "pressure_bound": {
            "target_kv_p95": args.target_kv_p95,
            "continuous_budget_bytes": pressure_continuous_bytes,
            "largest_whole_gib_budget_bytes": pressure_budget_bytes,
            "largest_whole_gib_budget_gib": pressure_budget_gib,
            "projected": projected(pressure_budget_bytes),
        },
        "single_request_safety_bound": {
            "safety_factor": args.single_request_safety_factor,
            "continuous_budget_bytes": safe_continuous_bytes,
            "smallest_whole_gib_budget_bytes": safe_budget_bytes,
            "smallest_whole_gib_budget_gib": safe_budget_gib,
            "projected": projected(safe_budget_bytes),
        },
        "bounds_overlap": feasible,
        "selected_budget_bytes_per_gpu": pressure_budget_bytes if feasible else None,
        "pressure_gate": {
            "threshold": float(target_config.get("pressure_kv_threshold", 0.8)),
            "p95_min": float(target_config.get("pressure_kv_p95_min", 0.8)),
            "time_fraction_min": float(target_config.get("pressure_time_fraction_min", 0.15)),
        },
        "conclusion": (
            "A fixed cache budget can satisfy both constraints."
            if feasible
            else "The cache budget needed for target pressure is smaller than the safe single-request bound. "
            "Do not probe intermediate budgets as release candidates."
        ),
        "allowed_next_steps": [
            "Keep the frozen model at natural KV capacity for functional workload validation.",
            "With explicit author approval, change the model/workload shape so real contexts create pressure without violating the single-request bound.",
            "Do not use synthetic prompt padding or truncate candidate requests to force occupancy.",
        ],
    }
    atomic_write(output, evidence)
    print(json.dumps(evidence, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
