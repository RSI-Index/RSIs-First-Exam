#!/usr/bin/env python3
"""Host-side fail-fast checks and Hugging Face mount resolution."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any


TASK_DIR = Path(__file__).resolve().parents[1]
RUNTIME_DIR = TASK_DIR / "environment" / "vllm-runtime"
sys.path.insert(0, str(RUNTIME_DIR))

from model_contract import (  # noqa: E402
    ContractError,
    load_profile,
    resolve_mount,
    sha256_file,
    validate_model,
)


def run(command: list[str], timeout: int = 60) -> str:
    try:
        return subprocess.check_output(command, text=True, stderr=subprocess.STDOUT, timeout=timeout).strip()
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        output = getattr(exc, "output", "")
        raise ContractError(f"command failed: {' '.join(command)}\n{output}") from exc


def gpu_inventory() -> list[dict[str, Any]]:
    output = run(
        [
            "nvidia-smi",
            "--query-gpu=index,uuid,name,memory.total,compute_cap",
            "--format=csv,noheader,nounits",
        ]
    )
    inventory = []
    for line in output.splitlines():
        fields = [field.strip() for field in line.split(",")]
        if len(fields) != 5:
            raise ContractError(f"unexpected nvidia-smi output: {line!r}")
        index, uuid, name, memory_mib, compute_capability = fields
        inventory.append(
            {
                "index": int(index),
                "uuid": uuid,
                "name": name,
                "memory_mib": int(memory_mib),
                "compute_capability": compute_capability,
            }
        )
    return inventory


def validate_gpus(inventory: list[dict[str, Any]], contract: dict[str, Any]) -> None:
    if len(inventory) != contract["count"]:
        raise ContractError(f"host must expose exactly {contract['count']} GPUs; found {len(inventory)}")
    if len({gpu["uuid"] for gpu in inventory}) != len(inventory):
        raise ContractError("GPU UUIDs are not distinct")
    allowed = set(contract["allowed_names"])
    for gpu in inventory:
        if gpu["name"] not in allowed:
            raise ContractError(f"GPU {gpu['index']} is not allowlisted: {gpu['name']}")
        if gpu["memory_mib"] < contract["minimum_memory_mib"]:
            raise ContractError(f"GPU {gpu['index']} has insufficient HBM: {gpu['memory_mib']} MiB")
        if gpu["compute_capability"] != contract["compute_capability"]:
            raise ContractError(f"GPU {gpu['index']} has compute capability {gpu['compute_capability']}")


def select_gpus(inventory: list[dict[str, Any]], indices: list[int]) -> list[dict[str, Any]]:
    if len(indices) != len(set(indices)):
        raise ContractError(f"GPU indices are duplicated: {indices}")
    by_index = {int(gpu["index"]): gpu for gpu in inventory}
    missing = sorted(set(indices) - set(by_index))
    if missing:
        raise ContractError(f"requested GPU indices do not exist: {missing}")
    return [by_index[index] for index in indices]


def active_gpu_processes(selected_uuids: set[str]) -> list[dict[str, Any]]:
    output = run(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
            "--format=csv,noheader,nounits",
        ]
    )
    if not output or output == "No running processes found":
        return []
    result = []
    for line in output.splitlines():
        fields = [field.strip() for field in line.split(",", 3)]
        if len(fields) == 4 and fields[0] in selected_uuids:
            result.append(
                {
                    "gpu_uuid": fields[0],
                    "pid": int(fields[1]),
                    "process_name": fields[2],
                    "used_memory_mib": int(fields[3]),
                }
            )
    return result


def _object_section(container: dict[str, Any], name: str) -> dict[str, Any]:
    value = container.get(name)
    if not isinstance(value, dict):
        raise ContractError(f"Docker inspect returned a malformed {name} section")
    return value


def _nvidia_visible_devices(container: dict[str, Any]) -> str | None:
    environment = _object_section(container, "Config").get("Env") or []
    if not isinstance(environment, list):
        raise ContractError("Docker inspect returned a non-list container environment")
    for entry in environment:
        if isinstance(entry, str) and entry.startswith("NVIDIA_VISIBLE_DEVICES="):
            return entry.partition("=")[2]
    return None


def _gpu_device_requests(container: dict[str, Any]) -> list[dict[str, Any]]:
    requests = _object_section(container, "HostConfig").get("DeviceRequests") or []
    if not isinstance(requests, list):
        raise ContractError("Docker inspect returned non-list device requests")
    result = []
    for request in requests:
        if not isinstance(request, dict):
            raise ContractError("Docker inspect returned a malformed device request")
        driver = str(request.get("Driver") or "").lower()
        capabilities = request.get("Capabilities") or []
        if not isinstance(capabilities, list):
            raise ContractError("Docker inspect returned malformed device capabilities")
        flattened = {
            str(capability).lower()
            for group in capabilities
            if isinstance(group, list)
            for capability in group
        }
        if driver == "nvidia" or "gpu" in flattened:
            device_ids = request.get("DeviceIDs")
            if device_ids is not None and not isinstance(device_ids, list):
                raise ContractError("Docker inspect returned malformed GPU device IDs")
            result.append(
                {
                    "driver": request.get("Driver"),
                    "count": request.get("Count"),
                    "device_ids": device_ids,
                    "capabilities": capabilities,
                }
            )
    return result


def _legacy_nvidia_devices(container: dict[str, Any]) -> list[dict[str, Any]]:
    devices = _object_section(container, "HostConfig").get("Devices") or []
    if not isinstance(devices, list):
        raise ContractError("Docker inspect returned a non-list device mapping")
    result = []
    for device in devices:
        if not isinstance(device, dict):
            raise ContractError("Docker inspect returned a malformed device mapping")
        host_path = str(device.get("PathOnHost") or "")
        container_path = str(device.get("PathInContainer") or "")
        if host_path.startswith("/dev/nvidia") or container_path.startswith("/dev/nvidia"):
            result.append(
                {
                    "path_on_host": host_path,
                    "path_in_container": container_path,
                }
            )
    return result


def _reservation_intersects(
    requests: list[dict[str, Any]],
    devices: list[dict[str, Any]],
    visible_devices: str | None,
    selected_indices: set[int] | None,
    selected_uuids: set[str] | None,
) -> bool:
    """Return whether a container can access one of the selected host GPUs.

    An omitted selection retains the old whole-host behavior for unit callers.
    Unknown/count-based reservations are treated conservatively as intersecting.
    """

    if selected_indices is None or selected_uuids is None:
        return bool(requests or devices or visible_devices)
    selected = {str(index) for index in selected_indices} | selected_uuids
    for request in requests:
        ids = request.get("device_ids")
        if ids:
            if selected.intersection(str(value) for value in ids):
                return True
            continue
        count = request.get("count")
        if isinstance(count, int) and count != 0:
            return True
    for device in devices:
        for key in ("path_on_host", "path_in_container"):
            name = Path(str(device.get(key) or "")).name
            if name.startswith("nvidia") and name.removeprefix("nvidia").isdigit():
                if int(name.removeprefix("nvidia")) in selected_indices:
                    return True
    if visible_devices is not None:
        value = visible_devices.strip()
        lowered = value.lower()
        if lowered in {"all", "*"}:
            return True
        if lowered not in {"", "none", "void"}:
            visible = {item.strip() for item in value.split(",") if item.strip()}
            if selected.intersection(visible):
                return True
    return False


def gpu_reserving_containers_from_inspect(
    containers: Any,
    selected_indices: set[int] | None = None,
    selected_uuids: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Return running containers retaining access to selected host GPUs."""

    if not isinstance(containers, list):
        raise ContractError("Docker inspect did not return a container list")
    result = []
    for container in containers:
        if not isinstance(container, dict):
            raise ContractError("Docker inspect returned a malformed container")
        state = _object_section(container, "State")
        if state.get("Running") is not True:
            continue
        host_config = _object_section(container, "HostConfig")
        config = _object_section(container, "Config")
        requests = _gpu_device_requests(container)
        devices = _legacy_nvidia_devices(container)
        runtime = str(host_config.get("Runtime") or "")
        visible_devices = _nvidia_visible_devices(container)
        legacy_visible = (
            runtime == "nvidia"
            and visible_devices is not None
            and visible_devices.strip().lower() not in {"", "none", "void"}
        )
        effective_visible = visible_devices if legacy_visible else None
        if not _reservation_intersects(
            requests,
            devices,
            effective_visible,
            selected_indices,
            selected_uuids,
        ):
            continue
        result.append(
            {
                "id": str(container.get("Id") or ""),
                "name": str(container.get("Name") or "").removeprefix("/"),
                "image": str(config.get("Image") or ""),
                "runtime": runtime,
                "device_requests": requests,
                "legacy_devices": devices,
                "nvidia_visible_devices": visible_devices,
            }
        )
    return result


def running_gpu_reserving_containers(
    selected_indices: set[int] | None = None,
    selected_uuids: set[str] | None = None,
) -> list[dict[str, Any]]:
    container_ids = run(["docker", "ps", "--quiet", "--no-trunc"])
    if not container_ids:
        return []
    encoded = run(
        ["docker", "container", "inspect", *container_ids.splitlines()],
        timeout=120,
    )
    try:
        containers = json.loads(encoded)
    except json.JSONDecodeError as exc:
        raise ContractError("cannot decode Docker container inventory") from exc
    return gpu_reserving_containers_from_inspect(
        containers,
        selected_indices=selected_indices,
        selected_uuids=selected_uuids,
    )


def memory_total_bytes() -> int:
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemTotal:"):
            return int(line.split()[1]) * 1024
    raise ContractError("cannot read MemTotal from /proc/meminfo")


def docker_info() -> dict[str, Any]:
    version = run(["docker", "version", "--format", "{{.Server.Version}}"])
    compose_version = run(["docker", "compose", "version", "--short"])
    raw = run(["docker", "info", "--format", "{{json .}}"])
    info = json.loads(raw)
    runtimes = info.get("Runtimes", {})
    if "nvidia" not in runtimes:
        raise ContractError("Docker daemon does not advertise the nvidia runtime")
    root = Path(info["DockerRootDir"])
    free = shutil.disk_usage(root).free
    if free < 100 * 1024**3:
        raise ContractError(f"Docker root has less than 100 GiB free: {root}")
    return {
        "server_version": version,
        "compose_version": compose_version,
        "root": str(root),
        "free_bytes": free,
        "nvidia_runtime": True,
    }


def probe_container_mount(source: Path, relative: Path, model: dict[str, Any]) -> None:
    model_in_container = Path("/opt/model-repo") / relative
    shard = str(model["first_shard_name"])
    probe_name = f".kvbench-write-probe-{os.getpid()}"
    probe_path = model_in_container / probe_name
    command = [
        "docker",
        "run",
        "--rm",
        "--network",
        "none",
        "--mount",
        f"type=bind,source={source},target=/opt/model-repo,readonly",
        "ubuntu:24.04@sha256:52df9b1ee71626e0088f7d400d5c6b5f7bb916f8f0c82b474289a4ece6cf3faf",
        "bash",
        "-ceu",
        (
            f"test -r {str(model_in_container / 'config.json')!r}; "
            f"test -r {str(model_in_container / shard)!r}; "
            f"if touch {str(probe_path)!r} 2>/dev/null; then exit 42; fi"
        ),
    ]
    try:
        subprocess.check_output(command, text=True, stderr=subprocess.STDOUT, timeout=60)
    except subprocess.CalledProcessError as exc:
        if exc.returncode == 42:
            (Path(model["model_path"]) / probe_name).unlink(missing_ok=True)
            raise ContractError("container model mount unexpectedly accepted a write") from exc
        raise ContractError(f"container mount probe failed: {exc.output}") from exc


def validate_build_parent(profile: dict[str, Any]) -> dict[str, str] | None:
    runtime = profile.get("runtime", {})
    reference = runtime.get("build_parent_image")
    expected_id = runtime.get("build_parent_image_id")
    if reference is None and expected_id is None:
        return None
    if not isinstance(reference, str) or not reference or not isinstance(expected_id, str):
        raise ContractError("build parent image reference/ID contract is incomplete")
    observed_id = run(["docker", "image", "inspect", "--format", "{{.Id}}", reference])
    if observed_id != expected_id:
        raise ContractError(f"build parent image changed: {observed_id!r} != {expected_id!r}")
    return {"reference": reference, "image_id": observed_id}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument(
        "--profile",
        type=Path,
        default=RUNTIME_DIR / "model-profile-qwen3.6-27b.json",
    )
    parser.add_argument(
        "--gpu-indices",
        help="comma-separated physical GPU indices; defaults to gpu_contract.host_indices or all GPUs",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--allow-busy-gpus", action="store_true")
    args = parser.parse_args()

    profile_path = args.profile.expanduser().resolve(strict=True)
    profile = load_profile(profile_path)
    mount_source, relative, resolved = resolve_mount(args.model_path, profile)
    model = validate_model(resolved, profile)
    full_inventory = gpu_inventory()
    if args.gpu_indices:
        try:
            requested_indices = [int(value) for value in args.gpu_indices.split(",") if value != ""]
        except ValueError as exc:
            raise ContractError(f"invalid --gpu-indices value: {args.gpu_indices!r}") from exc
    else:
        requested_indices = [
            int(value)
            for value in profile["gpu_contract"].get(
                "host_indices",
                [gpu["index"] for gpu in full_inventory],
            )
        ]
    gpus = select_gpus(full_inventory, requested_indices)
    validate_gpus(gpus, profile["gpu_contract"])
    selected_uuids = {str(gpu["uuid"]) for gpu in gpus}
    processes = active_gpu_processes(selected_uuids)
    docker = docker_info()
    gpu_containers = running_gpu_reserving_containers(
        selected_indices=set(requested_indices),
        selected_uuids=selected_uuids,
    )
    if not args.allow_busy_gpus:
        if processes:
            raise ContractError(f"GPUs already have compute processes: {processes}")
        if gpu_containers:
            raise ContractError(
                f"running Docker containers still reserve host GPUs: {gpu_containers}"
            )
    build_parent = validate_build_parent(profile)
    ram = memory_total_bytes()
    if ram < 512 * 1024**3:
        raise ContractError(f"host has less than 512 GiB RAM: {ram}")
    probe_container_mount(mount_source, relative, model)

    report = {
        "schema_version": 1,
        "status": "ok",
        "created_unix": time.time(),
        "task_dir": str(TASK_DIR),
        "model_profile_path": str(profile_path),
        "model_profile_sha256": sha256_file(profile_path),
        "model_mount_source": str(mount_source),
        "model_relative_path": str(relative),
        "model": model,
        "gpus": gpus,
        "active_gpu_processes": processes,
        "gpu_reserving_containers": gpu_containers,
        "docker": docker,
        "build_parent": build_parent,
        "host_memory_bytes": ram,
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", dir=args.output.parent, delete=False) as handle:
            handle.write(encoded)
            temporary = Path(handle.name)
        temporary.replace(args.output)
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ContractError, KeyError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}), file=sys.stderr)
        raise SystemExit(2) from exc
