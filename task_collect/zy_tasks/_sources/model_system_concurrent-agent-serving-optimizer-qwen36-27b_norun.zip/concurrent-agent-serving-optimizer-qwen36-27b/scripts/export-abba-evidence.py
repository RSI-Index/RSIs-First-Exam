#!/usr/bin/env python3
"""Sanitize trusted ABBA reports into publishable calibration evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


sys.path.insert(0, str(Path(__file__).resolve().parent))
from evidence_contract import (  # noqa: E402
    PRESSURE_QUALIFICATION_PATHS,
    validate_audited_oversubscribed_working_set,
    validate_finite_agent_execution_interval,
)


SELECTED_COUNTERS = {
    "vllm:generation_tokens_total",
    "vllm:num_preemptions_total",
    "vllm:prefix_cache_hits_total",
    "vllm:prefix_cache_queries_total",
    "vllm:prompt_tokens_total",
}
QWEN_PROFILE_ID = "qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2"
QWEN_REVISION = "6a9e13bd6fc8f0983b9b99948120bc37f49c13e9"
TASK_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_GATEWAY_TREE = TASK_ROOT / "solution" / "reference_gateway"


def reference_gateway_tree_sha256(root: Path = REFERENCE_GATEWAY_TREE) -> str:
    """Return the stable identity of the complete authored Oracle tree."""

    if root.is_symlink() or not root.is_dir():
        raise OSError(f"Oracle reference tree is not a real directory: {root}")
    records: list[bytes] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink():
            raise OSError(f"Oracle reference tree contains a symlink: {relative.as_posix()}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise OSError(f"Oracle reference tree contains a special file: {relative.as_posix()}")
        payload = path.read_bytes()
        record = {
            "path": relative.as_posix(),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "size": len(payload),
        }
        records.append(json.dumps(record, separators=(",", ":"), sort_keys=True).encode())
    if not records:
        raise OSError(f"Oracle reference tree has no authored files: {root}")
    digest = hashlib.sha256(b"reference-gateway-tree-v1\n")
    for record in records:
        digest.update(record)
        digest.update(b"\n")
    return digest.hexdigest()


def atomic_write_new(path: Path, rendered: str) -> None:
    path = path.expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink() or path.exists():
        raise SystemExit(f"refusing to overwrite evidence output: {path}")
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w") as stream:
            stream.write(rendered)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        try:
            os.link(temporary, path)
        except FileExistsError as exc:
            raise SystemExit(f"refusing to overwrite evidence output: {path}") from exc
    finally:
        temporary.unlink(missing_ok=True)


def selected_counters(leg: dict[str, Any]) -> dict[str, float]:
    return {
        sample["name"]: sample["delta"]
        for sample in leg["vllm_metrics"]["counter_deltas"]
        if sample["name"] in SELECTED_COUNTERS
        and sample.get("labels", "") in ("", 'engine="0",model_name="target-model"')
    }


def validate_pressure_qualification(leg: dict[str, Any], path: Path) -> None:
    config = leg.get("profile_config")
    pressure = leg.get("pressure_validation")
    if not isinstance(config, dict) or not isinstance(pressure, dict):
        raise SystemExit(f"ABBA leg is missing pressure qualification: {path}")
    expected_required = bool(
        config.get("pressure_required") is True and leg.get("mode") == "baseline"
    )
    contention = pressure.get("contention_evidence")
    if (
        pressure.get("qualification_schema_version") != 1
        or pressure.get("required") is not expected_required
        or pressure.get("valid") is not True
        or not isinstance(contention, dict)
        or contention.get("required") is not expected_required
        or contention.get("valid") is not True
    ):
        raise SystemExit(f"ABBA leg lacks current KV contention evidence: {path}")
    if not expected_required:
        return
    paths = contention.get("qualification_paths")
    if (
        not isinstance(paths, list)
        or not paths
        or not all(
            isinstance(item, str) and item in PRESSURE_QUALIFICATION_PATHS
            for item in paths
        )
    ):
        raise SystemExit(f"ABBA baseline has no safe KV qualification path: {path}")
    if (
        "audited_active_working_set" in paths
        and (contention.get("active_working_set") or {}).get("valid") is not True
    ):
        raise SystemExit(f"ABBA active-working-set evidence is invalid: {path}")
    if "audited_oversubscribed_working_set" in paths:
        try:
            validate_audited_oversubscribed_working_set(
                contention,
                f"ABBA baseline {path}",
            )
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    preemption = contention.get("preemption") or {}
    preemption_delta = preemption.get("preemptions_delta")
    if "vllm_preemption" in paths and not (
        preemption.get("valid") is True
        and isinstance(preemption_delta, (int, float))
        and not isinstance(preemption_delta, bool)
        and float(preemption_delta) > 0
    ):
        raise SystemExit(f"ABBA preemption evidence is invalid: {path}")


def sanitized(
    path: Path, *, expected_release_id: str, expected_profile_sha256: str
) -> dict[str, Any]:
    raw = path.read_bytes()
    report = json.loads(raw)
    provenance = report.get("model_provenance") or {}
    legs = report.get("legs")
    if (
        report.get("release_id") != expected_release_id
        or report.get("model_profile_sha256") != expected_profile_sha256
        or provenance.get("profile_id") != QWEN_PROFILE_ID
        or provenance.get("profile_sha256") != expected_profile_sha256
        or provenance.get("model_revision") != QWEN_REVISION
        or provenance.get("tensor_parallel_size") != 2
        or provenance.get("kv_cache_dtype") != "fp8"
        or not isinstance(provenance.get("runtime_boot_identity_sha256"), str)
        or re.fullmatch(
            r"[0-9a-f]{64}", provenance["runtime_boot_identity_sha256"]
        )
        is None
        or not isinstance(legs, list)
        or not legs
        or any(
            not isinstance(leg, dict) or leg.get("model_provenance") != provenance
            for leg in (legs or [])
        )
    ):
        raise SystemExit(f"ABBA input is not bound to the frozen Qwen runtime: {path}")
    for leg in legs:
        validate_pressure_qualification(leg, path)
        try:
            validate_finite_agent_execution_interval(
                leg,
                f"ABBA input {path}:{leg.get('run_id')}",
                require_live_samples=True,
            )
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    return {
        "raw_private_result": {
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
        },
        "summary": {key: value for key, value in report.items() if key != "legs"},
        "profile_config": report["legs"][0]["profile_config"],
        "corpus_fingerprint": report["legs"][0]["corpus_fingerprint"],
        "legs": [
            {
                "mode": leg["mode"],
                "run_id": leg["run_id"],
                "started_unix": leg["started_unix"],
                "ended_unix": leg["ended_unix"],
                "elapsed_sec": leg["elapsed_sec"],
                "wall_elapsed_sec": leg["wall_elapsed_sec"],
                "agent_execution_interval": leg["agent_execution_interval"],
                "measurement_window": leg["measurement_window"],
                "valid_steps": leg["valid_steps"],
                "valid_step_ratio": leg["valid_step_ratio"],
                "valid_steps_per_min": leg["valid_steps_per_min"],
                "request_success_rate": leg["request_success_rate"],
                "minimum_workflow_progress": leg["minimum_workflow_progress"],
                "backend_tokens_per_valid_step": leg["backend_tokens_per_valid_step"],
                "backend_audit": {
                    key: value for key, value in leg["backend_audit"].items() if key != "mismatches"
                },
                "warmup_audit": {
                    key: value for key, value in leg["warmup_audit"].items() if key != "mismatches"
                },
                "pressure_validation": leg["pressure_validation"],
                "selected_vllm_counter_deltas": selected_counters(leg),
            }
            for leg in report["legs"]
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--gateway-tree-sha256", required=True)
    parser.add_argument("--controller-image-id", required=True)
    parser.add_argument("--release-id", required=True)
    parser.add_argument("--model-profile-sha256", required=True)
    args = parser.parse_args()
    if not args.release_id or args.release_id.startswith("development"):
        raise SystemExit("--release-id must be a non-development release ID")
    if not re.fullmatch(r"[0-9a-f]{64}", args.model_profile_sha256):
        raise SystemExit("--model-profile-sha256 must be a lowercase SHA-256 digest")
    if not re.fullmatch(r"[0-9a-f]{64}", args.gateway_tree_sha256):
        raise SystemExit("--gateway-tree-sha256 must be a lowercase SHA-256 digest")
    try:
        expected_gateway_tree_sha256 = reference_gateway_tree_sha256()
    except OSError as exc:
        raise SystemExit(f"cannot hash frozen Oracle reference tree: {exc}") from exc
    if args.gateway_tree_sha256 != expected_gateway_tree_sha256:
        raise SystemExit(
            "--gateway-tree-sha256 does not identify the frozen Oracle reference tree"
        )
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", args.controller_image_id):
        raise SystemExit("--controller-image-id must be a Docker SHA-256 image ID")
    profiles = [
        sanitized(
            path,
            expected_release_id=args.release_id,
            expected_profile_sha256=args.model_profile_sha256,
        )
        for path in args.input
    ]
    if len({item["summary"]["profile"] for item in profiles}) != len(profiles):
        raise SystemExit("duplicate ABBA profile inputs")
    output = {
        "schema_version": 1,
        "kind": "hidden-profile-reference-abba-calibration",
        "release_id": args.release_id,
        "model_profile_sha256": args.model_profile_sha256,
        "status": "complete",
        "errors": [],
        "observed_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "reference_gateway_tree_sha256_at_run": args.gateway_tree_sha256,
        "bench_controller_image_id_at_run": args.controller_image_id,
        "all_profiles_passed": all(
            item["summary"]["all_audits_passed"]
            and item["summary"]["minimum_request_success_rate"] >= 0.98
            for item in profiles
        ),
        "profiles": profiles,
    }
    rendered = json.dumps(output, indent=2, sort_keys=True) + "\n"
    atomic_write_new(args.output, rendered)
    print(rendered, end="")
    return 0 if output["all_profiles_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
