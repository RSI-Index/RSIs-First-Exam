#!/usr/bin/env python3
"""Fast preflight for the frozen SWE-bench Lite manifest and local image IDs."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path


TASK_ROOT = Path(__file__).resolve().parents[1]
COMPACT_SELECTION = TASK_ROOT / "scripts" / "swebench-compact-selection.json"
DATASET = "princeton-nlp/SWE-Bench_Lite"
DATASET_REVISION = "6ec7bb89b9342f664a54a6e0a6ea6501d3437cc2"
PARQUET_SHA256 = "7a21f37b8bc179c7db5beeb14e88ac538ba283455c776e6b2535bbfb6e3551b4"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    manifest_bytes = args.manifest.read_bytes()
    manifest = json.loads(manifest_bytes)
    if manifest.get("schema_version") != 1:
        raise RuntimeError("unsupported corpus manifest schema")
    if manifest.get("dataset") != DATASET or manifest.get("dataset_revision") != DATASET_REVISION:
        raise RuntimeError("corpus dataset/revision does not match the task contract")
    if manifest.get("dataset_parquet_sha256") != PARQUET_SHA256:
        raise RuntimeError("corpus parquet digest does not match the task contract")
    corpus_mode = str(manifest.get("corpus_mode") or "full-300")
    if corpus_mode == "compact-repeated-rollouts":
        expected_instances = 12
        expected_partition_counts = {"public": 6, "hidden": 6}
    elif corpus_mode == "full-300":
        expected_instances = 300
        expected_partition_counts = {"public": 150, "hidden": 150}
    else:
        raise RuntimeError(f"unsupported corpus mode: {corpus_mode!r}")
    entries = manifest.get("instances")
    if not isinstance(entries, list) or len(entries) != expected_instances:
        raise RuntimeError(
            f"{corpus_mode} manifest must contain {expected_instances} SWE-bench Lite instances"
        )
    instance_ids = [entry.get("instance_id") for entry in entries]
    references = [entry.get("image_name") for entry in entries]
    if len(set(instance_ids)) != expected_instances or not all(
        isinstance(value, str) and value for value in instance_ids
    ):
        raise RuntimeError("corpus instance IDs are invalid or duplicated")
    if len(set(references)) != expected_instances or not all(
        isinstance(value, str) and value for value in references
    ):
        raise RuntimeError("corpus image references are invalid or duplicated")
    counts = {
        name: sum(entry.get("partition") == name for entry in entries)
        for name in ("public", "hidden")
    }
    if counts != expected_partition_counts:
        raise RuntimeError(f"corpus partitions are invalid: {counts}")
    policy = manifest.get("partition_policy")
    if not isinstance(policy, dict):
        raise RuntimeError("corpus partition policy is invalid")
    if corpus_mode == "compact-repeated-rollouts":
        if (
            manifest.get("source_instance_count") != 300
            or manifest.get("selected_instance_count") != 12
            or policy.get("algorithm") != "compact-six-repositories-per-partition"
            or policy.get("rollout_reuse") is not True
            or policy.get("fresh_sibling_container_per_rollout") is not True
        ):
            raise RuntimeError("compact corpus metadata or rollout policy is invalid")
        lock_digest = manifest.get("selection_lock_sha256")
        expected_lock_digest = hashlib.sha256(COMPACT_SELECTION.read_bytes()).hexdigest()
        if lock_digest != expected_lock_digest:
            raise RuntimeError("compact corpus selection lock digest is invalid")
        selection = json.loads(COMPACT_SELECTION.read_text())
        expected_partitions = {
            instance_id: partition
            for partition, instance_ids in selection["partitions"].items()
            for instance_id in instance_ids
        }
        observed_partitions = {
            str(entry.get("instance_id")): str(entry.get("partition")) for entry in entries
        }
        if observed_partitions != expected_partitions:
            raise RuntimeError("compact corpus does not match the pinned instance/partition selection")
    elif (
        policy.get("algorithm") != "stratified-repo-sha256-balanced"
        or policy.get("salt") != "harbor-kv-scheduler-swebench-lite-v2"
    ):
        raise RuntimeError("full corpus partition policy is invalid")
    by_repo: dict[str, Counter[str]] = {}
    for entry in entries:
        by_repo.setdefault(str(entry.get("repo")), Counter())[str(entry.get("partition"))] += 1
    if corpus_mode == "compact-repeated-rollouts":
        if len(by_repo) != 12 or any(sum(repo_counts.values()) != 1 for repo_counts in by_repo.values()):
            raise RuntimeError("compact corpus must contain one instance from each of 12 repositories")
    else:
        unbalanced = {
            repo: dict(repo_counts)
            for repo, repo_counts in by_repo.items()
            if abs(repo_counts["public"] - repo_counts["hidden"]) > 1
        }
        if unbalanced:
            raise RuntimeError(f"corpus repo strata are unbalanced: {unbalanced}")
    for entry in entries:
        for key in ("base_commit", "runtime_head_commit"):
            value = entry.get(key)
            if (
                not isinstance(value, str)
                or len(value) != 40
                or any(character not in "0123456789abcdef" for character in value.lower())
            ):
                raise RuntimeError(f"invalid {key}: {entry.get('instance_id')}")
        digest = entry.get("image_digest")
        if (
            not isinstance(digest, str)
            or not digest.startswith("sha256:")
            or len(digest) != 71
        ):
            raise RuntimeError(f"invalid image digest: {entry.get('instance_id')}")
        manifest_digest = entry.get("official_manifest_digest")
        if (
            not isinstance(manifest_digest, str)
            or not manifest_digest.startswith("sha256:")
            or len(manifest_digest) != 71
        ):
            raise RuntimeError(f"invalid official manifest digest: {entry.get('instance_id')}")

    inspected = subprocess.run(
        ["docker", "image", "inspect", "--format", "{{json .}}", *references],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=120,
        check=False,
    )
    if inspected.returncode != 0:
        raise RuntimeError(f"one or more staged images are unavailable:\n{inspected.stdout[-4000:]}")
    observed = [json.loads(line) for line in inspected.stdout.splitlines() if line.strip()]
    if len(observed) != len(entries):
        raise RuntimeError(f"Docker returned {len(observed)} images for {len(entries)} references")
    mismatches = [
        str(entry["instance_id"])
        for entry, image in zip(entries, observed, strict=True)
        if str(image.get("Id") or "").lower() != str(entry["image_digest"]).lower()
    ]
    if mismatches:
        raise RuntimeError(f"staged image IDs changed: {mismatches[:20]}")
    registry_mismatches = [
        str(entry["instance_id"])
        for entry, image in zip(entries, observed, strict=True)
        if not any(
            str(value).lower().endswith(f"@{str(entry['official_manifest_digest']).lower()}")
            for value in image.get("RepoDigests") or []
        )
    ]
    if registry_mismatches:
        raise RuntimeError(f"staged OCI digests changed: {registry_mismatches[:20]}")
    print(
        json.dumps(
            {
                "schema_version": 1,
                "kind": "staged-corpus-preflight",
                "passed": True,
                "corpus_mode": corpus_mode,
                "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                "instances": len(entries),
                "repositories": len(by_repo),
                "partition_counts": counts,
                "image_ids_matched": len(observed),
                "oci_digests_matched": len(observed),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
