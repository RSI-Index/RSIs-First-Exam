#!/usr/bin/env python3
"""Derive a provisional fixed KV budget from a natural-capacity sweep."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


GIB = 1024**3


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def percentile(values: Iterable[float], quantile: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("cannot calculate a percentile from no values")
    position = (len(ordered) - 1) * quantile
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    return ordered[low] * (high - position) + ordered[high] * (position - low)


def atomic_write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    with tempfile.NamedTemporaryFile(prefix=f".{path.name}.", dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def kv_samples(run: dict[str, Any]) -> list[float]:
    points = run.get("vllm_metrics", {}).get("live_samples")
    if not isinstance(points, list):
        raise ValueError("calibration run does not contain trusted live_samples")
    values = [
        float(point["kv_cache_usage"])
        for point in points
        if isinstance(point, dict) and isinstance(point.get("kv_cache_usage"), (int, float))
    ]
    if not values or any(not math.isfinite(value) or value < 0 for value in values):
        raise ValueError("calibration run contains no valid KV usage samples")
    return values


def projection(
    values: list[float],
    *,
    capacity_bytes: int,
    budget_bytes: int,
    pressure_threshold: float,
) -> dict[str, Any]:
    scaled = [value * capacity_bytes / budget_bytes for value in values]
    return {
        "sample_count": len(scaled),
        "kv_cache_usage_p50": percentile(scaled, 0.50),
        "kv_cache_usage_p95": percentile(scaled, 0.95),
        "kv_cache_usage_max": max(scaled),
        "pressure_threshold": pressure_threshold,
        "fraction_at_or_above_pressure_threshold": (
            sum(value >= pressure_threshold for value in scaled) / len(scaled)
        ),
        "fraction_above_capacity": sum(value > 1.0 for value in scaled) / len(scaled),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--target-profile", default="calibration-72")
    parser.add_argument("--available-kv-gib", type=float, required=True)
    parser.add_argument("--observed-token-capacity", type=int, required=True)
    parser.add_argument("--target-kv-p95", type=float, default=0.90)
    parser.add_argument("--single-request-safety-factor", type=float, default=1.10)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = args.input.expanduser().resolve(strict=True)
    output = args.output.expanduser().resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite KV decision evidence: {output}")
    if not 1.0 <= args.available_kv_gib <= 80.0:
        raise ValueError("--available-kv-gib must be in 1..80")
    if not 0.80 <= args.target_kv_p95 < 1.0:
        raise ValueError("--target-kv-p95 must be in [0.80, 1.0)")
    if args.observed_token_capacity <= 0:
        raise ValueError("--observed-token-capacity must be positive")
    if not 1.0 <= args.single_request_safety_factor <= 2.0:
        raise ValueError("--single-request-safety-factor must be in [1.0, 2.0]")

    sweep = json.loads(source.read_text())
    if sweep.get("kind") != "real-swe-baseline-calibration-sweep":
        raise ValueError("input is not a real-SWE baseline calibration sweep")
    if sweep.get("status") != "complete" or sweep.get("errors"):
        raise ValueError("input calibration sweep is not clean and complete")
    runs = sweep.get("runs")
    if not isinstance(runs, dict) or args.target_profile not in runs:
        raise ValueError(f"target profile is absent: {args.target_profile}")

    target_run = runs[args.target_profile]
    if target_run.get("backend_audit", {}).get("passed") is not True or float(
        target_run.get("request_success_rate", 0.0)
    ) < 1.0:
        raise ValueError("target run is not a clean 100%-success calibration leg")
    target_values = kv_samples(target_run)
    natural_p95 = percentile(target_values, 0.95)
    reported_p95 = target_run.get("vllm_metrics", {}).get("live_series", {}).get(
        "kv_cache_usage_p95"
    )
    if not isinstance(reported_p95, (int, float)) or not math.isclose(
        natural_p95, float(reported_p95), rel_tol=0, abs_tol=1e-12
    ):
        raise ValueError("raw samples do not reproduce the controller's reported KV p95")

    capacity_bytes = round(args.available_kv_gib * GIB)
    continuous_budget_bytes = capacity_bytes * natural_p95 / args.target_kv_p95
    budget_gib = math.floor(continuous_budget_bytes / GIB)
    if budget_gib < 1:
        raise ValueError("derived KV budget is below the runtime's 1 GiB safety floor")
    budget_bytes = budget_gib * GIB
    if budget_bytes >= capacity_bytes:
        raise ValueError("derived KV budget does not reduce natural capacity")
    total_token_max = (
        target_run.get("request_token_distribution", {}).get("total_tokens", {}).get("max")
    )
    if not isinstance(total_token_max, (int, float)):
        raise ValueError(
            "target run has no request token distribution; collect telemetry and use "
            "scripts/assess-kv-feasibility.py before deriving a probe"
        )
    safe_budget_bytes = math.ceil(
        (
            capacity_bytes
            * float(total_token_max)
            * args.single_request_safety_factor
            / args.observed_token_capacity
        )
        / GIB
    ) * GIB
    if budget_bytes < safe_budget_bytes:
        raise ValueError(
            f"pressure-derived budget is below the single-request safety bound: "
            f"{budget_bytes}<{safe_budget_bytes}; use scripts/assess-kv-feasibility.py"
        )

    projections = {}
    for profile, run in runs.items():
        config = run.get("profile_config", {})
        projections[profile] = projection(
            kv_samples(run),
            capacity_bytes=capacity_bytes,
            budget_bytes=budget_bytes,
            pressure_threshold=float(config.get("pressure_kv_threshold", 0.85)),
        )

    target_config = target_run.get("profile_config", {})
    evidence = {
        "schema_version": 1,
        "kind": "provisional-kv-budget-decision",
        "status": "probe_required",
        "created_at_utc": utc_now(),
        "source_sweep": str(source),
        "source_sweep_sha256": sha256(source),
        "source_model_profile_sha256": sweep.get("model_profile_sha256"),
        "source_controller_config_sha256": sweep.get("controller_readiness", {}).get(
            "controller_config_sha256"
        ),
        "target_profile": args.target_profile,
        "natural_capacity": {
            "bytes_per_gpu": capacity_bytes,
            "gib_per_gpu": args.available_kv_gib,
            "observed_token_capacity": args.observed_token_capacity,
            "source": "pinned vLLM startup log: Available KV cache memory",
        },
        "derivation": {
            "natural_kv_p95": natural_p95,
            "target_kv_p95": args.target_kv_p95,
            "continuous_budget_bytes": continuous_budget_bytes,
            "rounding": "floor to a whole GiB so the first probe reaches the pressure knee",
            "selected_budget_bytes_per_gpu": budget_bytes,
            "selected_budget_gib_per_gpu": budget_gib,
        },
        "projected_if_demand_is_unchanged": projections,
        "limitations": [
            "Projection rescales the natural trajectory and cannot model queueing or preemption feedback.",
            "The selected value is not a release setting until a fresh fixed-budget run passes every gate.",
        ],
        "probe_acceptance": {
            "profile": args.target_profile,
            "pressure_kv_p95_min": float(target_config.get("pressure_kv_p95_min", 0.8)),
            "pressure_time_fraction_min": float(
                target_config.get("pressure_time_fraction_min", 0.15)
            ),
            "pressure_threshold": float(target_config.get("pressure_kv_threshold", 0.8)),
            "min_request_success_rate": 0.98,
            "min_valid_step_ratio": 0.90,
            "backend_and_warmup_audits_must_pass": True,
        },
    }
    atomic_write(output, evidence)
    print(json.dumps(evidence, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
