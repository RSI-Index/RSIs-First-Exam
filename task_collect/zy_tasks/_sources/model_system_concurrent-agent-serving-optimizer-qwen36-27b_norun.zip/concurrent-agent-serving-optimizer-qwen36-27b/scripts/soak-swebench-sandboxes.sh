#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
STATE_ROOT="${HARBOR_KVBENCH_STATE_ROOT:-$HOME/.cache/harbor-kv-scheduler-v2}"
CORPUS_ROOT="${HARBOR_SWEBENCH_CORPUS_SOURCE:-$STATE_ROOT/swebench-lite}"
CONCURRENCY=72
PREPARE_CONCURRENCY=16
DURATION_SEC=1800
PROBE_INTERVAL_SEC=60
OUTPUT=""

while (($#)); do
  case "$1" in
    --concurrency) CONCURRENCY="${2:?--concurrency requires a value}"; shift 2 ;;
    --prepare-concurrency) PREPARE_CONCURRENCY="${2:?--prepare-concurrency requires a value}"; shift 2 ;;
    --duration-sec) DURATION_SEC="${2:?--duration-sec requires a value}"; shift 2 ;;
    --probe-interval-sec) PROBE_INTERVAL_SEC="${2:?--probe-interval-sec requires a value}"; shift 2 ;;
    --output) OUTPUT="${2:?--output requires a value}"; shift 2 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

if [[ ! "$CONCURRENCY" =~ ^[0-9]+$ ]] || ((CONCURRENCY < 1 || CONCURRENCY > 192)); then
  echo "--concurrency must be in 1..192" >&2
  exit 2
fi

if [[ -z "$OUTPUT" ]]; then
  OUTPUT="$TASK_DIR/calibration/sandbox-soak-${CONCURRENCY}-$(date -u +%Y%m%dT%H%M%SZ).json"
fi

# Docker interprets a relative source in ``-v source:target`` as a named
# volume. Resolve the evidence path before mounting so a caller can safely use
# the documented relative ``calibration/...json`` form.
OUTPUT="$(realpath -m -- "$OUTPUT")"

if ((PREPARE_CONCURRENCY > CONCURRENCY)); then
  PREPARE_CONCURRENCY="$CONCURRENCY"
fi

if ! docker info >/dev/null 2>&1; then
  if [[ "${KV_TASK_DOCKER_GROUP_REEXEC:-0}" == 1 ]]; then
    echo "Docker remains unavailable after entering the docker group" >&2
    exit 2
  fi
  printf -v reexec 'KV_TASK_DOCKER_GROUP_REEXEC=1 HARBOR_KVBENCH_STATE_ROOT=%q HARBOR_SWEBENCH_CORPUS_SOURCE=%q exec %q --concurrency %q --prepare-concurrency %q --duration-sec %q --probe-interval-sec %q --output %q' \
    "$STATE_ROOT" "$CORPUS_ROOT" "$0" "$CONCURRENCY" "$PREPARE_CONCURRENCY" "$DURATION_SEC" "$PROBE_INTERVAL_SEC" "$OUTPUT"
  exec sg docker -c "$reexec"
fi

[[ -f "$CORPUS_ROOT/manifest.json" ]] || { echo "missing corpus manifest: $CORPUS_ROOT/manifest.json" >&2; exit 4; }
mkdir -p "$(dirname -- "$OUTPUT")"

worker_name="kvbench-sandbox-soak-$$"
run_owner="soak-$$"
control_dir="$(mktemp -d -t kvbench-soak-control.XXXXXX)"
workspace_dir="$(mktemp -d -t kvbench-soak-workspaces.XXXXXX)"
cleanup() {
  original_status=$?
  trap - EXIT
  # Give worker.py's signal handler time to remove every runtime it still
  # owns.  A force-only removal would skip cleanup_all_runtimes() precisely on
  # the failure path where that fallback is needed most.
  docker stop --time 180 "$worker_name" >/dev/null 2>&1 || true
  # If the worker exhausted its own bounded Docker cleanup retries, remove
  # only children carrying this invocation's scoped author-side owner label.
  # Never sweep the global managed label: another trusted worker could
  # legitimately own those containers.
  owned_ids=()
  if ! owned_output="$(docker ps -aq --no-trunc \
    --filter "label=org.harbor-kv-scheduler.swe-sandbox.owner=$run_owner")"; then
    echo "could not enumerate run-owned SWE sandboxes during cleanup" >&2
    original_status=5
  elif [[ -n "$owned_output" ]]; then
    mapfile -t owned_ids <<<"$owned_output"
  fi
  validated_ids=()
  for container_id in "${owned_ids[@]}"; do
    if [[ "$container_id" =~ ^[0-9a-f]{64}$ ]]; then
      validated_ids+=("$container_id")
    else
      echo "refusing malformed owned sandbox ID during cleanup: $container_id" >&2
      original_status=5
    fi
  done
  if ((${#validated_ids[@]})); then
    docker rm -f "${validated_ids[@]}" >/dev/null 2>&1 || original_status=5
  fi
  if ! remaining_owned="$(docker ps -aq \
    --filter "label=org.harbor-kv-scheduler.swe-sandbox.owner=$run_owner")"; then
    echo "could not verify run-owned SWE sandbox cleanup" >&2
    original_status=5
  elif [[ -n "$remaining_owned" ]]; then
    echo "run-owned SWE sandboxes remain after fallback cleanup" >&2
    original_status=5
  fi
  docker rm -f "$worker_name" >/dev/null 2>&1 || true
  rm -rf -- "$control_dir" "$workspace_dir"
  exit "$original_status"
}
trap cleanup EXIT

docker build -t harbor-kv/sandbox-worker:swebench-soak "$TASK_DIR/environment/sandbox-worker" >/dev/null
docker run -d \
  --name "$worker_name" \
  --env "SANDBOX_OWNER=$run_owner" \
  --network none \
  --read-only \
  --cap-add ALL \
  --security-opt seccomp=unconfined \
  --security-opt apparmor=unconfined \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v "$control_dir:/run/kvbench-sandbox" \
  -v "$workspace_dir:/run/kvbench-workspaces" \
  -v "$CORPUS_ROOT:/opt/kvbench-corpus:ro" \
  -v "$SCRIPT_DIR:/opt/kvbench-soak:ro" \
  -v "$(dirname -- "$OUTPUT"):/opt/kvbench-evidence" \
  harbor-kv/sandbox-worker:swebench-soak >/dev/null

for _ in $(seq 1 100); do
  if docker exec "$worker_name" test -S /run/kvbench-sandbox/control.sock; then
    break
  fi
  sleep 0.1
done
docker exec "$worker_name" test -S /run/kvbench-sandbox/control.sock

container_output="/opt/kvbench-evidence/$(basename -- "$OUTPUT")"
docker exec "$worker_name" python3 /opt/kvbench-soak/soak-swebench-sandboxes.py \
  --manifest /opt/kvbench-corpus/manifest.json \
  --output "$container_output" \
  --concurrency "$CONCURRENCY" \
  --prepare-concurrency "$PREPARE_CONCURRENCY" \
  --duration-sec "$DURATION_SEC" \
  --probe-interval-sec "$PROBE_INTERVAL_SEC"

test -f "$OUTPUT"
test -z "$(docker ps -aq --filter "label=org.harbor-kv-scheduler.swe-sandbox=true")"
echo "Soak evidence: $OUTPUT"
