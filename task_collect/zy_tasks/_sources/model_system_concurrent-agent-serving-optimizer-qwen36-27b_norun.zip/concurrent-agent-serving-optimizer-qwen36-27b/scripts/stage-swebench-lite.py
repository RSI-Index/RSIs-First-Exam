#!/usr/bin/env python3
"""Stage the pinned SWE-bench Lite corpus and immutable official images."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any

TASK_ROOT = Path(__file__).resolve().parents[1]
DATASET = "princeton-nlp/SWE-Bench_Lite"
DATASET_REVISION = "6ec7bb89b9342f664a54a6e0a6ea6501d3437cc2"
PARQUET_PATH = "data/test-00000-of-00001.parquet"
PARQUET_SHA256 = "7a21f37b8bc179c7db5beeb14e88ac538ba283455c776e6b2535bbfb6e3551b4"
PARTITION_SALT = "harbor-kv-scheduler-swebench-lite-v2"
EXPECTED_INSTANCES = 300
COMPACT_SELECTION = TASK_ROOT / "scripts" / "swebench-compact-selection.json"
DOCKER_HUB_RATE_LIMITED = threading.Event()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def command(*argv: str, timeout: int | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        argv,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )


def require_docker() -> dict[str, str]:
    info = command("docker", "info", "--format", "{{json .}}", timeout=30)
    if info.returncode != 0:
        raise RuntimeError(f"Docker is unavailable:\n{info.stdout[-2000:]}")
    raw = json.loads(info.stdout)
    if not isinstance(raw, dict):
        raise RuntimeError("Docker info returned an invalid payload")
    return {
        "server_version": str(raw.get("ServerVersion") or ""),
        "docker_root_dir": str(raw.get("DockerRootDir") or ""),
        "architecture": str(raw.get("Architecture") or ""),
        "operating_system": str(raw.get("OperatingSystem") or ""),
    }


def ensure_parquet(output_root: Path, source: Path | None) -> Path:
    if source is not None:
        path = source.expanduser().resolve(strict=True)
    else:
        dataset_dir = output_root / "dataset"
        dataset_dir.mkdir(parents=True, exist_ok=True)
        path = dataset_dir / "test-00000-of-00001.parquet"
        if not path.exists():
            url = (
                "https://huggingface.co/datasets/princeton-nlp/SWE-Bench_Lite/resolve/"
                f"{DATASET_REVISION}/{PARQUET_PATH}"
            )
            with tempfile.NamedTemporaryFile(prefix="swebench-lite-", dir=dataset_dir, delete=False) as stream:
                temporary = Path(stream.name)
            try:
                request = urllib.request.Request(url, headers={"User-Agent": "harbor-kv-scheduler-stage/2"})
                with urllib.request.urlopen(request, timeout=120) as response, temporary.open("wb") as stream:
                    while chunk := response.read(1024 * 1024):
                        stream.write(chunk)
                    stream.flush()
                    os.fsync(stream.fileno())
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
    observed = sha256_file(path)
    if observed != PARQUET_SHA256:
        raise RuntimeError(f"dataset parquet digest mismatch: expected {PARQUET_SHA256}, got {observed}")
    return path


def load_instances(path: Path) -> list[dict[str, Any]]:
    import pyarrow.parquet as parquet

    required = {"repo", "instance_id", "base_commit", "problem_statement"}
    table = parquet.read_table(path, columns=sorted(required))
    if table.num_rows != EXPECTED_INSTANCES:
        raise RuntimeError(f"expected {EXPECTED_INSTANCES} SWE-bench Lite instances, got {table.num_rows}")
    if not required.issubset(table.column_names):
        raise RuntimeError(f"dataset columns are missing: {sorted(required - set(table.column_names))}")
    instances = table.to_pylist()
    ids = [str(instance["instance_id"]) for instance in instances]
    if len(set(ids)) != EXPECTED_INSTANCES:
        raise RuntimeError("SWE-bench Lite instance IDs are not unique")
    for instance in instances:
        if not all(isinstance(instance.get(key), str) and instance[key].strip() for key in required):
            raise RuntimeError(f"invalid dataset row: {instance.get('instance_id')!r}")
        base_commit = instance["base_commit"].lower()
        if len(base_commit) != 40 or any(character not in "0123456789abcdef" for character in base_commit):
            raise RuntimeError(f"invalid base commit: {instance['instance_id']}")
    return instances


def load_compact_selection(
    path: Path,
    instances: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, str], dict[str, Any]]:
    selection = json.loads(path.read_text())
    if (
        selection.get("schema_version") != 1
        or selection.get("dataset") != DATASET
        or selection.get("dataset_revision") != DATASET_REVISION
        or selection.get("source_instance_count") != EXPECTED_INSTANCES
    ):
        raise RuntimeError("compact selection lock does not match the pinned dataset")
    raw_partitions = selection.get("partitions")
    if not isinstance(raw_partitions, dict) or set(raw_partitions) != {"public", "hidden"}:
        raise RuntimeError("compact selection lock must contain public and hidden partitions")
    partitions: dict[str, str] = {}
    for partition in ("public", "hidden"):
        instance_ids = raw_partitions.get(partition)
        if not isinstance(instance_ids, list) or len(instance_ids) != 6:
            raise RuntimeError(f"compact {partition} partition must contain six instances")
        for instance_id in instance_ids:
            if not isinstance(instance_id, str) or not instance_id or instance_id in partitions:
                raise RuntimeError(f"invalid or duplicated compact instance: {instance_id!r}")
            partitions[instance_id] = partition
    by_id = {str(instance["instance_id"]): instance for instance in instances}
    missing = sorted(set(partitions) - set(by_id))
    if missing:
        raise RuntimeError(f"compact selection is absent from the dataset: {missing}")
    selected = [by_id[instance_id] for instance_id in sorted(partitions)]
    repositories = {str(instance["repo"]) for instance in selected}
    if len(selected) != 12 or len(repositories) != 12:
        raise RuntimeError("compact selection must contain one instance from each repository")
    return selected, partitions, selection


def image_name(instance_id: str) -> str:
    compatible = instance_id.replace("__", "_1776_")
    return f"docker.io/swebench/sweb.eval.x86_64.{compatible}:latest".lower()


def image_repository(reference: str) -> str:
    value = reference.removeprefix("docker.io/")
    return value.rsplit(":", 1)[0]


def official_manifest_digest(reference: str) -> str:
    repository = image_repository(reference)
    url = f"https://hub.docker.com/v2/repositories/{repository}/tags/latest"
    request = urllib.request.Request(url, headers={"User-Agent": "harbor-kv-scheduler-stage/2"})
    last_error: Exception | None = None
    for attempt in range(5):
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.load(response)
            digest = str(payload.get("digest") or "").lower()
            if not digest.startswith("sha256:") or len(digest) != 71:
                raise RuntimeError(f"Docker Hub returned an invalid manifest digest for {reference}")
            architectures = {
                str(image.get("architecture"))
                for image in payload.get("images", [])
                if isinstance(image, dict)
            }
            if "amd64" not in architectures:
                raise RuntimeError(f"Docker Hub tag has no amd64 image: {reference}")
            return digest
        except Exception as exc:
            last_error = exc
            if attempt < 4:
                time.sleep(2**attempt)
    raise RuntimeError(f"Docker Hub tag metadata failed for {reference}: {last_error}")


def partition_map(instances: list[dict[str, Any]]) -> dict[str, str]:
    by_repo: dict[str, list[str]] = defaultdict(list)
    for instance in instances:
        by_repo[str(instance["repo"])].append(str(instance["instance_id"]))
    floor_total = sum(len(instance_ids) // 2 for instance_ids in by_repo.values())
    public_odd_repos = set(
        sorted(
            (repo for repo, instance_ids in by_repo.items() if len(instance_ids) % 2),
            key=lambda repo: hashlib.sha256(f"{PARTITION_SALT}:odd:{repo}".encode()).hexdigest(),
        )[: EXPECTED_INSTANCES // 2 - floor_total]
    )
    partitions: dict[str, str] = {}
    for repo, instance_ids in sorted(by_repo.items()):
        ordered = sorted(
            instance_ids,
            key=lambda instance_id: hashlib.sha256(
                f"{PARTITION_SALT}:{repo}:{instance_id}".encode()
            ).hexdigest(),
        )
        public_count = len(ordered) // 2 + int(repo in public_odd_repos)
        public = set(ordered[:public_count])
        partitions.update(
            {instance_id: ("public" if instance_id in public else "hidden") for instance_id in ordered}
        )
    return partitions


def inspect_image(reference: str) -> dict[str, Any]:
    inspected = command("docker", "image", "inspect", reference, timeout=30)
    if inspected.returncode != 0:
        raise RuntimeError(f"image inspect failed for {reference}:\n{inspected.stdout[-2000:]}")
    payload = json.loads(inspected.stdout)
    if not isinstance(payload, list) or len(payload) != 1:
        raise RuntimeError(f"image inspect returned an invalid payload for {reference}")
    image = payload[0]
    image_id = str(image.get("Id") or "").lower()
    if not image_id.startswith("sha256:") or len(image_id) != 71:
        raise RuntimeError(f"image has an invalid local ID: {reference}")
    repo_digests = image.get("RepoDigests") or []
    if not isinstance(repo_digests, list) or not repo_digests:
        raise RuntimeError(f"image has no registry digest: {reference}")
    return {
        "image_digest": image_id,
        "image_repo_digests": sorted(str(item) for item in repo_digests),
        "image_size_bytes": int(image.get("Size") or 0),
    }


def image_has_manifest_digest(reference: str, manifest_digest: str) -> bool:
    try:
        details = inspect_image(reference)
    except RuntimeError:
        return False
    suffix = f"@{manifest_digest}"
    return any(value.endswith(suffix) for value in details["image_repo_digests"])


def pull_locked_image(reference: str, manifest_digest: str, mirror: str | None) -> None:
    repository = image_repository(reference)
    primary = f"docker.io/{repository}@{manifest_digest}"
    pulled_reference = primary
    primary_output = ""
    if not DOCKER_HUB_RATE_LIMITED.is_set():
        pulled = command("docker", "pull", primary, timeout=3600)
        primary_output = pulled.stdout
        if pulled.returncode == 0:
            tagged = command("docker", "tag", primary, reference, timeout=30)
            if tagged.returncode != 0:
                raise RuntimeError(f"image tag failed for {reference}:\n{tagged.stdout[-2000:]}")
            return
        if "toomanyrequests" in pulled.stdout.lower() or "rate limit" in pulled.stdout.lower():
            DOCKER_HUB_RATE_LIMITED.set()
        elif not mirror:
            raise RuntimeError(f"image pull failed for {reference}:\n{pulled.stdout[-4000:]}")
    if not mirror:
        raise RuntimeError(f"Docker Hub rate-limited image pull for {reference}:\n{primary_output[-4000:]}")

    pulled_reference = f"{mirror.rstrip('/')}/{repository}@{manifest_digest}"
    last_output = ""
    for attempt in range(3):
        pulled = command("docker", "pull", pulled_reference, timeout=3600)
        last_output = pulled.stdout
        if pulled.returncode == 0:
            tagged = command("docker", "tag", pulled_reference, reference, timeout=30)
            if tagged.returncode != 0:
                raise RuntimeError(f"image tag failed for {reference}:\n{tagged.stdout[-2000:]}")
            return
        if attempt < 2:
            time.sleep(2 ** (attempt + 1))
    raise RuntimeError(
        f"digest-locked mirror pull failed for {reference} via {pulled_reference}:\n{last_output[-4000:]}"
    )


def validate_image(reference: str, image_id: str, base_commit: str) -> str:
    script = (
        "set -eu; cd /testbed; test -d .git; "
        f"git merge-base --is-ancestor {base_commit} HEAD; "
        "git reset --hard HEAD >/dev/null; git clean -fd >/dev/null; "
        "test -z \"$(git status --porcelain=v1)\"; "
        "command -v bash >/dev/null; command -v timeout >/dev/null; git rev-parse HEAD"
    )
    checked = command(
        "docker",
        "run",
        "--rm",
        "--network",
        "none",
        "--cap-drop",
        "ALL",
        "--security-opt",
        "no-new-privileges:true",
        "--entrypoint",
        "/bin/bash",
        image_id,
        "-lc",
        script,
        timeout=120,
    )
    if checked.returncode != 0:
        raise RuntimeError(f"offline image validation failed for {reference}:\n{checked.stdout[-4000:]}")
    runtime_head = checked.stdout.strip().splitlines()[-1].lower() if checked.stdout.strip() else ""
    if len(runtime_head) != 40 or any(character not in "0123456789abcdef" for character in runtime_head):
        raise RuntimeError(f"image returned an invalid runtime HEAD for {reference}: {runtime_head!r}")
    return runtime_head


def stage_one(
    instance: dict[str, Any],
    *,
    pull: bool,
    mirror: str | None = None,
    manifest_digest: str | None = None,
) -> dict[str, Any]:
    instance_id = str(instance["instance_id"])
    reference = image_name(instance_id)
    manifest_digest = manifest_digest or official_manifest_digest(reference)
    if pull:
        pull_locked_image(reference, manifest_digest, mirror)
    details = inspect_image(reference)
    if not any(
        value.endswith(f"@{manifest_digest}")
        for value in details["image_repo_digests"]
    ):
        raise RuntimeError(f"local image is not backed by the official manifest digest: {reference}")
    runtime_head = validate_image(reference, details["image_digest"], str(instance["base_commit"]).lower())
    return {
        "instance_id": instance_id,
        "repo": str(instance["repo"]),
        "base_commit": str(instance["base_commit"]).lower(),
        "problem_statement": str(instance["problem_statement"]),
        "image_name": reference,
        "runtime_head_commit": runtime_head,
        "official_manifest_digest": manifest_digest,
        **details,
        "test_command": "run the narrowest relevant existing offline repository test",
        "verification_command": "git diff --check && test -n \"$(git status --porcelain=v1)\"",
    }


def stage_one_resumable(
    instance: dict[str, Any],
    *,
    resume: bool,
    mirror: str | None,
) -> dict[str, Any]:
    reference = image_name(str(instance["instance_id"]))
    manifest_digest = official_manifest_digest(reference)
    reusable = resume and image_has_manifest_digest(reference, manifest_digest)
    return stage_one(
        instance,
        pull=not reusable,
        mirror=mirror,
        manifest_digest=manifest_digest,
    )


def verify_existing_manifest(
    output_root: Path,
    instances: list[dict[str, Any]],
    partitions: dict[str, str],
    corpus_mode: str,
) -> dict[str, Any]:
    manifest_path = output_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if (
        manifest.get("schema_version") != 1
        or manifest.get("dataset") != DATASET
        or manifest.get("dataset_revision") != DATASET_REVISION
        or manifest.get("dataset_parquet_sha256") != PARQUET_SHA256
    ):
        raise RuntimeError("existing corpus manifest does not match the pinned dataset")
    entries = manifest.get("instances")
    if not isinstance(entries, list) or len(entries) != len(instances):
        raise RuntimeError("existing corpus manifest is incomplete")
    expected_ids = {str(instance["instance_id"]) for instance in instances}
    if {entry.get("instance_id") for entry in entries} != expected_ids:
        raise RuntimeError("existing corpus manifest instance set is incorrect")
    observed_mode = str(manifest.get("corpus_mode") or "full-300")
    if observed_mode != corpus_mode:
        raise RuntimeError(
            f"existing corpus mode is {observed_mode!r}, expected {corpus_mode!r}; "
            "use --refresh only if replacing it is intentional"
        )
    for index, entry in enumerate(entries, start=1):
        if entry.get("partition") != partitions[str(entry["instance_id"])]:
            raise RuntimeError(f"staged partition changed: {entry.get('instance_id')}")
        details = inspect_image(str(entry["image_name"]))
        if details["image_digest"] != entry.get("image_digest"):
            raise RuntimeError(f"staged image ID changed: {entry.get('instance_id')}")
        manifest_digest = str(entry.get("official_manifest_digest") or "")
        if not manifest_digest.startswith("sha256:") or len(manifest_digest) != 71:
            raise RuntimeError(f"official manifest digest is invalid: {entry.get('instance_id')}")
        if not any(
            value.endswith(f"@{manifest_digest}")
            for value in details["image_repo_digests"]
        ):
            raise RuntimeError(f"official manifest digest is absent locally: {entry.get('instance_id')}")
        runtime_head = validate_image(str(entry["image_name"]), details["image_digest"], str(entry["base_commit"]))
        if runtime_head != entry.get("runtime_head_commit"):
            raise RuntimeError(f"staged runtime HEAD changed: {entry.get('instance_id')}")
        print(f"[{index}/{len(entries)}] VERIFIED {entry['instance_id']}", flush=True)
    return manifest


def write_manifest(output_root: Path, payload: dict[str, Any]) -> Path:
    manifest_path = output_root / "manifest.json"
    encoded = (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    with tempfile.NamedTemporaryFile(prefix="manifest-", suffix=".json", dir=output_root, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.chmod(0o444)
    temporary.replace(manifest_path)
    return manifest_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("~/.cache/harbor-kv-scheduler-v2/swebench-lite").expanduser(),
    )
    parser.add_argument("--parquet", type=Path)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="repull official tags and replace an existing manifest; otherwise an existing manifest is verified",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="reuse already-pulled local tags after an interrupted initial stage and pull only missing images",
    )
    parser.add_argument(
        "--registry-mirror",
        help="optional OCI registry host used only with the Docker-Hub-provided manifest digest",
    )
    parser.add_argument(
        "--full-corpus",
        action="store_true",
        help="explicitly stage all 300 images; default is the pinned 12-image compact corpus",
    )
    parser.add_argument(
        "--compact-selection",
        type=Path,
        default=COMPACT_SELECTION,
        help="pinned 12-image selection used unless --full-corpus is supplied",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.workers <= 16:
        raise ValueError("--workers must be in 1..16")
    output_root = args.output_root.expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True, mode=0o755)
    docker_info = require_docker()
    parquet_path = ensure_parquet(output_root, args.parquet)
    all_instances = load_instances(parquet_path)
    selection: dict[str, Any] | None = None
    if args.full_corpus:
        instances = all_instances
        partitions = partition_map(instances)
        corpus_mode = "full-300"
    else:
        instances, partitions, selection = load_compact_selection(
            args.compact_selection.expanduser().resolve(strict=True),
            all_instances,
        )
        corpus_mode = "compact-repeated-rollouts"
    manifest_path = output_root / "manifest.json"
    if manifest_path.exists() and not args.refresh:
        manifest = verify_existing_manifest(output_root, instances, partitions, corpus_mode)
        print(
            json.dumps(
                {
                    "status": "verified",
                    "manifest": str(manifest_path),
                    "instances": len(manifest["instances"]),
                    "corpus_mode": corpus_mode,
                    "manifest_sha256": sha256_file(manifest_path),
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0

    started = time.time()
    entries: list[dict[str, Any]] = []
    failures: list[str] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(
                stage_one_resumable,
                instance,
                resume=args.resume,
                mirror=args.registry_mirror,
            ): instance
            for instance in instances
        }
        for index, future in enumerate(concurrent.futures.as_completed(futures), start=1):
            instance = futures[future]
            try:
                entry = future.result()
                entry["partition"] = partitions[entry["instance_id"]]
                entries.append(entry)
                print(f"[{index}/{len(instances)}] READY {entry['instance_id']}", flush=True)
            except Exception as exc:
                instance_id = str(instance.get("instance_id"))
                failures.append(f"{instance_id}: {type(exc).__name__}: {exc}")
                print(f"[{index}/{len(instances)}] FAILED {instance_id}: {exc}", file=sys.stderr, flush=True)
    if failures:
        raise RuntimeError(f"{len(failures)} SWE-bench images failed staging:\n" + "\n".join(failures))

    entries.sort(key=lambda entry: entry["instance_id"])
    partition_counts = {
        name: sum(entry["partition"] == name for entry in entries)
        for name in ("public", "hidden")
    }
    expected_partition_count = len(entries) // 2
    if partition_counts != {
        "public": expected_partition_count,
        "hidden": expected_partition_count,
    }:
        raise RuntimeError(f"unexpected partition counts: {partition_counts}")
    if corpus_mode == "compact-repeated-rollouts":
        partition_policy = {
            "algorithm": "compact-six-repositories-per-partition",
            "public_instances": expected_partition_count,
            "hidden_instances": expected_partition_count,
            "calibration_partition": "public",
            "rollout_reuse": True,
            "fresh_sibling_container_per_rollout": True,
        }
    else:
        partition_policy = {
            "algorithm": "stratified-repo-sha256-balanced",
            "salt": PARTITION_SALT,
            "public_instances": expected_partition_count,
            "hidden_instances": expected_partition_count,
            "calibration_partition": "public",
            "repo_balance_max_delta": 1,
        }
    manifest = {
        "schema_version": 1,
        "corpus_mode": corpus_mode,
        "dataset": DATASET,
        "dataset_revision": DATASET_REVISION,
        "dataset_split": "test",
        "dataset_parquet_path": PARQUET_PATH,
        "dataset_parquet_sha256": PARQUET_SHA256,
        "source_instance_count": EXPECTED_INSTANCES,
        "selected_instance_count": len(entries),
        "partition_policy": partition_policy,
        "docker_host": docker_info,
        "image_transport": {
            "authority": "hub.docker.com/v2 tag metadata over TLS",
            "primary_registry": "docker.io",
            "digest_locked_fallback_registry": args.registry_mirror,
        },
        "staging_elapsed_sec": time.time() - started,
        "instances": entries,
    }
    if selection is not None:
        manifest["selection_policy"] = selection["selection_policy"]
        manifest["selection_lock_sha256"] = sha256_file(
            args.compact_selection.expanduser().resolve(strict=True)
        )
    written = write_manifest(output_root, manifest)
    print(
        json.dumps(
            {
                "status": "staged",
                "manifest": str(written),
                "instances": len(entries),
                "corpus_mode": corpus_mode,
                "partition_counts": partition_counts,
                "manifest_sha256": sha256_file(written),
                "elapsed_sec": manifest["staging_elapsed_sec"],
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
