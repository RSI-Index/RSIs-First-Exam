#!/usr/bin/env bash
set -euo pipefail

rm -rf /app/submission
install -d -m 0755 /app/submission
install -m 0644 \
  /solution/reference_gateway/gateway.py \
  /solution/reference_gateway/scheduler.py \
  /solution/reference_gateway/THIRD_PARTY_LICENSE.md \
  /app/submission/
install -m 0755 /solution/reference_gateway/launch.sh /app/submission/launch.sh
