# Qwen3.6-27B release evidence

This is the only release-evidence directory accepted by the Qwen release
freezer. Historical development JSON files elsewhere under `calibration/` are
ignored.

Historical workload exploration remains outside `evidence-index.json`. The
frozen policy uses reference `1.195`, gateway hard/soft tail bounds `720/420`,
a single-pair step-latency ratio of `1.25`, and one shared 9,000-second hidden
suite deadline. The 30-minute release migration started on 2026-07-21; only a
newly measured public30 Oracle full-verifier artifact in this directory is
eligible for the release index. Former public10 evidence is preserved under
`calibration/archive/qwen36-public10-v5-r2-release/` and is ineligible here.

This task deliberately uses a **single-run research release** policy. It is not
a publication-grade repeated-measurement claim. The release freezer requires
zero final Direct sweep series, zero frozen-candidate reports, and one complete
Oracle full-verifier report. That report must retain the nonce-committed hidden
AB or BA order, one independent Candidate epoch, all pressure/audit/quality
gates, and the exact frozen Oracle submission.

The hidden `reference_speedup` cannot be chosen from the eventual final report.
It was derived conservatively from exploratory hidden ABBA measurements while
`release_ready:false`, then frozen together with the workload and scoring
contract before the final controller is built. The exploratory geometric-mean
speedup was 1.223906; a worst-cross-leg/CV penalty and downward 0.005
quantization produced the frozen 1.195 reference.

Collect that private pre-freeze diagnostic outside this task tree with:

```bash
sg docker -c 'python3 scripts/run-exploratory-hidden-abba.py \
  --profile hidden-pressure-192 \
  --output /tmp/qwen36-private-exploratory-hidden-abba.json'
```

The runner records `release_evidence_eligible:false`; do not list its output in
`evidence-index.json`. Review its two Direct/two Oracle rates, baseline and
candidate CV, geometric-mean speedup, audit/pressure/quality gates, reset
boundaries, and fresh B-process identities only to choose the later frozen
reference conservatively.

The completed release sequence was:

1. finish the continuation/container/isolation regressions while the policy
   remained closed;
2. flip only `release_ready`, rebuild the final controller, and collect a
   fixed-1800 public Direct/Oracle calibration, its private reusable Direct
   anchor, and one complete two-leg Oracle full-verifier report on that exact
   controller image;
3. list only the reviewed sanitized JSON basename in `evidence-index.json`, bound
   to the exact Qwen model-profile digest and final controller;
4. generate `calibration/release-manifest.json`, pass pre-author currentness,
   then enable and strictly verify the real-agent trial gate.

The public30 Direct/Oracle rates and matching formal hidden result are filled
from the fresh release artifacts after both measurements complete. Old
public10 numbers are not carried forward as public30 qualification.

The eventual index has this structure, with values filled only from the
sanitized evidence that jointly binds both raw measurements:

```json
{
  "schema_version": 1,
  "release_id": "<frozen-non-development-release-id>",
  "model_profile_sha256": "<exact-final-qwen-profile-sha256>",
  "files": [
    "<reviewed-final-oracle-full-verifier-evidence>.json"
  ]
}
```

The freezer rejects an empty index, development release IDs, symlinks, path
traversal, unindexed JSON, model/profile drift, profile-order drift, controller
drift, a hidden order inconsistent with its nonce commitment, anchor drift,
Oracle identity/performance drift, and a missing final Oracle report.
Standalone `export-abba-evidence.py` output is
exploratory input to reference selection and is never final release evidence.
