# Qwen3.6-27B release readiness

Current phase: fairness-free `v7-r1` protocol defined; release requalification
is pending. `release_ready` remains true in the frozen scoring policy, while
`release-readiness.json` keeps real-agent execution disabled until fresh
images, public anchor, Oracle hidden evidence, evidence index, and manifest
all bind the new scoring-policy digest.

## Frozen infrastructure

- [x] Qwen/Qwen3.6-27B revision
  `6a9e13bd6fc8f0983b9b99948120bc37f49c13e9` with all 15 BF16 weight shards
  and required configuration/tokenizer files pinned.
- [x] Model profile
  `qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2`, SHA-256
  `3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46`.
- [x] Standalone networkless vLLM 0.24.0 on physical H100 NVL devices 6 and 7,
  TP2, FP8 KV, prefix caching, 192 sequence ceiling and 30 GiB KV per GPU.
- [x] Exact runtime image, process/container identity, UDS, model/profile,
  selected GPU UUIDs and readiness attestation checked on every launch.
- [x] Raw launch identity remains private input only. Sanitized evidence and
  the manifest publish no absolute snapshot/corpus/Harbor or socket path, PID,
  container/token identity, or GPU UUID; they bind the launch through an
  opaque boot digest plus an exact static model/runtime allowlist.
- [x] Only trusted model-api can read the UDS runtime. Candidate code receives
  only the verifier-selected OpenAI-compatible `BACKEND_URL`.
- [x] Hybrid page accounting uses 1,252 decision pages, 1,568 attention tokens
  per page, three resident Mamba pages and up to three transient Mamba pages.
- [x] Compact 12-image SWE-bench Lite corpus is pinned and split into six
  public plus six disjoint held-out issues. It is scoped as a systems-load
  fixture, not broad SWE generalization evidence.

## Workload and public feedback

- [x] Adapter `qwen36-text-bash-v1`: thinking disabled, no function tools,
  temperature 0, top-p 1 and one Bash-fence action.
- [x] Real multi-turn trajectories demonstrate natural prompt/KV growth; no
  synthetic prompt padding or tool sleeps are used.
- [x] Selected pressure family: 192 independent rollouts, concurrency 192,
  maximum 24 actions and 2,048 completion tokens.
- [x] Complete finite Direct qualification reached KV p95/max 0.9888/1.0,
  waiting p95/max 104/171, 44 preemptions, request success 1.0, fairness 1.0
  and minimum progress 24.
- [ ] One author calibration uses an exact 1800-second Direct interval and an
  exact 1800-second Oracle interval, taking about 60–70 minutes and creating a
  private immutable Direct anchor. Harbor public rounds are Candidate-only,
  normally 30–35 minutes, with a 2100-second outer ceiling.
- [x] Public candidate output is a recursive explicit allowlist. It excludes
  private profiles, trajectories, raw health, host paths/UDS, process/container
  and GPU identities, commands, tokens and future unknown fields.
- [x] Private uncaught-public diagnostics are atomic 0600 files with a hard
  maximum of eight 4-KiB slots / 32 KiB total; saturation causes later events
  to be dropped without further artifact replacement.
- [x] Pair attempts are append-only; completed raw leg payloads are immutable;
  every release Candidate points directly to the same external anchor as both
  parent and baseline anchor; repeated compare is byte-idempotent.

## Reference solution

- [x] Oracle source is a task-compatible extraction of upstream ThunderAgent
  commit `7ddc8610270e56d3b109eed8796b3a4360fc67c9`, with attribution retained.
- [x] Data plane preserves one client request to one backend request, body,
  headers, streaming order, errors and cancellation semantics.
- [x] Qwen admission decisions use request-phase hybrid pages rather than the
  informational logical-token telemetry.
- [x] v4 public qualification measured 1.157895× speedup while improving
  fairness and reducing KV occupancy/preemption.
- [x] v5 preserves the v4 protected policy through step 12 and uses total-token
  SJF for deep requests from step 13, without bypassing capacity or aged-request
  safety.
- [x] v5 development public result measured Direct 153.0 versus Oracle 176.0
  steps/minute (1.150327×), fairness 0.9666→0.9829, KV p95
  0.9745→0.7348 and preemptions 3→0. All gates passed; all deep/mixed signals
  were zero.
- [x] The v5 exploratory hidden A/B/B/A measured Direct 79.376/81.134 versus
  Oracle 98.100/98.338 steps/minute: 1.223906x geometric-mean speedup, Direct
  CV 0.010955 and Oracle CV 0.001209. Both fresh B epochs independently
  activated deep offers, waiters, wait duration, service-lag bypass, deep
  resumes and SJF ticks while every non-tail contract passed.
- [x] Freeze the conservative hidden reference at 1.195. It is the lower of
  the worst-cross-leg rate ratio and the CV-penalized geometric-mean speedup,
  rounded down to 0.005. Freeze gateway p99 hard/soft bounds at 720/420 seconds;
  the hard bound is the next minute above a 20 percent margin on the repeated
  Oracle p99 observations.
- [x] Exploratory ABBA used position-paired tails to select the reference.
  Formal hidden has one recomputed `Candidate/Direct` p99-step ratio with
  maximum 1.25; fixed-window public evaluation skips this right-censored gate.

## Timing, isolation and verifier

- [x] Finite rate interval begins globally immediately before dispatch and ends
  at the final `agent.run` termination. Verification/cleanup remain hard gates
  outside the denominator.
- [x] Fixed-window cutoff atomically seals/cancels in-flight public work; only
  completed in-window actions count.
- [x] Hidden runs fresh B processes and scrubs candidate PIDs, ports, home,
  `/tmp`, shared memory, message queues, locks and SysV IPC between epochs.
- [x] Candidate-visible output roots are root-sealed for hidden execution;
  hidden gateway logs and post-B health remain private.
- [x] Main is detached from every non-internal Docker network before hidden
  execution using a root-worker topology attestation; trusted model/controller
  traffic remains available on internal front.
- [x] Re-run the full CPU/mutation suite, transparent bridge/UDS integration,
  hidden reset, egress seal and real task-image continuation tests after the
  final raw-feedback/handoff isolation changes. The immediately preceding
  source line passed all of them.
- [x] Formal exporter requires a passed fixed-1800 public calibration, its
  private Direct anchor, zero public deep signals, and a nonce-committed hidden
  AB-or-BA pair with one fresh Candidate epoch and all six positive deep
  witnesses. Exporter and freezer independently recompute the single hidden
  p99-step ratio and revalidate both raw identities.

## Multi-session Luna mechanism

- [x] One Harbor attempt/concurrent trial can run 1–3 fresh serial native Codex
  sessions; default and minimum are both three.
- [x] Sessions share only current `/app/submission` code and sanitized public
  handoff. Codex homes/transcripts/history/state are not resumed.
- [x] Every round freezes a root-owned read-only code tree, manifest, tree hash
  and validated tar before public evaluation.
- [x] Public, phase-0 and hidden gateways execute only from the same
  `/run/kvbench-candidate/submission` argv/cwd. The root-only evidence tree is
  copied with no-follow directory FDs, pre/post digest checks and fail-closed
  post-run cleanup, so a mode-0700 training ancestor cannot break candidate
  execution or expose a phase-specific path.
- [x] Automatic pressure Candidate may use only the manifest-bound external
  Direct anchor. Every round forks directly from that anchor; a manual public
  attempt cannot replace it or trigger an automatic Direct fallback.
- [x] Snapshot/tar or artifact-seal failure cannot produce a valid latest/best
  round or start the next native session.
- [x] Runner source defaults to frozen/no-build launch, performs any explicit
  author-development build before strict verification, and still passes
  literal `--no-force-build` to Harbor.
- [x] Release currentness binds an exact allowlist for the local continuation,
  its import helpers, the Luna launch/run/status/monitor scripts and egress
  overlay; neighboring documentation/tests are not implicitly trusted.
- [x] Rebuild the pre-release test images and rerun the offline/container isolation
  regressions that prove UID 1000 sees only current submission plus the two
  sanitized handoff files.
- [x] After the first Luna run, reproduce and fix the cross-round traverse-mode
  regression. Public helper installation now preserves the 0711 wrapper root,
  and the exact-capability container test exercises
  Round 1 -> helper install -> Round 2.
- [x] Replace lower-layer `RENAME_EXCHANGE` with a root-inode-preserving,
  descriptor-anchored content transaction. The exact r2 main image regression
  covers mode-000 directories, a symlink escape, a FIFO, manifest equality,
  stable root inode, final sealing, and durable marker creation.

## One-way release sequence

- [x] Review the v5 exploratory hidden A/B/B/A and choose a conservative
  reference above noise. The two corresponding one-Direct/one-Oracle orders
  took 6,300 and 6,214 seconds; the formal 9,000-second suite deadline retains
  roughly 40 percent margin, plus separate verifier pre/post reserves.
- [x] Select non-development release ID
  `qwen36-27b-tp2-public30-v7-r1` while still closed. Freeze the exact workload
  profiles, thresholds, reference, empty release-sweep allowlist and timeout.
- [ ] Set `release_ready:true` and build the exact final controller/task images.
- [ ] Run one final fixed-1800 public Direct/Oracle calibration on that image,
  create its private anchor, and require every public gate plus zero deep/mixed
  activation.
- [ ] Run one full Oracle verifier hidden AB-or-BA pair on that same image;
  require one fresh Candidate epoch, positive deep witnesses, baseline-rate
  floor, and all quality, pressure, audit, lifecycle and isolation gates.
- [ ] Export the joint Oracle evidence and exact
  `calibration/qwen36-release/evidence-index.json`.
- [ ] Freeze and verify the new release manifest, enable the agent gate, and
  launch a three-session GPT-5.6 Luna Max trial.
- [x] Inspect that trial after more than 30 minutes. Round 1 completed a valid
  public pair; Round 2/3 permission failure and terminal OverlayFS restore
  failure were classified as runner infrastructure faults, so the verifier
  correctly did not run.
- [ ] Regenerate the release manifest over the repaired execution surface,
  pass the pre-author gate, enable only `real_agent_test_allowed`, and pass
  strict currentness plus runner preflight.
- [ ] Launch a fresh three-session Luna Max trial and require all native rounds,
  terminal best restore, and final Harbor verifier execution to complete.

## Current blockers

1. A fresh Luna trial has not yet demonstrated successful Round 2/3 continuity
   and terminal verifier handoff on those repairs.

These blockers are fail-closed: the current launcher must reject a real Luna
trial.
