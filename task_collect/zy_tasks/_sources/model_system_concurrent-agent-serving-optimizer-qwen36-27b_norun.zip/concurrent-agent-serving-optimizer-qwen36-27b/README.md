# Concurrent Agent Serving Optimizer — Qwen3.6-27B

This Harbor task evaluates a transparent scheduling gateway in front of a
fixed, concurrent coding-agent backend. The candidate may control admission
and queue order, but every accepted model request must produce exactly one
faithful backend request and response.

The active development backend is `Qwen/Qwen3.6-27B` revision
`6a9e13bd6fc8f0983b9b99948120bc37f49c13e9`. It runs outside Harbor Compose in
a networkless vLLM container on physical H100 NVL devices 6 and 7 with tensor
parallel size 2. Only the trusted model API receives the Unix-domain-socket
runtime mount. The normal benchmark supplies `http://127.0.0.1:8100/v1`
through `BACKEND_URL`. That environment variable is the authoritative
upstream; candidate code must also work when protocol verification points it
at a local mock endpoint.

The workload shape is calibrated, but the fairness-free `v7-r1` scoring
protocol still requires fresh release qualification. A bounded
192-workflow, 192-concurrency, 24-step pressure shape is promoted to public and
hidden profiles because completed calibration legs establish real KV contention. The
Oracle policy, reference speedup, scoring thresholds, and two-leg hidden
protocol are frozen under release ID `qwen36-27b-tp2-public30-v7-r1`. The
next release build requires newly tagged task images, a measured immutable
30-minute Direct anchor plus a matching two-leg Oracle full-verifier report.

The public pressure contract is intentionally a thirty-minute scoring window per
leg. On the active runtime, Direct KV p95 was only about 0.870 at 300 seconds
and 0.868 at 360 seconds, but reached about 0.971 by 420 seconds and remained
near saturation thereafter. A materially shorter window would mostly measure
ramp-up instead of cache-contention scheduling. One author-only release
calibration therefore costs about 60 minutes plus warmup/teardown (Direct and
Oracle) and creates a private immutable Direct anchor. Harbor never repeats
that Direct leg: whenever the agent chooses to run the public pressure profile,
only a fresh Candidate window runs and normally costs about 30--35 minutes. A
preflight-rejected invocation creates no pair. Every attempt
that passes preflight and starts execution gets a new saved pair ID, including
runtime failures. Attempt history and completed leg payloads are immutable;
repeating compare may refresh only the current attempt's comparison metadata.
The default CLI text preserves the pair/anchor/parent IDs, and `--json` emits
the complete response for automation.
Every `public-pressure-192` Candidate invocation also creates a versioned
`/app/public_evals/eval_NNNNNN.COMPLETE/` artifact before contacting the
controller. It contains the evaluated code tree and tarball, Candidate result,
comparison, tree digest, pair/run IDs, and speedup. Harbor exports the complete
agent-initiated history as `public-evals`; session-boundary artifacts contain
code checkpoints only. The smoke and `public-12`
debugging profiles do not create code snapshots because their values are not
used for performance selection.

Public testing is entirely agent-initiated. The agent chooses when a cheap or
full pressure measurement is useful, inspects the saved results, and leaves its
chosen best version as the current submission. The full candidate-visible
`/app/public_evals` history persists throughout the search. Process boundaries
create immutable code-only checkpoints; they do not launch the gateway, call
the model, run `kvbench`, or select a public champion.

The candidate instruction deliberately describes the serving problem rather
than the frozen benchmark construction. It explains concurrent agents,
growing contexts, finite KV-cache contention, and the `valid_steps_per_min`
objective, while omitting corpus names, concrete workflow/step counts,
measurement-window length, and final-verifier shape. Candidate commands refer
to the environment-provided `KVBENCH_DEBUG_PROFILE` and
`KVBENCH_PUBLIC_PROFILE` handles; the concrete release values remain an
operator concern documented here.

## When the Direct anchor runs

The expensive public Direct baseline is **not** launched automatically by an
ordinary `harbor run`. It is an author/operator release-preparation artifact,
created once with `scripts/run-reference-pair.py --suite public` after the
model, workload and release-critical controller contract have been frozen. On
this host its private canonical path is:

```text
~/.cache/harbor-kv-qwen36-public30/release/public-direct-anchor.json
```

The resulting anchor contains the saved Direct aggregate result and bindings
to the workload/corpus, model boot, controller image/config, scoring policy,
raw pair and release ID. Its SHA-256 is then recorded in
`calibration/release-manifest.json`.

An ordinary real-agent launch works as follows:

1. The repository Luna/Harbor runner performs preflight before creating a
   trial. It requires the anchor and release manifest to exist and verifies
   their hashes and current runtime identity. Missing or stale input stops the
   launch immediately; there is no automatic 30-minute Direct fallback.
2. The runner mounts the host anchor read-only at
   `/run/kvbench-release/public-direct-anchor.json` in the trusted controller
   only. It is not mounted into the candidate/agent container.
3. When Codex invokes the public pressure test, only the current Candidate
   gateway runs for 1800 seconds. The controller compares that result with the
   cached Direct value. Each later public attempt reuses the same immutable
   anchor and snapshots only the Candidate code/result.
4. After the last Codex session, Harbor automatically invokes the final
   verifier. Hidden scoring does not use the public anchor: the trusted
   verifier runs one fresh held-out Direct leg and one fresh held-out Candidate
   leg in its nonce-committed AB or BA order.

Thus `harbor run` automatically consumes and validates a previously prepared
public anchor, and automatically runs the hidden A/B verifier at the end. It
does not create or refresh release evidence. Rebuilding an anchor, collecting
Oracle evidence and freezing a release manifest are explicit author-side
operations described under **Calibration commands** and **Release sequence**.

Each leg's model provenance includes only an opaque SHA-256 of the trusted
host-vLLM ready epoch, wrapper PID/start ticks, container ID, and one-time
launch token. The raw values never enter public feedback. This makes an
otherwise identical host restart invalidate the public anchor and makes the
formal hidden pair fail closed on any cross-leg runtime drift. Public abnormal
responses expose only fixed error/gate codes; raw exception and failure detail
is written only to 0700/0600 controller evidence. That exception store has a
hard lifetime ceiling of eight 4-KiB slots and 32 KiB total; once full, later
exceptions are dropped without another artifact write.

## Architecture

```text
author-owned host runtime
  networkless vLLM (physical GPUs 6,7; TP2; target-model)
              |
              | Unix socket + ready attestation
              v
Harbor trusted model-api :8100
              ^
              | fixed OpenAI-compatible URL
              |
candidate gateway :9000 <---- trusted benchmark controller
                                  |
                                  v
                         trusted sandbox worker
                                  |
                                  v
                      fresh no-network SWE containers
```

The vLLM container publishes no TCP port and is not owned by Harbor Compose.
Candidate containers never receive the socket, model files, GPU devices,
Docker socket, verifier credentials, hidden profiles, or precomputed
Direct/Oracle trajectories. During a measured leg the candidate necessarily
sees the request and response bytes that it must proxy; the isolation boundary
prevents advance knowledge and cross-leg leakage.

The final verifier runs only after the last Codex process is gone and no
continuation follows it. Its canonical `verifier/report.json` therefore keeps
both held-out Direct and Candidate aggregate legs, profile metrics, speedup,
performance/tail components, gates, provenance, and failure detail. It
omits the repeated 192-workflow records and per-second vLLM series; their
counts remain in `omitted_detail_counts`. This is a report-size policy, not a
sanitization boundary. `reward.json` also exposes the baseline and Candidate
valid steps/min, measured speedup, and frozen reference speedup as scalar
reward dimensions.

## Buildability and operator prerequisites

There are two different reproducibility claims:

1. **Task images are source-buildable.** From this directory,
   `scripts/calibration-stack.sh build` builds the candidate `main`, trusted
   `model-api`, trusted `bench-controller`, and trusted `sandbox-worker`
   images. The candidate image does not contain this README, `docs/`,
   `calibration/`, `author_tests/`, `solution/`, or either hidden profile or
   scoring policy. Its `/app` surface contains only the editable starter,
   public-evaluation artifacts, and the public-feedback mount.
2. **The complete benchmark is not a self-contained one-command build.** A
   benchmark operator must additionally provide the pinned Qwen snapshot, the
   exact attested vLLM runtime image, two compatible H100 GPUs, a staged and
   validated SWE-bench Lite corpus plus its sandbox images, Docker access for
   the trusted no-network sandbox worker, and the private immutable public
   Direct anchor. Hidden corpus/profile material belongs to the trusted
   operator surface and should not be placed in the candidate image.

The current host launcher defaults to this author's model-cache path and
physical GPU devices 6 and 7. `HARBOR_VLLM_MODEL_PATH` is configurable, but GPU
placement and the attested runtime image are intentionally frozen release
inputs. Consequently another machine can build the four task images from
source, but cannot reproduce the exact released score unless it has the same
operator assets and compatible hardware. A future portability pass should add
a documented runtime-image build recipe, parameterized development-mode GPU
selection, and one preflight/bootstrap entrypoint; strict release mode should
remain content-addressed and fail closed.

Any source change to the instruction, environment, verifier, profiles, or
release-critical tests invalidates release-manifest currentness. After such a
change, rerun CPU/container tests, public Direct/Oracle calibration, the formal
hidden Direct/Oracle verifier, and freeze a new manifest before calling the
tree release-ready.

## Frozen development runtime

The active model contract is
[`environment/vllm-runtime/model-profile-qwen3.6-27b.json`](environment/vllm-runtime/model-profile-qwen3.6-27b.json).
Its current SHA-256 is
`3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46`.
The profile ID is
`qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2`.
It pins:

- `Qwen3_5ForConditionalGeneration`, 64 text layers, 15 BF16 weight shards;
- native 262,144-token context, TP2, and physical H100 NVL devices 6 and 7;
- vLLM 0.24.0, prefix caching, chunked prefill, FP8 KV, and 16-token user
  block size;
- `max-num-seqs=192`, `max-num-batched-tokens=8192`, hybrid-cache alignment,
  and a networkless UDS-only server;
- an explicit 30 GiB KV-cache allocation on each GPU. vLLM reports 1,887,738
  logical tokens as informational telemetry; scheduler admission uses the
  resolved hybrid geometry: 1,253 raw aligned pages minus one reserved null
  page, or 1,252 usable pages, with 1,568 attention tokens per page and three
  resident Mamba pages per live program. Three additional Mamba pages can be
  transiently required at peak.

The coding-agent adapter is `qwen36-text-bash-v1`. Direct and Oracle legs send
the same request contract: Qwen chat-template thinking is disabled with
`chat_template_kwargs={"enable_thinking": false}`, function tools are not
used, and the model must emit one Bash code fence for the next action. This is
necessary for real multi-step execution: development probes showed that
thinking mode could consume a 2,048-token completion budget without producing
an executable action, while the non-thinking form returned a valid action.

## Start and stop

Use the same absolute runtime directory for the standalone host launcher and
all task-stack commands:

```bash
export HARBOR_VLLM_RUNTIME_DIR="/tmp/harbor-kv-qwen36-27b-$(id -u)"

scripts/host-vllm-qwen36-27b.sh preflight
scripts/host-vllm-qwen36-27b.sh start
scripts/host-vllm-qwen36-27b.sh status
```

`start` waits for `target-model` health over the UDS and then writes
`vllm.sock`, `attestation.json`, and `vllm.log` below the runtime directory.
Inspect the persistent log with:

```bash
scripts/host-vllm-qwen36-27b.sh logs
```

Stage the pinned SWE-bench Lite corpus if needed, then build and start only the
Harbor task services:

```bash
scripts/stage-swebench-lite.sh
scripts/calibration-stack.sh build
scripts/calibration-stack.sh start
scripts/calibration-stack.sh status
scripts/calibration-stack.sh verify-phase0-local
```

Stop the two ownership domains independently:

```bash
scripts/calibration-stack.sh stop
scripts/host-vllm-qwen36-27b.sh stop
```

The task-stack stop preserves named audit, benchmark-result, and attestation
volumes and leaves the external model running. The host stop validates the
attested tmux/process/container identity before signaling anything.

## What the current evidence says

Two early Qwen Direct diagnostics established the request contract and natural
trajectory growth:

- `qwen36-adapter-8`: 64/64 successful model calls, 61 executed actions, no
  completion-budget exhaustion, about 165 valid steps/minute, and negligible
  KV pressure.
- `qwen36-trajectory-24-deep48`: 1,032/1,032 successful model calls, 1,022
  executed actions, about 181 valid steps/minute, prompt p95 27,660 tokens,
  and KV maximum about 14.4%.

The 24-agent trajectory shows why step depth matters. All 24 workflows reached
step 24, 21 reached step 32, 18 reached step 40, and 12 reached step 48; prompt
contexts grew from roughly 1.6k tokens at step 1 to a 24.2k median among step-48
survivors. Against that preceding runtime's 3,492,240-token capacity,
projecting the exact trajectory to 192 simultaneous workflows suggested a
contention knee around steps 40–44. That projection is historical
workload-selection evidence, not qualification for the smaller active
`kv30g-v2` cache and not Oracle evidence.

An author-only `qwen36-pressure-192-deep48` diagnostic then ran for 1,480.8
seconds before being safely cancelled. It was not a completed 48-step run:
workflow depth p50/p95/max was only 19/25/30, and the cancellation left 192
query failures, a 0.9481 request-success rate, and expected incomplete-stream
audit mismatches. Before cancellation it recorded 3,476 valid steps (140.84
steps/minute), KV p95 0.7708 and maximum 0.8032, waiting during 0.8250 of
backend-active time, and prefix-cache hit ratio 0.2245. This diagnostic binds
the preceding `bf283…` runtime profile, not the active `kv30g-v2` profile, so
it is workload-selection evidence only and cannot qualify current pressure or
Oracle performance. Its occupancy ratios also cannot simply be rescaled to the
new cache, because changing the allocation changes admission, retention, and
execution dynamics.

The complete active-runtime Direct runs selected `qwen36-pressure-192-deep24`.
The latest frozen baseline completed in 3,207.9 seconds with 4,542 valid actions
at 84.953 steps/minute, 100% request success, 0.9924 valid-step ratio, and
minimum workflow progress 24. KV p95/max were 0.9888/1.0; 69.77% of
backend-active time was at or above the 0.8 threshold, audited prompt demand
p95 was 1.239× reported logical capacity, and vLLM recorded 44 preemptions.
This is complete, natural, one-wave pressure evidence without prompt padding.

The early schema-v2 hybrid-page Oracle pair did not improve that workload. Its candidate
leg produced 84.843 steps/minute, or 0.9987× Direct. Request success, action
validity, tests, progress, and the one-to-one audit were preserved,
but p99/max gateway wait reached 1,317.6/1,800.0 seconds, backend work per step
rose about 2.05%, preemptions rose to 71, and a force-resume occurred. The pair
therefore failed effect, tail/backend-work, and scheduler-contract gates. It is
evidence that the workload shape is useful, not evidence that the current
Oracle is the desired solution.

A later fixed-window public v4 pair on the selected shape measured Direct at
150.1 valid steps/minute and Oracle at 173.8, a 1.1579x improvement. Direct KV
p95/max were 0.987/0.998 versus 0.739/0.769 for Oracle, and preemptions fell
from four to zero. An exploratory
finite hidden v4 A/B/B/A measured Direct geometric mean 81.164 and Oracle
84.082 valid steps/minute, or 1.0360x, with Direct CV 0.76%. That hidden result
is not release evidence: it exposed that normal 24-step-limit exits were being
mistaken for missing natural completions, and that the old finite denominator
included post-agent repository verification and cleanup. Those semantics and
the hidden state/output/network boundaries have since been fixed and covered by
mutation and container tests.

The v5 protected-tier development public rerun measured Direct at 153.0 and
Oracle at 176.0 valid steps/minute, a 1.1503x improvement. KV p95 fell from
0.9745 to 0.7348, and preemptions fell
from three to zero. Every public contract passed; all deep-tier and mixed-tier
signals were exactly zero, as required for the ten-minute feedback boundary.

The v5 exploratory hidden A/B/B/A completed with Direct 79.376/81.134 versus
Oracle 98.100/98.338 valid steps/minute. The geometric-mean speedup was
1.223906x, with Direct CV 0.010955 and Oracle CV 0.001209. Both Oracle epochs
activated every required deep-tier signal and passed the non-tail contracts.
Those four legs are author-only reference-selection evidence, not the formal
release protocol. They support the conservative frozen reference 1.195 and a
baseline-rate floor of 74.5 steps/minute.

The 192×24 bounded shape is consequently promoted as the Harbor test on
disjoint public and hidden partitions. Release remains closed until final
images, one public calibration/anchor, one formal hidden two-leg report, and
their joint manifest are frozen on one unchanged controller/model epoch.

Finite formal hidden qualification has a single-pair tail anti-gaming gate:
`candidate.p99_step_latency/baseline.p99_step_latency` must be at most 1.25.
The fixed-1800 public pair skips this finite-cohort gate because its p99 is
right-censored at the measurement deadline. Export and release freeze
independently recompute the hidden ratio from the preserved legs instead of
trusting a declared summary.

The formal hidden verifier runs exactly one Direct and one Candidate leg. A
domain-separated hash of the private workload-nonce commitment chooses AB or
BA, so the order is committed before measurement without paying for four
formal legs. Both legs share one 9,000-second monotonic suite deadline; it is
not repeated per leg. The complete verifier timeout is 12,600 seconds, leaving
3,000 seconds for pre-suite checks and a hard 600-second post-suite cleanup and
artifact reserve.

## Calibration commands

Run only explicitly named development profiles while `release_ready` is false:

```bash
sg docker -c 'python3 scripts/run-real-swe-calibration.py \
  --profile qwen36-pressure-192-deep24 \
  --output calibration/qwen36-pressure-192-deep24-direct.json'
```

Author-side Direct/Oracle qualification uses an isolated same-nonce pair. The
runner stops `main` for the Direct leg, recreates the complete reference
gateway for the Oracle leg, verifies lifecycle cleanup, and records both raw
trusted results:

```bash
sg docker -c 'python3 scripts/run-reference-pair.py \
  --suite calibration \
  --profile qwen36-pressure-192-deep24 \
  --output /tmp/qwen36-reference-pair.json'
```

For the final public suite, add `--public-anchor-output` with a private path
outside the task tree. After the complete pair passes, the runner atomically
creates a mode-0600 Direct anchor bound to the raw report, policy, controller
image/config, corpus, model provenance, and host-vLLM boot. Harbor mounts that
artifact read-only into the trusted controller only. It is never mounted into
the agent or exported as candidate feedback.

```bash
sg docker -c 'python3 scripts/run-reference-pair.py \
  --suite public \
  --profile public-pressure-192 \
  --output /tmp/qwen36-final-public30-pair-r1.json \
  --public-anchor-output "$HOME/.cache/harbor-kv-qwen36-public30/release/public-direct-anchor.json"'
```

The author-only exploratory hidden reference measurement uses four independent
controller legs and owns the runtime-bound host measurement flock for the whole
sequence. It stops `main` for both Direct legs, resets a quiescent model-api at
every boundary, and starts B1 and B2 from separate containers/processes backed
by one nonwritable snapshot of `solution/reference_gateway/`:

```bash
sg docker -c 'python3 scripts/run-exploratory-hidden-abba.py \
  --profile hidden-pressure-192 \
  --output /tmp/qwen36-private-exploratory-hidden-abba.json'
```

The output is atomically checkpointed with mode `0600` and contains private
hidden raw legs plus audit, pressure, quality, position-paired p99-step tail,
geometric-mean, CV, and speedup summaries. The runner refuses
`release_ready:true` and any output path inside
the task tree. Its result is only an input to pre-freeze reference selection;
it cannot be indexed or relabeled as final release evidence. Do not run it at
the same time as a Luna/public/calibration measurement sharing the Qwen runtime.

## Oracle boundary

The author Oracle under `solution/reference_gateway/` is a task-compatible
extraction of upstream ThunderAgent at commit
`7ddc8610270e56d3b109eed8796b3a4360fc67c9`. Its aiohttp data plane stays byte
transparent; only program state, token accounting, ACTING-first pause,
pending-state restore, shortest-context selection, five-second scheduling,
and acting-token decay are adapted. The current Qwen path makes admission
decisions in the resolved 1,252-page hybrid geometry; the reported 1,887,738
logical-token value is informational. Its transport ceiling is 192 requests.
The controller may send the optional `/programs/release` lifecycle hint when a
workflow ends.

Normal Harbor agent trials build only `environment/` and do not mount
`solution/`. Harbor's Oracle path alone installs `solution/` before running the
reference gateway.

## Release sequence

Release evidence has a one-way freeze boundary:

1. Keep `release_ready` and `real_agent_test_allowed` false during workload
   exploration, pressure calibration, A/B runs, and soaks.
2. From `release_ready:false` exploratory public/hidden measurements, choose a
   non-development release ID and freeze the public/hidden shapes, thresholds,
   ABBA-derived reference values, completion caps, and verifier timeout. The
   final release-sweep allowlist remains explicitly empty.
3. Flip only `release_ready`, rebuild the final controller once, and make no
   subsequent contract/runtime/Oracle change.
4. Collect one fixed-1800 public Direct/Oracle calibration and its private
   Direct anchor, then one complete Oracle full-verifier report on that exact
   build. Public must remain entirely in the protected tier. Formal hidden uses
   its nonce-committed AB or BA order, exactly one fresh Candidate epoch, and
   must activate every deep-tier witness. This is explicitly a single-run
   research release, not a repeated-measurement publication claim.
5. Create `calibration/qwen36-release/evidence-index.json`, generate the
   immutable release manifest, and pass currentness validation before enabling
   a real Luna Max trial. The manifest hashes both the task's critical tree and
   a fixed, repository-relative real-agent execution allowlist (continuation,
   local helpers, launch/status/monitor scripts, and egress overlay), so runner
   code cannot drift after the release is frozen.

Sanitized evidence and the release manifest have a strict publication
boundary. They contain no absolute model/corpus/Harbor paths, UDS paths,
attestation filename, PID/start ticks, container ID/launch token, or GPU UUID.
The publishable model identity is an exact allowlist of frozen profile/model
hashes, runtime image digest and static serving fields plus one opaque
`runtime_boot_identity_sha256`. The raw attestation remains only a private
input to freeze/currentness checks. At launch, currentness reads the model path
from that caller-supplied live attestation, validates the real snapshot files,
image, UDS, process/container epoch and GPU contract, then compares only the
safe projection with the manifest.

Historical development artifacts outside the Qwen release-evidence index
cannot qualify the release.

## Tests and task deliverable

Run CPU contracts without the model:

```bash
scripts/test-cpu.sh
```

With the external runtime and task stack ready:

```bash
scripts/calibration-stack.sh verify-phase0-local
scripts/calibration-stack.sh verify-local
```

The candidate writes an executable `/app/submission/launch.sh`. Harbor starts
it with a required `BACKEND_URL` (normally
`http://127.0.0.1:8100/v1`) and `PORT=9000`; it must use that exact environment
value, stay in the foreground, and expose `/health`, `/v1/models`, and
`/v1/chat/completions`. See [`instruction.md`](instruction.md) for the complete
candidate-facing transparency contract.

## Read these files first

- [`instruction.md`](instruction.md): the candidate-visible gateway contract.
- [`docs/dev/CURRENT_STATE.md`](docs/dev/CURRENT_STATE.md): live evidence,
  blockers, and the next experiment.
- [`calibration/READINESS.md`](calibration/READINESS.md): release gate checklist.
- [`docs/dev/HOST_QWEN36_RUNTIME.md`](docs/dev/HOST_QWEN36_RUNTIME.md): external
  Qwen lifecycle and UDS ownership.
- [`environment/bench-controller/profiles/calibration.json`](environment/bench-controller/profiles/calibration.json):
  author-only experiment shapes; do not confuse them with frozen scoring.
- [`environment/bench-controller/profiles/scoring-policy.json`](environment/bench-controller/profiles/scoring-policy.json):
  frozen r2 scoring policy. The conservative 1.195 reference was selected from
  completed v5 exploratory ABBA evidence and then qualified by the formal
  two-leg Oracle report. Four-leg ABBA remains author-only exploratory tooling,
  not the formal hidden protocol.
