#!/usr/bin/env python3
"""Phase-0 verifier: isolation, transparent proxy, and shared lifecycle."""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import re
import signal
import shutil
import stat
import subprocess
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any


class VerificationError(RuntimeError):
    pass


CANDIDATE_RUNTIME_ROOT = Path("/run/kvbench-candidate")
CANDIDATE_RUNTIME_SUBMISSION = CANDIDATE_RUNTIME_ROOT / "submission"
CANDIDATE_RUNTIME_DIGEST = CANDIDATE_RUNTIME_ROOT / ".submission.sha256"
TRUSTED_UID = 0
TRUSTED_GID = 0


EXPECTED_REVISION = "6a9e13bd6fc8f0983b9b99948120bc37f49c13e9"
EXPECTED_PROFILE = "qwen3.6-27b-6a9e13bd-h100-nvl-tp2-kv30g-v2"
EXPECTED_PROFILE_SHA256 = "3c8dce7272dbb3d97202471df24fac713144bd34d67bff9ede290f2e458b6a46"
EXPECTED_VLLM_PACKAGE = "0.24.0"
EXPECTED_RUNTIME_IMAGE_REF = "harbor-kv/vllm-qwen36-27b-h100:host-r1"
EXPECTED_RUNTIME_IMAGE_ID = "sha256:1d8369b9e3c91aa8cba5c7aeeef26e3c4afd455e5d2ce9aebe6f30f6dd9344bd"
EXPECTED_CONFIG_SHA256 = "69db4eb7196bc8190813231b3018ca05d8c2e3abc7b1af19d55c157af44a9d9c"
EXPECTED_INDEX_SHA256 = "a8ad2c26fb707ff8c245806315b03e3b4b74595528492423af5dae0ce39b4d9b"
EXPECTED_GPU_UUIDS = (
    "GPU-22c98c90-b7be-5cb7-47cc-1f097071187b",
    "GPU-8dac3778-a2a5-cebf-134f-1b43c9b973c9",
)
EXPECTED_TMUX_SESSION = "harbor-kv-qwen36-27b"
EXPECTED_CONTAINER_NAME = "harbor-kv-qwen36-27b-host"
EXPECTED_CONTAINER_SOCKET = "/run/kvbench-vllm/vllm.sock"

# vLLM 0.24 resolves the frozen Qwen3.6 hybrid cache into allocation pages
# that are deliberately distinct from the user-specified 16-token CLI block.
# ``kv_cache_size_tokens`` remains useful model-level telemetry, but it is not
# an additive admission budget for multiple hybrid-model sequences.
EXPECTED_HYBRID_CACHE_ACCOUNTING = {
    "accounting_schema_version": 2,
    "accounting_mode": "qwen36-vllm024-hybrid-pages",
    "decision_unit": "kv_pages",
    "attention_page_tokens": 1568,
    "raw_gpu_blocks": 1253,
    "reserved_null_blocks": 1,
    "capacity_pages": 1252,
    "mamba_group_count": 3,
    "mamba_resident_pages_per_group": 1,
    "mamba_peak_pages_per_group": 2,
    "fixed_mamba_pages_per_program": 3,
    "transient_mamba_pages_per_program": 3,
    "reported_logical_capacity_tokens": 1887738,
    "reported_logical_capacity_is_informational": True,
}

ATTESTATION_OVERRIDE_NAMES = (
    "KV_EXPECTED_MODEL_PROFILE_ID",
    "KV_EXPECTED_MODEL_PROFILE_SHA256",
    "KV_EXPECTED_MODEL_REVISION",
    "KV_EXPECTED_RUNTIME_IMAGE_REF",
    "KV_EXPECTED_RUNTIME_IMAGE_ID",
    "KV_EXPECTED_VLLM_PACKAGE",
    "KV_EXPECTED_GPU_UUIDS",
)

EXPECTED_REQUIRED_FILE_HASHES = {
    "chat_template.jinja": "e84f32a23fdda27689f868aa4a1a5621f41133e51a48d7f3efcbea2839574259",
    "config.json": EXPECTED_CONFIG_SHA256,
    "generation_config.json": "e70c136c1b78ddc1fb0905bac8e733a4dc448d4f852a5dd75143fffc70be550e",
    "model.safetensors.index.json": EXPECTED_INDEX_SHA256,
    "tokenizer.json": "5f9e4d4901a92b997e463c1f46055088b6cca5ca61a6522d1b9f64c4bb81cb42",
    "tokenizer_config.json": "5186f0defcd7f232382c7f0aebcd2252d073bb921ab240e407b7ae8745d2b29b",
}

EXPECTED_RUNTIME = {
    "runtime_image_ref": EXPECTED_RUNTIME_IMAGE_REF,
    "runtime_image_id": EXPECTED_RUNTIME_IMAGE_ID,
    "vllm_package_version": EXPECTED_VLLM_PACKAGE,
    "vllm_engine_version": "0.24.0+ee0da84ab9e04ac7610e28580af62c365e898389",
    "served_model_name": "target-model",
    "tensor_parallel_size": 2,
    "preserve_checkpoint_quantization": False,
    "checkpoint_quantization_method": None,
    "dtype": "bfloat16",
    "model_impl": "vllm",
    "runner": "generate",
    "kv_cache_dtype": "fp8",
    "enable_prefix_caching": True,
    "enable_chunked_prefill": True,
    "mamba_cache_mode": "align",
    "mamba_ssm_cache_dtype": "float32",
    "gdn_prefill_backend": "triton",
    "load_format": "safetensors",
    "safetensors_load_strategy": "lazy",
    "mm_processor_cache_gb": 0,
    "block_size": 16,
    "max_model_len": 262144,
    "max_num_seqs": 192,
    "max_num_batched_tokens": 8192,
    "kv_cache_memory_bytes": 32212254720,
    "gpu_memory_utilization": 0.9,
    "generation_config": "vllm",
    "fail_on_environ_validation": False,
    "server_dev_mode": True,
    "network_mode": "none",
    "transport": "unix",
    "container_socket_path": EXPECTED_CONTAINER_SOCKET,
    "language_model_only": True,
    "tool_call_parser": None,
    "reasoning_parser": "qwen3",
}


def http(method: str, url: str, body: bytes | None = None, headers: dict[str, str] | None = None, timeout: int = 120) -> tuple[int, bytes]:
    request = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()


def admin(method: str, base: str, path: str, token: str) -> dict[str, Any]:
    status, body = http(method, f"{base}{path}", headers={"Authorization": f"Bearer {token}"})
    if status != 200:
        raise VerificationError(f"admin endpoint {path} returned {status}: {body!r}")
    return json.loads(body)


def submission_tree_sha256(submission: Path) -> str:
    """Content-bind a frozen submission using the final-session wire format."""

    digest = hashlib.sha256()
    for entry in [submission, *sorted(submission.rglob("*"))]:
        relative = "." if entry == submission else entry.relative_to(submission).as_posix()
        metadata = entry.lstat()
        if stat.S_ISDIR(metadata.st_mode):
            kind = "directory"
            payload_digest = ""
            size = 0
        elif stat.S_ISREG(metadata.st_mode):
            kind = "file"
            payload_digest = hashlib.sha256(entry.read_bytes()).hexdigest()
            size = metadata.st_size
        else:
            raise VerificationError(
                f"frozen submission contains unsupported entry: {relative}"
            )
        record = {
            "kind": kind,
            "path": relative,
            "executable": bool(metadata.st_mode & 0o111),
            "size": size,
            "sha256": payload_digest,
        }
        digest.update(json.dumps(record, separators=(",", ":"), sort_keys=True).encode())
        digest.update(b"\n")
    return digest.hexdigest()


def _same_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return (
        left.st_dev,
        left.st_ino,
        stat.S_IFMT(left.st_mode),
    ) == (
        right.st_dev,
        right.st_ino,
        stat.S_IFMT(right.st_mode),
    )


def _same_stable_metadata(left: os.stat_result, right: os.stat_result) -> bool:
    return _same_identity(left, right) and (
        left.st_uid,
        left.st_gid,
        left.st_size,
        left.st_mtime_ns,
        left.st_ctime_ns,
    ) == (
        right.st_uid,
        right.st_gid,
        right.st_size,
        right.st_mtime_ns,
        right.st_ctime_ns,
    )


def _secure_copy_frozen_tree(source: Path, destination: Path) -> None:
    """Copy a root-owned frozen tree through anchored, no-follow descriptors."""

    nofollow = getattr(os, "O_NOFOLLOW", 0)
    cloexec = getattr(os, "O_CLOEXEC", 0)
    directory_flags = os.O_RDONLY | os.O_DIRECTORY | nofollow | cloexec
    file_flags = os.O_RDONLY | nofollow | cloexec
    source_path_stat = source.lstat()
    if (
        stat.S_ISLNK(source_path_stat.st_mode)
        or not stat.S_ISDIR(source_path_stat.st_mode)
        or source_path_stat.st_uid != TRUSTED_UID
        or source_path_stat.st_gid != TRUSTED_GID
    ):
        raise VerificationError("frozen evidence root is unsafe")
    source_fd = os.open(source, directory_flags)
    try:
        source_fd_stat = os.fstat(source_fd)
        if not _same_identity(source_path_stat, source_fd_stat):
            raise VerificationError("frozen evidence root changed before open")
        destination.mkdir(mode=0o700, parents=False, exist_ok=False)
        destination_fd = os.open(destination, directory_flags)
        try:
            def copy_directory(source_dir_fd: int, destination_dir_fd: int) -> None:
                directory_before = os.fstat(source_dir_fd)
                if (
                    not stat.S_ISDIR(directory_before.st_mode)
                    or directory_before.st_uid != TRUSTED_UID
                    or directory_before.st_gid != TRUSTED_GID
                ):
                    raise VerificationError("frozen evidence directory is unsafe")
                for name in sorted(os.listdir(source_dir_fd)):
                    if name in {"", ".", ".."} or "/" in name:
                        raise VerificationError("frozen evidence entry name is unsafe")
                    before = os.stat(name, dir_fd=source_dir_fd, follow_symlinks=False)
                    if before.st_uid != TRUSTED_UID or before.st_gid != TRUSTED_GID:
                        raise VerificationError("frozen evidence entry owner is unsafe")
                    if stat.S_ISDIR(before.st_mode):
                        child_source_fd = os.open(
                            name, directory_flags, dir_fd=source_dir_fd
                        )
                        try:
                            opened = os.fstat(child_source_fd)
                            if not _same_identity(before, opened):
                                raise VerificationError(
                                    "frozen evidence directory changed during open"
                                )
                            os.mkdir(name, 0o700, dir_fd=destination_dir_fd)
                            child_destination_fd = os.open(
                                name, directory_flags, dir_fd=destination_dir_fd
                            )
                            try:
                                copy_directory(child_source_fd, child_destination_fd)
                                os.fchmod(child_destination_fd, 0o555)
                            finally:
                                os.close(child_destination_fd)
                            after = os.fstat(child_source_fd)
                            named_after = os.stat(
                                name, dir_fd=source_dir_fd, follow_symlinks=False
                            )
                            if not (
                                _same_stable_metadata(before, after)
                                and _same_stable_metadata(after, named_after)
                            ):
                                raise VerificationError(
                                    "frozen evidence directory changed during copy"
                                )
                        finally:
                            os.close(child_source_fd)
                    elif stat.S_ISREG(before.st_mode):
                        child_source_fd = os.open(name, file_flags, dir_fd=source_dir_fd)
                        try:
                            opened = os.fstat(child_source_fd)
                            if not _same_identity(before, opened):
                                raise VerificationError(
                                    "frozen evidence file changed during open"
                                )
                            # The evidence freezer has already forced only the
                            # root launch.sh executable. Preserve every other
                            # entry's executable bit exactly so the wire digest
                            # cannot change for a nested file with the same name.
                            executable = bool(before.st_mode & 0o111)
                            child_destination_fd = os.open(
                                name,
                                os.O_WRONLY
                                | os.O_CREAT
                                | os.O_EXCL
                                | nofollow
                                | cloexec,
                                0o555 if executable else 0o444,
                                dir_fd=destination_dir_fd,
                            )
                            try:
                                while True:
                                    chunk = os.read(child_source_fd, 1024 * 1024)
                                    if not chunk:
                                        break
                                    view = memoryview(chunk)
                                    while view:
                                        written = os.write(child_destination_fd, view)
                                        view = view[written:]
                                os.fsync(child_destination_fd)
                                os.fchmod(
                                    child_destination_fd,
                                    0o555 if executable else 0o444,
                                )
                            finally:
                                os.close(child_destination_fd)
                            after = os.fstat(child_source_fd)
                            named_after = os.stat(
                                name, dir_fd=source_dir_fd, follow_symlinks=False
                            )
                            if not (
                                _same_stable_metadata(before, after)
                                and _same_stable_metadata(after, named_after)
                            ):
                                raise VerificationError(
                                    "frozen evidence file changed during copy"
                                )
                        finally:
                            os.close(child_source_fd)
                    elif stat.S_ISLNK(before.st_mode):
                        raise VerificationError("frozen evidence contains a symlink")
                    else:
                        raise VerificationError("frozen evidence contains a special file")
                if not _same_stable_metadata(
                    directory_before, os.fstat(source_dir_fd)
                ):
                    raise VerificationError("frozen evidence directory changed during scan")

            copy_directory(source_fd, destination_fd)
            os.fchmod(destination_fd, 0o555)
            os.fsync(destination_fd)
        finally:
            os.close(destination_fd)
        if not (
            _same_stable_metadata(source_path_stat, os.fstat(source_fd))
            and _same_stable_metadata(os.fstat(source_fd), source.lstat())
        ):
            raise VerificationError("frozen evidence root changed during copy")
    except Exception:
        if destination.exists() and not destination.is_symlink():
            shutil.rmtree(destination)
        raise
    finally:
        os.close(source_fd)


def _freeze_candidate_tree(root: Path) -> None:
    for path in [root, *root.rglob("*")]:
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix() if path != root else "."
        if stat.S_ISLNK(metadata.st_mode) or not (
            stat.S_ISDIR(metadata.st_mode) or stat.S_ISREG(metadata.st_mode)
        ):
            raise VerificationError(f"unsupported frozen entry: {relative}")
        os.chown(path, TRUSTED_UID, TRUSTED_GID, follow_symlinks=False)
        if stat.S_ISDIR(metadata.st_mode):
            os.chmod(path, 0o555)
        else:
            executable = bool(metadata.st_mode & 0o111) or relative == "launch.sh"
            os.chmod(path, 0o555 if executable else 0o444)


def _require_candidate_runtime_root() -> None:
    run_metadata = CANDIDATE_RUNTIME_ROOT.parent.lstat()
    if (
        stat.S_ISLNK(run_metadata.st_mode)
        or not stat.S_ISDIR(run_metadata.st_mode)
        or run_metadata.st_uid != TRUSTED_UID
        or run_metadata.st_gid != TRUSTED_GID
    ):
        raise VerificationError("/run is not a trusted real directory")
    try:
        metadata = CANDIDATE_RUNTIME_ROOT.lstat()
    except FileNotFoundError:
        CANDIDATE_RUNTIME_ROOT.mkdir(mode=0o700)
        os.chown(CANDIDATE_RUNTIME_ROOT, TRUSTED_UID, TRUSTED_GID)
        os.chmod(CANDIDATE_RUNTIME_ROOT, 0o711)
        metadata = CANDIDATE_RUNTIME_ROOT.lstat()
    if (
        stat.S_ISLNK(metadata.st_mode)
        or not stat.S_ISDIR(metadata.st_mode)
        or metadata.st_uid != TRUSTED_UID
        or metadata.st_gid != TRUSTED_GID
        or stat.S_IMODE(metadata.st_mode) != 0o711
    ):
        raise VerificationError("candidate runtime root has unsafe ownership or mode")


def _validate_candidate_runtime_tree(root: Path) -> None:
    for path in [root, *root.rglob("*")]:
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix() if path != root else "."
        if metadata.st_uid != TRUSTED_UID or metadata.st_gid != TRUSTED_GID:
            raise VerificationError(f"candidate runtime owner is unsafe: {relative}")
        if stat.S_ISDIR(metadata.st_mode):
            valid = stat.S_IMODE(metadata.st_mode) == 0o555
        elif stat.S_ISREG(metadata.st_mode):
            valid = stat.S_IMODE(metadata.st_mode) in {0o444, 0o555}
        else:
            valid = False
        if not valid:
            raise VerificationError(f"candidate runtime type/mode is unsafe: {relative}")


def _remove_trusted_runtime_tree(path: Path) -> None:
    if path.is_symlink() or not path.is_dir():
        raise VerificationError("candidate runtime cleanup target is unsafe")
    for directory in [path, *(item for item in path.rglob("*") if item.is_dir())]:
        if directory.is_symlink():
            raise VerificationError("candidate runtime cleanup found a symlink")
        directory.chmod(0o700)
    shutil.rmtree(path)


def clear_candidate_execution_root() -> None:
    """Post-verify and remove the canonical execution copy, or fail closed."""

    _require_candidate_runtime_root()
    entries = set(CANDIDATE_RUNTIME_ROOT.iterdir())
    if not entries:
        return
    if entries != {CANDIDATE_RUNTIME_SUBMISSION, CANDIDATE_RUNTIME_DIGEST}:
        raise VerificationError("candidate runtime root contains unexpected entries")
    marker = CANDIDATE_RUNTIME_DIGEST.lstat()
    if (
        stat.S_ISLNK(marker.st_mode)
        or not stat.S_ISREG(marker.st_mode)
        or marker.st_uid != TRUSTED_UID
        or marker.st_gid != TRUSTED_GID
        or stat.S_IMODE(marker.st_mode) != 0o600
        or marker.st_size > 128
    ):
        raise VerificationError("candidate runtime digest marker is unsafe")
    expected = CANDIDATE_RUNTIME_DIGEST.read_text(encoding="ascii").strip()
    if re.fullmatch(r"[0-9a-f]{64}", expected) is None:
        raise VerificationError("candidate runtime digest marker is invalid")
    if (
        CANDIDATE_RUNTIME_SUBMISSION.is_symlink()
        or not CANDIDATE_RUNTIME_SUBMISSION.is_dir()
    ):
        raise VerificationError("candidate runtime submission is unsafe")
    _validate_candidate_runtime_tree(CANDIDATE_RUNTIME_SUBMISSION)
    if submission_tree_sha256(CANDIDATE_RUNTIME_SUBMISSION) != expected:
        raise VerificationError("candidate runtime tree changed after staging")
    _remove_trusted_runtime_tree(CANDIDATE_RUNTIME_SUBMISSION)
    CANDIDATE_RUNTIME_DIGEST.unlink()
    if any(CANDIDATE_RUNTIME_ROOT.iterdir()):
        raise VerificationError("candidate runtime cleanup left unexpected entries")


def stage_candidate_execution(source: Path) -> Path:
    """FD-copy evidence to the only path visible in candidate argv/cwd."""

    clear_candidate_execution_root()
    expected = submission_tree_sha256(source)
    temporary = CANDIDATE_RUNTIME_ROOT / f".submission.{uuid.uuid4().hex}.tmp"
    marker_temporary = CANDIDATE_RUNTIME_ROOT / (
        f".submission.sha256.{uuid.uuid4().hex}.tmp"
    )
    try:
        _secure_copy_frozen_tree(source, temporary)
        _freeze_candidate_tree(temporary)
        if submission_tree_sha256(source) != expected:
            raise VerificationError("frozen evidence changed while runtime was staged")
        if submission_tree_sha256(temporary) != expected:
            raise VerificationError("candidate runtime copy digest mismatch")
        _validate_candidate_runtime_tree(temporary)
        with marker_temporary.open("x", encoding="ascii") as handle:
            handle.write(expected + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chown(marker_temporary, TRUSTED_UID, TRUSTED_GID)
        os.chmod(marker_temporary, 0o600)
        os.replace(temporary, CANDIDATE_RUNTIME_SUBMISSION)
        os.replace(marker_temporary, CANDIDATE_RUNTIME_DIGEST)
        _validate_candidate_runtime_tree(CANDIDATE_RUNTIME_SUBMISSION)
        if submission_tree_sha256(CANDIDATE_RUNTIME_SUBMISSION) != expected:
            raise VerificationError("installed candidate runtime digest mismatch")
        return CANDIDATE_RUNTIME_SUBMISSION
    except Exception:
        for path in (temporary, CANDIDATE_RUNTIME_SUBMISSION):
            if path.exists() and not path.is_symlink():
                _remove_trusted_runtime_tree(path)
        marker_temporary.unlink(missing_ok=True)
        CANDIDATE_RUNTIME_DIGEST.unlink(missing_ok=True)
        raise


def freeze_submission(path: Path) -> Path:
    if path.is_symlink() or not path.is_dir():
        raise VerificationError("submission must be a real directory")
    if not (path / "launch.sh").is_file():
        raise VerificationError("submission/launch.sh is missing")
    if (path / "launch.sh").is_symlink():
        raise VerificationError("launch.sh may not be a symlink")
    files = list(path.rglob("*"))
    if len(files) > 2000:
        raise VerificationError("submission contains too many files")
    if sum(item.stat().st_size for item in files if item.is_file() and not item.is_symlink()) > 100 * 1024**2:
        raise VerificationError("submission is larger than 100 MiB")
    for item in files:
        mode = item.lstat().st_mode
        if stat.S_ISLNK(mode) or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise VerificationError(f"unsupported submission entry: {item}")

    snapshot_root = Path("/run/kvbench-verifier")
    snapshot_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chown(snapshot_root, TRUSTED_UID, TRUSTED_GID)
    os.chmod(snapshot_root, 0o700)
    snapshot = snapshot_root / "submission"
    if snapshot.exists():
        for item in snapshot.rglob("*"):
            if item.is_dir():
                os.chmod(item, 0o700)
        os.chmod(snapshot, 0o700)
        shutil.rmtree(snapshot)
    shutil.copytree(path, snapshot, symlinks=False)
    _freeze_candidate_tree(snapshot)
    seal_original_submission(path)
    scrub_candidate_state(path)
    return snapshot


def seal_original_submission(path: Path) -> None:
    """Keep Harbor artifacts readable while eliminating a mutable shadow tree."""
    for item in sorted(path.rglob("*"), reverse=True):
        if item.is_dir():
            mode = 0o555
        else:
            mode = 0o555 if item.stat().st_mode & 0o111 else 0o444
        os.chown(item, 0, 0, follow_symlinks=False)
        os.chmod(item, mode, follow_symlinks=False)
    os.chown(path, 0, 0)
    os.chmod(path, 0o555)


def remove_entry(path: Path) -> None:
    if path.is_symlink() or not path.is_dir():
        path.unlink(missing_ok=True)
    else:
        shutil.rmtree(path)


def scrub_candidate_state(submission: Path) -> None:
    """Remove agent-created dependencies outside the frozen deliverable."""
    for root in (Path("/home/candidate"), Path("/tmp"), Path("/dev/shm")):
        if not root.is_dir():
            continue
        for entry in root.iterdir():
            try:
                owned_by_candidate = entry.lstat().st_uid == 1000
            except FileNotFoundError:
                continue
            if root == Path("/home/candidate") or owned_by_candidate:
                remove_entry(entry)
    home = Path("/home/candidate")
    home.mkdir(mode=0o555, parents=True, exist_ok=True)
    os.chown(home, 0, 0)
    os.chmod(home, 0o555)

    app_root = submission.parent
    for entry in app_root.iterdir():
        if entry.name not in {submission.name, "feedback"}:
            remove_entry(entry)
    os.chown(app_root, 0, 0)
    os.chmod(app_root, 0o755)


def check_isolation(token_path: Path) -> dict[str, Any]:
    forbidden = [Path("/model"), Path("/opt/model-repo"), Path("/var/run/docker.sock")]
    present = [str(path) for path in forbidden if path.exists()]
    gpu_devices = sorted(str(path) for path in Path("/dev").glob("nvidia*"))
    if present or gpu_devices:
        raise VerificationError(f"candidate container isolation failed: paths={present}, gpus={gpu_devices}")
    token_stat = token_path.stat()
    if token_stat.st_uid != 0 or stat.S_IMODE(token_stat.st_mode) != 0o400 or not stat.S_ISREG(token_stat.st_mode):
        raise VerificationError("admin token is not a root-owned 0400 regular file")
    readable = subprocess.run(
        ["setpriv", "--reuid", "candidate", "--regid", "candidate", "--init-groups", "test", "-r", str(token_path)],
        check=False,
    ).returncode == 0
    if readable:
        raise VerificationError("candidate UID can read the admin token")
    candidate_status = subprocess.check_output(
        [
            "setpriv",
            "--reuid",
            "candidate",
            "--regid",
            "candidate",
            "--init-groups",
            "--no-new-privs",
            "sh",
            "-c",
            "grep -E '^(CapPrm|CapEff|NoNewPrivs):' /proc/self/status",
        ],
        text=True,
    )
    status_fields = dict(line.split(":", 1) for line in candidate_status.splitlines())
    candidate_caps = {
        "permitted": status_fields.get("CapPrm", "").strip(),
        "effective": status_fields.get("CapEff", "").strip(),
        "no_new_privs": status_fields.get("NoNewPrivs", "").strip(),
    }
    if candidate_caps != {
        "permitted": "0000000000000000",
        "effective": "0000000000000000",
        "no_new_privs": "1",
    }:
        raise VerificationError(f"candidate process capability isolation failed: {candidate_caps}")
    return {
        "forbidden_paths_present": present,
        "gpu_devices": gpu_devices,
        "candidate_can_read_admin_token": readable,
        "candidate_capabilities": candidate_caps,
    }


def _selected_attestation_contract() -> dict[str, Any]:
    present = [name for name in ATTESTATION_OVERRIDE_NAMES if os.environ.get(name)]
    if present and len(present) != len(ATTESTATION_OVERRIDE_NAMES):
        missing = sorted(set(ATTESTATION_OVERRIDE_NAMES) - set(present))
        raise VerificationError(
            f"environment-selected Qwen attestation contract is incomplete: {missing}"
        )
    if not present:
        return {
            "profile_id": EXPECTED_PROFILE,
            "profile_sha256": EXPECTED_PROFILE_SHA256,
            "revision": EXPECTED_REVISION,
            "runtime_image_ref": EXPECTED_RUNTIME_IMAGE_REF,
            "runtime_image_id": EXPECTED_RUNTIME_IMAGE_ID,
            "vllm_package_version": EXPECTED_VLLM_PACKAGE,
            "gpu_uuids": EXPECTED_GPU_UUIDS,
        }
    try:
        gpu_uuids = tuple(
            value.strip()
            for value in os.environ["KV_EXPECTED_GPU_UUIDS"].split(",")
            if value.strip()
        )
    except KeyError as exc:  # Defensive: the completeness check above should catch this.
        raise VerificationError("KV_EXPECTED_GPU_UUIDS is missing") from exc
    selected = {
        "profile_id": os.environ["KV_EXPECTED_MODEL_PROFILE_ID"],
        "profile_sha256": os.environ["KV_EXPECTED_MODEL_PROFILE_SHA256"],
        "revision": os.environ["KV_EXPECTED_MODEL_REVISION"],
        "runtime_image_ref": os.environ["KV_EXPECTED_RUNTIME_IMAGE_REF"],
        "runtime_image_id": os.environ["KV_EXPECTED_RUNTIME_IMAGE_ID"],
        "vllm_package_version": os.environ["KV_EXPECTED_VLLM_PACKAGE"],
        "gpu_uuids": gpu_uuids,
    }
    # An environment override selects physical runtime identity, not another
    # model family or an unfrozen profile.
    if (
        selected["profile_id"] != EXPECTED_PROFILE
        or selected["profile_sha256"] != EXPECTED_PROFILE_SHA256
        or selected["revision"] != EXPECTED_REVISION
        or selected["runtime_image_ref"] != EXPECTED_RUNTIME_IMAGE_REF
        or selected["runtime_image_id"] != EXPECTED_RUNTIME_IMAGE_ID
        or selected["vllm_package_version"] != EXPECTED_VLLM_PACKAGE
        or len(gpu_uuids) != 2
        or len(set(gpu_uuids)) != 2
    ):
        raise VerificationError("environment-selected Qwen attestation contract is not frozen")
    return selected


def _require_positive_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
        raise VerificationError(f"attestation {field} must be a positive number")
    return float(value)


def validate_attestation(attestation: dict[str, Any]) -> None:
    selected = _selected_attestation_contract()
    model = attestation.get("model") or {}
    runtime = attestation.get("runtime") or {}
    gpus = attestation.get("gpus") or []
    transport = attestation.get("transport") or {}
    process = attestation.get("process") or {}
    container = attestation.get("container") or {}

    if attestation.get("schema_version") != 1:
        raise VerificationError("unsupported external vLLM attestation schema")
    if attestation.get("state") != "ready":
        raise VerificationError("external vLLM attestation is not ready")
    if attestation.get("preflight_status") != "ok":
        raise VerificationError("external vLLM host preflight is not successful")
    if attestation.get("model_mount_read_only") is not True:
        raise VerificationError("external vLLM model mount is not attested read-only")

    preflight_unix = _require_positive_number(
        attestation.get("preflight_created_unix"), "preflight_created_unix"
    )
    created_unix = _require_positive_number(attestation.get("created_unix"), "created_unix")
    ready_unix = _require_positive_number(attestation.get("ready_unix"), "ready_unix")
    if not preflight_unix <= created_unix <= ready_unix:
        raise VerificationError("external vLLM attestation timestamps are incoherent")

    if (
        attestation.get("profile_id") != selected["profile_id"]
        or attestation.get("profile_sha256") != selected["profile_sha256"]
        or model.get("profile_id") != selected["profile_id"]
        or model.get("revision") != selected["revision"]
    ):
        raise VerificationError("Qwen3.6-27B revision/profile attestation mismatch")
    if model.get("file_hashes") != EXPECTED_REQUIRED_FILE_HASHES:
        raise VerificationError("Qwen3.6-27B required-file attestation mismatch")
    if (
        model.get("shard_count") != 15
        or model.get("tensor_count") != 1199
        or model.get("index_total_size") != 55562855904
        or model.get("stat_total_size") != 55563006400
        or model.get("hf_symlink_manifest_sha256")
        != "91241d609ad30b9ed110284ea48e2ea740a2cba9ecb248a107fbd6295a62f4bb"
    ):
        raise VerificationError("Qwen3.6-27B weight-shard attestation mismatch")

    expected_runtime = dict(EXPECTED_RUNTIME)
    expected_runtime.update(
        {
            "runtime_image_ref": selected["runtime_image_ref"],
            "runtime_image_id": selected["runtime_image_id"],
            "vllm_package_version": selected["vllm_package_version"],
        }
    )
    if runtime != expected_runtime:
        raise VerificationError("frozen external Qwen vLLM runtime attestation mismatch")
    if attestation.get("observed_vllm_package_version") != selected["vllm_package_version"]:
        raise VerificationError("observed external vLLM package version mismatch")

    expected_uuids = tuple(selected["gpu_uuids"])
    if (
        not isinstance(gpus, list)
        or len(gpus) != 2
        or tuple(gpu.get("uuid") for gpu in gpus) != expected_uuids
        or [gpu.get("index") for gpu in gpus] != [6, 7]
    ):
        raise VerificationError("external vLLM GPU UUID/order attestation mismatch")
    for gpu in gpus:
        if (
            gpu.get("name") != "NVIDIA H100 NVL"
            or gpu.get("memory_mib") != 95830
            or gpu.get("compute_capability") != "9.0"
        ):
            raise VerificationError(f"external vLLM H100 attestation mismatch: {gpu}")

    socket_path = transport.get("socket_path")
    if (
        transport.get("kind") != "unix"
        or transport.get("container_socket_path") != EXPECTED_CONTAINER_SOCKET
        or not isinstance(socket_path, str)
        or not socket_path.startswith("/")
        or Path(socket_path).name != "vllm.sock"
        or os.path.normpath(socket_path) != socket_path
    ):
        raise VerificationError("external vLLM Unix-socket transport attestation mismatch")

    if (
        process.get("tmux_session") != EXPECTED_TMUX_SESSION
        or isinstance(process.get("wrapper_pid"), bool)
        or not isinstance(process.get("wrapper_pid"), int)
        or process["wrapper_pid"] < 2
        or isinstance(process.get("wrapper_start_ticks"), bool)
        or not isinstance(process.get("wrapper_start_ticks"), int)
        or process["wrapper_start_ticks"] < 1
    ):
        raise VerificationError("external vLLM tmux/process identity attestation mismatch")
    if (
        container.get("name") != EXPECTED_CONTAINER_NAME
        or container.get("image_ref") != selected["runtime_image_ref"]
        or container.get("image_id") != selected["runtime_image_id"]
        or container.get("environment") != {"VLLM_SERVER_DEV_MODE": "1"}
        or not re.fullmatch(r"[0-9a-f]{64}", str(container.get("id", "")))
        or not re.fullmatch(
            r"[0-9a-f]{64}", str(container.get("launch_token_sha256", ""))
        )
    ):
        raise VerificationError("external vLLM container identity attestation mismatch")

    command = attestation.get("vllm_command")
    if not isinstance(command, list) or not command or not all(isinstance(value, str) for value in command):
        raise VerificationError("external vLLM command attestation is invalid")
    if (
        command[:2] != ["/usr/local/bin/vllm", "serve"]
        or len(command) < 3
        or Path(command[2]).name != EXPECTED_REVISION
    ):
        raise VerificationError("external vLLM command does not serve the frozen Qwen snapshot")
    expected_command = [
        "/usr/local/bin/vllm",
        "serve",
        command[2],
        "--served-model-name",
        "target-model",
        "--uds",
        EXPECTED_CONTAINER_SOCKET,
        "--tensor-parallel-size",
        "2",
        "--model-impl",
        "vllm",
        "--runner",
        "generate",
        "--language-model-only",
        "--mm-processor-cache-gb",
        "0",
        "--dtype",
        "bfloat16",
        "--kv-cache-dtype",
        "fp8",
        "--enable-prefix-caching",
        "--mamba-cache-mode",
        "align",
        "--mamba-ssm-cache-dtype",
        "float32",
        "--gdn-prefill-backend",
        "triton",
        "--block-size",
        "16",
        "--max-model-len",
        "262144",
        "--max-num-seqs",
        "192",
        "--max-num-batched-tokens",
        "8192",
        "--kv-cache-memory-bytes",
        "32212254720",
        "--gpu-memory-utilization",
        "0.9",
        "--enable-chunked-prefill",
        "--load-format",
        "safetensors",
        "--safetensors-load-strategy",
        "lazy",
        "--reasoning-parser",
        "qwen3",
        "--generation-config",
        "vllm",
        "--no-enable-log-requests",
        "--disable-uvicorn-access-log",
        "--no-fail-on-environ-validation",
    ]
    if command != expected_command:
        raise VerificationError("external Qwen vLLM command differs from the frozen UDS command")


def _quoted_metric_label(labels: Any, key: str) -> str | None:
    if not isinstance(labels, str):
        return None
    match = re.search(rf'(?:^|,){re.escape(key)}="([^"]*)"', labels)
    return match.group(1) if match else None


def validate_hybrid_cache_metrics(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Validate the resolved hybrid-page facts already exposed by vLLM.

    The host readiness file attests the immutable launch inputs, including the
    user-requested 16-token block size.  Resolved hybrid allocation facts only
    exist after engine initialization, so Phase-0 binds those facts through
    the trusted metrics snapshot instead of inventing an unsupported startup
    attestation field.
    """

    if snapshot.get("schema_version") != 1:
        raise VerificationError("unsupported trusted metrics snapshot schema")
    samples = snapshot.get("samples")
    if not isinstance(samples, list):
        raise VerificationError("trusted metrics snapshot has no sample list")
    cache_samples = [
        sample
        for sample in samples
        if isinstance(sample, dict)
        and sample.get("name") == "vllm:cache_config_info"
    ]
    if len(cache_samples) != 1:
        raise VerificationError(
            "expected exactly one vllm:cache_config_info sample for the frozen engine"
        )
    sample = cache_samples[0]
    value = sample.get("value")
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or float(value) != 1.0
    ):
        raise VerificationError("vllm:cache_config_info gauge is not asserted")

    expected_labels = {
        "_block_size_resolved": "True",
        "block_size": str(EXPECTED_HYBRID_CACHE_ACCOUNTING["attention_page_tokens"]),
        "num_gpu_blocks": str(EXPECTED_HYBRID_CACHE_ACCOUNTING["raw_gpu_blocks"]),
        "kv_cache_size_tokens": str(
            EXPECTED_HYBRID_CACHE_ACCOUNTING[
                "reported_logical_capacity_tokens"
            ]
        ),
    }
    observed_labels = {
        key: _quoted_metric_label(sample.get("labels"), key)
        for key in expected_labels
    }
    if observed_labels != expected_labels:
        raise VerificationError(
            "frozen Qwen hybrid cache metrics mismatch: "
            f"{observed_labels!r} != {expected_labels!r}"
        )

    accounting = dict(EXPECTED_HYBRID_CACHE_ACCOUNTING)
    if accounting["capacity_pages"] != (
        accounting["raw_gpu_blocks"] - accounting["reserved_null_blocks"]
    ):
        raise VerificationError("frozen Qwen usable-page derivation is incoherent")
    if accounting["fixed_mamba_pages_per_program"] != (
        accounting["mamba_group_count"]
        * accounting["mamba_resident_pages_per_group"]
    ):
        raise VerificationError("frozen Qwen resident Mamba-page derivation is incoherent")
    if accounting["transient_mamba_pages_per_program"] != (
        accounting["mamba_group_count"]
        * (
            accounting["mamba_peak_pages_per_group"]
            - accounting["mamba_resident_pages_per_group"]
        )
    ):
        raise VerificationError("frozen Qwen transient Mamba-page derivation is incoherent")
    return accounting


def launch_gateway(
    submission: Path,
    backend: str,
    *,
    log_name: str | None = "gateway.log",
) -> subprocess.Popen[bytes]:
    if log_name is not None and not re.fullmatch(r"[A-Za-z0-9_.-]+\.log", log_name):
        raise VerificationError("gateway log name is invalid")
    runtime_submission = stage_candidate_execution(submission)
    environment = {
        "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "HOME": "/home/candidate",
        "PYTHONDONTWRITEBYTECODE": "1",
        "BACKEND_URL": backend,
        "PORT": "9000",
    }
    log = None
    stdout: int | Any = subprocess.DEVNULL
    stderr: int = subprocess.DEVNULL
    try:
        if log_name is not None:
            log_root = Path("/logs/verifier")
            log_root.mkdir(mode=0o700, parents=True, exist_ok=True)
            os.chown(log_root, 0, 0)
            os.chmod(log_root, 0o700)
            descriptor = os.open(
                log_root / log_name,
                os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_CLOEXEC,
                0o600,
            )
            os.fchmod(descriptor, 0o600)
            log = os.fdopen(descriptor, "wb")
            stdout = log
            stderr = subprocess.STDOUT
        return subprocess.Popen(
            [
                "setpriv",
                "--reuid",
                "candidate",
                "--regid",
                "candidate",
                "--init-groups",
                "--no-new-privs",
                str(runtime_submission / "launch.sh"),
            ],
            cwd=runtime_submission,
            env=environment,
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
    except Exception:
        clear_candidate_execution_root()
        raise
    finally:
        if log is not None:
            log.close()


def wait_gateway(process: subprocess.Popen[bytes]) -> None:
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise VerificationError(f"gateway exited during startup with code {process.returncode}")
        try:
            status, _ = http("GET", "http://127.0.0.1:9000/health", timeout=2)
            if 200 <= status < 300:
                return
        except OSError:
            pass
        time.sleep(0.25)
    raise VerificationError("gateway did not become healthy within 30 seconds")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission", type=Path, required=True)
    parser.add_argument("--backend", required=True)
    parser.add_argument("--admin-base", required=True)
    parser.add_argument("--admin-token-file", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--reward-json", type=Path, required=True)
    parser.add_argument("--reward-txt", type=Path, required=True)
    args = parser.parse_args()

    report: dict[str, Any] = {"schema_version": 1, "phase": 0, "checks": {}}
    process: subprocess.Popen[bytes] | None = None
    try:
        report["checks"]["isolation"] = check_isolation(args.admin_token_file)
        token = args.admin_token_file.read_text().strip()
        health_status, health_body = http("GET", f"{args.admin_base}/health", timeout=10)
        if health_status != 200:
            raise VerificationError(f"model API died with the agent: {health_status} {health_body!r}")
        report["checks"]["shared_lifecycle"] = {
            "model_api_healthy_after_agent_kill": True,
            "http_status": health_status,
        }
        attestation = admin("GET", args.admin_base, "/admin/attestation", token)
        validate_attestation(attestation)
        report["checks"]["attestation"] = attestation
        metrics_snapshot = admin(
            "GET", args.admin_base, "/admin/metrics/snapshot", token
        )
        report["checks"]["hybrid_cache_accounting"] = (
            validate_hybrid_cache_metrics(metrics_snapshot)
        )

        frozen_submission = freeze_submission(args.submission)
        process = launch_gateway(frozen_submission, args.backend)
        wait_gateway(process)

        # The trusted model API requires the same epoch-bound request HMAC for
        # model discovery as it does for completions.  Keep this discovery in
        # its own measurement epoch so the stream audit below can still prove
        # that exactly one completion reached the backend.
        models_reset = admin("POST", args.admin_base, "/admin/measurement/reset", token)
        models_audit_epoch = int(models_reset["audit_epoch"])
        models_request_id = str(uuid.uuid4())
        models_run_id = "phase0-models-run"
        models_profile = uuid.uuid4().hex[:24]
        models_leg_id = uuid.uuid4().hex
        models_cache_namespace = uuid.uuid4().hex
        empty_digest = hashlib.sha256(b"").hexdigest()
        models_auth_fields = {
            "audit_epoch": models_audit_epoch,
            "body_digest": empty_digest,
            "cache_namespace": models_cache_namespace,
            "leg_id": models_leg_id,
            "method": "GET",
            "path": "/v1/models",
            "profile": models_profile,
            "request_id": models_request_id,
            "run_id": models_run_id,
        }
        models_canonical_auth = json.dumps(
            models_auth_fields,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
        models_auth = hmac.new(
            token.encode(),
            b"kvbench-data-request-v2\n" + models_canonical_auth,
            hashlib.sha256,
        ).hexdigest()
        models_headers = {
            "X-Agent-Run-ID": models_run_id,
            "X-KVBench-Request-ID": models_request_id,
            "X-KVBench-Auth": models_auth,
            "X-KVBench-Audit-Epoch": str(models_audit_epoch),
            "X-KVBench-Body-SHA256": empty_digest,
            "X-KVBench-Profile": models_profile,
            "X-KVBench-Leg": models_leg_id,
            "X-KVBench-Cache-Namespace": models_cache_namespace,
        }
        status, models_body = http(
            "GET",
            "http://127.0.0.1:9000/v1/models",
            headers=models_headers,
        )
        if status != 200:
            raise VerificationError(
                f"gateway models endpoint returned {status}: {models_body!r}"
            )
        models = json.loads(models_body)
        if not any(model.get("id") == "target-model" for model in models.get("data", [])):
            raise VerificationError(f"gateway models endpoint is incompatible: {status} {models}")

        reset = admin("POST", args.admin_base, "/admin/measurement/reset", token)
        audit_epoch = int(reset["audit_epoch"])
        request_id = str(uuid.uuid4())
        run_id = "phase0-stream-run"
        profile_token = uuid.uuid4().hex[:24]
        leg_id = uuid.uuid4().hex
        cache_namespace = uuid.uuid4().hex
        payload = json.dumps(
            {
                "model": "target-model",
                "messages": [{"role": "user", "content": "Reply with exactly OK."}],
                "temperature": 0,
                "seed": 1234,
                "max_tokens": 16,
                "stream": True,
                "stream_options": {"include_usage": True},
            },
            separators=(",", ":"),
        ).encode()
        body_digest = hashlib.sha256(payload).hexdigest()
        auth_fields = {
            "audit_epoch": audit_epoch,
            "body_digest": body_digest,
            "cache_namespace": cache_namespace,
            "leg_id": leg_id,
            "method": "POST",
            "path": "/v1/chat/completions",
            "profile": profile_token,
            "request_id": request_id,
            "run_id": run_id,
        }
        canonical_auth = json.dumps(
            auth_fields,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
        auth = hmac.new(
            token.encode(),
            b"kvbench-data-request-v2\n" + canonical_auth,
            hashlib.sha256,
        ).hexdigest()
        headers = {
            "Content-Type": "application/json",
            "X-Agent-Run-ID": run_id,
            "X-KVBench-Request-ID": request_id,
            "X-KVBench-Auth": auth,
            "X-KVBench-Audit-Epoch": str(audit_epoch),
            "X-KVBench-Body-SHA256": body_digest,
            "X-KVBench-Profile": profile_token,
            "X-KVBench-Leg": leg_id,
            "X-KVBench-Cache-Namespace": cache_namespace,
        }
        status, streamed_body = http(
            "POST", "http://127.0.0.1:9000/v1/chat/completions", body=payload, headers=headers, timeout=300
        )
        if status != 200 or b"data: [DONE]" not in streamed_body:
            raise VerificationError(f"streaming completion failed: {status} {streamed_body[-500:]!r}")

        snapshot = admin("GET", args.admin_base, "/admin/audit/snapshot", token)
        records = snapshot.get("records", [])
        if len(records) != 1:
            raise VerificationError(f"expected one audited backend request, got {len(records)}")
        record = records[0]
        response_digest = hashlib.sha256(streamed_body).hexdigest()
        expected = {
            "request_id": request_id,
            "run_id": run_id,
            "benchmark_auth_valid": True,
            "canonical_body_digest": body_digest,
            "response_digest": response_digest,
            "status": 200,
        }
        for key, value in expected.items():
            if record.get(key) != value:
                raise VerificationError(f"audit mismatch for {key}: {record.get(key)!r} != {value!r}")
        report["checks"]["transparent_stream"] = expected
        report["reward"] = 1.0
    except Exception as exc:
        report["reward"] = 0.0
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if process and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
        try:
            clear_candidate_execution_root()
        except Exception as cleanup_exc:
            report["reward"] = 0.0
            report["error"] = (
                "candidate canonical runtime cleanup failed: "
                f"{type(cleanup_exc).__name__}: {cleanup_exc}"
            )

    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    args.reward_json.write_text(json.dumps({"reward": report["reward"], "phase0_infrastructure": report["reward"]}) + "\n")
    args.reward_txt.write_text(f"{report['reward']:.1f}\n")
    if report["reward"] != 1.0:
        print(report.get("error", "verification failed"))
        return 1
    print("Phase-0 infrastructure verifier passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
