#!/usr/bin/env python3
"""Deterministic OpenAI-proxy protocol cases backed by an in-process mock."""

from __future__ import annotations

import concurrent.futures
import gzip
import hashlib
import http.client
import json
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


class ProtocolError(RuntimeError):
    pass


class MockState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.records: list[dict[str, Any]] = []

    def append(self, record: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.records.append(record)
        return record

    def snapshot(self) -> list[dict[str, Any]]:
        with self.lock:
            return [record.copy() for record in self.records]

    def reset(self) -> None:
        with self.lock:
            self.records.clear()


STATE = MockState()
NONSTREAM_BODY = json.dumps(
    {
        "id": "mock-nonstream",
        "object": "chat.completion",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": "héllo 世界"}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
    },
    ensure_ascii=False,
    separators=(",", ":"),
).encode()
MODELS_BODY = b'{"object":"list","data":[{"id":"target-model","object":"model"}]}'
GZIP_BODY = gzip.compress(NONSTREAM_BODY, mtime=0)
STREAM_CHUNKS = [
    b'data: {"id":"mock-stream","choices":[{"index":0,"delta":{"content":"alpha"}}]}\n\n',
    b'data: {"id":"mock-stream","choices":[{"index":0,"delta":{"content":" beta"},"finish_reason":"stop"}]}\n\n',
    b'data: {"id":"mock-stream","choices":[],"usage":{"prompt_tokens":9,"completion_tokens":2,"total_tokens":11}}\n\n',
    b"data: [DONE]\n\n",
]


class MockHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "KVBenchMock/1"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _send(
        self,
        status: int,
        body: bytes,
        headers: dict[str, str] | list[tuple[str, str]] | None = None,
    ) -> None:
        self.send_response(status)
        pairs = headers.items() if isinstance(headers, dict) else (headers or [])
        for name, value in pairs:
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._send(200, b'{"status":"ok"}', {"Content-Type": "application/json"})
        elif self.path == "/v1/models":
            STATE.append(
                {
                    "kind": "models_get",
                    "run_id": self.headers.get("X-Agent-Run-ID"),
                    "request_id": self.headers.get("X-KVBench-Request-ID"),
                    "auth": self.headers.get("X-KVBench-Auth"),
                    "audit_epoch": self.headers.get("X-KVBench-Audit-Epoch"),
                    "claimed_body_sha256": self.headers.get("X-KVBench-Body-SHA256"),
                    "profile": self.headers.get("X-KVBench-Profile"),
                    "leg_id": self.headers.get("X-KVBench-Leg"),
                    "cache_namespace": self.headers.get("X-KVBench-Cache-Namespace"),
                    "authorization": self.headers.get("Authorization"),
                }
            )
            self._send(
                200,
                MODELS_BODY,
                {"Content-Type": "application/json", "X-Mock-Models": "forwarded"},
            )
        else:
            self._send(404, b'{"error":"not_found"}', {"Content-Type": "application/json"})

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        record = STATE.append(
            {
                "body_sha256": hashlib.sha256(body).hexdigest(),
                "run_id": self.headers.get("X-Agent-Run-ID"),
                "request_id": self.headers.get("X-KVBench-Request-ID"),
                "auth": self.headers.get("X-KVBench-Auth"),
                "audit_epoch": self.headers.get("X-KVBench-Audit-Epoch"),
                "claimed_body_sha256": self.headers.get("X-KVBench-Body-SHA256"),
                "profile": self.headers.get("X-KVBench-Profile"),
                "leg_id": self.headers.get("X-KVBench-Leg"),
                "cache_namespace": self.headers.get("X-KVBench-Cache-Namespace"),
                "authorization": self.headers.get("Authorization"),
                "large_opaque": self.headers.get("X-Large-Opaque"),
                "repeat_values": self.headers.get_all("X-Repeat") or [],
                "removed_header": self.headers.get("X-Remove"),
                "connection_values": self.headers.get_all("Connection") or [],
                "content_encoding": self.headers.get("Content-Encoding"),
                "started_unix": time.time(),
                "ended_unix": None,
                "client_disconnected": False,
            }
        )
        try:
            if self.path != "/v1/chat/completions":
                self._send(404, b'{"error":"not_found"}')
                return
            try:
                payload = json.loads(body)
                messages = payload.get("messages") or []
                marker = str((messages[-1] if messages else {}).get("content", ""))
            except (json.JSONDecodeError, UnicodeDecodeError):
                self._send(400, b'{"error":{"type":"invalid_json","message":"malformed"}}', {"Content-Type": "application/json"})
                return
            if marker.startswith("case-status-429"):
                self._send(
                    429,
                    b'{"error":{"type":"rate_limit","message":"mock 429"}}',
                    {"Content-Type": "application/json", "Retry-After": "7"},
                )
            elif marker.startswith("case-status-500"):
                self._send(
                    500,
                    b'{"error":{"type":"server_error","message":"mock 500"}}',
                    {"Content-Type": "application/json"},
                )
            elif marker.startswith("case-stream"):
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "close")
                self.end_headers()
                for chunk in STREAM_CHUNKS:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                    time.sleep(0.015)
            elif marker.startswith("case-disconnect"):
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Connection", "close")
                self.end_headers()
                for index in range(80):
                    data = b"x" * 65536
                    chunk = b'data: {"choices":[{"delta":{"content":"' + data + b'"}}],"n":' + str(index).encode() + b"}\n\n"
                    self.wfile.write(chunk)
                    self.wfile.flush()
                    time.sleep(0.03)
            elif marker.startswith("case-preheader-disconnect"):
                time.sleep(1.5)
                self._send(
                    200,
                    NONSTREAM_BODY,
                    {"Content-Type": "application/json", "X-Mock-Case": "preheader"},
                )
            elif marker.startswith("case-delay"):
                time.sleep(0.25)
                self._send(200, NONSTREAM_BODY, {"Content-Type": "application/json", "X-Mock-Case": "delay"})
            elif marker.startswith("case-gzip"):
                self._send(
                    200,
                    GZIP_BODY,
                    {
                        "Content-Type": "application/json",
                        "Content-Encoding": "gzip",
                        "X-Mock-Case": "gzip",
                    },
                )
            elif marker.startswith("case-repeat-headers"):
                self._send(
                    200,
                    NONSTREAM_BODY,
                    [
                        ("Content-Type", "application/json"),
                        ("X-Repeat-Response", "one"),
                        ("X-Repeat-Response", "two"),
                        ("Connection", "X-Remove-Response"),
                        ("X-Remove-Response", "must-not-forward"),
                    ],
                )
            else:
                self._send(200, NONSTREAM_BODY, {"Content-Type": "application/json", "X-Mock-Case": "nonstream"})
        except (BrokenPipeError, ConnectionResetError, socket.error):
            record["client_disconnected"] = True
        finally:
            record["ended_unix"] = time.time()


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 128


def request(
    method: str,
    path: str,
    body: bytes | None = None,
    headers: dict[str, str] | list[tuple[str, str]] | None = None,
    timeout: float = 30,
) -> tuple[int, bytes, list[tuple[str, str]]]:
    connection = http.client.HTTPConnection("127.0.0.1", 9000, timeout=timeout)
    try:
        if isinstance(headers, list):
            connection.putrequest(method, path)
            for name, value in headers:
                connection.putheader(name, value)
            if body is not None and not any(
                name.lower() == "content-length" for name, _ in headers
            ):
                connection.putheader("Content-Length", str(len(body)))
            connection.endheaders(body)
        else:
            connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        payload = response.read()
        return response.status, payload, response.getheaders()
    finally:
        connection.close()


def chat_body(marker: str, *, stream: bool = False, padding: str = "") -> bytes:
    return json.dumps(
        {
            "model": "target-model",
            "messages": [{"role": "user", "content": marker + padding}],
            "max_tokens": 32,
            "temperature": 0,
            "stream": stream,
        },
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode()


def tracing_headers(index: int) -> dict[str, str]:
    return {
        "Content-Type": "application/json",
        "X-Agent-Run-ID": f"opaque-run-world-{index}",
        "X-KVBench-Request-ID": f"protocol-request-{index}",
        "X-KVBench-Auth": f"opaque-auth-{index}",
        "X-KVBench-Audit-Epoch": str(1000 + index),
        "X-KVBench-Body-SHA256": f"opaque-body-sha256-{index}",
        "X-KVBench-Profile": f"opaque-profile-{index}",
        "X-KVBench-Leg": f"opaque-leg-{index}",
        "X-KVBench-Cache-Namespace": f"opaque-cache-namespace-{index}",
        "Authorization": f"Bearer opaque-client-key-{index}",
    }


def assert_response(
    actual: tuple[int, bytes, list[tuple[str, str]]],
    *,
    status: int,
    body: bytes,
    header: tuple[str, str] | None = None,
) -> None:
    actual_status, actual_body, actual_headers = actual
    if actual_status != status or actual_body != body:
        raise ProtocolError(
            f"response mismatch: status={actual_status}/{status}, body_sha256={hashlib.sha256(actual_body).hexdigest()}/"
            f"{hashlib.sha256(body).hexdigest()}"
        )
    if header:
        values = [
            value
            for name, value in actual_headers
            if name.lower() == header[0].lower()
        ]
        if not values or values[-1] != header[1]:
            raise ProtocolError(f"response header mismatch: {header[0]}")


def verify_forwarded(expected: list[tuple[bytes, dict[str, str]]]) -> None:
    records = STATE.snapshot()
    by_digest: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        if "body_sha256" in record:
            by_digest.setdefault(record["body_sha256"], []).append(record)
    for body, headers in expected:
        digest = hashlib.sha256(body).hexdigest()
        matches = by_digest.get(digest, [])
        if len(matches) != 1:
            raise ProtocolError(f"body {digest} reached mock backend {len(matches)} times")
        record = matches[0]
        for header, key in (
            ("X-Agent-Run-ID", "run_id"),
            ("X-KVBench-Request-ID", "request_id"),
            ("X-KVBench-Auth", "auth"),
            ("X-KVBench-Audit-Epoch", "audit_epoch"),
            ("X-KVBench-Body-SHA256", "claimed_body_sha256"),
            ("X-KVBench-Profile", "profile"),
            ("X-KVBench-Leg", "leg_id"),
            ("X-KVBench-Cache-Namespace", "cache_namespace"),
            ("Authorization", "authorization"),
            ("X-Large-Opaque", "large_opaque"),
        ):
            if header in headers and record[key] != headers[header]:
                raise ProtocolError(f"gateway changed opaque header {header}")


def verify_models_forwarded(headers: dict[str, str]) -> None:
    records = [record for record in STATE.snapshot() if record.get("kind") == "models_get"]
    if len(records) != 1:
        raise ProtocolError(f"GET /v1/models reached mock backend {len(records)} times")
    record = records[0]
    for header, key in (
        ("X-Agent-Run-ID", "run_id"),
        ("X-KVBench-Request-ID", "request_id"),
        ("X-KVBench-Auth", "auth"),
        ("X-KVBench-Audit-Epoch", "audit_epoch"),
        ("X-KVBench-Body-SHA256", "claimed_body_sha256"),
        ("X-KVBench-Profile", "profile"),
        ("X-KVBench-Leg", "leg_id"),
        ("X-KVBench-Cache-Namespace", "cache_namespace"),
        ("Authorization", "authorization"),
    ):
        if record[key] != headers[header]:
            raise ProtocolError(f"gateway changed opaque models header {header}")


def run_protocol_cases(*, include_disconnect: bool = True) -> dict[str, Any]:
    # The full verifier calls this once, while author-side mutation tests call
    # it repeatedly in one process.  Starting from an empty ledger preserves
    # the same one-to-one audit contract in both cases.
    STATE.reset()
    server = ReusableThreadingHTTPServer(("127.0.0.1", 18080), MockHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    expected: list[tuple[bytes, dict[str, str]]] = []
    checks: list[str] = []
    try:
        models_headers = tracing_headers(0)
        assert_response(
            request("GET", "/v1/models", headers=models_headers),
            status=200,
            body=MODELS_BODY,
            header=("X-Mock-Models", "forwarded"),
        )
        checks.append("models")

        lifecycle_body = b'{"program_id":"protocol-lifecycle-only"}'
        lifecycle_headers = {
            "Content-Type": "application/json",
            "X-Agent-Run-ID": "protocol-lifecycle-only",
        }
        records_before_lifecycle = len(STATE.snapshot())
        lifecycle_status, _, _ = request(
            "POST",
            "/programs/release",
            lifecycle_body,
            lifecycle_headers,
        )
        if not (200 <= lifecycle_status < 300 or lifecycle_status in {404, 405}):
            raise ProtocolError(
                f"optional lifecycle endpoint returned {lifecycle_status}"
            )
        if len(STATE.snapshot()) != records_before_lifecycle:
            raise ProtocolError("lifecycle control request reached model backend")
        checks.append("lifecycle_control_not_forwarded")

        body = chat_body("case-nonstream")
        headers = tracing_headers(1)
        expected.append((body, headers))
        assert_response(
            request("POST", "/v1/chat/completions", body, headers),
            status=200,
            body=NONSTREAM_BODY,
            header=("X-Mock-Case", "nonstream"),
        )
        checks.append("nonstream_unicode")

        body = chat_body("case-gzip")
        headers = tracing_headers(8)
        expected.append((body, headers))
        assert_response(
            request("POST", "/v1/chat/completions", body, headers),
            status=200,
            body=GZIP_BODY,
            header=("Content-Encoding", "gzip"),
        )
        checks.append("compressed_body_bytes")

        # Inbound compression is transport metadata, not permission for the
        # gateway to rewrite the request body.  The mock intentionally does
        # not decode it, so a transparent proxy returns its invalid-JSON 400.
        plain_body = chat_body("case-compressed-request")
        body = gzip.compress(plain_body, mtime=0)
        headers = tracing_headers(9) | {"Content-Encoding": "gzip"}
        expected.append((body, headers))
        assert_response(
            request("POST", "/v1/chat/completions", body, headers),
            status=400,
            body=b'{"error":{"type":"invalid_json","message":"malformed"}}',
        )
        checks.append("compressed_request_bytes")

        # Repeated end-to-end headers must retain both values.  A field named
        # by Connection is dynamically hop-by-hop and must not cross either
        # side of the proxy.
        body = chat_body("case-repeat-headers")
        trace = tracing_headers(10)
        header_pairs = [*trace.items(), ("X-Repeat", "one"), ("X-Repeat", "two")]
        header_pairs.extend(
            [("Connection", "X-Remove"), ("X-Remove", "must-not-forward")]
        )
        expected.append((body, trace))
        response = request("POST", "/v1/chat/completions", body, header_pairs)
        assert_response(response, status=200, body=NONSTREAM_BODY)
        response_headers = response[2]
        response_repeats = [
            value
            for name, value in response_headers
            if name.lower() == "x-repeat-response"
        ]
        if response_repeats != ["one", "two"]:
            raise ProtocolError(
                f"duplicate response headers changed: {response_repeats!r}"
            )
        if any(
            name.lower() == "x-remove-response" for name, _ in response_headers
        ):
            raise ProtocolError("dynamic response hop header crossed gateway")
        record = next(
            item
            for item in STATE.snapshot()
            if item.get("body_sha256") == hashlib.sha256(body).hexdigest()
        )
        if record["repeat_values"] != ["one", "two"]:
            raise ProtocolError(
                f"duplicate request headers changed: {record['repeat_values']!r}"
            )
        if record["removed_header"] is not None:
            raise ProtocolError("dynamic request hop header crossed gateway")
        checks.append("duplicate_and_dynamic_hop_headers")

        body = chat_body("case-stream", stream=True)
        headers = tracing_headers(2)
        expected.append((body, headers))
        assert_response(
            request("POST", "/v1/chat/completions", body, headers),
            status=200,
            body=b"".join(STREAM_CHUNKS),
        )
        checks.append("sse_order_done_usage")

        for index, marker, status_code, response_body in (
            (3, "case-status-429", 429, b'{"error":{"type":"rate_limit","message":"mock 429"}}'),
            (4, "case-status-500", 500, b'{"error":{"type":"server_error","message":"mock 500"}}'),
        ):
            body = chat_body(marker)
            headers = tracing_headers(index)
            expected.append((body, headers))
            response = request("POST", "/v1/chat/completions", body, headers)
            assert_response(
                response,
                status=status_code,
                body=response_body,
                header=("Retry-After", "7") if status_code == 429 else None,
            )
        checks.append("status_429_500")

        malformed = b'{"model":"target-model","messages":['
        headers = tracing_headers(5)
        expected.append((malformed, headers))
        assert_response(
            request("POST", "/v1/chat/completions", malformed, headers),
            status=400,
            body=b'{"error":{"type":"invalid_json","message":"malformed"}}',
        )
        checks.append("malformed_body")

        body = chat_body("case-delay")
        headers = tracing_headers(6) | {"X-Large-Opaque": "h" * 7000}
        expected.append((body, headers))
        assert_response(
            request("POST", "/v1/chat/completions", body, headers, timeout=10),
            status=200,
            body=NONSTREAM_BODY,
        )
        checks.append("backend_delay_large_header")

        body = chat_body("case-large-body", padding="界" * 350_000)
        headers = tracing_headers(7)
        expected.append((body, headers))
        assert_response(
            request("POST", "/v1/chat/completions", body, headers, timeout=30),
            status=200,
            body=NONSTREAM_BODY,
        )
        checks.append("large_unicode_body")

        concurrent_inputs = []
        for index in range(20, 52):
            body = chat_body(f"case-concurrent-{index}")
            headers = tracing_headers(index)
            expected.append((body, headers))
            concurrent_inputs.append((body, headers))
        with concurrent.futures.ThreadPoolExecutor(max_workers=32) as pool:
            futures = [
                pool.submit(request, "POST", "/v1/chat/completions", body, headers, 30)
                for body, headers in concurrent_inputs
            ]
            for future in futures:
                assert_response(future.result(), status=200, body=NONSTREAM_BODY)
        checks.append("concurrent_32")

        if include_disconnect:
            preheader_body = chat_body("case-preheader-disconnect")
            preheader_headers = tracing_headers(89)
            connection = http.client.HTTPConnection("127.0.0.1", 9000, timeout=10)
            connection.request(
                "POST",
                "/v1/chat/completions",
                body=preheader_body,
                headers=preheader_headers,
            )
            digest = hashlib.sha256(preheader_body).hexdigest()
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                if any(
                    record.get("body_sha256") == digest
                    for record in STATE.snapshot()
                ):
                    break
                time.sleep(0.01)
            else:
                connection.close()
                raise ProtocolError("pre-header disconnect request never reached backend")
            expected.append((preheader_body, preheader_headers))
            connection.close()
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                matching = [
                    record
                    for record in STATE.snapshot()
                    if record.get("body_sha256") == digest
                ]
                if matching and matching[0]["client_disconnected"]:
                    break
                time.sleep(0.05)
            else:
                raise ProtocolError(
                    "pre-response-header disconnect was not propagated to backend"
                )
            checks.append("pre_header_disconnect")

            cancel_body = chat_body("case-disconnect", stream=True)
            cancel_headers = tracing_headers(90)
            connection = http.client.HTTPConnection("127.0.0.1", 9000, timeout=10)
            connection.request("POST", "/v1/chat/completions", body=cancel_body, headers=cancel_headers)
            response = connection.getresponse()
            if response.status != 200:
                raise ProtocolError(f"disconnect probe returned {response.status}")
            response.read(128)
            connection.close()
            deadline = time.monotonic() + 5
            cancelled = False
            while time.monotonic() < deadline:
                matching = [
                    record
                    for record in STATE.snapshot()
                    # The same ledger also contains the preceding GET
                    # /v1/models record, which intentionally has no body.
                    if record.get("body_sha256") == hashlib.sha256(cancel_body).hexdigest()
                ]
                if matching and matching[0]["client_disconnected"]:
                    cancelled = True
                    break
                time.sleep(0.05)
            if not cancelled:
                raise ProtocolError("active client disconnect was not propagated to the backend")
            checks.append("active_disconnect")

        verify_forwarded(expected)
        verify_models_forwarded(models_headers)
        checks.append("one_to_one_and_opaque_headers")
        return {
            "passed": True,
            "checks": checks,
            "expected_backend_requests": len(expected) + 1 + int(include_disconnect),
            "observed_backend_requests": len(STATE.snapshot()),
            "cancelled_backend_request_observed": include_disconnect,
        }
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
