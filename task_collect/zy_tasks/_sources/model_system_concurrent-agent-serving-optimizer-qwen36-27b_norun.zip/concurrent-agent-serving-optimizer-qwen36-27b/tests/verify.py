#!/usr/bin/env python3
"""Full shared verifier: isolation, protocol, real audit, and hidden pair score."""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import math
import os
import re
import signal
import socket
import stat
import subprocess
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any

from protocol_cases import run_protocol_cases
from verify_phase0 import (
    VerificationError,
    admin,
    check_isolation,
    clear_candidate_execution_root,
    freeze_submission,
    http,
    launch_gateway,
    submission_tree_sha256,
    validate_attestation,
    wait_gateway,
)


LIFECYCLE_ATTESTATION_CONTEXT = b"kvbench-final-candidate-lifecycle-v1\n"
BENCHMARK_AUTH_CONTEXT = b"kvbench-data-request-v2"
NETWORK_EGRESS_SEAL_SCHEMA_VERSION = 2
NETWORK_EGRESS_SEAL_PROTOCOL = "same-compose-main-egress-hmac-v2"
CANDIDATE_SHARED_OUTPUT_ROOTS = (
    Path("/logs/agent"),
    Path("/logs/artifacts"),
)
SANDBOX_CONTROL_SOCKET = Path("/run/kvbench-sandbox/control.sock")
MAX_SANDBOX_CONTROL_RESPONSE_BYTES = 256 * 1024
MAX_CANDIDATE_HEALTH_RESPONSE_BYTES = 64 * 1024
CANDIDATE_HEALTH_TIMEOUT_SEC = 5
CANDIDATE_REFERENCE_TREE_FIELD = "reference_" + "gateway_tree_sha256_at_start"
CANDIDATE_HEALTH_STRING_FIELDS = (
    "status",
    "oracle",
    "thunderagent_source_commit",
    CANDIDATE_REFERENCE_TREE_FIELD,
)
CANDIDATE_SCHEDULER_STRING_FIELDS = (
    "algorithm",
    "queue_policy",
    "protected_request_policy",
    "deep_request_policy",
    "normal_restore_order",
    "deep_restore_order",
)
CANDIDATE_SCHEDULER_INTEGER_FIELDS = (
    "scheduler_policy_schema_version",
    "fair_service_until_step",
    "deep_request_first_step",
    "deep_pending_request_waiters_peak",
    "deep_pause_wait_count",
)
CANDIDATE_SCHEDULER_BOOLEAN_FIELDS = (
    "deep_reentry_bypasses_service_lag",
)
CANDIDATE_SCHEDULER_COUNTER_FIELDS = (
    "deep_request_offers",
    "deep_service_lag_bypass_decisions",
    "resume_deep_request",
    "deep_sjf_priority_ticks",
    "mixed_request_tier_ticks",
)
# Harbor gives the complete verifier 12.6 ks.  The measured hidden A/B pair
# gets one 9 ks monotonic budget, leaving an explicit 3.6 ks outside
# that clock for freezing, protocol checks, egress sealing, fail-closed
# teardown, and report/reward artifact writes.  The 9 ks value is never a
# per-leg timeout.
HARBOR_VERIFIER_WALL_BUDGET_SEC = 12_600.0
HIDDEN_PAIR_SUITE_TIMEOUT_SEC = 9_000.0
VERIFIER_FREEZE_PROTOCOL_CLEANUP_ARTIFACT_MARGIN_SEC = (
    HARBOR_VERIFIER_WALL_BUDGET_SEC - HIDDEN_PAIR_SUITE_TIMEOUT_SEC
)
VERIFIER_POST_PAIR_CLEANUP_ARTIFACT_MARGIN_SEC = 600.0
VERIFIER_PRE_PAIR_FREEZE_PROTOCOL_SEAL_MARGIN_SEC = (
    VERIFIER_FREEZE_PROTOCOL_CLEANUP_ARTIFACT_MARGIN_SEC
    - VERIFIER_POST_PAIR_CLEANUP_ARTIFACT_MARGIN_SEC
)


class CandidateSharedOutputRootSeal:
    """Temporarily make Harbor's shared output mounts opaque to UID 1000.

    Only the bind-mount roots are changed. Descendant metadata is deliberately
    untouched: candidate files may be hard-linked elsewhere, and recursively
    chowning them would mutate inodes outside the output tree. A root-owned 0500
    mount root blocks both traversal and creation after every old candidate
    process has been reaped.
    """

    def __init__(
        self,
        metadata: dict[Path, tuple[int, int, int] | None],
    ) -> None:
        self._metadata = metadata
        self._restored = False

    @classmethod
    def acquire(cls) -> "CandidateSharedOutputRootSeal":
        metadata: dict[Path, tuple[int, int, int] | None] = {}
        try:
            for root in CANDIDATE_SHARED_OUTPUT_ROOTS:
                try:
                    info = root.lstat()
                except FileNotFoundError:
                    root.mkdir(mode=0o700, parents=True, exist_ok=False)
                    os.chown(root, 0, 0)
                    os.chmod(root, 0o500)
                    metadata[root] = None
                    continue
                if root.is_symlink() or not stat.S_ISDIR(info.st_mode):
                    raise VerificationError(
                        f"candidate shared output root is not a real directory: {root}"
                    )
                metadata[root] = (
                    info.st_uid,
                    info.st_gid,
                    stat.S_IMODE(info.st_mode),
                )
                # CHOWN must precede chmod because the shared verifier keeps a
                # narrow capability set and intentionally lacks CAP_FOWNER.
                os.chown(root, 0, 0)
                os.chmod(root, 0o500)
            seal = cls(metadata)
            seal.attest()
            return seal
        except Exception:
            # No candidate process is alive when acquire() is called. Restore
            # every root already touched so an infrastructure error does not
            # strand otherwise public Harbor outputs.
            for root, original in reversed(tuple(metadata.items())):
                try:
                    if original is None:
                        root.rmdir()
                    else:
                        uid, gid, mode = original
                        os.chmod(root, mode)
                        os.chown(root, uid, gid)
                except OSError:
                    pass
            raise

    @staticmethod
    def _candidate_access_probe() -> None:
        probe = r'''
import errno
import os
import sys

roots = ("/logs/agent", "/logs/artifacts")
denied = {errno.EACCES, errno.EPERM}
for root in roots:
    try:
        descriptor = os.open(
            root,
            os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC,
        )
    except OSError as exc:
        if exc.errno not in denied:
            raise
    else:
        os.close(descriptor)
        sys.exit(10)

    candidate = os.path.join(root, ".kvbench-candidate-access-probe")
    try:
        descriptor = os.open(
            candidate,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC,
            0o600,
        )
    except OSError as exc:
        if exc.errno not in denied:
            raise
    else:
        os.close(descriptor)
        os.unlink(candidate)
        sys.exit(11)
'''
        try:
            completed = subprocess.run(
                [
                    "/usr/bin/setpriv",
                    "--reuid",
                    "candidate",
                    "--regid",
                    "candidate",
                    "--init-groups",
                    "--no-new-privs",
                    "/usr/bin/python3",
                    "-c",
                    probe,
                ],
                check=False,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise VerificationError(
                "candidate shared output root access probe failed"
            ) from exc
        if completed.returncode != 0:
            raise VerificationError(
                "candidate can read or write a sealed shared output root"
            )

    def attest(self) -> dict[str, Any]:
        if self._restored:
            raise VerificationError("candidate shared output roots were already restored")
        for root in CANDIDATE_SHARED_OUTPUT_ROOTS:
            info = root.lstat()
            if (
                not stat.S_ISDIR(info.st_mode)
                or info.st_uid != 0
                or info.st_gid != 0
                or stat.S_IMODE(info.st_mode) != 0o500
            ):
                raise VerificationError(
                    f"candidate shared output root seal changed unexpectedly: {root}"
                )
        self._candidate_access_probe()
        return {
            "candidate_shared_output_roots_sealed": True,
            "candidate_shared_output_roots_candidate_accessible": [],
        }

    def restore(self) -> None:
        if self._restored:
            return
        live = candidate_pids()
        if live:
            raise VerificationError(
                f"refusing to restore candidate shared output roots with live processes: {live}"
            )
        failures: list[str] = []
        for root, original in reversed(tuple(self._metadata.items())):
            try:
                if original is None:
                    root.rmdir()
                else:
                    uid, gid, mode = original
                    # Restore mode while root still owns the directory; this
                    # container intentionally does not grant CAP_FOWNER.
                    os.chmod(root, mode)
                    os.chown(root, uid, gid)
            except OSError as exc:
                failures.append(f"{root}:{type(exc).__name__}:{exc}")
        if failures:
            raise VerificationError(
                "could not restore candidate shared output roots: " + ";".join(failures)
            )
        self._restored = True


def signed_benchmark_auth(
    token: str,
    *,
    audit_epoch: int,
    method: str,
    path: str,
    request_id: str,
    run_id: str,
    profile: str,
    leg_id: str,
    cache_namespace: str,
    body_digest: str,
) -> str:
    canonical = json.dumps(
        {
            "audit_epoch": audit_epoch,
            "body_digest": body_digest,
            "cache_namespace": cache_namespace,
            "leg_id": leg_id,
            "method": method.upper(),
            "path": path,
            "profile": profile,
            "request_id": request_id,
            "run_id": run_id,
        },
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hmac.new(
        token.encode(),
        BENCHMARK_AUTH_CONTEXT + b"\n" + canonical,
        hashlib.sha256,
    ).hexdigest()


def validate_trusted_final_report(final_report: dict[str, Any]) -> dict[str, float]:
    """Map only the controller's typed terminal status into reward dimensions."""

    if final_report.get("schema_version") != 2:
        raise VerificationError("trusted final report has an invalid schema")
    status = final_report.get("status")
    if status not in {"ok", "candidate_failed", "infra_invalid"}:
        raise VerificationError(f"trusted final report has an invalid status: {status!r}")
    infra_failures = final_report.get("infra_failures")
    candidate_failures = final_report.get("candidate_failures")
    hard_gates = final_report.get("hard_gates_passed")
    reward = final_report.get("reward")
    if (
        not isinstance(infra_failures, list)
        or not isinstance(candidate_failures, list)
        or not isinstance(hard_gates, bool)
        or isinstance(reward, bool)
        or not isinstance(reward, (int, float))
        or not math.isfinite(float(reward))
        or not 0 <= float(reward) <= 1
    ):
        raise VerificationError("trusted final report has malformed score fields")
    if status == "ok":
        valid = hard_gates and not infra_failures and not candidate_failures and float(reward) > 0
    elif status == "candidate_failed":
        valid = (
            not hard_gates
            and not infra_failures
            and bool(candidate_failures)
            and float(reward) == 0.0
        )
    else:
        valid = (
            not hard_gates
            and bool(infra_failures)
            and not candidate_failures
            and float(reward) == 0.0
        )
    if not valid:
        raise VerificationError(
            f"trusted final report status/score fields disagree: {status}"
        )
    return {
        "reward": float(reward),
        "backend_audit": 1.0 if hard_gates else 0.0,
        "infra_valid": 0.0 if status == "infra_invalid" else 1.0,
    }


def public_benchmark_result(benchmark: dict[str, Any]) -> dict[str, Any]:
    """Expose typed final status without publishing held-out configuration."""

    summary = {
        key: benchmark.get(key)
        for key in (
            "schema_version",
            "release_id",
            "status",
            "hard_gates_passed",
            "reward",
        )
    }
    summary["infra_failure_count"] = len(benchmark.get("infra_failures") or [])
    summary["candidate_failure_count"] = len(
        benchmark.get("candidate_failures") or []
    )
    attribution = benchmark.get("failure_attribution")
    if isinstance(attribution, dict):
        # The trusted controller calls the wire field ``type``.  Project it to
        # the candidate-facing ``failure_type`` name, but only for the finite
        # set of coarse controller failures that contain no profile, corpus,
        # threshold, leg, or raw exception detail.
        failure_type = attribution.get("type", attribution.get("failure_type"))
        public_failure_types = {
            "admin_token_unavailable",
            "baseline_candidate_port_open",
            "baseline_runtime_failed",
            "candidate_gateway_exited",
            "candidate_gateway_unavailable",
            "candidate_health_protocol_failure",
            "candidate_runtime_failed",
            "controller_leg_mode_invalid",
            "model_api_unhealthy_during_candidate_leg",
            "model_control_plane_diagnostic_failed",
            "model_provenance_changed",
            "model_provenance_changed_across_final_session",
            "model_provenance_changed_during_candidate_leg",
            "model_provenance_postflight_failed",
            "model_provenance_preflight_failed",
            "model_provenance_preflight_mismatch",
            "trusted_controller_internal_failure",
        }
        public_attribution: dict[str, str] = {}
        if attribution.get("authority") == "trusted-bench-controller":
            public_attribution["authority"] = "trusted-bench-controller"
        if attribution.get("classification") in {
            "candidate_failed",
            "infra_invalid",
        }:
            public_attribution["classification"] = attribution["classification"]
        if failure_type in public_failure_types:
            public_attribution["failure_type"] = failure_type
        if public_attribution:
            summary["failure_attribution"] = public_attribution
    return summary


def trusted_controller_image_id(final_report: dict[str, Any]) -> str:
    """Extract the controller image identity authenticated by the root worker."""

    lifecycle = final_report.get("candidate_lifecycle")
    seal = lifecycle.get("network_egress_seal") if isinstance(lifecycle, dict) else None
    image_id = seal.get("controller_image_id") if isinstance(seal, dict) else None
    if (
        not isinstance(seal, dict)
        or seal.get("schema_version") != NETWORK_EGRESS_SEAL_SCHEMA_VERSION
        or seal.get("protocol") != NETWORK_EGRESS_SEAL_PROTOCOL
        or seal.get("sealed") is not True
        or not isinstance(image_id, str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", image_id) is None
    ):
        raise VerificationError(
            "trusted final report lacks an authenticated controller image identity"
        )
    return image_id


def is_typed_terminal_failure_shape(final_report: Any) -> bool:
    """Recognize only the zero-score envelope allowed to end a pair early.

    This is an admission check, not trust validation.  The returned report is
    still passed to :func:`validate_trusted_final_report`, which validates its
    schema, failure lists, and status consistency before any reward is used.
    """

    if not isinstance(final_report, dict):
        return False
    reward = final_report.get("reward")
    return (
        final_report.get("status") in {"candidate_failed", "infra_invalid"}
        and final_report.get("hard_gates_passed") is False
        and isinstance(reward, (int, float))
        and not isinstance(reward, bool)
        and math.isfinite(float(reward))
        and float(reward) == 0.0
    )


def public_verifier_report(report: dict[str, Any]) -> dict[str, Any]:
    """Remove hidden profiles, trajectories, seeds, and raw failure details."""

    public = {
        key: report.get(key)
        for key in (
            "schema_version",
            "phase",
            "reward",
            "correctness",
            "backend_audit",
            "infra_valid",
            "classification_status",
        )
    }
    checks = report.get("checks")
    public_checks: dict[str, dict[str, Any]] = {}
    if isinstance(checks, dict):
        isolation = checks.get("isolation")
        if isinstance(isolation, dict):
            capabilities = isolation.get("candidate_capabilities")
            public_checks["isolation"] = {
                "passed": bool(
                    isolation.get("forbidden_paths_present") == []
                    and isolation.get("gpu_devices") == []
                    and isolation.get("candidate_can_read_admin_token") is False
                    and capabilities
                    == {
                        "permitted": "0000000000000000",
                        "effective": "0000000000000000",
                        "no_new_privs": "1",
                    }
                )
            }

        # The full attestation contains host paths, UDS/PID/container identity,
        # GPU UUIDs, launch-token hashes, and the vLLM command.  It is retained
        # only in the author-side private report; candidate output gets a coarse
        # validation status derived from non-identifying control fields.
        attestation = checks.get("attestation")
        if isinstance(attestation, dict):
            public_checks["attestation"] = {
                "passed": bool(
                    attestation.get("schema_version") == 1
                    and attestation.get("state") == "ready"
                    and attestation.get("preflight_status") == "ok"
                    and attestation.get("model_mount_read_only") is True
                )
            }

        initial_reset = checks.get("initial_candidate_reset")
        if isinstance(initial_reset, dict):
            public_checks["initial_candidate_reset"] = {
                "passed": bool(
                    initial_reset.get("port_closed_before_launch") is True
                    and initial_reset.get("runtime_state_scrubbed") is True
                    and initial_reset.get("prelaunch_candidate_pids") == []
                    and initial_reset.get("candidate_owned_runtime_entries") == []
                    and initial_reset.get("candidate_owned_ipc_objects") == []
                ),
                "port_closed_before_launch": (
                    initial_reset.get("port_closed_before_launch") is True
                ),
                "runtime_state_scrubbed": (
                    initial_reset.get("runtime_state_scrubbed") is True
                ),
            }

        shared_roots = checks.get("candidate_shared_output_roots")
        if isinstance(shared_roots, dict):
            public_checks["candidate_shared_output_roots"] = {
                "passed": bool(
                    shared_roots.get("candidate_shared_output_roots_sealed")
                    is True
                    and shared_roots.get(
                        "candidate_shared_output_roots_candidate_accessible"
                    )
                    == []
                ),
                "sealed": (
                    shared_roots.get("candidate_shared_output_roots_sealed")
                    is True
                ),
            }

        protocol = checks.get("protocol")
        if isinstance(protocol, dict):
            protocol_summary: dict[str, Any] = {
                "passed": protocol.get("passed") is True,
                "cancelled_backend_request_observed": (
                    protocol.get("cancelled_backend_request_observed") is True
                ),
            }
            for key in (
                "expected_backend_requests",
                "observed_backend_requests",
            ):
                value = protocol.get(key)
                if (
                    isinstance(value, int)
                    and not isinstance(value, bool)
                    and 0 <= value <= 1_000_000
                ):
                    protocol_summary[key] = value
            public_checks["protocol"] = protocol_summary

        real_protocol = checks.get("real_protocol_audit")
        if isinstance(real_protocol, dict):
            requests = real_protocol.get("requests")
            public_checks["real_protocol_audit"] = {
                "passed": real_protocol.get("passed") is True,
                "request_count": (
                    len(requests)
                    if isinstance(requests, list) and len(requests) <= 1_000_000
                    else None
                ),
            }
    public["checks"] = public_checks
    benchmark = report.get("benchmark")
    if isinstance(benchmark, dict):
        public["benchmark"] = public_benchmark_result(benchmark)
    error = report.get("error")
    if isinstance(error, str) and error:
        public["error_type"] = error.partition(":")[0]
    if report.get("cleanup_error") is not None:
        public["cleanup_failed"] = True
    return public


def public_reward(report: dict[str, Any]) -> dict[str, Any]:
    """Return scalar Harbor reward dimensions plus the measured hidden rates."""

    reward = {
        key: report[key]
        for key in ("reward", "correctness", "backend_audit", "infra_valid")
    }
    benchmark = report.get("benchmark")
    if isinstance(benchmark, dict):
        reward["hard_gates_passed"] = bool(benchmark.get("hard_gates_passed"))
        profiles = benchmark.get("profiles")
        if isinstance(profiles, dict) and len(profiles) == 1:
            profile = next(iter(profiles.values()))
            if isinstance(profile, dict):
                for reward_key, profile_key in (
                    ("baseline_valid_steps_per_min", "baseline_geomean"),
                    ("candidate_valid_steps_per_min", "candidate_geomean"),
                    ("speedup", "speedup"),
                    ("reference_speedup", "reference_speedup"),
                ):
                    value = profile.get(profile_key)
                    if (
                        isinstance(value, (int, float))
                        and not isinstance(value, bool)
                        and math.isfinite(float(value))
                    ):
                        reward[reward_key] = float(value)
    return reward


def compact_verifier_report(report: dict[str, Any]) -> dict[str, Any]:
    """Keep complete aggregate scoring data while dropping bulky raw series.

    The verifier runs after the last agent session, so this is a size policy,
    not a secrecy policy. Hidden profile names, rates, speedup, reference,
    gates, failure detail, provenance, and both aggregate legs remain present.
    """

    compact = dict(report)
    benchmark = report.get("benchmark")
    if not isinstance(benchmark, dict):
        compact["report_detail_policy"] = "aggregate-no-raw-workflow-series-v1"
        return compact

    compact_benchmark = dict(benchmark)
    raw_profiles = benchmark.get("profiles")
    if isinstance(raw_profiles, dict):
        compact_profiles: dict[str, Any] = {}
        for profile_name, raw_profile in raw_profiles.items():
            if not isinstance(raw_profile, dict):
                compact_profiles[str(profile_name)] = raw_profile
                continue
            profile = dict(raw_profile)
            raw_legs = raw_profile.get("legs")
            if isinstance(raw_legs, list):
                legs: list[Any] = []
                for raw_leg in raw_legs:
                    if not isinstance(raw_leg, dict):
                        legs.append(raw_leg)
                        continue
                    leg = dict(raw_leg)
                    omitted: dict[str, int] = {}
                    workflows = leg.pop("workflows", None)
                    if isinstance(workflows, (list, dict)):
                        omitted["workflows"] = len(workflows)
                    trajectories = leg.pop("step_token_trajectories", None)
                    if isinstance(trajectories, (list, dict)):
                        omitted["step_token_trajectories"] = len(trajectories)

                    raw_vllm = leg.get("vllm_metrics")
                    if isinstance(raw_vllm, dict):
                        vllm_metrics = dict(raw_vllm)
                        vllm_omitted: dict[str, int] = {}
                        for key in ("live_samples", "live_series"):
                            values = vllm_metrics.pop(key, None)
                            if isinstance(values, (list, dict)):
                                vllm_omitted[key] = len(values)
                        if vllm_omitted:
                            vllm_metrics["omitted_detail_counts"] = vllm_omitted
                        leg["vllm_metrics"] = vllm_metrics
                    if omitted:
                        leg["omitted_detail_counts"] = omitted
                    legs.append(leg)
                profile["legs"] = legs
            compact_profiles[str(profile_name)] = profile
        compact_benchmark["profiles"] = compact_profiles
    compact["benchmark"] = compact_benchmark
    compact["report_detail_policy"] = "aggregate-no-raw-workflow-series-v1"
    return compact


def candidate_pids() -> list[int]:
    completed = subprocess.run(
        ["pgrep", "-u", "candidate"],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    if completed.returncode not in {0, 1}:
        raise VerificationError(f"could not enumerate candidate processes: {completed.returncode}")
    return sorted(
        int(line)
        for line in completed.stdout.splitlines()
        if line.strip().isdigit()
    )


def _remove_entry(path: Path) -> None:
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        return
    if stat.S_ISDIR(mode) and not stat.S_ISLNK(mode):
        import shutil

        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def scrub_candidate_runtime_state() -> list[str]:
    """Delete state UID 1000 could carry between frozen gateway processes."""

    candidate_uid = 1000
    home = Path("/home/candidate")
    home.mkdir(mode=0o555, parents=True, exist_ok=True)
    for entry in list(home.iterdir()):
        _remove_entry(entry)

    # Candidate code has no writable application directory or network egress,
    # but the standard container scratch roots remain writable.  Walk them
    # recursively so a file hidden below an existing root-owned /tmp directory
    # cannot survive merely because its top-level parent is trusted-owned.
    scratch_roots = (
        Path("/tmp"),
        Path("/var/tmp"),
        Path("/dev/shm"),
        Path("/dev/mqueue"),
        Path("/run/lock"),
    )
    for root in scratch_roots:
        if not root.is_dir():
            continue
        entries = sorted(root.rglob("*"), key=lambda item: len(item.parts), reverse=True)
        for entry in entries:
            try:
                owned_by_candidate = entry.lstat().st_uid == candidate_uid
            except FileNotFoundError:
                continue
            if owned_by_candidate:
                _remove_entry(entry)

    os.chown(home, 0, 0)
    os.chmod(home, 0o555)
    remaining = []
    for root in (home, *scratch_roots):
        if not root.is_dir():
            continue
        for entry in root.rglob("*"):
            try:
                if entry.lstat().st_uid == candidate_uid:
                    remaining.append(str(entry))
            except FileNotFoundError:
                continue
    return sorted(remaining)


def candidate_sysv_ipc() -> list[tuple[str, str]]:
    objects: list[tuple[str, str]] = []
    for table, identifier_field, remove_flag in (
        (Path("/proc/sysvipc/shm"), "shmid", "-m"),
        (Path("/proc/sysvipc/msg"), "msqid", "-q"),
        (Path("/proc/sysvipc/sem"), "semid", "-s"),
    ):
        if not table.is_file():
            continue
        lines = table.read_text().splitlines()
        if not lines:
            continue
        header = lines[0].split()
        try:
            identifier_index = header.index(identifier_field)
            owner_indexes = [header.index(field) for field in ("uid", "cuid")]
        except ValueError as exc:
            raise VerificationError(f"unsupported SysV IPC table schema: {table}") from exc
        for line in lines[1:]:
            fields = line.split()
            if len(fields) < len(header):
                continue
            if any(fields[index] == "1000" for index in owner_indexes):
                objects.append((remove_flag, fields[identifier_index]))
    return sorted(objects)


def scrub_candidate_sysv_ipc() -> list[str]:
    deadline = time.monotonic() + 5
    while True:
        objects = candidate_sysv_ipc()
        if not objects:
            return []
        for remove_flag, identifier in objects:
            subprocess.run(
                [
                    "setpriv",
                    "--reuid",
                    "candidate",
                    "--regid",
                    "candidate",
                    "--init-groups",
                    "--no-new-privs",
                    "ipcrm",
                    remove_flag,
                    identifier,
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        if time.monotonic() >= deadline:
            return [f"{flag}:{identifier}" for flag, identifier in candidate_sysv_ipc()]
        time.sleep(0.05)


def wait_candidate_port_closed(timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", 9000), timeout=0.2):
                pass
        except OSError:
            return
        time.sleep(0.05)
    raise VerificationError("candidate port 9000 remained open after process reset")


def reset_candidate_runtime(process: subprocess.Popen[bytes] | None) -> dict[str, Any]:
    """Fail closed unless every UID-1000 process and writable artifact is gone."""

    observed = set(candidate_pids())
    if process is not None and process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + 10
    while True:
        # Reap the direct gateway parent as soon as SIGTERM/KILL lands. A
        # zombie still matches pgrep but cannot be killed, so deferring wait()
        # until after the loop would falsely report an immortal candidate.
        if process is not None:
            process.poll()
        live = candidate_pids()
        observed.update(live)
        if not live:
            break
        subprocess.run(
            ["pkill", "-KILL", "-u", "candidate"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if time.monotonic() >= deadline:
            raise VerificationError(f"candidate processes survived reset: {live}")
        time.sleep(0.05)
    if process is not None:
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired as exc:
            raise VerificationError("candidate gateway parent survived UID reset") from exc
    wait_candidate_port_closed()
    # The candidate can execute only this root-owned canonical copy. Verify its
    # post-run digest and remove it after every protocol/final candidate epoch.
    clear_candidate_execution_root()
    remaining = scrub_candidate_runtime_state()
    if remaining:
        raise VerificationError(f"candidate-owned runtime state survived reset: {remaining[:8]}")
    remaining_ipc = scrub_candidate_sysv_ipc()
    if remaining_ipc:
        raise VerificationError(f"candidate-owned SysV IPC survived reset: {remaining_ipc[:8]}")
    if candidate_pids():
        raise VerificationError("candidate process appeared while runtime state was scrubbed")
    return {
        "terminated_candidate_pids": sorted(observed),
        "prelaunch_candidate_pids": [],
        "port_closed_before_launch": True,
        "runtime_state_scrubbed": True,
        "candidate_owned_runtime_entries": [],
        "candidate_owned_ipc_objects": [],
    }


def terminate(process: subprocess.Popen[bytes] | None) -> None:
    reset_candidate_runtime(process)


def process_start_ticks(pid: int) -> int:
    raw = Path(f"/proc/{pid}/stat").read_text()
    fields_after_name = raw.rsplit(")", 1)[1].split()
    # /proc/<pid>/stat field 22, while this list begins at field 3.
    return int(fields_after_name[19])


def frozen_submission_sha256(submission: Path) -> str:
    # Keep this public name stable for author/release tooling while sharing the
    # exact digest implementation used for pre/post canonical runtime checks.
    return submission_tree_sha256(submission)


def lifecycle_attestation(
    *,
    token: str,
    session_id: str,
    leg_ordinal: int,
    mode: str,
    challenge: str,
    snapshot_sha256: str,
    reset_report: dict[str, Any],
    process: subprocess.Popen[bytes] | None,
) -> dict[str, Any]:
    gateway_pid: int | None = None
    gateway_start_ticks: int | None = None
    live_pids: list[int] = []
    gateway_healthy = False
    if mode == "candidate":
        if process is None or process.poll() is not None:
            raise VerificationError("fresh candidate gateway exited before lifecycle attestation")
        gateway_pid = process.pid
        gateway_start_ticks = process_start_ticks(process.pid)
        live_pids = candidate_pids()
        if gateway_pid not in live_pids:
            raise VerificationError("gateway process is absent from the fresh candidate UID epoch")
        gateway_healthy = True
    elif mode != "baseline":
        raise VerificationError(f"unexpected final leg mode: {mode}")
    elif candidate_pids():
        raise VerificationError("baseline leg would start while a candidate process is alive")

    attestation: dict[str, Any] = {
        "schema_version": 1,
        "session_id": session_id,
        "leg_ordinal": leg_ordinal,
        "mode": mode,
        "challenge": challenge,
        "epoch_nonce": uuid.uuid4().hex,
        "frozen_submission_sha256": snapshot_sha256,
        "gateway_pid": gateway_pid,
        "gateway_start_ticks": gateway_start_ticks,
        "candidate_pids": live_pids,
        "gateway_healthy_after_launch": gateway_healthy,
        **reset_report,
    }
    canonical = json.dumps(attestation, separators=(",", ":"), sort_keys=True).encode()
    attestation["signature"] = hmac.new(
        token.encode(), LIFECYCLE_ATTESTATION_CONTEXT + canonical, hashlib.sha256
    ).hexdigest()
    return attestation


def signed_real_protocol(backend: str, admin_base: str, token: str) -> dict[str, Any]:
    reset = admin("POST", admin_base, "/admin/measurement/reset", token)
    audit_epoch = int(reset["audit_epoch"])
    expected = []
    request_id = str(uuid.uuid4())
    run_id = "final-protocol-models"
    profile_token = uuid.uuid4().hex[:24]
    leg_token = uuid.uuid4().hex
    cache_namespace = uuid.uuid4().hex
    empty_digest = hashlib.sha256(b"").hexdigest()
    auth = signed_benchmark_auth(
        token,
        audit_epoch=audit_epoch,
        method="GET",
        path="/v1/models",
        request_id=request_id,
        run_id=run_id,
        profile=profile_token,
        leg_id=leg_token,
        cache_namespace=cache_namespace,
        body_digest=empty_digest,
    )
    headers = {
        "X-Agent-Run-ID": run_id,
        "X-KVBench-Request-ID": request_id,
        "X-KVBench-Auth": auth,
        "X-KVBench-Audit-Epoch": str(audit_epoch),
        "X-KVBench-Body-SHA256": empty_digest,
        "X-KVBench-Profile": profile_token,
        "X-KVBench-Leg": leg_token,
        "X-KVBench-Cache-Namespace": cache_namespace,
        "Authorization": "Bearer opaque-real-protocol-key",
    }
    status, response_body = http("GET", "http://127.0.0.1:9000/v1/models", headers=headers, timeout=60)
    if status != 200 or not json.loads(response_body).get("data"):
        raise VerificationError(f"real models request returned {status}: {response_body!r}")
    expected.append(
        {
            "audit_epoch": audit_epoch,
            "method": "GET",
            "request_id": request_id,
            "run_id": run_id,
            "profile": profile_token,
            "leg_id": leg_token,
            "cache_namespace": cache_namespace,
            "canonical_body_digest": empty_digest,
            "response_digest": hashlib.sha256(response_body).hexdigest(),
            "status": 200,
        }
    )
    for stream, prompt in ((False, "Reply with exactly NONSTREAM_OK."), (True, "Reply with exactly STREAM_OK.")):
        request_id = str(uuid.uuid4())
        run_id = f"final-protocol-{'stream' if stream else 'nonstream'}"
        profile_token = uuid.uuid4().hex[:24]
        leg_token = uuid.uuid4().hex
        cache_namespace = uuid.uuid4().hex
        payload = json.dumps(
            {
                "model": "target-model",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0,
                "seed": 8801 + int(stream),
                "max_tokens": 32,
                "stream": stream,
                **({"stream_options": {"include_usage": True}} if stream else {}),
            },
            separators=(",", ":"),
        ).encode()
        body_digest = hashlib.sha256(payload).hexdigest()
        auth = signed_benchmark_auth(
            token,
            audit_epoch=audit_epoch,
            method="POST",
            path="/v1/chat/completions",
            request_id=request_id,
            run_id=run_id,
            profile=profile_token,
            leg_id=leg_token,
            cache_namespace=cache_namespace,
            body_digest=body_digest,
        )
        headers = {
            "Content-Type": "application/json",
            "X-Agent-Run-ID": run_id,
            "X-KVBench-Request-ID": request_id,
            "X-KVBench-Auth": auth,
            "X-KVBench-Audit-Epoch": str(audit_epoch),
            "X-KVBench-Body-SHA256": body_digest,
            "X-KVBench-Profile": profile_token,
            "X-KVBench-Leg": leg_token,
            "X-KVBench-Cache-Namespace": cache_namespace,
        }
        status, response_body = http(
            "POST", f"http://127.0.0.1:9000/v1/chat/completions", payload, headers, timeout=600
        )
        if status != 200:
            raise VerificationError(f"real {'stream' if stream else 'non-stream'} request returned {status}")
        if stream and b"data: [DONE]" not in response_body:
            raise VerificationError("real SSE response omitted [DONE]")
        if not stream:
            parsed = json.loads(response_body)
            if not parsed.get("choices"):
                raise VerificationError("real non-stream response has no choices")
        expected.append(
            {
                "audit_epoch": audit_epoch,
                "method": "POST",
                "request_id": request_id,
                "run_id": run_id,
                "profile": profile_token,
                "leg_id": leg_token,
                "cache_namespace": cache_namespace,
                "canonical_body_digest": body_digest,
                "response_digest": hashlib.sha256(response_body).hexdigest(),
                "status": 200,
            }
        )
    snapshot = admin("GET", admin_base, "/admin/audit/snapshot", token)
    records = {record.get("request_id"): record for record in snapshot.get("records", [])}
    if len(records) != len(expected):
        raise VerificationError(f"real protocol audit count mismatch: {len(records)} != {len(expected)}")
    for item in expected:
        record = records.get(item["request_id"])
        if record is None or record.get("benchmark_auth_valid") is not True:
            raise VerificationError("real protocol audit authentication failed")
        for key, value in item.items():
            if record.get(key) != value:
                raise VerificationError(f"real protocol audit mismatch for {key}")
    return {"passed": True, "requests": expected}


def controller_post(
    base: str,
    path: str,
    token: str,
    timeout: float,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    encoded = json.dumps(payload or {}, separators=(",", ":"), sort_keys=True).encode()
    request = urllib.request.Request(
        f"{base.rstrip('/')}{path}",
        data=encoded,
        method="POST",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        raise VerificationError(f"controller {path} returned {exc.code}: {exc.read()!r}") from exc


def hidden_suite_remaining_timeout(
    deadline_monotonic: float,
    *,
    stage: str,
) -> float:
    """Return the one suite clock's remaining time or fail closed.

    A fresh timeout must be derived immediately before every controller leg;
    otherwise both calls could each receive the complete 9 ks allowance.
    The post-call checks also make a response arriving after the monotonic
    deadline unusable even if the HTTP implementation returns it.
    """

    if not math.isfinite(deadline_monotonic):
        raise VerificationError("hidden pair suite has an invalid monotonic deadline")
    remaining = deadline_monotonic - time.monotonic()
    if not math.isfinite(remaining) or remaining <= 0:
        raise VerificationError(
            f"hidden pair suite monotonic deadline exhausted at {stage}"
        )
    return remaining


def sanitize_candidate_health(payload: Any) -> dict[str, Any]:
    """Select only bounded Oracle-policy scalars from candidate-controlled JSON.

    The held-out verifier records this private observation for author-side
    qualification, but it is not a correctness requirement for ordinary
    submissions.  In particular, arbitrary candidate health fields, prompts,
    scheduler program identifiers, and error strings are never persisted.
    """

    if not isinstance(payload, dict):
        return {}
    selected: dict[str, Any] = {}
    for key in CANDIDATE_HEALTH_STRING_FIELDS:
        value = payload.get(key)
        if isinstance(value, str) and len(value.encode("utf-8")) <= 256:
            selected[key] = value

    scheduler = payload.get("scheduler")
    if not isinstance(scheduler, dict):
        return selected
    selected_scheduler: dict[str, Any] = {}
    for key in CANDIDATE_SCHEDULER_STRING_FIELDS:
        value = scheduler.get(key)
        if isinstance(value, str) and len(value.encode("utf-8")) <= 512:
            selected_scheduler[key] = value
    for key in CANDIDATE_SCHEDULER_INTEGER_FIELDS:
        value = scheduler.get(key)
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            selected_scheduler[key] = value
    for key in CANDIDATE_SCHEDULER_BOOLEAN_FIELDS:
        value = scheduler.get(key)
        if isinstance(value, bool):
            selected_scheduler[key] = value

    counters = scheduler.get("counters")
    if isinstance(counters, dict):
        selected_counters = {
            key: counters[key]
            for key in CANDIDATE_SCHEDULER_COUNTER_FIELDS
            if isinstance(counters.get(key), int)
            and not isinstance(counters.get(key), bool)
            and counters[key] >= 0
        }
        if selected_counters:
            selected_scheduler["counters"] = selected_counters
    if selected_scheduler:
        selected["scheduler"] = selected_scheduler
    return selected


def observe_candidate_post_leg_health(
    leg_ordinal: int,
    *,
    timeout_sec: float = CANDIDATE_HEALTH_TIMEOUT_SEC,
) -> dict[str, Any]:
    """Read one bounded health snapshot while the just-finished B is alive.

    Capture errors are deliberately represented as small typed states rather
    than failing an otherwise valid candidate.  Formal Oracle evidence fails
    closed later unless the one candidate observation contains the exact v5
    contract.
    """

    observation: dict[str, Any] = {
        "schema_version": 1,
        "leg_ordinal": leg_ordinal,
        "capture_status": "unavailable",
        "http_status": None,
        "response_bytes": 0,
        "selected": {},
    }
    request = urllib.request.Request(
        "http://127.0.0.1:9000/health",
        method="GET",
        headers={"Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_sec) as response:
            observation["http_status"] = response.status
            declared = response.headers.get("Content-Length")
            if declared is not None:
                try:
                    if int(declared) > MAX_CANDIDATE_HEALTH_RESPONSE_BYTES:
                        observation["capture_status"] = "response_too_large"
                        return observation
                except ValueError:
                    observation["capture_status"] = "invalid_content_length"
                    return observation
            raw = response.read(MAX_CANDIDATE_HEALTH_RESPONSE_BYTES + 1)
    except urllib.error.HTTPError as exc:
        observation["http_status"] = exc.code
        observation["capture_status"] = "http_error"
        return observation
    except (OSError, socket.timeout):
        return observation

    observation["response_bytes"] = len(raw)
    if len(raw) > MAX_CANDIDATE_HEALTH_RESPONSE_BYTES:
        observation["capture_status"] = "response_too_large"
        return observation
    try:
        decoded = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError):
        observation["capture_status"] = "invalid_json"
        return observation
    if not isinstance(decoded, dict):
        observation["capture_status"] = "invalid_shape"
        return observation
    observation["capture_status"] = "ok"
    observation["selected"] = sanitize_candidate_health(decoded)
    return observation


def sandbox_worker_rpc(payload: dict[str, Any], *, timeout: int = 90) -> dict[str, Any]:
    """Call the root-owned sandbox worker over the verifier-only Unix socket."""

    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode() + b"\n"
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.settimeout(timeout)
    response = bytearray()
    try:
        client.connect(str(SANDBOX_CONTROL_SOCKET))
        client.sendall(encoded)
        client.shutdown(socket.SHUT_WR)
        while True:
            chunk = client.recv(65536)
            if not chunk:
                break
            response.extend(chunk)
            if len(response) > MAX_SANDBOX_CONTROL_RESPONSE_BYTES:
                raise VerificationError("sandbox worker response exceeded the verifier limit")
    except (OSError, socket.timeout) as exc:
        raise VerificationError("sandbox worker control RPC failed") from exc
    finally:
        client.close()
    try:
        decoded = json.loads(response)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise VerificationError("sandbox worker returned an invalid control response") from exc
    if not isinstance(decoded, dict):
        raise VerificationError("sandbox worker returned a non-object control response")
    if "protocol_error" in decoded:
        raise VerificationError("sandbox worker rejected the network-egress seal request")
    return decoded


def seal_main_network_egress(
    controller_base: str,
    token: str,
) -> dict[str, Any]:
    """Obtain one-use evidence that main has only the internal front network."""

    issued = controller_post(
        controller_base,
        "/admin/final/network-seal/challenge",
        token,
        timeout=30,
    )
    challenge = issued.get("challenge")
    if (
        issued.get("schema_version") != 1
        or isinstance(issued.get("schema_version"), bool)
        or not isinstance(challenge, str)
        or len(challenge) != 64
        or any(character not in "0123456789abcdef" for character in challenge)
    ):
        raise VerificationError("trusted controller returned an invalid network-seal challenge")
    evidence = sandbox_worker_rpc(
        {
            "action": "seal_main_egress",
            "schema_version": 2,
            "challenge": challenge,
        }
    )
    # The controller performs the authoritative HMAC, freshness, topology,
    # Compose-identity, and replay checks. Keep the verifier-side schema check
    # small but fail closed before sending malformed worker output over HTTP.
    expected_fields = {
        "schema_version",
        "action",
        "challenge",
        "attestation_nonce",
        "attested_unix_ns",
        "worker",
        "target",
        "controller",
        "topology",
        "signature",
    }
    if set(evidence) != expected_fields or evidence.get("challenge") != challenge:
        raise VerificationError("sandbox worker returned malformed network-seal evidence")
    return evidence


def run_isolated_final_session(
    *,
    controller_base: str,
    token: str,
    frozen_submission: Path,
    backend: str,
    suite_timeout_sec: float,
    verifier_deadline_monotonic: float,
    shared_output_seal: CandidateSharedOutputRootSeal,
    candidate_post_leg_observations: dict[str, Any],
) -> dict[str, Any]:
    """Drive one hidden baseline/candidate pair under one suite deadline.

    One-time reset and network sealing happen before the measured suite clock.
    The clock starts immediately before the trusted session is created and is
    shared by exactly one baseline and one candidate leg. The trusted
    controller chooses either A/B or B/A and the verifier follows each signed
    ``next_leg`` challenge without assuming the order. The deadline is capped
    early enough to
    retain the hard 600-second post-suite cleanup/artifact reserve. Earlier
    freeze/protocol/seal work normally fits the other 3 ks; if it does not,
    the hidden deadline is shortened instead of overrunning Harbor's verifier
    clock.
    """

    if candidate_post_leg_observations:
        raise VerificationError("candidate post-leg observations were not empty at pair start")
    snapshot_sha256 = frozen_submission_sha256(frozen_submission)
    # The interactive agent and every protocol gateway are gone before this
    # one-way transition. From this point through all held-out legs, main keeps
    # only its internal Compose front network. The root worker signs the Docker
    # topology against a fresh controller challenge; the controller validates
    # that evidence before it creates any hidden session state.
    reset_candidate_runtime(None)
    shared_output_seal.attest()
    network_egress_attestation = seal_main_network_egress(controller_base, token)
    if (
        not math.isfinite(suite_timeout_sec)
        or suite_timeout_sec <= 0
        or suite_timeout_sec > HIDDEN_PAIR_SUITE_TIMEOUT_SEC
    ):
        raise VerificationError("hidden pair suite timeout is invalid")
    if not math.isfinite(verifier_deadline_monotonic):
        raise VerificationError("complete verifier has an invalid monotonic deadline")
    suite_deadline_monotonic = min(
        time.monotonic() + suite_timeout_sec,
        verifier_deadline_monotonic
        - VERIFIER_POST_PAIR_CLEANUP_ARTIFACT_MARGIN_SEC,
    )
    begin = controller_post(
        controller_base,
        "/admin/final/session/begin",
        token,
        timeout=min(
            30.0,
            hidden_suite_remaining_timeout(
                suite_deadline_monotonic,
                stage="session-begin",
            ),
        ),
        payload={
            "frozen_submission_sha256": snapshot_sha256,
            "network_egress_attestation": network_egress_attestation,
        },
    )
    session_id = begin.get("session_id")
    next_leg = begin.get("next_leg")
    if not isinstance(session_id, str) or len(session_id) < 32 or not isinstance(next_leg, dict):
        raise VerificationError("trusted controller returned an invalid final-session plan")

    process: subprocess.Popen[bytes] | None = None
    completed = False
    completed_modes: list[str] = []
    completed_ordinals: list[int] = []
    try:
        while True:
            mode = next_leg.get("mode")
            challenge = next_leg.get("challenge")
            leg_ordinal = next_leg.get("leg_ordinal")
            if (
                mode not in {"baseline", "candidate"}
                or not isinstance(challenge, str)
                or len(challenge) < 32
                or not isinstance(leg_ordinal, int)
                or isinstance(leg_ordinal, bool)
                or leg_ordinal != len(completed_ordinals) + 1
                or leg_ordinal > 2
                or mode in completed_modes
            ):
                raise VerificationError("trusted controller returned an invalid next-leg challenge")

            hidden_suite_remaining_timeout(
                suite_deadline_monotonic,
                stage=f"before-leg-{leg_ordinal}-reset",
            )

            # This is intentionally done before *every* leg. It proves the
            # baseline runs without a gateway and gives the sole candidate leg
            # a fresh process, filesystem, and listening-socket epoch.
            reset_report = reset_candidate_runtime(process)
            process = None
            reset_report.update(shared_output_seal.attest())
            hidden_suite_remaining_timeout(
                suite_deadline_monotonic,
                stage=f"after-leg-{leg_ordinal}-reset",
            )
            if mode == "candidate":
                process = launch_gateway(
                    frozen_submission,
                    backend,
                    # Hidden prompts are necessarily visible to the gateway,
                    # but must never be persisted through its inherited file
                    # descriptors into Harbor verifier artifacts.
                    log_name=None,
                )
                wait_gateway(process)
                hidden_suite_remaining_timeout(
                    suite_deadline_monotonic,
                    stage=f"after-leg-{leg_ordinal}-gateway-start",
                )
            evidence = lifecycle_attestation(
                token=token,
                session_id=session_id,
                leg_ordinal=leg_ordinal,
                mode=mode,
                challenge=challenge,
                snapshot_sha256=snapshot_sha256,
                reset_report=reset_report,
                process=process,
            )
            response = controller_post(
                controller_base,
                "/admin/final/session/leg",
                token,
                timeout=hidden_suite_remaining_timeout(
                    suite_deadline_monotonic,
                    stage=f"leg-{leg_ordinal}-controller-call",
                ),
                payload={"session_id": session_id, "lifecycle_attestation": evidence},
            )
            hidden_suite_remaining_timeout(
                suite_deadline_monotonic,
                stage=f"after-leg-{leg_ordinal}-controller-call",
            )
            completed_modes.append(mode)
            completed_ordinals.append(leg_ordinal)
            typed_terminal_failure = (
                response.get("done") is True
                and is_typed_terminal_failure_shape(response.get("report"))
            )
            early_typed_terminal_failure = (
                typed_terminal_failure and len(completed_ordinals) < 2
            )
            if mode == "candidate":
                # The controller call returns only after this measured leg
                # has terminated.  Capture the persistent scheduler counters
                # and immediately reap the gateway so no candidate process can
                # survive between formal legs or after the suite.
                # A typed failure may terminate on the first candidate leg;
                # do not make a diagnostic health endpoint a prerequisite for
                # preserving that trusted zero-reward attribution.
                if not early_typed_terminal_failure:
                    health_timeout = min(
                        float(CANDIDATE_HEALTH_TIMEOUT_SEC),
                        hidden_suite_remaining_timeout(
                            suite_deadline_monotonic,
                            stage=f"before-leg-{leg_ordinal}-health-observation",
                        ),
                    )
                    candidate_post_leg_observations[str(leg_ordinal)] = (
                        observe_candidate_post_leg_health(
                            leg_ordinal,
                            timeout_sec=health_timeout,
                        )
                    )
                    hidden_suite_remaining_timeout(
                        suite_deadline_monotonic,
                        stage=f"after-leg-{leg_ordinal}-health-observation",
                    )
                reset_candidate_runtime(process)
                process = None
                hidden_suite_remaining_timeout(
                    suite_deadline_monotonic,
                    stage=f"after-leg-{leg_ordinal}-candidate-reset",
                )
            if response.get("done") is True:
                if response.get("next_leg") is not None:
                    raise VerificationError(
                        "trusted controller returned a next leg after completing the pair"
                    )
                report = response.get("report")
                if typed_terminal_failure:
                    # Candidate/infra failure can make a second measurement
                    # meaningless or impossible. Preserve the controller's
                    # typed zero-score report; the downstream trusted-report
                    # validator remains authoritative for its full schema.
                    completed = True
                    return report
                if completed_ordinals != [1, 2] or sorted(completed_modes) != [
                    "baseline",
                    "candidate",
                ]:
                    raise VerificationError(
                        "trusted controller did not complete exactly one baseline/candidate pair"
                    )
                if len(candidate_post_leg_observations) != 1:
                    raise VerificationError(
                        "formal pair did not capture exactly one candidate observation"
                    )
                if not isinstance(report, dict):
                    raise VerificationError("trusted controller omitted the final report")
                completed = True
                return report
            if response.get("done") is not False:
                raise VerificationError("trusted controller returned an invalid pair completion flag")
            if len(completed_ordinals) >= 2:
                raise VerificationError("trusted controller requested more than two final legs")
            next_leg = response.get("next_leg")
            if not isinstance(next_leg, dict):
                raise VerificationError("trusted controller omitted the next final leg")
    finally:
        # A detached child or a gateway that ignores SIGTERM must not outlive
        # either a successful final or a controller/verifier failure.
        try:
            reset_candidate_runtime(process)
        finally:
            if not completed:
                try:
                    controller_post(
                        controller_base,
                        "/admin/final/session/abort",
                        token,
                        timeout=30,
                        payload={"session_id": session_id},
                    )
                except Exception:
                    # Preserve the original verifier exception. The controller
                    # keeps an un-aborted session fail-closed until recreation.
                    pass


def main() -> int:
    verifier_started_monotonic = time.monotonic()
    verifier_deadline_monotonic = (
        verifier_started_monotonic + HARBOR_VERIFIER_WALL_BUDGET_SEC
    )
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission", type=Path, required=True)
    parser.add_argument("--backend", required=True)
    parser.add_argument("--admin-base", required=True)
    parser.add_argument("--bench-controller", required=True)
    parser.add_argument("--admin-token-file", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--summary-json", type=Path, required=True)
    parser.add_argument("--summary-md", type=Path, required=True)
    parser.add_argument("--reward-json", type=Path, required=True)
    parser.add_argument("--reward-txt", type=Path, required=True)
    args = parser.parse_args()

    report: dict[str, Any] = {"schema_version": 1, "phase": "final", "checks": {}}
    process: subprocess.Popen[bytes] | None = None
    shared_output_seal: CandidateSharedOutputRootSeal | None = None
    deterministic_correctness_passed = False
    try:
        report["checks"]["isolation"] = check_isolation(args.admin_token_file)
        token = args.admin_token_file.read_text().strip()
        status, health_body = http("GET", f"{args.admin_base}/health", timeout=10)
        if status != 200:
            raise VerificationError(f"model API died with the agent: {status} {health_body!r}")
        attestation = admin("GET", args.admin_base, "/admin/attestation", token)
        validate_attestation(attestation)
        report["checks"]["attestation"] = attestation

        frozen = freeze_submission(args.submission)
        # test.sh has already killed the interactive agent. Perform the full
        # PID/socket/scratch/IPC reset before making Harbor's two candidate-
        # writable output bind roots opaque for the entire verifier lifetime.
        report["checks"]["initial_candidate_reset"] = reset_candidate_runtime(None)
        shared_output_seal = CandidateSharedOutputRootSeal.acquire()
        report["checks"]["candidate_shared_output_roots"] = (
            shared_output_seal.attest()
        )
        process = launch_gateway(
            frozen,
            "http://127.0.0.1:18080/v1",
            log_name="gateway-protocol-mock.log",
        )
        wait_gateway(process)
        report["checks"]["protocol"] = run_protocol_cases()
        terminate(process)
        process = None

        process = launch_gateway(frozen, args.backend, log_name="gateway-real-protocol.log")
        wait_gateway(process)
        report["checks"]["real_protocol_audit"] = signed_real_protocol(args.backend, args.admin_base, token)
        terminate(process)
        process = None
        deterministic_correctness_passed = True
        final_report = run_isolated_final_session(
            controller_base=args.bench_controller,
            token=token,
            frozen_submission=frozen,
            backend=args.backend,
            # A qualified 192x24 hidden pair takes about 6.3 ks on the frozen
            # TP2 backend. This is one monotonic 9 ks A/B-or-B/A deadline, not
            # two 9 ks leg timeouts. The complete verifier's remaining 3.6
            # ks is reserved for freeze/protocol/seal work, teardown, and
            # report/reward artifact writes.
            suite_timeout_sec=HIDDEN_PAIR_SUITE_TIMEOUT_SEC,
            verifier_deadline_monotonic=verifier_deadline_monotonic,
            shared_output_seal=shared_output_seal,
            candidate_post_leg_observations=report["checks"].setdefault(
                "candidate_post_leg_health",
                {"schema_version": 1, "observations": {}},
            )["observations"],
        )
        report["benchmark"] = final_report
        report["artifacts"] = {
            "bench_controller_image_id": trusted_controller_image_id(final_report)
        }
        trusted_score = validate_trusted_final_report(final_report)
        report["reward"] = trusted_score["reward"]
        report["correctness"] = 1.0
        report["backend_audit"] = trusted_score["backend_audit"]
        report["infra_valid"] = trusted_score["infra_valid"]
        report["classification_status"] = final_report["status"]
    except Exception as exc:
        report["reward"] = 0.0
        # Once isolation, mock protocol cases, and the signed real-backend
        # audit have passed, a workload/controller failure is not evidence that
        # API correctness suddenly became zero. Keep the dimensions separate
        # so dirty queues or other measurement infrastructure cannot be
        # misreported as broad candidate incorrectness.
        report["correctness"] = 1.0 if deterministic_correctness_passed else 0.0
        report["backend_audit"] = 0.0
        # Without a typed report from the trusted controller, do not infer
        # candidate-vs-infrastructure attribution from exception text.
        report["infra_valid"] = 0.0
        report["classification_status"] = "unclassified_verifier_failure"
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        cleanup_errors: list[str] = []
        try:
            terminate(process)
        except Exception as cleanup_exc:
            cleanup_errors.append(f"{type(cleanup_exc).__name__}: {cleanup_exc}")
        if shared_output_seal is not None:
            try:
                shared_output_seal.restore()
            except Exception as cleanup_exc:
                cleanup_errors.append(f"{type(cleanup_exc).__name__}: {cleanup_exc}")
        if cleanup_errors:
            report["reward"] = 0.0
            report["backend_audit"] = 0.0
            report["infra_valid"] = 0.0
            cleanup_error = "; ".join(cleanup_errors)
            report["cleanup_error"] = cleanup_error
            report.setdefault("error", f"candidate lifecycle cleanup failed: {cleanup_error}")

    # Verification runs only after the final agent session has terminated, so
    # no later Codex continuation can observe this artifact. Keep all hidden
    # aggregate values and failure detail, but omit repeated per-workflow and
    # per-second raw series from the canonical Harbor report.
    canonical_report = compact_verifier_report(report)
    args.report.write_text(json.dumps(canonical_report, indent=2, sort_keys=True) + "\n")
    benchmark = report.get("benchmark") if isinstance(report.get("benchmark"), dict) else {}
    raw_profiles = benchmark.get("profiles") if isinstance(benchmark, dict) else {}
    profiles: dict[str, Any] = {}
    if isinstance(raw_profiles, dict):
        for profile_name, raw_profile in sorted(raw_profiles.items()):
            if not isinstance(raw_profile, dict):
                continue
            profiles[str(profile_name)] = {
                "baseline_valid_steps_per_min": raw_profile.get("baseline_geomean"),
                "candidate_valid_steps_per_min": raw_profile.get("candidate_geomean"),
                "speedup": raw_profile.get("speedup"),
                "reference_speedup": raw_profile.get("reference_speedup"),
                "performance_score": raw_profile.get("performance_score"),
                "backend_work_ratio": raw_profile.get("backend_work_ratio"),
                "candidate_request_success": raw_profile.get("candidate_request_success"),
                "candidate_valid_step_ratio": raw_profile.get("candidate_valid_step_ratio"),
                "candidate_p99_gateway_wait_sec": raw_profile.get(
                    "candidate_p99_gateway_wait_sec"
                ),
                "leg_order": (
                    raw_profile.get("leg_order_commitment", {}).get("order")
                    if isinstance(raw_profile.get("leg_order_commitment"), dict)
                    else None
                ),
            }
    summary = {
        "schema_version": 1,
        "phase": report.get("phase"),
        "classification_status": report.get("classification_status"),
        "reward": report.get("reward"),
        "correctness": report.get("correctness"),
        "backend_audit": report.get("backend_audit"),
        "infra_valid": report.get("infra_valid"),
        "hard_gates_passed": benchmark.get("hard_gates_passed"),
        "tail_score": benchmark.get("tail_score"),
        "performance_score": benchmark.get("performance_score"),
        "profiles": profiles,
        "error": report.get("error"),
        "cleanup_error": report.get("cleanup_error"),
        "aggregate_report": "report.json",
    }
    args.summary_json.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    lines = [
        "# Final verifier summary",
        "",
        f"- Reward: `{summary['reward']}`",
        f"- Classification: `{summary['classification_status']}`",
        f"- Correctness: `{summary['correctness']}`",
        f"- Backend audit: `{summary['backend_audit']}`",
        f"- Infrastructure valid: `{summary['infra_valid']}`",
        f"- Hard gates passed: `{summary['hard_gates_passed']}`",
        f"- Performance score: `{summary['performance_score']}`",
    ]
    for profile_name, profile in profiles.items():
        lines.extend(
            [
                "",
                f"## {profile_name}",
                "",
                f"- Baseline valid steps/min: `{profile['baseline_valid_steps_per_min']}`",
                f"- Candidate valid steps/min: `{profile['candidate_valid_steps_per_min']}`",
                f"- Speedup: `{profile['speedup']}`",
                f"- Reference speedup: `{profile['reference_speedup']}`",
                f"- Backend-work ratio: `{profile['backend_work_ratio']}`",
                f"- Leg order: `{profile['leg_order']}`",
            ]
        )
    lines.extend(["", "Aggregate verifier data: `report.json`", ""])
    args.summary_md.write_text("\n".join(lines))
    reward = public_reward(report)
    args.reward_json.write_text(json.dumps(reward, sort_keys=True) + "\n")
    args.reward_txt.write_text(f"{report['reward']:.6f}\n")
    if report["reward"] <= 0:
        reason = report.get("classification_status") or report.get(
            "error_type", "verification_failed"
        )
        print(f"Full verifier failed: {reason}")
        return 1
    print(f"Full verifier completed with reward {report['reward']:.6f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
