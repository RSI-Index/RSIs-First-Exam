#!/usr/bin/env bash
set -euo pipefail

# Harbor uploads this deliberately generic four-file verifier bundle only after
# the agent phase.  Kill every interactive-phase candidate process before any
# other verifier work.  Author-only unit/mutation sources live outside
# ``tests/`` because the cap-dropped shared container cannot reliably chmod
# Harbor's uploaded directory.
pkill -KILL -u candidate 2>/dev/null || true

restore_verifier_log_root() {
  local original_status=$?
  local metadata=/run/kvbench-log-guard/verifier-root.meta
  local uid gid mode
  local restore_status=0

  # A verifier exception must not make a writable log mount visible to a
  # surviving hidden gateway. Reap UID 1000 again and fail closed if it cannot
  # be made quiescent.
  pkill -KILL -u candidate 2>/dev/null || true
  for _ in $(seq 1 100); do
    if ! pgrep -u candidate >/dev/null 2>&1; then
      break
    fi
    sleep 0.05
  done
  if pgrep -u candidate >/dev/null 2>&1; then
    echo "candidate process survived verifier exit" >&2
    restore_status=74
  elif ! read -r uid gid mode < "$metadata"; then
    echo "verifier log root metadata is unavailable" >&2
    restore_status=74
  elif [[ ! "$uid" =~ ^[0-9]+$ \
    || ! "$gid" =~ ^[0-9]+$ \
    || ! "$mode" =~ ^[0-7]{3,4}$ ]]; then
    echo "verifier log root metadata is invalid" >&2
    restore_status=74
  elif ! chmod "$mode" /logs/verifier || ! chown "$uid:$gid" /logs/verifier; then
    echo "could not restore verifier log root metadata" >&2
    restore_status=74
  fi

  trap - EXIT
  if ((original_status != 0)); then
    exit "$original_status"
  fi
  exit "$restore_status"
}
trap restore_verifier_log_root EXIT

install -d -o root -g root -m 0700 /logs/verifier
# Harbor bind-mounts /logs/verifier itself.  Removing that path fails with
# EBUSY (and, under set -e, aborts before any reward is written).  Clear only
# children while preserving Harbor's already-open stdout capture file.
find /logs/verifier -mindepth 1 -maxdepth 1 \
  ! -name test-stdout.txt -exec rm -rf -- {} +
echo 0 > /logs/verifier/reward.txt

python3 /tests/verify.py \
  --submission /app/submission \
  --backend http://127.0.0.1:8100/v1 \
  --admin-base http://127.0.0.1:8100 \
  --bench-controller http://bench-controller:7000 \
  --admin-token-file /run/kvbench-admin/token \
  --report /logs/verifier/report.json \
  --summary-json /logs/verifier/summary.json \
  --summary-md /logs/verifier/summary.md \
  --reward-json /logs/verifier/reward.json \
  --reward-txt /logs/verifier/reward.txt
