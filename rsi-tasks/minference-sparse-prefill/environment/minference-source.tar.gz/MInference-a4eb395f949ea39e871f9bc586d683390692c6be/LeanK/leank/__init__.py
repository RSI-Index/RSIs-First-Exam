# Copyright (c) 2025 Microsoft
# Licensed under The MIT License [see LICENSE for details]
